extends Control
## 开始界面：开始游戏、退出游戏

@onready var start_button: Button = $StartButton
@onready var quit_button: Button = $QuitButton

func _ready():
	start_button.pressed.connect(_on_start_pressed)
	quit_button.pressed.connect(_on_quit_pressed)

func _on_start_pressed():
	GlobalScenes.go_to_choose()

func _on_quit_pressed():
	get_tree().quit()
