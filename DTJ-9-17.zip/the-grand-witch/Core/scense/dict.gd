extends Control

@onready var button: Button = $Button


func _ready() -> void:
	button.pressed.connect(_on_pressed)

func _on_pressed() -> void:
	queue_free()
	get_viewport().set_input_as_handled()

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		queue_free()
		get_viewport().set_input_as_handled()
