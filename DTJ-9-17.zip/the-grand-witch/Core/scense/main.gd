extends Control
@onready var settings_button: Button = $Settings


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if settings_button:
			settings_button.pressed.emit()
			get_viewport().set_input_as_handled()
