extends Control

@onready var button: Button = $Button
@onready var button_2: Button = $Button2
@export var character: Generator_girl
@onready var character_vbox: VBoxContainer = $CharacterVBox
@onready var selected_label: Label = $SelectedLabel


func _ready():
	for btn in character_vbox.get_children():
		if btn is CharacterButton:
			btn.pressed.connect(_on_character_pressed.bind(btn))
	button.pressed.connect(start_pressed)
	button_2.pressed.connect(exit_pressed)

func start_pressed():
	if character == null:
		selected_label.text = "未选择角色"
	GlobalScenes.go_to_main()

func exit_pressed():
	GlobalScenes.go_to_start()

func _on_character_pressed(btn: CharacterButton):
	if btn.character == null:
		return
	GlobalPlayer.reset()
	GlobalPlayer.set_character(btn.character)
	selected_label.text = "已选择 " + btn.character.character_name
