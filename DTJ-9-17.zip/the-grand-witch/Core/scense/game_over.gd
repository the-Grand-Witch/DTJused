extends Control
## 游戏结束场景：清空所有数据，按任意键返回开始界面

func _ready():
	GlobalPlayer.reset()

	# 清空场景管理器记录
	GlobalScenes.last_scene_path = "res://scenes/main.tscn"


func _input(event: InputEvent):
	if event is InputEventKey and event.pressed:
		GlobalScenes.go_to_start()
	elif event is InputEventMouseButton and event.pressed:
		GlobalScenes.go_to_start()
