extends Control
## 状态图标显示：聚合相同图标的数值，统一尺寸和字体

@onready var icon_container: HBoxContainer = $IconContainer

# ==================== 可配置项 ====================
@export_group("图标尺寸")
## 图标大小
@export var icon_size: Vector2 = Vector2(64, 64)
## 图标之间的水平间距
@export var icon_spacing: int = 8

@export_group("数字样式")
## 数字字号
@export var font_size: int = 28
## 数字颜色
@export var font_color: Color = Color(1, 1, 1, 1)
## 数字描边颜色
@export var font_outline_color: Color = Color(0, 0, 0, 0.8)
## 数字描边粗细
@export var font_outline_size: int = 2

@export_group("数字位置")
## 数字距图标右边缘的距离
@export var count_margin_right: float = 4.0
## 数字距图标底边缘的距离
@export var count_margin_bottom: float = 2.0

# 系统状态 ID -> 图标路径
const SYSTEM_STATUS_ICONS := {
	"accessories_attack": "res://Assets/Textures/Icons/buffs/accessories_attack.png",
	"armor_per_turn": "res://Assets/Textures/Icons/buffs/armor_per_turn.png",
	"heal_per_turn": "res://Assets/Textures/Icons/buffs/heal_per_turn.png",
	"bian_layers": "res://Assets/Textures/Icons/buffs/bian_layers.png",
	"attack_bonus": "res://Assets/Textures/Icons/buffs/attack_bonus.png",
	"harmony": "res://Assets/Textures/Icons/buffs/WX_turn.png",
}

func _ready():
	icon_container.add_theme_constant_override("separation", icon_spacing)

## 显示状态图标
func update_display(statuses: Dictionary, ability_buffs: Array = []):
	var icon_counts := {}
	_collect_system_statuses(statuses, icon_counts)
	_collect_ability_buffs(ability_buffs, icon_counts)
	_clear_icons()
	_render_icons(icon_counts)

# ==================== 收集 ====================
func _collect_ability_buffs(ability_buffs: Array, icon_counts: Dictionary) -> void:
	for buff in ability_buffs:
		var texture = buff.get("icon")
		var count = buff.get("count", 0)
		if texture == null or count <= 0:
			continue
		_add_to_counts(icon_counts, texture, count)

func _collect_system_statuses(statuses: Dictionary, icon_counts: Dictionary) -> void:
	for key in statuses:
		var value = statuses[key]
		var count = 0
		var custom_icon: Texture2D = null

		if key is Generator_bookpage:
			if key.buff_icon:
				custom_icon = key.buff_icon
		elif key is BookmarkCard:
			for page in key.Generator_bookmark.pages:
				if page.buff_icon:
					custom_icon = page.buff_icon
					break

		if value is int:
			count = value
		elif value is Dictionary:
			count = value.get("count", 0)
			if value.has("icon"):
				custom_icon = value["icon"]
		else:
			continue

		if count <= 0:
			continue

		var texture = custom_icon if custom_icon else _get_icon_for_key(key)
		if texture == null:
			continue

		_add_to_counts(icon_counts, texture, count)

# ==================== 聚合 ====================
func _add_to_counts(icon_counts: Dictionary, texture: Texture2D, count: int) -> void:
	var icon_key = texture.resource_path
	if icon_key == "":
		icon_key = "tex_%d" % texture.get_instance_id()

	if icon_counts.has(icon_key):
		icon_counts[icon_key]["count"] += count
	else:
		icon_counts[icon_key] = {
			"texture": texture,
			"count": count,
		}

# ==================== 渲染 ====================
func _render_icons(icon_counts: Dictionary) -> void:
	for icon_key in icon_counts:
		var info = icon_counts[icon_key]
		_add_icon_with_count(info["texture"], info["count"])

func _clear_icons():
	for child in icon_container.get_children():
		child.queue_free()

func _get_icon_for_key(key) -> Texture2D:
	if key is Generator_bookpage:
		if key.buff_icon:
			return key.buff_icon
	elif key is BookmarkCard:
		for page in key.Generator_bookmark.pages:
			if page.buff_icon:
				return page.buff_icon
	elif key is String:
		if SYSTEM_STATUS_ICONS.has(key):
			return load(SYSTEM_STATUS_ICONS[key])
	return null

## 生成一个图标 + 右下角计数
func _add_icon_with_count(icon_texture: Texture2D, count: int) -> void:
	var icon_box = Control.new()
	icon_box.custom_minimum_size = icon_size
	icon_box.mouse_filter = Control.MOUSE_FILTER_IGNORE

	# 图标本体
	var texture_rect = TextureRect.new()
	texture_rect.texture = icon_texture
	texture_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	texture_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	texture_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	texture_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	icon_box.add_child(texture_rect)

	# 右下角数字
	var count_label = Label.new()
	count_label.text = str(count)
	count_label.add_theme_font_size_override("font_size", font_size)
	count_label.add_theme_color_override("font_color", font_color)
	count_label.add_theme_color_override("font_outline_color", font_outline_color)
	count_label.add_theme_constant_override("outline_size", font_outline_size)
	count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	count_label.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM

	# 锚定右下角
	count_label.anchor_left = 1.0
	count_label.anchor_top = 1.0
	count_label.anchor_right = 1.0
	count_label.anchor_bottom = 1.0
	count_label.offset_left = -icon_size.x
	count_label.offset_top = -icon_size.y
	count_label.offset_right = -count_margin_right
	count_label.offset_bottom = -count_margin_bottom
	count_label.mouse_filter = Control.MOUSE_FILTER_IGNORE

	icon_box.add_child(count_label)
	icon_container.add_child(icon_box)
