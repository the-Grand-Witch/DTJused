extends Button
class_name CharacterButton

@export var character: Generator_girl
