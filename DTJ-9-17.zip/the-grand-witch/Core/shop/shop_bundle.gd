extends Button
## 捆绑书签商品子脚本：负责捆绑内容生成、显示、购买

@onready var bundle_names_box: VBoxContainer = $BundleNamesBox
@onready var bundle_price_label: Label = $BundlePriceLabel

var item: Dictionary = {}
var all_cards: Array[Generator_bookpage] = []

func _ready():
	all_cards = GlobalCardLibrary.get_randomable_cards()
	_generate_item()
	_update_button()
	pressed.connect(_on_pressed)

func _generate_item():
	var epic_cards = all_cards.filter(func(c): return c.rarity == 2)
	if epic_cards.is_empty():
		return
	var epic_card: Generator_bookpage = epic_cards[randi() % epic_cards.size()]

	var non_epic_cards = all_cards.filter(func(c): return c.rarity != 2)
	if non_epic_cards.is_empty():
		return

	var pages: Array[Generator_bookpage] = [epic_card]
	for i in range(4):
		if randf() < 0.25:
			var rare_cards = non_epic_cards.filter(func(c): return c.rarity == 1)
			if rare_cards.size() > 0:
				pages.append(rare_cards[randi() % rare_cards.size()])
			else:
				pages.append(non_epic_cards[randi() % non_epic_cards.size()])
		else:
			var normal_cards = non_epic_cards.filter(func(c): return c.rarity == 0)
			if normal_cards.size() > 0:
				pages.append(normal_cards[randi() % normal_cards.size()])
			else:
				pages.append(non_epic_cards[randi() % non_epic_cards.size()])

	item = {
		"type": "bundle_bookmark",
		"name": "捆绑书签",
		"description": "包含1张史诗卡牌和4张随机卡牌",
		"price": 120,
		"pages": pages,
		"card": epic_card
	}

func _update_button():
	if item.is_empty():
		visible = false
		return
	tooltip_text = item["description"]
	visible = true
	if bundle_price_label:
		bundle_price_label.text = "%d金币" % item["price"]
		bundle_price_label.visible = true
	_update_preview()

func _update_preview():
	var pages = item.get("pages", [])
	var labels = bundle_names_box.get_children()
	for i in range(labels.size()):
		if i < pages.size():
			labels[i].text = pages[i].page_name
			labels[i].visible = true
		else:
			labels[i].visible = false

func _on_pressed():
	if item.is_empty():
		return
	if GlobalPlayer.gold < item["price"]:
		GlobalPlayer.show("金币不足")
		return
	GlobalPlayer.add_gold(-item["price"])
	var bookmark = Generator_bookmark.new()
	bookmark.title = "捆绑书签"
	for page in item["pages"]:
		bookmark.pages.append(page)
	GlobalBookMark.add_bookmark(bookmark)
	item = {}
	visible = false
