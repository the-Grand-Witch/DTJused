extends Control
## 商店场景主脚本：只保留基础交互，商品逻辑已拆分到各子脚本

@onready var close_button: Button = $CloseButton

func _ready():
	close_button.pressed.connect(_on_close_pressed)

func _on_close_pressed():
	var overlay = get_parent()
	queue_free()
	if overlay is Control:
		overlay.visible = false

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_on_close_pressed()
