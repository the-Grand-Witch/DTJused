extends Control
## 卡牌商品子脚本：负责随机卡牌生成、显示、购买

@onready var buttons: Array[Button] = [
	$CradButton1,
	$CradButton2,
	$CradButton3,
	$CradButton4
]

var items: Array[Dictionary] = []
var all_cards: Array[Generator_bookpage] = []

func _ready():
	all_cards = GlobalCardLibrary.get_randomable_cards()
	for card in all_cards:
		card.price = _get_price(card.rarity)
	_generate_items()
	for btn in buttons:
		btn.pressed.connect(_on_button_pressed.bind(btn))
	_update_buttons()

func _get_price(rarity: int) -> int:
	match rarity:
		0:
			return randi_range(17, 23)
		1:
			return randi_range(30, 40)
		2:
			return randi_range(43, 57)
	return 20

func _generate_items():
	items.clear()
	for i in range(4):
		var card = _get_random_card()
		if card:
			items.append({
				"type": "card",
				"name": card.page_name,
				"description": card.description,
				"price": card.price,
				"icon": card.icon,
				"card": card
			})

func _get_random_card() -> Generator_bookpage:
	if all_cards.is_empty():
		return null
	return all_cards[randi() % all_cards.size()]

func _update_buttons():
	for i in range(buttons.size()):
		if i < items.size() and items[i] != null:
			var item = items[i]
			buttons[i].text = "%s\n%d金币" % [item["name"], item["price"]]
			buttons[i].icon = item.get("icon", null)
			buttons[i].tooltip_text = item["description"]
			buttons[i].visible = true
		else:
			buttons[i].visible = false

func _on_button_pressed(btn: Button):
	var idx = buttons.find(btn)
	if idx == -1 or idx >= items.size():
		return
	var item = items[idx]
	if item.is_empty():
		return
	if GlobalPlayer.gold < item["price"]:
		GlobalPlayer.show("金币不足")
		return
	GlobalPlayer.add_gold(-item["price"])
	GlobalCardLibrary.add_acquired_count(item["card"].book_id, 1)
	btn.disabled = true
	btn.modulate.a = 0
	items[idx] = {}
