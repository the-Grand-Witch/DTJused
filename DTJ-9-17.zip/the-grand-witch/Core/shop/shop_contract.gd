extends Control
## 契约窗口控制：默认隐藏 ContractWindow，按下 ContractWindowButton 后显示整个窗口

@onready var contract_window: Control = $ContractWindow
@onready var contract_button: Button = $ContractWindowButton
@onready var name_input: LineEdit = $ContractWindow/NameInput
@onready var contract_name_label: Label = $ContractWindow/ContractName
@onready var contract_text_label: Label = $ContractWindow/ContractText
@onready var agree_button: Button = $ContractWindow/Agree
@onready var contract_back: TextureRect = $ContractBack

var current_contract: Generator_contract = null
var _is_closing: bool = false

func _ready():
	current_contract = GlobalContract.get_contract()
	if current_contract:
		contract_name_label.text = current_contract.ContractName
		contract_text_label.text = current_contract.ContractText

	contract_window.visible = false

	contract_button.pressed.connect(_on_contract_button_pressed)
	agree_button.pressed.connect(_on_agree_pressed)

func _on_contract_button_pressed():
	if _is_closing:
		return
	if contract_window.visible:
		return
	if current_contract == null:
		return

	name_input.text = ""
	contract_window.visible = true

func _on_agree_pressed():
	if current_contract == null:
		return
	var input_name = name_input.text.replace(" ", "")
	var character_name = GlobalPlayer.current_character.character_name.replace(" ", "")
	if input_name == character_name:
		current_contract.contract_script.new().execute({"player": GlobalPlayer})
		GlobalContract.mark_signed(current_contract.contract_id)
		GlobalPlayer.show("契约签订成功提示")
		_fade_out_and_close()
	else:
		GlobalPlayer.show("契约签订失败提示")

func _fade_out_and_close():
	_is_closing = true
	agree_button.disabled = true
	name_input.editable = false
	var tween = create_tween()
	tween.tween_property(contract_window, "modulate:a", 0.0, 0.5)
	await tween.finished
	contract_window.queue_free()
	contract_button.queue_free()
	contract_back.queue_free()
