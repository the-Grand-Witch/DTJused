extends Control
## 饰品商品子脚本：负责随机饰品生成、显示、购买

@onready var buttons: Array[Button] = [
	$AccessoryButton1,
	$AccessoryButton2
]

var items: Array[Dictionary] = []
var selected_ids: Array[int] = []
var all_accessories: Array[Generator_accessories] = []

func _ready():
	all_accessories = GlobalAccessories.all_accessories.duplicate()
	for acc in all_accessories:
		acc.price = _get_price(acc.rarity)
	_generate_items()
	for btn in buttons:
		btn.pressed.connect(_on_button_pressed.bind(btn))
	_update_buttons()

func _get_price(rarity: int) -> int:
	match rarity:
		0:
			return randi_range(147, 153)
		1:
			return randi_range(210, 220)
		2:
			return randi_range(273, 287)
	return 150

func _generate_items():
	items.clear()
	selected_ids.clear()
	for i in range(2):
		var acc = _get_random_accessory()
		if acc:
			items.append({
				"type": "accessory",
				"name": acc.name,
				"description": acc.Tooltip if acc.Tooltip else "",
				"price": acc.price,
				"icon": acc.icon,
				"accessory": acc
			})

func _get_random_accessory() -> Generator_accessories:
	var owned_ids = []
	for a in GlobalAccessories.accessories:
		owned_ids.append(a.acc_id)

	var pool: Array[Dictionary] = []
	for acc in all_accessories:
		if acc.acc_id in owned_ids:
			continue
		if acc.acc_id in selected_ids:
			continue
		if (acc.acc_id >= 666 and acc.acc_id <= 700) or acc.acc_id >= 1000:
			continue
		if acc.acc_id >= 1 and acc.acc_id <= 33:
			pool.append({"acc": acc, "weight": 25})
		elif acc.acc_id >= 34 and acc.acc_id <= 66:
			pool.append({"acc": acc, "weight": 15})
		elif acc.acc_id >= 67 and acc.acc_id <= 99:
			pool.append({"acc": acc, "weight": 10})
		elif acc.acc_id >= 777 and acc.acc_id <= 800:
			pool.append({"acc": acc, "weight": 50})

	if pool.is_empty():
		return null

	var total_weight = 0
	for entry in pool:
		total_weight += entry.weight
	var roll = randi() % total_weight
	var cumulative = 0
	for entry in pool:
		cumulative += entry.weight
		if roll < cumulative:
			var chosen = entry.acc
			selected_ids.append(chosen.acc_id)
			return chosen
	return null

func _update_buttons():
	for i in range(buttons.size()):
		if i < items.size() and not items[i].is_empty():
			var item = items[i]
			buttons[i].text = "%s\n%d金币" % [item["name"], item["price"]]
			buttons[i].icon = item.get("icon", null)
			buttons[i].tooltip_text = item["description"]
			buttons[i].visible = true
		else:
			buttons[i].visible = false

func _on_button_pressed(btn: Button):
	var idx = buttons.find(btn)
	if idx == -1 or idx >= items.size():
		return
	var item = items[idx]
	if item.is_empty():
		return
	if GlobalPlayer.gold < item["price"]:
		GlobalPlayer.show("金币不足")
		return
	GlobalPlayer.add_gold(-item["price"])
	GlobalAccessories.add_accessories(item["accessory"])
	btn.visible = false
	items[idx] = {}
