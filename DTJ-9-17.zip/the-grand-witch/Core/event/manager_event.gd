extends Node

# ==================== 常量 ====================
const EVENT_DIR : = "res://Data/event/"
const BOSS_EVENT_BASE_ID := 100          # Boss 事件基础 ID，100-103 为 Boss
const BOSS_TIME_MINUTES := 21 * 60       # 21:00 允许 Boss 进入随机池
const BOSS_FORCE_MINUTES := 21 * 60 + 30 # 21:30 强制 Boss
const DAY_END_MINUTES := 22 * 60         # 22:00 当天结束，事件不能超过此时间

# ==================== 节点引用 ====================
@onready var option_nodes = [$OptionA, $OptionB, $OptionC]
@onready var overlay_container: Control = $"../OverlayContainer"

# ==================== 状态变量 ====================
var cards := {}
var last_event_ids := {}
var is_boss_time := false
var event_pool: Array[Generator_event] = []

const ROAD_EVENT_TYPES = [Generator_event.EventType.WALK, Generator_event.EventType.DIG]

# ==================== 初始化 ====================
func _ready():
	GlobalScenes.event_manager = self
	randomize()
	_load_event_pool()
	for btn in option_nodes:
		btn.pressed.connect(_on_option_pressed.bind(btn))
		_create_card(btn)
	
	GlobalTime.time_changed.connect(_check_boss_time)
	_check_boss_time(GlobalTime.get_time())

# ==================== 事件池加载 ====================
func _load_event_pool():
	event_pool.clear()
	var files = ResourceLoader.list_directory("res://Data/event")
	for file in files:
		if file.ends_with(".tres"):
			var res = load("res://Data/event/" + file)
			if res is Generator_event:
				event_pool.append(res)

# ==================== 卡片创建 ====================
func _create_card(btn, forced_event: Generator_event = null):
	if cards.has(btn):
		var old_event: Generator_event = cards[btn]
		_play_animation(btn, old_event.anim_destroy_frames, old_event.anim_duration)
		for child in btn.get_children():
			child.queue_free()
	
	var chosen: Generator_event
	if forced_event:
		chosen = forced_event
	else:
		chosen = _choose_valid_event(btn)
	
	btn.icon = chosen.icon
	btn.text = chosen.event_name
	btn.tooltip_text = chosen.event_name + "\n" + chosen.description
	btn.flat = true
	btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	btn.set_meta("event_data", chosen)
	cards[btn] = chosen
	last_event_ids[btn] = chosen.event_id
	
	_play_animation(btn, chosen.anim_join_frames, chosen.anim_duration)

# ==================== 事件选择逻辑 ====================
func _choose_valid_event(btn):
	var candidates = event_pool.duplicate()
	var current_minutes = GlobalTime.get_time()

	# 时间限制
	candidates = candidates.filter(func(e):
		var event_end_time = current_minutes + e.time_units * 5
		return event_end_time <= DAY_END_MINUTES
	)

	# 21:00 之前排除 Boss 事件
	if current_minutes < BOSS_TIME_MINUTES:
		candidates = candidates.filter(func(e): return not (e.event_id >= BOSS_EVENT_BASE_ID and e.event_id <= BOSS_EVENT_BASE_ID + 3))

	# 排除与上次相同的事件
	if last_event_ids.has(btn):
		var last_id = last_event_ids[btn]
		candidates = candidates.filter(func(e): return e.event_id != last_id)

	# 如果其他按钮已有道路事件，排除道路事件
	if _has_road_event(btn):
		candidates = candidates.filter(func(e): return not (e.event_type in ROAD_EVENT_TYPES))

	# 剔除权重为0的事件，避免除零
	candidates = candidates.filter(func(e): return e.weight > 0)

	# 放宽条件（如果候选为空，逐步放宽）
	if candidates.is_empty():
		candidates = event_pool.duplicate()
		candidates = candidates.filter(func(e):
			var event_end_time = current_minutes + e.time_units * 5
			return event_end_time <= DAY_END_MINUTES
		)
		if current_minutes < BOSS_TIME_MINUTES:
			candidates = candidates.filter(func(e): return not (e.event_id >= BOSS_EVENT_BASE_ID and e.event_id <= BOSS_EVENT_BASE_ID + 3))
		if last_event_ids.has(btn):
			candidates = candidates.filter(func(e): return e.event_id != last_event_ids[btn])
		# 再次剔除权重为0
		candidates = candidates.filter(func(e): return e.weight > 0)
		if candidates.is_empty():
			candidates = event_pool.duplicate()
			# 最后兜底：权重为0也允许参与等概率随机
			if candidates.is_empty():
				return null
	# 使用加权随机选择
	return _weighted_random(candidates)

# 加权随机函数
func _weighted_random(events: Array[Generator_event]) -> Generator_event:
	var total_weight := 0
	for event in events:
		total_weight += event.weight

	var roll := randi() % total_weight
	var cumulative := 0
	for event in events:
		cumulative += event.weight
		if roll < cumulative:
			return event
	return events[0]

func _has_road_event(exclude_btn):
	for btn in option_nodes:
		if btn == exclude_btn:
			continue
		if cards.has(btn):
			if cards[btn].event_type in ROAD_EVENT_TYPES:
				return true
	return false

# ==================== 点击处理 ====================
func _on_option_pressed(btn):
	if not cards.has(btn):
		return
	var event_data: Generator_event = cards[btn]
	
	_play_animation(btn, event_data.anim_execute_frames, event_data.anim_duration)
	
	var completed = _trigger_event(event_data, btn)
	
	if completed and event_data.anim_end_frames:
		_play_animation(btn, event_data.anim_end_frames, event_data.anim_duration)
	
	if event_data.unique and completed:
		event_pool.erase(event_data)
	
	if completed:
		_create_card(btn)

# ==================== 事件效果触发 ====================
# ==================== 事件效果触发 ====================
func _trigger_event(event_data: Generator_event, btn: Button) -> bool:
	if event_data.time_units > 0:
		GlobalTime.add_time_units(event_data.time_units)
	
	if event_data.is_special:
		if event_data.effect_script:
			var obj = event_data.effect_script.new()
			add_child(obj)
			return obj.trigger_effect(btn)
		elif event_data.effect_scene:
			# 根据 is_full_scene 决定加载方式
			if event_data.is_full_scene:
				GlobalScenes.change_scene(event_data.effect_scene.resource_path)
			else:
				open_overlay(event_data.effect_scene)
			return true
	else:
		if event_data.health_change != 0:
			if event_data.health_change > 0:
				GlobalPlayer.heal(event_data.health_change)
			else:
				GlobalPlayer.take_damage(-event_data.health_change)
		if event_data.witch_power_change != 0:
			GlobalPlayer.possessed(event_data.witch_power_change)
		if event_data.gold_change != 0:
			GlobalPlayer.add_gold(event_data.gold_change)
		return true
	return false

# ==================== 动画播放 ====================
func _play_animation(btn: Button, frames: SpriteFrames, duration: float):
	if frames:
		var sprite = AnimatedSprite2D.new()
		sprite.sprite_frames = frames
		sprite.centered = false
		sprite.position = Vector2.ZERO
		btn.add_child(sprite)
		sprite.play()
		sprite.animation_finished.connect(func(): sprite.queue_free())
	else:
		var tween = create_tween()
		tween.tween_property(btn, "modulate:a", 0.0,0.2 )  # 淡出 0.3 秒
		tween.tween_property(btn, "modulate:a", 1.0, 0.0)  # 淡入 0 秒

func _play_join_animation(btn, event_data):
	_play_animation(btn, event_data.anim_join_frames, event_data.anim_duration)

func _play_execute_animation(btn, event_data):
	_play_animation(btn, event_data.anim_execute_frames, event_data.anim_duration)

func _play_end_animation(btn, event_data):
	_play_animation(btn, event_data.anim_end_frames, event_data.anim_duration)

func _play_destroy_animation(btn, event_data):
	_play_animation(btn, event_data.anim_destroy_frames, event_data.anim_duration)

# ==================== 深夜 Boss 检测 ====================
func _check_boss_time(minutes: int):
	if minutes >= BOSS_FORCE_MINUTES and not is_boss_time:
		is_boss_time = true
		_refresh_for_boss_time()

func _refresh_for_boss_time():
	# 左右按钮设置为透明占位空事件，保持布局
	var empty_event = _get_empty_event()
	for i in [0, 2]:
		var btn = option_nodes[i]
		_create_card(btn, empty_event)
		btn.disabled = true
		btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
		btn.modulate = Color(1, 1, 1, 0)   # 完全透明，但保留占位

	# 中间按钮切换到当天 Boss 事件
	var middle_btn = option_nodes[1]
	var boss_event = _get_boss_event_by_day()
	_create_card(middle_btn, boss_event)

func _get_boss_event_by_day() -> Generator_event:
	var day = GlobalTime.get_day()
	var boss_id = BOSS_EVENT_BASE_ID + day
	if boss_id > BOSS_EVENT_BASE_ID + 3:
		boss_id = BOSS_EVENT_BASE_ID + (day % 4)  # 循环使用 100-103
	for event in event_pool:
		if event.event_id == boss_id:
			return event
	# 如果找不到，随机选一个 Boss 事件
	return _get_random_boss_event()

func _get_random_boss_event() -> Generator_event:
	var boss_events: Array[Generator_event] = []
	for event in event_pool:
		if event.event_id >= BOSS_EVENT_BASE_ID and event.event_id <= BOSS_EVENT_BASE_ID + 3:
			boss_events.append(event)
	return boss_events[randi() % boss_events.size()]

func _get_empty_event() -> Generator_event:
	var empty = Generator_event.new()
	empty.event_id = -1
	empty.event_name = ""
	empty.description = ""
	empty.icon = null
	empty.time_units = 0
	empty.is_special = false
	empty.unique = false
	return empty

# ==================== Overlay 管理 ====================
## 打开一个覆盖场景（如商店）
func open_overlay(scene: PackedScene):
	# 清空旧内容
	for child in overlay_container.get_children():
		child.queue_free()
	# 实例化新场景
	var instance = scene.instantiate()
	overlay_container.add_child(instance)
	overlay_container.visible = true

## 关闭覆盖层
func close_overlay():
	for child in overlay_container.get_children():
		child.queue_free()
	overlay_container.visible = false

# ==================== 外部接口 ====================
func refresh_all_cards() -> void:
	for btn in option_nodes:
		_create_card(btn)
