extends Node

func trigger_effect(_btn: Button) -> bool:
	# 刷新所有事件卡牌
	GlobalScenes.refresh_events()
	# 时间消耗：Walk 事件消耗 3 个单位
	GlobalTime.add_time_units(3)
	return true
