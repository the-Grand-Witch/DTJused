extends TextureProgressBar

func _ready():
	max_value = 100
	value = _calculate_health_percent()

	GlobalPlayer.health_changed.connect(_on_health_changed)
	GlobalPlayer.max_health_changed.connect(_on_max_health_changed)
	GlobalPlayer.witch_power_changed.connect(_on_witch_power_changed)

	_update_witch_color(GlobalPlayer.witch_power)

func _on_health_changed(new_health: int) -> void:
	value = _calculate_health_percent()

func _on_max_health_changed(new_max_health: int) -> void:
	value = _calculate_health_percent()

func _on_witch_power_changed(new_witch_power: int) -> void:
	_update_witch_color(new_witch_power)

func _calculate_health_percent() -> float:
	if GlobalPlayer.max_health <= 0:
		return 0.0
	return (float(GlobalPlayer.health) / float(GlobalPlayer.max_health)) * 100.0

func _update_witch_color(witch_power: int) -> void:
	var max_wp = GlobalPlayer.max_witch_power + GlobalAccessories.get_witch_max_increase()
	if max_wp <= 0:
		modulate = Color(0, 1, 0)
		return
	var t = clamp(float(witch_power) / float(max_wp), 0.0, 1.0)
	var green = Color(0, 1, 0)
	var purple = Color(0.5, 0, 1)
	modulate = green.lerp(purple, t)
