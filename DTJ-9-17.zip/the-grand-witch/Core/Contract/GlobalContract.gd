extends Node
## 契约全局管理：扫描契约目录加载全部契约，提供随机获取与去重
var skip_rewards_remaining: int = 0
var skip_rewards_target_id: int = -1
const CONTRACT_DIR := "res://Data/contracts/"

var all_contracts: Array[Generator_contract] = []
var signed_ids: Array[int] = []

func _ready():
	signed_ids.clear()
	clear_skip_rewards()
	_load_all_contracts()


func _load_all_contracts():
	all_contracts.clear()
	var files = ResourceLoader.list_directory(CONTRACT_DIR)
	for file_name in files:
		if file_name.ends_with(".tres"):
			var path = CONTRACT_DIR + file_name
			var res = load(path)
			if res is Generator_contract:
				all_contracts.append(res)


func get_contract() -> Generator_contract:
	var pool: Array[Generator_contract] = []
	for c in all_contracts:
		if c.contract_id not in signed_ids:
			pool.append(c)
	if pool.is_empty():
		return null
	return pool[randi() % pool.size()]

func mark_signed(contract_id: int) -> void:
	if contract_id not in signed_ids:
		signed_ids.append(contract_id)

func start_skip_rewards(count: int, target_id: int) -> void:
	skip_rewards_remaining += count
	skip_rewards_target_id = target_id

func should_skip_rewards() -> bool:
	return skip_rewards_remaining > 0

func get_reward_effects() -> Array:
	if skip_rewards_remaining > 0:
		return [{
			"type": "accessories",
			"block_count": skip_rewards_remaining,
			"effect_id": "skip_accessories",
		}]
	return []

func consume_reward_block(effect_id: String, count: int) -> bool:
	if effect_id == "skip_accessories":
		if skip_rewards_remaining <= 0:
			return false
		skip_rewards_remaining -= count
		if skip_rewards_remaining <= 0:
			return true
	return false

func get_target_accessory() -> Generator_accessories:
	for acc in GlobalAccessories.all_accessories:
		if acc.acc_id == skip_rewards_target_id:
			return acc
	return null

## 消耗一次，返回 true 表示这是最后一次（该发目标饰品了）
func consume_skip_rewards() -> bool:
	if skip_rewards_remaining > 0:
		skip_rewards_remaining -= 1
		if skip_rewards_remaining == 0:
			return true
	return false

func clear_skip_rewards() -> void:
	skip_rewards_remaining = 0
	skip_rewards_target_id = -1

func reset():
	signed_ids.clear()
	_load_all_contracts()
