extends Node
## 契约效果：阻挡 3 次饰品掉落，3 次后给予指定饰品

const BLOCK_COUNT := 3
const TARGET_ACC_ID := 666

func execute(_context: Dictionary = {}) -> void:
	GlobalContract.start_skip_rewards(BLOCK_COUNT, TARGET_ACC_ID)
