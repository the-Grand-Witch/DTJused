extends Node
## 契约：血金交易
## 立刻获得 666 金币，但损失最大生命值的 50%

func execute(_context: Dictionary = {}) -> void:
	# 获得金币
	GlobalPlayer.add_gold(666)

	# 损失最大生命值的50%
	var cost = int(GlobalPlayer.max_health * 0.5)
	GlobalPlayer.take_damage(cost)
