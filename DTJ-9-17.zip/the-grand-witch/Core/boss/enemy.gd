extends Node
## 敌人根节点，统一管理 AI、魔女化、UI 子模块

# 引用模块
@onready var ai = $enemyAI
@onready var witch = $WitchSystem
@onready var ui = $enemyUI
@onready var calculator: Control = $EnemyCalculator

# 敌人数据
var snapshot: PlayerSnapshot
var health: int
var max_health: int
var base_attack: int
var cards: Array[BookmarkCard] = []
var selected_card: BookmarkCard
var max_witch_power: int = 100
var _stunned: bool = false
var _transformed: bool = false

func setup(snap: PlayerSnapshot):
	snapshot = snap
	max_health = snap.max_health
	health = snap.current_health
	base_attack = snap.base_attack
	max_witch_power = snap.max_witch_power
	witch.setup(snap.witch_power)
	ui.setup(snap, max_health, health)
	_create_cards()

func _create_cards():
	cards.clear()
	for data in snapshot.bookmarks:
		var card = preload("res://scenes/bookmark.tscn").instantiate()
		$EnemyHandContainer.add_child(card)
		card.setup(data)
		card.current_cd = 0
		cards.append(card)

func on_round_start(turn_count: int):
	# 冷却递减
	for card in cards:
		card.decrease_cooldown()

	# 魔女化系统：赋予冲动、触发彼岸之赐
	witch.on_round_start(turn_count, cards)

	# 更新敌人状态图标（彼岸之赐可能改变永久效果）
	_update_buff_display()

	# AI 选择书签
	selected_card = ai.choose_card(
		cards,
		health,
		max_health,
		GlobalPlayer.health,
		GlobalPlayer.max_health,
		witch.get_witch_power(),
		witch.get_impulses()
	)
	ui.show_intent(selected_card, ai)

func take_turn(player_armor: int) -> Dictionary:
	var result = {"damage_dealt": 0, "healing": 0, "armor": 0}
	if is_stunned():
		clear_stunned()
		return result

	if cards.is_empty():
		var attack_multiplier = witch.get_attack_multiplier()
		var attack_bonus = witch.get_permanent_effect("attack_bonus")
		var damage = calculator.calculate_direct_attack(base_attack, attack_bonus, attack_multiplier)
		var actual = max(damage - player_armor, 0)
		if actual > 0:
			GlobalPlayer.take_damage(actual)
		result["damage_dealt"] = actual
		return result

	# 正常手牌阶段
	if selected_card:
		var card_result = calculator.calculate_card_effects(selected_card, player_armor, base_attack, witch)
		result["damage_dealt"] = card_result.damage_dealt
		result["healing"] = card_result.healing
		result["armor"] = card_result.armor

		if card_result.damage_dealt > 0:
			GlobalPlayer.take_damage(card_result.damage_dealt)

		health = min(health + result.healing, max_health)
		ui.update_health(health, max_health)
		witch.update_witch_power_after_played_card(selected_card, card_result.damage_dealt)
		selected_card.start_cooldown()

	# 通知被动：敌人使用了这些页类型
	_notify_enemy_page_used(selected_card)

	# 未打出的冲动惩罚
	witch.punish_unused_impulses(selected_card)

	# 检查魔女化满值
	if not _transformed and witch.get_witch_power() >= max_witch_power:
		_transformed = true
		_transform()
	return result

func _notify_enemy_page_used(card: BookmarkCard) -> void:
	var used_types: Array = []
	for page in card.Generator_bookmark.pages:
		for t in page.page_type:
			if t not in used_types:
				used_types.append(t)
	if not used_types.is_empty():
		GlobalPassive.notify_enemy_page_used(used_types)

func _transform():
	cards.clear()
	var transform_result = witch.transform(snapshot, max_health, health, max_witch_power)
	max_health = transform_result["max_health"]
	health = transform_result["health"]
	ui.update_health(health, max_health)
	_update_buff_display()
	stunned()

## 更新敌人状态图标：从 WitchSystem 获取永久效果和彼岸层数
func _update_buff_display():
	var statuses = {}
	var effects = witch.get_permanent_effects()
	if effects["attack_bonus"] > 0:
		statuses["attack_bonus"] = effects["attack_bonus"]
	if effects["armor_per_turn"] > 0:
		statuses["armor_per_turn"] = effects["armor_per_turn"]
	if effects["heal_per_turn"] > 0:
		statuses["heal_per_turn"] = effects["heal_per_turn"]
	if witch.get_bian_layers() > 0:
		statuses["bian_layers"] = witch.get_bian_layers()
	ui.update_buffs(statuses)

func stunned() -> void:
	_stunned = true

func is_stunned() -> bool:
	return _stunned

func clear_stunned() -> void:
	_stunned = false

func get_health():
	return health

func get_max_health():
	return max_health

func take_damage(amount: int):
	health -= amount
	ui.update_health(health, max_health)

func heal(amount: int):
	health = min(health + amount, max_health)
	ui.update_health(health, max_health)
