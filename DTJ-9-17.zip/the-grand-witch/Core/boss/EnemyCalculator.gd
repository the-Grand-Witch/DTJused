extends Node
## 敌人伤害计算：纯计算，不持有状态

func calculate_card_effects(card: BookmarkCard, player_armor: int, base_attack: int, witch_system) -> Dictionary:
	var result = {"damage_dealt": 0, "healing": 0, "armor": 0}
	var attack_bonus = witch_system.get_permanent_effect("attack_bonus")
	var attack_multiplier = witch_system.get_attack_multiplier()
	var total_damage = 0
	for idx in range(card.Generator_bookmark.pages.size()):
		var page = card.Generator_bookmark.pages[idx]
		match page.pickup_type:
			Generator_bookpage.PickupType.Attack:
				var base_float = (base_attack + attack_bonus + page.damage) * attack_multiplier
				if witch_system.has_impulse(card, idx):
					base_float *= (1.0 + float(witch_system.get_witch_power()) / 100.0)
				total_damage += int(base_float)
			Generator_bookpage.PickupType.Heal:
				result.healing += page.healing
			Generator_bookpage.PickupType.Defense:
				result.armor += page.armor
	result.damage_dealt = max(total_damage - player_armor, 0)
	return result

func calculate_direct_attack(base_attack: int, attack_bonus: int, attack_multiplier: float) -> int:
	return int((base_attack + attack_bonus) * attack_multiplier)
