extends Node

var enemy_witch_power: int = 0
var enemy_bian_layers: int = 0
var enemy_attack_multiplier: float = 1.0
var enemy_impulse_pages: Array[Dictionary] = []
var enemy_permanent_effects = {"attack_bonus":0, "armor_per_turn":0, "max_health_bonus":0, "heal_per_turn":0}

func setup(initial_witch: int):
	enemy_witch_power = initial_witch

func get_witch_power():
	return enemy_witch_power

func get_impulses():
	return enemy_impulse_pages

func get_attack_multiplier():
	return enemy_attack_multiplier

func get_permanent_effect(key):
	return enemy_permanent_effects[key]

func get_permanent_effects():
	return enemy_permanent_effects

func get_bian_layers():
	return enemy_bian_layers

func has_impulse(card, page_index):
	for entry in enemy_impulse_pages:
		if entry["card"] == card and entry["page_index"] == page_index:
			return true
	return false

func on_round_start(turn_count, cards):
	_clear_impulses()
	var lost = 1 + (turn_count - 1) / 2
	var normal = enemy_witch_power / 10
	var total = lost + normal
	_apply_impulses(total, cards)
	_trigger_bian_effects()

func _clear_impulses():
	enemy_impulse_pages.clear()

func _apply_impulses(total, cards):
	var attack_pages: Array[Dictionary] = []
	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			var p = card.Generator_bookmark.pages[idx]
			if p.pickup_type == Generator_bookpage.PickupType.Attack:
				attack_pages.append({"card": card, "page_index": idx})
	for i in range(total):
		if attack_pages.is_empty(): break
		var r = randi() % attack_pages.size()
		enemy_impulse_pages.append(attack_pages[r])
		attack_pages.remove_at(r)

func _trigger_bian_effects():
	for i in range(enemy_bian_layers):
		var roll = randi() % 4
		match roll:
			0: enemy_attack_multiplier *= 1.1
			1: enemy_permanent_effects["armor_per_turn"] += 2
			2: enemy_permanent_effects["heal_per_turn"] += 2
			3: enemy_bian_layers += 1

func update_witch_power_after_played_card(card, damage_dealt):
	var impulses_played = 0
	for entry in enemy_impulse_pages:
		if entry["card"] == card:
			impulses_played += 1
	if impulses_played == 0: return
	if damage_dealt <= 0:
		enemy_witch_power += 3 * impulses_played

func punish_unused_impulses(selected_card):
	for entry in enemy_impulse_pages:
		if entry["card"] != selected_card:
			enemy_witch_power += 2

func transform(snapshot, max_health, current_health, max_witch_power) -> Dictionary:
	var old_max = max_health
	for data in snapshot.bookmarks:
		for page in data.pages:
			match page.pickup_type:
				Generator_bookpage.PickupType.Attack:
					enemy_permanent_effects["attack_bonus"] += 2 + page.rarity
				Generator_bookpage.PickupType.Defense:
					enemy_permanent_effects["armor_per_turn"] += 1 + page.rarity
				Generator_bookpage.PickupType.Ability:
					enemy_bian_layers += 1 + page.rarity
				Generator_bookpage.PickupType.Heal:
					enemy_permanent_effects["max_health_bonus"] += 5 + page.rarity * 2.5
	var new_max = int(max_health * (1 + enemy_permanent_effects["max_health_bonus"] / 100.0))
	var new_health = current_health + (new_max - old_max)
	enemy_permanent_effects["heal_per_turn"] = enemy_bian_layers * 2
	enemy_impulse_pages.clear()
	enemy_witch_power = max_witch_power
	return {"max_health": new_max, "health": new_health}
