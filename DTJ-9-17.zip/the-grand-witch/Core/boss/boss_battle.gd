extends Node
## Boss战特殊逻辑

signal boss_defeated

@onready var enemy = $Enemy

const NORMAL_SNAPSHOT_DIR := "res://Data/DownloadPlayer/"
const SPECIAL_SNAPSHOT_DIR := "res://Data/DownloadPlayer/special/"

var battle_main: Node
var player_snapshot: PlayerSnapshot

func setup():
	player_snapshot = _load_random_snapshot()
	enemy.setup(player_snapshot)

func _load_random_snapshot() -> PlayerSnapshot:
	var dir_path = SPECIAL_SNAPSHOT_DIR if randf() < 0.05 else NORMAL_SNAPSHOT_DIR
	var files = ResourceLoader.list_directory(dir_path)
	var snapshot_files: Array[String] = []
	for f in files:
		if f.ends_with(".tres"):
			snapshot_files.append(dir_path + f)
	return load(snapshot_files[randi() % snapshot_files.size()]) as PlayerSnapshot

func on_round_start(turn_count: int):
	enemy.on_round_start(turn_count)

func enemy_witch_power() -> int:
	return enemy.witch.get_witch_power()

func enemy_take_damage(amount: int):
	enemy.take_damage(amount)

func is_enemy_dead() -> bool:
	return enemy.get_health() <= 0

func on_enemy_defeated():
	emit_signal("boss_defeated")
	GlobalScenes.check_victory()

func enemy_take_turn(player_armor: int):
	enemy.take_turn(player_armor)
