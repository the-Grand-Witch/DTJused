extends Node

@onready var settings_button: Button = $"."

func _ready():
	settings_button.pressed.connect(_on_settings_button_pressed)

func _on_settings_button_pressed():
	GlobalScenes.open_settings()
