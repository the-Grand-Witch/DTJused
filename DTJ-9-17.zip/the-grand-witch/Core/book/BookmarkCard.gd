extends Control
class_name BookmarkCard

signal selection_changed(selected: bool)
signal card_confirmed(card: BookmarkCard)
signal cd_changed(current_cd: int)
signal data_changed()

var Generator_bookmark: Generator_bookmark
var current_cd: int = 0
var page_marks: Array[Dictionary] = []
var is_selected := false

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func setup(data: Generator_bookmark) -> void:
	Generator_bookmark = data
	current_cd = 0
	_init_page_marks()
	data_changed.emit()
	cd_changed.emit(current_cd)

# ==================== 标记 ====================
func _init_page_marks() -> void:
	page_marks.clear()
	var cid = get_instance_id()
	for i in range(Generator_bookmark.pages.size()):
		var page = Generator_bookmark.pages[i]
		page_marks.append({
			"card_id": cid,
			"page_index": i,
			"page_type": page.page_type,
			"page_position": "bookmark",
			"cd_remaining": max(0, page.cd - GlobalAccessories.get_bookpage_cd_reload()),
			"usable": current_cd <= 0,
			"used": false,
			"use_count": 0,
			"play_count": 1,
			"overall_multiplier": 1.0,
			"overall_sum": 0,
			"snapshots": [],
			"effects": {},
			"values": {
				"damage": page.damage,
				"healing": page.healing,
				"armor": page.armor,
				"witchpower": page.witchpower,
				"counting": page.counting,
				"effect_damage": page.effect_damage,
				"effect_healing": page.effect_healing,
				"effect_armor": page.effect_armor,
				"effect_witchpower": page.effect_witchpower,
				"effect_counting": page.effect_counting,
			},
		})

func get_page_mark(page_index: int) -> Dictionary:
	if page_index < 0 or page_index >= page_marks.size():
		return {}
	return page_marks[page_index]

func get_all_marks() -> Array[Dictionary]:
	return page_marks

func set_page_position(page_index: int, pos: String) -> void:
	if page_index < 0 or page_index >= page_marks.size():
		return
	page_marks[page_index]["page_position"] = pos

func get_initial_cd(page_index: int) -> int:
	if page_index < 0 or page_index >= Generator_bookmark.pages.size():
		return 0
	return Generator_bookmark.pages[page_index].cd

func _update_usable_marks() -> void:
	for mark in page_marks:
		mark["usable"] = current_cd <= 0

# ==================== values 只读 ====================
func get_values(page_index: int) -> Dictionary:
	if page_index < 0 or page_index >= page_marks.size():
		return {}
	return page_marks[page_index].get("values", {})

func get_value(page_index: int, field: String):
	var v = get_values(page_index)
	return v.get(field, 0)

# ==================== 回合重置 ====================
func reset_round_modifiers() -> void:
	for i in range(page_marks.size()):
		var page = Generator_bookmark.pages[i]
		page_marks[i]["play_count"] = 1
		page_marks[i]["overall_multiplier"] = 1.0
		page_marks[i]["overall_sum"] = 0
		page_marks[i]["snapshots"] = []
		page_marks[i]["effects"] = {}
		page_marks[i]["values"] = {
			"damage": page.damage,
			"healing": page.healing,
			"armor": page.armor,
			"witchpower": page.witchpower,
			"counting": page.counting,
			"effect_damage": page.effect_damage,
			"effect_healing": page.effect_healing,
			"effect_armor": page.effect_armor,
			"effect_witchpower": page.effect_witchpower,
			"effect_counting": page.effect_counting,
		}
# ==================== CD ====================
func is_ready() -> bool:
	return current_cd <= 0

func decrease_cooldown() -> void:
	if current_cd > 0:
		current_cd -= 1
		_update_usable_marks()
		cd_changed.emit(current_cd)

func start_cooldown() -> void:
	if page_marks.is_empty():
		current_cd = 0
	else:
		var total = 0
		for mark in page_marks:
			total += mark["cd_remaining"]
		current_cd = int(round(float(total) / page_marks.size()))
	for i in range(page_marks.size()):
		var page = Generator_bookmark.pages[i]
		page_marks[i]["cd_remaining"] = max(0, page.cd - GlobalAccessories.get_bookpage_cd_reload())
	_update_usable_marks()
	cd_changed.emit(current_cd)

# ==================== 选择 ====================
func _on_clicked() -> void:
	if not is_ready():
		return
	if not is_selected:
		set_selected(true)
	else:
		card_confirmed.emit(self)

func set_selected(selected: bool) -> void:
	if is_selected == selected:
		return
	is_selected = selected
	selection_changed.emit(is_selected)
