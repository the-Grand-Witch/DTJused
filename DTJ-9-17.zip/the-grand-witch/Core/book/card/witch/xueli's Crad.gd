extends RefCounted
class_name LunchEffect

## 大家的午餐：减少魔女化
## 总减少 = 3 × friend 数
## friend 数 = 所有书签的 friend 页 + 已拥有饰品的 friend 标签

func on_use(_context: Dictionary) -> void:
	var friend_count = _count_friends()
	if friend_count > 0:
		GlobalPlayer.possessed(-3 * friend_count)

func _count_friends() -> int:
	var count = 0
	for bookmark in GlobalBookMark.bookmarks:
		for page in bookmark.pages:
			if Generator_bookpage.PickupType.friend in page.page_type:
				count += 1
	for acc in GlobalAccessories.accessories:
		if acc.pickup_type == Generator_accessories.PickupType.friend:
			count += 1
	return count
