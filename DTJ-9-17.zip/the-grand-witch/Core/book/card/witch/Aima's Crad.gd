extends Node
## 特殊书页效果：伙伴的力量
## 每拥有一个 girl 种类饰品（acc_id >= 1000）：伤害 +5
## 基础 +8；数量为 0 时伤害 = 0

func execute(_context: Dictionary) -> Dictionary:
	var count = 0
	for acc in GlobalAccessories.accessories:
		if acc.acc_id >= 1000:
			count += 1
	var bonus = min(count, 1) * (8 + 5 * count)
	return {"damage": bonus}
