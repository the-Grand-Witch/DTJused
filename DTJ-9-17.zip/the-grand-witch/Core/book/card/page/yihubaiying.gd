extends RefCounted
## 联动：攻击2
## 使用阶段：给同书签内所有攻击页加 damage +2

func execute(phase: String, context: Dictionary) -> void:
	if phase != "use":
		return
	var cid = context.bookmark_card.get_instance_id()
	var marks = context.bookmark_marks
	var hit = []
	for mark in marks:
		if mark.type == Generator_bookpage.PickupType.Attack:
			context.modifiers.append({
				"target_card_id": cid,
				"target_page_index": mark.page_index,
				"changes": [
					{"field": "damage", "add": 2, "multiply": 1.0, "source": "attack_2"},
				],
			})
			hit.append(mark.page_index)
