extends RefCounted
## 联动：防御1
## 使用阶段：给索引 +1 的页加 page_multiplier × 1.5

func execute(phase: String, context: Dictionary) -> void:
	if phase != "use":
		return
	var idx = context.self_mark.page_index
	var marks = context.bookmark_marks
	var target = idx + 1
	if target < 0 or target >= marks.size():
		return
	context.modifiers.append({
		"target_card_id": context.bookmark_card.get_instance_id(),
		"target_page_index": target,
		"changes": [
			{"field": "page_multiplier", "add": 0, "multiply": 1.5, "source": "defense_1"},
		],
	})
