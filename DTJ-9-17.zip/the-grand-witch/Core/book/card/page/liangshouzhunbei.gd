extends RefCounted
## 联动：攻击3
## 编入阶段：给索引 ±1 的页加 base_value +1

func execute(phase: String, context: Dictionary) -> void:
	if phase != "enter":
		return
	var idx = context.self_mark.page_index
	var marks = context.bookmark_marks
	var cid = context.bookmark_card.get_instance_id()
	var hit = []
	for offset in [-1, 1]:
		var target = idx + offset
		if target < 0 or target >= marks.size():
			continue
		context.modifiers.append({
			"target_card_id": cid,
			"target_page_index": target,
			"changes": [
				{"field": "base_value", "add": 1, "multiply": 1.0, "source": "attack_3"},
			],
		})
		hit.append(target)
