extends RefCounted
class_name AttackUpEffect

## 攻击力提升：读取当前 counting 值，输出为攻击加成

func on_ability(context: Dictionary) -> Dictionary:
	var counting = context.get("counting", 0)
	return {"attack_bonus": int(counting)}
