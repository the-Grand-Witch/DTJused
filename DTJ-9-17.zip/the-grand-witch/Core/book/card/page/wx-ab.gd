extends RefCounted
class_name HarmonyCdEffect

## 打出时：
##   1. 若触发维协：本页 CD 变为 5（受饰品 CD 缩减影响）
##   2. 每回合回血 += counting（通过 on_ability 走 ability 分支）

const HARMONY_CD := 5

func on_use(context: Dictionary) -> void:
	var page = context.get("self_page")
	if page == null:
		return
	if "维协" not in page.keywords:
		return
	var bs = context.get("battle_state")
	if bs == null or bs.harmony_stacks <= 0:
		return
	var card = context.get("self_card")
	var idx = context.get("self_index")
	if card != null:
		var cd_reduce = GlobalAccessories.get_bookpage_cd_reload()
		var new_cd = max(0, HARMONY_CD - cd_reduce)
		card.page_marks[idx]["cd_remaining"] = new_cd

func on_ability(context: Dictionary) -> Dictionary:
	var counting = context.get("counting", 0)
	return {"heal_count": int(counting)}
