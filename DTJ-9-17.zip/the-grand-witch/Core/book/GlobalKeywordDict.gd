extends Node
## 全局关键词字典：管理关键词描述与效果逻辑

var keyword_dict: Dictionary = {}

func _ready():
	_register_default_keywords()

func _register_default_keywords():
	keyword_dict["始源"] = {
		"description": "增加卡牌效果，但同一书签内始源越多，效果越弱",
		"execute": _execute_primordial
	}
	keyword_dict["维协"] = {
		"description": "打出后获得维协buff，再次打出时消耗buff获得额外效果",
		"execute": _execute_harmony
	}
	keyword_dict["强压"] = {
		"description": "书签中书页少于上限时，触发额外特效，每缺少2张再触发一次",
		"execute": _execute_pressure
	}
	keyword_dict["统洁"] = {
		"description": "根据书签内同类型页数量，触发额外数值",
		"execute": _execute_purity
	}
	keyword_dict["疯狂"] = {
		"description": "任何类型可被赋予冲动",
		"execute": _execute_crazy
	}

func get_keyword_description(keyword_name: StringName) -> String:
	if keyword_dict.has(keyword_name):
		return keyword_dict[keyword_name]["description"]
	return ""

func execute_keyword(keyword_name: StringName, context) -> Dictionary:
	if keyword_dict.has(keyword_name):
		var func_ref = keyword_dict[keyword_name]["execute"]
		if func_ref is Callable:
			return func_ref.call(context)
	return {}

# ==================== 关键词效果实现 ====================
## 始源
func _execute_primordial(context) -> Dictionary:
	var bookmark = context.get("bookmark")
	if bookmark == null:
		return {}
	var count = 0
	for page in bookmark.pages:
		if "始源" in page.keywords:
			count += 1
	var multiplier = 1.0
	if count > 1:
		multiplier = pow(0.75, count - 1)
	var card = context["card"]
	return {"add": {
		"damage": card.effect_damage * multiplier,
		"healing": card.effect_healing * multiplier,
		"armor": card.effect_armor * multiplier,
		"witchpower": card.effect_witchpower * multiplier,
		"counting": card.effect_counting * multiplier,
	}}

## 维协
func _execute_harmony(context) -> Dictionary:
	var card = context["card"]
	var bs = context.get("battle_state")
	if bs == null:
		return {}
	if bs.harmony_stacks > 0:
		bs.harmony_stacks -= 1
		bs.harmony_save += 1
		return {"add": {
			"damage": card.effect_damage,
			"healing": card.effect_healing,
			"armor": card.effect_armor,
			"witchpower": card.effect_witchpower,
			"counting": card.effect_counting,
		}, "harmony_triggered": true}
	bs.harmony_save += 1
	return {}

## 强压
func _execute_pressure(context) -> Dictionary:
	var card = context["card"]
	var bookmark = context.get("bookmark")
	if bookmark == null:
		return {}
	var page_limit = GlobalBookMark.BASE_PAGE_LIMIT + GlobalAccessories.get_bookmark_page_limit_up()
	var missing_pages = page_limit - bookmark.pages.size()
	var extra_triggers = int(missing_pages / 2)
	if extra_triggers <= 0:
		return {}
	var multiplier = 1.0 + extra_triggers
	return {"add": {
		"damage": card.effect_damage * multiplier,
		"healing": card.effect_healing * multiplier,
		"armor": card.effect_armor * multiplier,
		"witchpower": card.effect_witchpower * multiplier,
		"counting": card.effect_counting * multiplier,
	}}

## 统洁
func _execute_purity(context) -> Dictionary:
	var card = context["card"]
	var bookmark = context.get("bookmark")
	if bookmark == null:
		return {}
	var result = {}
	for type in card.page_type:
		var count = 0
		for page in bookmark.pages:
			if type in page.page_type:
				count += 1
		var bonus = 1.0 + 0.3 * count
		match type:
			Generator_bookpage.PickupType.Attack:
				result["damage"] = card.effect_damage * bonus
			Generator_bookpage.PickupType.Defense:
				result["armor"] = card.effect_armor * bonus
			Generator_bookpage.PickupType.Heal:
				result["healing"] = card.effect_healing * bonus
			Generator_bookpage.PickupType.Ability:
				result["counting"] = card.effect_counting * bonus
			Generator_bookpage.PickupType.Witch:
				result["witchpower"] = card.effect_witchpower * bonus
	return {"add": result}

## 疯狂
func _execute_crazy(context) -> Dictionary:
	var card = context["card"]
	return {"add": {
		"damage": card.effect_damage,
		"healing": card.effect_healing,
		"armor": card.effect_armor,
		"witchpower": card.effect_witchpower,
		"counting": card.effect_counting,
	}}
