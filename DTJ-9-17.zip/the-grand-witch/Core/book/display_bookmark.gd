extends PanelContainer
class_name BookmarkDisplay

@onready var card: BookmarkCard = get_parent()
@onready var title_label: Label = $TextureRect/TitleLabel
@onready var pages_vbox: VBoxContainer = $TextureRect/PagesVBox

const BORDER_COLOR := Color(1, 0.8, 0, 1)
const BORDER_WIDTH := 4

var default_style: StyleBox
var page_labels: Array[Label] = []

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	default_style = get_theme_stylebox("panel")
	title_label.add_theme_font_size_override("font_size", 28)

	card.selection_changed.connect(_on_selection_changed)
	card.cd_changed.connect(_on_cd_changed)
	card.data_changed.connect(_on_data_changed)

	if card.Generator_bookmark:
		_refresh_all()
		_on_cd_changed(card.current_cd)

func _refresh_all() -> void:
	title_label.text = card.Generator_bookmark.title
	_rebuild_page_labels()

func _rebuild_page_labels() -> void:
	for child in pages_vbox.get_children():
		child.queue_free()
	page_labels.clear()
	for page in card.Generator_bookmark.pages:
		var label = Label.new()
		label.text = page.page_name
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.add_theme_font_size_override("font_size", 18)
		label.modulate = Color(1, 1, 1)
		pages_vbox.add_child(label)
		page_labels.append(label)

func get_page_label_by_index(idx: int) -> Label:
	if idx >= 0 and idx < page_labels.size():
		return page_labels[idx]
	return null

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if not event.pressed:
			card._on_clicked()

# ==================== 信号响应 ====================
func _on_selection_changed(selected: bool) -> void:
	if selected:
		var style := StyleBoxFlat.new()
		style.bg_color = Color(0, 0, 0, 0)
		style.border_color = BORDER_COLOR
		style.set_border_width_all(BORDER_WIDTH)
		add_theme_stylebox_override("panel", style)
	else:
		add_theme_stylebox_override("panel", default_style)

func _on_cd_changed(cd: int) -> void:
	var gray: Color
	match cd:
		0: gray = Color(1, 1, 1, 1)
		1: gray = Color(0.7, 0.7, 0.7, 1)
		2: gray = Color(0.5, 0.5, 0.5, 1)
		3: gray = Color(0.4, 0.4, 0.4, 1)
		_: gray = Color(0.2, 0.2, 0.2, 1)
	modulate = gray
	mouse_filter = Control.MOUSE_FILTER_IGNORE if cd > 0 else Control.MOUSE_FILTER_STOP

func _on_data_changed() -> void:
	_refresh_all()
