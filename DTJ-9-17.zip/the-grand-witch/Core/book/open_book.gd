extends Control
## 主场景的卡组互动逻辑

@onready var bookmark_container: Node = $disply_bookmark
@onready var open_book_button: Button = $open

var book_instance: Node = null
var selected_cards: Array[BookmarkCard] = []
var max_selected: int = 1   # 最多选择一张，可修改



func _ready() -> void:
	var bm = GlobalBookMark
	bm.bookmark_added.connect(_on_bookmark_added)
	bm.bookmark_removed.connect(_on_bookmark_removed)
	_refresh_bookmark_display()
	open_book_button.pressed.connect(_on_open_book_pressed)

func _on_bookmark_added(_data) -> void:
	_refresh_bookmark_display()

func _on_bookmark_removed(_data) -> void:
	_refresh_bookmark_display()

func _refresh_bookmark_display() -> void:
	# 清除旧节点
	for child in bookmark_container.get_children():
		bookmark_container.remove_child(child)
		child.queue_free()
	# 清空选择状态
	selected_cards.clear()
	# 重新构建卡片
	var bm = GlobalBookMark
	for Generator_bookmark in bm.bookmarks:
		var card = GlobalScenes.BOOKMARK_CARD_SCENE.instantiate()
		bookmark_container.add_child(card)
		card.setup(Generator_bookmark)

func _on_open_book_pressed() -> void:
	book_instance = GlobalScenes.BOOK_SCENE.instantiate()
	if book_instance is Control:
		book_instance.anchor_left = 0.0
		book_instance.anchor_top = 0.0
		book_instance.anchor_right = 1.0
		book_instance.anchor_bottom = 1.0
		book_instance.offset_left = 0
		book_instance.offset_top = 0
		book_instance.offset_right = 0
		book_instance.offset_bottom = 0
		book_instance.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(book_instance)
	
		
func _on_book_closed() -> void:
	book_instance = null
