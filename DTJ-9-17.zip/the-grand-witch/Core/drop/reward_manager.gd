extends Node
## 奖励场景主控：跑管道修改掉落，调 RewardPopup 显示

const REWARD_POPUP_SCENE = preload("res://scenes/RewardPopup.tscn")

@onready var reward_popup = $Background

func setup(monster: Generator_monster, gold: int, accessories: Array, cards: Array, on_done: Callable) -> void:
	var accs: Array[Generator_accessories] = []
	accs.assign(accessories)
	var card_list: Array[Generator_bookpage] = []
	card_list.assign(cards)

	var pipeline = _run_pipeline(gold, accs, card_list)

	reward_popup.setup_rewards(gold, pipeline.accessories, card_list, pipeline.blocked_flags)
	reward_popup.closed.connect(func():
		on_done.call(pipeline.triggered)
	)

func _run_pipeline(gold: int, accessories: Array[Generator_accessories], cards: Array[Generator_bookpage]) -> Dictionary:
	var block_count = 0
	var effect_id = ""
	for source in [GlobalContract, GlobalPassive, GlobalAccessories]:
		for effect in source.get_reward_effects():
			if effect.get("type", "") == "accessories":
				var bc = effect.get("block_count", 0)
				if bc > 0:
					block_count += bc
					effect_id = effect.get("effect_id", "")

	var blocked_flags: Array[bool] = []
	for i in range(accessories.size()):
		blocked_flags.append(false)

	var triggered = false
	var remaining = block_count
	for i in range(accessories.size()):
		if remaining <= 0:
			break
		blocked_flags[i] = true
		remaining -= 1
		for source in [GlobalContract, GlobalPassive, GlobalAccessories]:
			if source.consume_reward_block(effect_id, 1):
				triggered = true

	return {
		"accessories": accessories,
		"blocked_flags": blocked_flags,
		"triggered": triggered,
	}

# ==================== 目标奖励 ====================
func _open_target_reward(on_closed: Callable) -> void:
	var target = GlobalContract.get_target_accessory()
	var accs: Array[Generator_accessories] = []
	if target:
		accs.append(target)

	var popup = REWARD_POPUP_SCENE.instantiate()
	add_child(popup)
	popup.setup_rewards(0, accs, [], [])
	popup.closed.connect(func(): on_closed.call())
