extends Control
class_name RewardPopup

signal closed

@onready var background: TextureRect = $"."
@onready var title_label: Label = $TitleLabel
@onready var return_button: Button = $ReturnButton
@onready var loot_vbox: VBoxContainer = $LootVBox

var gold_amount: int = 0
var accessories: Array[Generator_accessories] = []
var cards: Array[Generator_bookpage] = []
var blocked_flags: Array[bool] = []

func _ready():
	return_button.pressed.connect(_on_return_pressed)
	title_label.text = "战利品"

func setup_rewards(gold: int, accs: Array[Generator_accessories], card_list: Array = [], flags: Array[bool] = []) -> void:
	gold_amount = gold
	accessories = accs
	cards.clear()
	for c in card_list:
		cards.append(c)
	blocked_flags = flags
	if is_inside_tree():
		_populate_rewards()
	else:
		call_deferred("_populate_rewards")

func _populate_rewards():
	for child in loot_vbox.get_children():
		child.queue_free()

	if gold_amount > 0:
		var gold_btn = Button.new()
		gold_btn.text = "金币 x%d" % gold_amount
		gold_btn.pressed.connect(_on_gold_pressed.bind(gold_btn))
		loot_vbox.add_child(gold_btn)

	for i in range(accessories.size()):
		var acc = accessories[i]
		var acc_btn = Button.new()
		acc_btn.text = acc.name
		acc_btn.icon = acc.icon
		var is_blocked = i < blocked_flags.size() and blocked_flags[i]
		if is_blocked:
			acc_btn.modulate = Color(0.5, 0.5, 0.5)
		acc_btn.pressed.connect(_on_acc_pressed.bind(acc_btn, acc, is_blocked))
		loot_vbox.add_child(acc_btn)

	for card in cards:
		var page_btn = Button.new()
		page_btn.text = card.page_name
		page_btn.icon = card.icon
		page_btn.pressed.connect(_on_page_pressed.bind(page_btn, card))
		loot_vbox.add_child(page_btn)

func _on_gold_pressed(gold_btn: Button):
	GlobalPlayer.add_gold(gold_amount)
	gold_btn.queue_free()

func _on_acc_pressed(acc_btn: Button, acc: Generator_accessories, is_blocked: bool):
	if is_blocked:
		GlobalPlayer.show("被契约阻挡")
		return
	GlobalAccessories.add_accessories(acc)
	acc_btn.queue_free()

func _on_page_pressed(page_btn: Button, card: Generator_bookpage):
	GlobalCardLibrary.add_acquired_count(card.book_id, 1)
	page_btn.queue_free()

func _on_return_pressed():
	emit_signal("closed")
	queue_free()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_on_return_pressed()
		get_viewport().set_input_as_handled()
