extends Node
## 游戏内时间与天数

signal time_changed(total_minutes)
signal time_units_added(units)

const TIME_UNIT := 5
var total_minutes: int = 6 * 60
var day: int = 1

func add_time_units(units: int) -> void:
	total_minutes += units * TIME_UNIT
	time_changed.emit(total_minutes)
	time_units_added.emit(units)

func reset() -> void:
	total_minutes = 6 * 60
	day = 1
	time_changed.emit(total_minutes)

func get_time() -> int:
	return total_minutes

func get_formatted_time() -> String:
	var h = total_minutes / 60
	var m = total_minutes % 60
	return "%02d:%02d" % [h, m]

func get_day() -> int:
	return day
