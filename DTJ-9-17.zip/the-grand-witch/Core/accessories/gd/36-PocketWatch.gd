extends Generator_PassiveEffect
class_name BlockChargeEffect

var block_charges: int = 0
var block_charge_timer: int = 0
var max_charges: int = 1
var time_threshold: int = 60

func setup(acc: Generator_accessories) -> void:
	max_charges = max(1, acc.block_charges)

func on_time_changed(units: int) -> void:
	if block_charges < max_charges:
		block_charge_timer += units * 5
		if block_charge_timer >= time_threshold:
			block_charges += 1
			block_charge_timer = 0

func try_consume_block() -> bool:
	if block_charges > 0:
		block_charges -= 1
		block_charge_timer = 0
		return true
	return false

func get_block_charge() -> int:
	return block_charges
