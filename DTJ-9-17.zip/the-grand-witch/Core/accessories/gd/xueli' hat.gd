extends Generator_PassiveEffect
class_name DetectiveHatEffect

var insight_stacks: int = 0
var recorded_types: Array = []

func modify_damage_multiplier(_enemy_wp: int) -> float:
	if insight_stacks > 0:
		return 1.0 + 0.1 * insight_stacks
	return 1.0

func on_page_played(mark: Dictionary) -> void:
	recorded_types.clear()
	var types = mark.get("page_type", [])
	for t in types:
		recorded_types.append(t)

func on_enemy_page_used(types: Array) -> void:
	for t in types:
		if t in recorded_types:
			insight_stacks += 1
			break

func clear_insight() -> void:
	insight_stacks = 0
