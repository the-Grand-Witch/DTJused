extends Generator_PassiveEffect
class_name DoubleNextPageEffect

## 每隔一回合触发一次：该回合下一个打出的书页数值 ×2

func on_turn_start(turn_count: int) -> Array:
	if turn_count % 2 == 1:
		return [{"effect": "overall_multiplier_pending", "condition": {}, "value": 2.0}]
	return []
