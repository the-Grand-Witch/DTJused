extends Node
## 战斗主控制器：通用流程 + 根据场景分派特殊逻辑

@onready var player_ui = $Player
@onready var battle_calculator = $BattleCalculator
@onready var battle_state: BattleState = $BattleState
@onready var turn_label: Label = $TurnLabel
@onready var end_turn_button: Button = $EndTurnButton

var special: Node

func _ready():
	if has_node("Monster"):
		special = $Monster/Nomel
	elif has_node("Boss"):
		special = $Boss
	special.battle_main = self
	special.setup()

	battle_state.reset_battle()
	_create_player_cards()
	end_turn_button.pressed.connect(_on_end_turn_pressed)
	player_ui.cancel_requested.connect(_cancel_all_selections)
	GlobalPassive.notify_battle_start()
	_start_round()
	_update_player_buffs()

func _create_player_cards():
	player_ui.clear_hand()
	battle_state.player_cards.clear()
	for data in GlobalBookMark.bookmarks:
		var card = GlobalScenes.BOOKMARK_CARD_SCENE.instantiate()
		player_ui.add_card(card)
		card.setup(data)
		card.selection_changed.connect(_on_player_card_selected.bind(card))
		card.card_confirmed.connect(_on_card_confirmed)
		battle_state.player_cards.append(card)

func _on_player_card_selected(selected: bool, card: BookmarkCard):
	if selected:
		if battle_state.player_selected_cards.size() >= battle_state.max_selected:
			var oldest = battle_state.player_selected_cards[0]
			battle_state.player_selected_cards.erase(oldest)
			oldest.set_selected(false)
		battle_state.player_selected_cards.append(card)
	else:
		battle_state.player_selected_cards.erase(card)

func _on_card_confirmed(card: BookmarkCard):
	if card in battle_state.player_selected_cards:
		_on_end_turn_pressed()

func _cancel_all_selections() -> void:
	for card in battle_state.player_selected_cards:
		card.set_selected(false)
	battle_state.player_selected_cards.clear()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_SPACE:
			if not battle_state.player_selected_cards.is_empty():
				_on_end_turn_pressed()
				get_viewport().set_input_as_handled()
		elif event.keycode == KEY_Q:
			_cancel_all_selections()
			get_viewport().set_input_as_handled()

func _start_round():
	battle_state.turn_count += 1
	turn_label.text = "回合 %d" % battle_state.turn_count

	# 先更新所有被动的回合钩子（含心衰更新）
	var effects = GlobalPassive.get_turn_effects(battle_state.turn_count)

	if battle_state.heal_count > 0:
		GlobalPlayer.heal(battle_state.heal_count)

	for card in battle_state.player_cards:
		card.reset_round_modifiers()

	battle_state.reset_round()
	_update_player_buffs()

	for card in battle_state.player_cards:
		card.decrease_cooldown()

	var impulse_count = GlobalPlayer.get_impulse_count()
	GlobalPassive.apply_impulses(battle_state.player_cards, impulse_count)
	player_ui.refresh_impulse_visual(battle_state.player_cards)

	battle_state.used_ability_pages.clear()

	_apply_turn_effects(effects)

	special.on_round_start(battle_state.turn_count)

func _on_end_turn_pressed():
	GlobalTime.add_time_units(1)

	for card in battle_state.player_selected_cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			battle_state.consume_pending(card.get_page_mark(idx))

	var player_result = battle_calculator.calculate_player_effects(
		battle_state.player_selected_cards,
		battle_state,
		player_ui,
		special.enemy_witch_power()
	)
	battle_state.player_attack_bonus = player_result.attack_bonus
	_update_player_buffs()
	
	GlobalPassive.clear_insight()

	special.enemy_take_damage(player_result.damage)
	if special.is_enemy_dead():
		end_turn_button.disabled = true
		special.on_enemy_defeated()
		return

	if player_result.healing > 0:
		GlobalPlayer.heal(player_result.healing)

	if player_result.witch_power != 0:
		GlobalPlayer.possessed(player_result.witch_power)

	GlobalPassive.punish_unused_impulses(battle_state.player_cards)
	player_ui.refresh_impulse_visual(battle_state.player_cards)

	for card in battle_state.player_cards:
		if card not in battle_state.player_selected_cards:
			for page in card.Generator_bookmark.pages:
				if "疯狂" in page.keywords:
					GlobalPlayer.possessed(1)
					break

	special.enemy_take_turn(player_result.armor + battle_state.armor_count)

	if GlobalPlayer.health <= 0:
		GlobalScenes.check_game_over()
		return

	battle_state.clear_round_end()
	_update_player_buffs()

	GlobalPassive.notify_turn_end(battle_state.turn_count)
	_start_round()

func _update_player_buffs():
	var statuses = battle_state.player_status_dict.duplicate()
	var accessories_bonus = _get_accessories_attack_bonus()
	if accessories_bonus > 0:
		statuses["accessories_attack"] = accessories_bonus
	if battle_state.harmony_stacks > 0:
		statuses["harmony"] = battle_state.harmony_stacks
	if battle_state.armor_count > 0:
		statuses["armor_per_turn"] = battle_state.armor_count
	player_ui.update_buffs(statuses, battle_state.ability_buffs)

func _get_accessories_attack_bonus() -> int:
	var bonus = 0
	for acc in GlobalAccessories.accessories:
		bonus += acc.attack_bonus
	return bonus

func _apply_turn_effects(effects: Array) -> void:
	for effect_data in effects:
		var condition: Dictionary = effect_data.get("condition", {})
		for card in battle_state.player_cards:
			for mark in card.get_all_marks():
				if _match_condition(mark, condition):
					battle_state.apply_effect(effect_data, mark)

func _match_condition(mark: Dictionary, condition: Dictionary) -> bool:
	for key in condition:
		if mark.get(key) != condition[key]:
			return false
	return true
