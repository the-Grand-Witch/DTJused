extends Node
class_name BattleState

var turn_count: int = 0
var player_attack_bonus: int = 0
var heal_count: int = 0
var armor_count: int = 0
var harmony_stacks: int = 0
var harmony_save: int = 0
var pending_effect: String = ""
var pending_value: float = 0.0
var max_selected: int = 1
var player_cards: Array[BookmarkCard] = []
var player_selected_cards: Array[BookmarkCard] = []
var player_status_dict: Dictionary = {}
var used_ability_pages: Array = []
var ability_buffs: Array = []
var used_pages: Dictionary = {}

# ==================== used / use_count ====================
func _key(card: BookmarkCard, page_index: int) -> String:
	return "%d:%d" % [card.get_instance_id(), page_index]

func record_use(card: BookmarkCard, page_index: int) -> void:
	card.page_marks[page_index]["use_count"] += 1

func mark_used(card: BookmarkCard, page_index: int) -> void:
	used_pages[_key(card, page_index)] = true

func is_used(card: BookmarkCard, page_index: int) -> bool:
	return used_pages.get(_key(card, page_index), false)

func clear_used() -> void:
	used_pages.clear()

# ==================== 页数值 ====================
func set_page_value(card: BookmarkCard, page_index: int, field: String, value) -> void:
	if is_used(card, page_index):
		return
	var v = card.get_values(page_index)
	v[field] = value

func add_page_value(card: BookmarkCard, page_index: int, field: String, delta) -> void:
	if is_used(card, page_index):
		return
	var v = card.get_values(page_index)
	v[field] = v.get(field, 0) + delta

# ==================== play_count / overall ====================
func add_play_count(card: BookmarkCard, page_index: int, n: int) -> void:
	var mark = card.get_page_mark(page_index)
	mark["play_count"] = mark.get("play_count", 1) + n

func multiply_overall(card: BookmarkCard, page_index: int, m: float) -> void:
	var mark = card.get_page_mark(page_index)
	mark["overall_multiplier"] = mark.get("overall_multiplier", 1.0) * m

func add_overall(card: BookmarkCard, page_index: int, s: int) -> void:
	var mark = card.get_page_mark(page_index)
	mark["overall_sum"] = mark.get("overall_sum", 0) + s

# ==================== 回合转换 ====================
func reset_round() -> void:
	harmony_stacks = harmony_save
	harmony_save = 0

func clear_round_end() -> void:
	harmony_stacks = 0

# ==================== 效果标记 ====================
## effect_data: {"effect": "xxx" 或 "xxx_pending", "condition": {...}, "value": 数值}
func apply_effect(effect_data: Dictionary, mark: Dictionary) -> void:
	var effect_name: String = effect_data.get("effect", "")
	if effect_name == "":
		return
	if effect_name.ends_with("_pending"):
		pending_effect = effect_name.replace("_pending", "")
		pending_value = effect_data.get("value", 0)
		return
	if not mark.has("effects"):
		mark["effects"] = {}
	mark["effects"][effect_name] = true

func consume_pending(mark: Dictionary) -> bool:
	if pending_effect == "":
		return false
	match pending_effect:
		"overall_multiplier":
			mark["overall_multiplier"] = mark.get("overall_multiplier", 1.0) * pending_value
		"overall_sum":
			mark["overall_sum"] = mark.get("overall_sum", 0) + int(pending_value)
		"play_count":
			mark["play_count"] = mark.get("play_count", 1) + int(pending_value)
		_:
			if not mark.has("effects"):
				mark["effects"] = {}
			mark["effects"][pending_effect] = true
	pending_effect = ""
	pending_value = 0.0
	return true

# ==================== 战斗重置 ====================
func reset_battle() -> void:
	turn_count = 0
	player_attack_bonus = 0
	heal_count = 0
	armor_count = 0
	harmony_stacks = 0
	harmony_save = 0
	pending_effect = ""
	pending_value = 0.0
	player_cards.clear()
	player_selected_cards.clear()
	player_status_dict.clear()
	used_ability_pages.clear()
	used_pages.clear()
	ability_buffs.clear()

# ==================== 调试 ====================
func printf() -> void:
	print("[State] attack_bonus=%d heal_count=%d armor_count=%d harmony=%d/%d pending=%s" % [
		player_attack_bonus,
		heal_count,
		armor_count,
		harmony_stacks,
		harmony_save,
		pending_effect,
	])
