extends Node
## 战斗数值计算：编入 → 使用 → 结束 → 结算

@onready var battle_state: BattleState = $"../BattleState"

func calculate_player_effects(cards: Array[BookmarkCard], battle_state: BattleState, player_ui, enemy_witch_power: int) -> Dictionary:
	# ========== 编入阶段（一次） ==========
	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			_run_page_effects(card, idx, "enter", cards, battle_state)

	# ========== 使用阶段（play_count 次） ==========
	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			var page = card.Generator_bookmark.pages[idx]
			if not GlobalPassive.is_page_available(page):
				continue
			var mark = card.get_page_mark(idx)
			if not mark.has("snapshots"):
				mark["snapshots"] = []
			var played = 0
			while played < mark.get("play_count", 1):
				_run_page_effects(card, idx, "use", cards, battle_state)
				_run_keywords(card, idx, cards, battle_state, enemy_witch_power)
				battle_state.record_use(card, idx)
				_record_snapshot(card, idx)
				played += 1
			battle_state.mark_used(card, idx)

	# ========== 结束阶段（一次） ==========
	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			_run_page_effects(card, idx, "end", cards, battle_state)

	# ========== 结算 ==========
	var result = _aggregate(cards, battle_state, enemy_witch_power)

	# ========== 清理 ==========
	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			var mark = card.get_page_mark(idx)
			mark["overall_multiplier"] = 1.0
			mark["overall_sum"] = 0
			mark["play_count"] = 1
			mark["snapshots"] = []

	for card in cards:
		card.set_selected(false)
		card.start_cooldown()

	player_ui.refresh_impulse_visual(cards)
	printf(result)
	return result

# ==================== 快照 ====================
func _record_snapshot(card: BookmarkCard, idx: int) -> void:
	var mark = card.get_page_mark(idx)
	var snap = {
		"values": card.get_values(idx).duplicate(),
		"mult": mark.get("overall_multiplier", 1.0),
		"sum": mark.get("overall_sum", 0),
	}
	mark["snapshots"].append(snap)
	mark["overall_multiplier"] = 1.0
	mark["overall_sum"] = 0

# ==================== 效果脚本 ====================
func _run_page_effects(card: BookmarkCard, idx: int, phase: String, all_cards: Array, battle_state: BattleState) -> void:
	var page = card.Generator_bookmark.pages[idx]
	if page.page_effects.is_empty():
		return
	var context = _build_context(card, idx, all_cards, battle_state, phase)
	for effect_script in page.page_effects:
		if effect_script == null:
			continue
		var script_obj = effect_script.new()
		match phase:
			"enter":
				if script_obj.has_method("on_enter"):
					script_obj.on_enter(context)
			"use":
				if script_obj.has_method("on_use"):
					script_obj.on_use(context)
			"end":
				if script_obj.has_method("on_end"):
					script_obj.on_end(context)

# ==================== 关键词 ====================
func _run_keywords(card: BookmarkCard, idx: int, all_cards: Array, battle_state: BattleState, enemy_witch_power: int) -> void:
	var page = card.Generator_bookmark.pages[idx]
	if page.keywords.is_empty():
		return
	var mark = card.get_page_mark(idx)
	var has_impulse = GlobalPassive.has_impulse(card, idx)
	for keyword in page.keywords:
		var context = {
			"card": page,
			"bookmark": card.Generator_bookmark,
			"player_cards": all_cards,
			"player_attack_bonus": battle_state.player_attack_bonus,
			"has_impulse": has_impulse,
			"enemy_witch_power": enemy_witch_power,
			"battle_state": battle_state,
		}
		var keyword_result = GlobalKeywordDict.execute_keyword(keyword, context)
		var add = keyword_result.get("add", {})
		for field in add:
			battle_state.add_page_value(card, idx, field, add[field])
		if keyword_result.get("harmony_triggered", false):
			GlobalPassive.notify_harmony_triggered(mark, card)

# ==================== 结算 ====================
func _aggregate(cards: Array[BookmarkCard], battle_state: BattleState, enemy_witch_power: int) -> Dictionary:
	var result = {
		"damage": 0,
		"healing": 0,
		"armor": 0,
		"attack_bonus": battle_state.player_attack_bonus,
		"witch_power": 0,
	}
	var total_attack_bonus = battle_state.player_attack_bonus + _get_accessories_attack_bonus()

	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			var mark = card.get_page_mark(idx)
			var types = card.Generator_bookmark.pages[idx].page_type
			var snapshots = mark.get("snapshots", [])

			for snap in snapshots:
				var v = snap["values"]
				var mult = snap["mult"]
				var sum = snap["sum"]

				if Generator_bookpage.PickupType.Attack in types:
					var base = v.get("damage", 0) + v.get("effect_damage", 0) + total_attack_bonus + sum
					var dmg = int(ceil(base * mult))
					result.damage += dmg

				if Generator_bookpage.PickupType.Heal in types:
					var heal = int(round((v.get("healing", 0) + v.get("effect_healing", 0) + sum) * mult))
					result.healing += heal

				if Generator_bookpage.PickupType.Defense in types:
					var armor = int(round((v.get("armor", 0) + v.get("effect_armor", 0) + sum) * mult))
					result.armor += armor

				if Generator_bookpage.PickupType.Witch in types:
					var wp = int(round((v.get("witchpower", 0) + v.get("effect_witchpower", 0) + sum) * mult))
					result.witch_power += wp

				if Generator_bookpage.PickupType.Ability in types:
					var counting = (v.get("counting", 0) + v.get("effect_counting", 0) + sum) * mult
					var ability_result = _call_ability_scripts(card, idx, counting)
					for key in ability_result:
						var value = int(ability_result[key])
						if result.has(key):
							result[key] += value
						elif key == "heal_count":
							battle_state.heal_count += value
					var ability_page = card.Generator_bookmark.pages[idx]
					if ability_page.buff_icon:
						battle_state.ability_buffs.append({
							"icon": ability_page.buff_icon,
							"count": int(counting),
						})

	return result

func _call_ability_scripts(card: BookmarkCard, idx: int, counting: float) -> Dictionary:
	var page = card.Generator_bookmark.pages[idx]
	var combined = {}
	for effect_script in page.page_effects:
		if effect_script == null:
			continue
		var script_obj = effect_script.new()
		if script_obj.has_method("on_ability"):
			var r = script_obj.on_ability({"counting": counting, "self_card": card, "self_index": idx})
			if r is Dictionary:
				for key in r:
					combined[key] = combined.get(key, 0) + r[key]
	return combined

# ==================== context ====================
func _build_context(card: BookmarkCard, idx: int, all_cards: Array, battle_state: BattleState, phase: String) -> Dictionary:
	return {
		"self_card": card,
		"self_index": idx,
		"self_page": card.Generator_bookmark.pages[idx],
		"self_values": card.get_values(idx),
		"all_cards": all_cards,
		"set_self": func(field, value): battle_state.set_page_value(card, idx, field, value),
		"add_self": func(field, delta): battle_state.add_page_value(card, idx, field, delta),
		"get_of": func(target_card, target_idx): return target_card.get_values(target_idx),
		"set_of": func(target_card, target_idx, field, value): battle_state.set_page_value(target_card, target_idx, field, value),
		"add_of": func(target_card, target_idx, field, delta): battle_state.add_page_value(target_card, target_idx, field, delta),
		"add_play_count": func(target_card, target_idx, n): battle_state.add_play_count(target_card, target_idx, n),
		"multiply_overall": func(target_card, target_idx, m): battle_state.multiply_overall(target_card, target_idx, m),
		"add_overall": func(target_card, target_idx, s): battle_state.add_overall(target_card, target_idx, s),
		"battle_state": battle_state,
		"phase": phase,
	}

# ==================== 其他 ====================
func _get_accessories_attack_bonus() -> int:
	var bonus = 0
	for acc in GlobalAccessories.accessories:
		bonus += acc.attack_bonus
	return bonus

func calculate_monster_attack(monster_attack: int, player_armor: int) -> Dictionary:
	var actual_damage = max(monster_attack - player_armor, 0)
	return {"damage_dealt": actual_damage}

# ==================== 调试 ====================
func printf(result: Dictionary) -> void:
	print("========== [Calc] ==========")
	for key in result:
		print("  %s = %s" % [key, result[key]])
	print("============================")
