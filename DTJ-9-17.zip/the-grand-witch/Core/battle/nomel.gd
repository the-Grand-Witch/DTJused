extends Node
## 普通战斗特殊逻辑

signal monster_defeated

@onready var monster_manager = $".."


var battle_main: Node
var loot_bonus: int = 0

func setup():
	monster_manager.load_random_monster()
	monster_manager.setup_ui()

func on_round_start(_turn_count: int):
	pass

func enemy_witch_power() -> int:
	return 0

func enemy_take_damage(amount: int):
	monster_manager.take_damage(amount)

func is_enemy_dead() -> bool:
	return monster_manager.is_dead()

func on_enemy_defeated():
	var monster = monster_manager.get_current_monster()
	var gold = randi_range(monster.min_gold, monster.max_gold)
	var dropped_accessories: Array[Generator_accessories] = []

	if monster.fixed_drop_id != -1:
		var fixed_acc = _get_any_accessories_by_id(monster.fixed_drop_id)
		if fixed_acc and not GlobalAccessories.has_accessories(fixed_acc.acc_id):
			dropped_accessories.append(fixed_acc)

	var candidates: Array[Generator_accessories] = []
	for acc in GlobalAccessories.all_accessories:
		if acc.acc_id >= monster.accessories_id_min and acc.acc_id <= monster.accessories_id_max:
			if not GlobalAccessories.has_accessories(acc.acc_id):
				candidates.append(acc)

	var count = monster.random_drop_count + loot_bonus
	count = min(count, candidates.size())
	for i in range(count):
		var idx = randi() % candidates.size()
		var acc = candidates[idx]
		candidates.remove_at(idx)
		dropped_accessories.append(acc)

	var on_closed = func(): GlobalScenes.return_to_previous()
	GlobalScenes.show_reward(monster, gold, dropped_accessories, [], on_closed)

	emit_signal("monster_defeated")

func _get_any_accessories_by_id(acc_id: int) -> Generator_accessories:
	for acc in GlobalAccessories.all_accessories:
		if acc.acc_id == acc_id:
			return acc
	return null

func enemy_take_turn(player_armor: int):
	var result = battle_main.battle_calculator.calculate_monster_attack(
		monster_manager.get_attack(),
		player_armor
	)
	if result.damage_dealt > 0:
		GlobalPlayer.take_damage(result.damage_dealt)
	# 通知被动：怪物使用了 Attack 类型
	GlobalPassive.notify_enemy_page_used([Generator_bookpage.PickupType.Attack])

func increase_loot_bonus(amount: int):
	loot_bonus += amount
