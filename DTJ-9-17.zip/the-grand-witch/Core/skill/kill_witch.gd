@tool
extends Generator_PassiveEffect
class_name KillWitchPassive

## 覆写伤害倍率方法，实现你的“kill_witch”效果
func modify_damage_multiplier(enemy_witch_power: int) -> float:
	var max_wp = GlobalPlayer.max_witch_power + GlobalAccessories.get_witch_max_increase()
	var e = clamp(enemy_witch_power, 0, max_wp)
	var s = clamp(GlobalPlayer.witch_power, 0, max_wp)
	var multiplier = 1.0 + (e * s) / 10000.0
	return multiplier
	
