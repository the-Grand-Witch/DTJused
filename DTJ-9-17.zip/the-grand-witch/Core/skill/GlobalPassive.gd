extends Node
## 全局被动：注册被动、广播钩子、转发查询

var character_passive: Generator_PassiveEffect
var accessories_passives: Array[Generator_PassiveEffect] = []
var accessories_passive_map: Dictionary = {}

var impulse_immune: bool = false
var insight_stacks: int = 0

func _ready():
	character_passive = Generator_PassiveEffect.new()
	GlobalPlayer.character_changed.connect(_on_character_changed)
	GlobalAccessories.accessories_added.connect(_on_accessories_added)
	GlobalAccessories.accessories_removed.connect(_on_accessories_removed)
	GlobalTime.time_units_added.connect(_on_time_units_added)

func _on_character_changed(character: Generator_girl):
	if character == null:
		return
	if character.passive:
		character_passive = character.passive

func _on_accessories_added(acc: Generator_accessories):
	if acc == null:
		return
	if acc.effect_script:
		var instance = acc.effect_script.new()
		if instance.has_method("setup"):
			instance.setup(acc)
		accessories_passives.append(instance)
		accessories_passive_map[acc.acc_id] = instance

func _on_accessories_removed(acc_id: int):
	if accessories_passive_map.has(acc_id):
		var instance = accessories_passive_map[acc_id]
		accessories_passives.erase(instance)
		accessories_passive_map.erase(acc_id)

# ==================== 被动获取 ====================
func get_passive() -> Generator_PassiveEffect:
	return character_passive

func set_passive(passive: Generator_PassiveEffect) -> void:
	character_passive = passive

# ==================== 事件钩子广播 ====================
func is_page_available(page: Generator_bookpage) -> bool:
	if not character_passive.is_page_available(page):
		return false
	for p in accessories_passives:
		if not p.is_page_available(page):
			return false
	return true

func notify_battle_start() -> void:
	impulse_immune = false
	character_passive.on_battle_start()
	for p in accessories_passives:
		p.on_battle_start()

func get_turn_effects(turn_count: int) -> Array:
	var effects: Array = []
	effects.append_array(character_passive.on_turn_start(turn_count))
	for p in accessories_passives:
		effects.append_array(p.on_turn_start(turn_count))
	return effects

func notify_turn_end(turn_count: int) -> void:
	character_passive.on_turn_end(turn_count)
	for p in accessories_passives:
		p.on_turn_end(turn_count)

func notify_page_played(mark: Dictionary) -> void:
	character_passive.on_page_played(mark)
	for p in accessories_passives:
		p.on_page_played(mark)

func notify_damage_taken(amount: int) -> void:
	character_passive.on_damage_taken(amount)
	for p in accessories_passives:
		p.on_damage_taken(amount)

func notify_damage_dealt(amount: int) -> void:
	character_passive.on_damage_dealt(amount)
	for p in accessories_passives:
		p.on_damage_dealt(amount)

func notify_heal(amount: int) -> void:
	character_passive.on_heal(amount)
	for p in accessories_passives:
		p.on_heal(amount)

func notify_witch_power_changed(value: int) -> void:
	character_passive.on_witch_power_changed(value)
	for p in accessories_passives:
		p.on_witch_power_changed(value)

func notify_harmony_triggered(page_mark: Dictionary, bookmark_card) -> void:
	character_passive.on_harmony_triggered(page_mark, bookmark_card)
	for p in accessories_passives:
		p.on_harmony_triggered(page_mark, bookmark_card)

func _on_time_units_added(units: int) -> void:
	character_passive.on_time_changed(units)
	for p in accessories_passives:
		p.on_time_changed(units)

func notify_enemy_page_used(types: Array) -> void:
	for p in accessories_passives:
		if p.has_method("on_enemy_page_used"):
			p.on_enemy_page_used(types)

# ==================== 查询转发 ====================
func try_consume_block() -> bool:
	for p in accessories_passives:
		if p.has_method("try_consume_block"):
			if p.try_consume_block():
				return true
	return false

func get_block_charge() -> int:
	var total = 0
	for p in accessories_passives:
		if p.has_method("get_block_charge"):
			total += p.get_block_charge()
	return total

func is_heal_disabled() -> bool:
	if character_passive.has_method("is_heal_disabled"):
		return character_passive.is_heal_disabled()
	return false

func get_heart_failure() -> int:
	if character_passive.has_method("get_heart_failure"):
		return character_passive.get_heart_failure()
	return 0

func clear_insight() -> void:
	for p in accessories_passives:
		if p.has_method("clear_insight"):
			p.clear_insight()

# ==================== 掉落 ====================
func get_reward_effects() -> Array:
	return []

func consume_reward_block(_effect_id: String, _count: int) -> bool:
	return false

# ==================== 冲动 ====================
func apply_impulses(cards: Array[BookmarkCard], count: int) -> void:
	if impulse_immune:
		return
	clear_impulses(cards)
	if count <= 0:
		return

	var priority_pages: Array[Dictionary] = []
	var normal_pages: Array[Dictionary] = []
	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			var page = card.Generator_bookmark.pages[idx]
			if "疯狂" in page.keywords:
				priority_pages.append({"card": card, "page_index": idx})
			elif Generator_bookpage.PickupType.Attack in page.page_type:
				normal_pages.append({"card": card, "page_index": idx})

	var selected_pages: Array[Dictionary] = priority_pages.duplicate()
	while selected_pages.size() < count and not normal_pages.is_empty():
		selected_pages.append(normal_pages.pop_front())

	selected_pages.shuffle()
	for i in range(min(count, selected_pages.size())):
		var entry = selected_pages[i]
		var card: BookmarkCard = entry["card"]
		var idx: int = entry["page_index"]
		var mark = card.get_page_mark(idx)
		if not mark.has("effects"):
			mark["effects"] = {}
		mark["effects"]["impulse"] = true

func clear_impulses(cards: Array[BookmarkCard]) -> void:
	for card in cards:
		for mark in card.get_all_marks():
			if mark.has("effects"):
				mark["effects"].erase("impulse")

func has_impulse(card: BookmarkCard, page_index: int) -> bool:
	var mark = card.get_page_mark(page_index)
	return mark.get("effects", {}).get("impulse", false)

func consume_impulse(card: BookmarkCard, page_index: int) -> bool:
	var mark = card.get_page_mark(page_index)
	if mark.get("effects", {}).get("impulse", false):
		mark["effects"].erase("impulse")
		return true
	return false

func punish_unused_impulses(cards: Array[BookmarkCard]) -> void:
	for card in cards:
		for mark in card.get_all_marks():
			if mark.get("effects", {}).get("impulse", false):
				GlobalPlayer.possessed(GlobalPlayer.get_impulse_punishment())
				mark["effects"].erase("impulse")

# ==================== 重置 ====================
func reset() -> void:
	character_passive = Generator_PassiveEffect.new()
	accessories_passives.clear()
	accessories_passive_map.clear()
	impulse_immune = false
