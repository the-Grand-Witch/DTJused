@tool
extends Generator_PassiveEffect
class_name XueliPassive

var heart_failure: int = 0

# 心衰六档
const HF_ABILITY_DISABLE := 22
const HF_ARMOR_HALF := 29
const HF_HEAL_DISABLE := 37
const HF_DAMAGE_075 := 52
const HF_ARMOR_ZERO := 60
const HF_DAMAGE_ZERO := 90

func on_battle_start() -> void:
	GlobalPassive.impulse_immune = true

func on_turn_start(_turn_count: int) -> Array:
	heart_failure = int(GlobalPlayer.witch_power / 10)
	return []

func is_page_available(page: Generator_bookpage) -> bool:
	if Generator_bookpage.PickupType.Ability in page.page_type:
		if heart_failure >= HF_ABILITY_DISABLE:
			return false
	return true

# ==================== 数值接口 ====================
## 所有基础伤害 ×1.5，心衰 52 再 ×0.75，心衰 90 归 0
func modify_damage_multiplier(_enemy_witch_power: int) -> float:
	if heart_failure >= HF_DAMAGE_ZERO:
		return 0.0
	var mult = 1.5
	if heart_failure >= HF_DAMAGE_075:
		mult *= 0.75
	return mult

## 护甲倍率：心衰 27 减半，心衰 60 归 0
func modify_armor_multiplier() -> float:
	if heart_failure >= HF_ARMOR_ZERO:
		return 0.0
	if heart_failure >= HF_ARMOR_HALF:
		return 0.5
	return 1.0

## 心衰 20 起 ability 失效
func is_ability_disabled() -> bool:
	return heart_failure >= HF_ABILITY_DISABLE

## 心衰 37 起 heal 不可用
func is_heal_disabled() -> bool:
	return heart_failure >= HF_HEAL_DISABLE
