
extends Resource
class_name Generator_bookmark
#书签data数据，定义名称，图像

@export var title: String = ""
@export var icon: Texture2D
@export var pages: Array[Generator_bookpage] = []
