@tool
extends Resource
class_name Generator_bookpage

enum PickupType {
	Attack = 1,
	Defense = 2,
	Ability = 3,
	Heal = 4,
	Witch = 5,
	friend = 10,
}

@export_group("书页配置")
@export var book_id : int
@export var page_name : String = "未命名卡牌"
@export var icon : Texture2D
@export var description : String = ""
@export var cd : int

@export_group("书页效果")
@export var damage : int = 0
@export var healing : int = 0
@export var armor : int = 0
@export var witchpower : int = 0
@export var counting : int = 0
@export var page_effects: Array[Script] = []

@export_group("特效数值")
@export var effect_damage : int = 0
@export var effect_healing : int = 0
@export var effect_armor : int = 0
@export var effect_witchpower : int = 0
@export var effect_counting : int = 0

@export_group("稀有度")
@export var rarity : int = 0
@export var price : int = 0

@export_group("buff 配置")
@export var buff_icon : Texture2D


@export_group("关键词")
@export var keywords: Array[StringName] = []

@export_group("书页归类")
@export var page_type: Array[PickupType] = []
