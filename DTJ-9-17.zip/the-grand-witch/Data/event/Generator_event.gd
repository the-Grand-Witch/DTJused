@tool
extends Resource
class_name Generator_event

# 事件类型枚举
enum EventType {
	event,
	BATTLE,
	SHOP,
	REST,
	WALK,
	DIG,
	SPECIAL,
}

# === 基础信息 ===
@export_group("基础信息")
@export var event_id: int
@export var event_type: EventType = EventType.WALK
@export var weight: int = 1   #权重
@export var is_special: bool = false    #启用脚本

# === 显示信息 ===
@export_group("显示信息")
@export var event_name: String = "未命名事件"
@export_multiline var description: String = ""
@export var icon: Texture2D

# === 效果调用 ===
@export_group("效果调用")
@export var effect_script: Script
@export var effect_scene: PackedScene
@export var health_change: int = 0
@export var witch_power_change: int = 0
@export var gold_change: int = 0
@export var time_units: int = 1

# === 特殊标记 ===
@export_group("特殊标记")
@export var unique: bool = false
@export var conditions: Array[String] = []
@export_group("场景加载")
@export var is_full_scene: bool = false   # true 表示切换整个场景（如战斗），false 表示作为覆盖层加载（如商店）
# === 动画资源 ===
@export_group("动画资源")
@export var anim_join_frames: SpriteFrames
@export var anim_execute_frames: SpriteFrames
@export var anim_end_frames: SpriteFrames
@export var anim_destroy_frames: SpriteFrames
@export var anim_duration: float = 0.3
