@tool
extends Resource
class_name Generator_PassiveEffect

# 数值修改型
func modify_gold_gain(value: int) -> int:
	return value
func modify_damage_multiplier(enemy_witch_power: int) -> float:
	return 1.0
func modify_witch_power_gain(value: int) -> int:
	return value
func modify_max_health(value: int) -> int:
	return value
func modify_armor_per_turn(value: int) -> int:
	return value
func modify_heal_per_turn(value: int) -> int:
	return value
# 事件钩子，基类默认空
func on_battle_start() -> void:
	pass
func on_turn_start(_turn_count: int) -> Array:
	return []
func on_turn_end(_turn_count: int) -> void:
	pass
func on_page_played(_mark: Dictionary) -> void:
	pass
func on_damage_taken(_amount: int) -> void:
	pass
func on_damage_dealt(_amount: int) -> void:
	pass
func on_heal(_amount: int) -> void:
	pass
func on_witch_power_changed(_value: int) -> void:
	pass
func on_harmony_triggered(_page_mark: Dictionary, _bookmark_card) -> void:
	pass
func on_time_changed(_units: int) -> void:
	pass
func get_description() -> String:
	return ""
func clear_insight() -> void:
	pass

func on_enemy_page_used(_types: Array) -> void:
	pass

func is_page_available(_page: Generator_bookpage) -> bool:
	return true

func modify_armor_multiplier() -> float:
	return 1.0

func is_ability_disabled() -> bool:
	return false

func is_heal_disabled() -> bool:
	return false
