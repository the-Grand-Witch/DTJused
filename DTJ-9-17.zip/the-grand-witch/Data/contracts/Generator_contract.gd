@tool
extends Resource
class_name Generator_contract

## 契约类型
enum PickType {
	INSTANT,      # 立刻：签订后立刻生效，一次性
	PERMANENT,    # 常驻：签订后永久生效
	SHORT_TERM,   # 短线交易：短时间内生效，到期结束
}

@export_group("契约配置")
@export var contract_id: int = 0
@export var pick_type: PickType = PickType.INSTANT

## 商店契约窗口显示的名称
@export var ContractName: String = "未命名契约"

## 签订后显示的效果描述
@export var ContractText: String = "效果说明"


@export_group("效果接口")
## 复杂契约效果脚本，脚本需实现 execute(context) 方法
@export var contract_script: Script
