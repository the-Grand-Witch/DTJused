extends Node
## 最终Boss战场景主控制器

signal boss_defeated

# 模块引用
@onready var enemy = $Enemy
@onready var player_ui = $Player
@onready var turn_label = $TurnLabel
@onready var end_turn_button = $EndTurnButton
@onready var battle_calculator = $BattleCalculator
const BookmarkCardScene = preload("res://scenes/bookmark.tscn")
const NORMAL_SNAPSHOT_DIR := "res://Data/DownloadPlayer/"
const SPECIAL_SNAPSHOT_DIR := "res://Data/DownloadPlayer/special/"

var player_snapshot: PlayerSnapshot
var player_selected_cards: Array[BookmarkCard] = []
var player_cards: Array[BookmarkCard] = []
var player_max_selected: int = 1
var player_attack_bonus: int = 0
var player_status_dict: Dictionary = {}   # 常驻状态：卡牌来源
var turn_count: int = 0

func _ready():
	player_snapshot = _load_random_snapshot()
	enemy.setup(player_snapshot)
	_create_player_cards()
	end_turn_button.pressed.connect(_on_end_turn_pressed)
	player_status_dict.clear()
	_start_round()
	_update_player_buffs()

func _load_random_snapshot() -> PlayerSnapshot:
	var dir_path = SPECIAL_SNAPSHOT_DIR if randf() < 0.05 else NORMAL_SNAPSHOT_DIR
	var files: Array[String] = []
	var dir = DirAccess.open(dir_path)
	dir.list_dir_begin()
	var f = dir.get_next()
	while f != "":
		if not dir.current_is_dir() and f.ends_with(".tres"):
			files.append(dir_path + f)
		f = dir.get_next()
	dir.list_dir_end()
	return load(files[randi() % files.size()]) as PlayerSnapshot

func _create_player_cards():
	player_ui.clear_hand()
	player_cards.clear()
	for data in GlobalBookMark.bookmarks:
		var card = BookmarkCardScene.instantiate()
		player_ui.add_card(card)
		card.setup(data)
		card.selection_changed.connect(_on_player_card_selected.bind(card))
		player_cards.append(card)

func _on_player_card_selected(selected: bool, card: BookmarkCard):
	if selected:
		if player_selected_cards.size() >= player_max_selected:
			var oldest = player_selected_cards[0]
			player_selected_cards.erase(oldest)
			oldest.set_selected(false)
		player_selected_cards.append(card)
	else:
		player_selected_cards.erase(card)

func _start_round():
	turn_count += 1
	turn_label.text = "回合 %d" % turn_count

	# 玩家卡牌冷却递减
	for card in player_cards:
		card.decrease_cooldown()

	# 赋予冲动
	var impulse_count = GlobalPlayer.get_impulse_count()
	player_ui.apply_impulses(player_cards, impulse_count)

	# 敌人回合开始
	enemy.on_round_start(turn_count)

func _on_end_turn_pressed():
	# 收集本回合使用的能力页，累加到常驻状态字典
	for card in player_selected_cards:
		for page in card.bookmark_data.pages:
			if page.pickup_type == Generator_bookpage.PickupType.Ability:
				player_status_dict[page] = player_status_dict.get(page, 0) + 1

	# 玩家结算
	var player_result = battle_calculator.calculate_player_effects(
		player_selected_cards,
		player_attack_bonus,
		player_ui
	)
	player_attack_bonus = battle_calculator.get_player_attack_bonus()

	# 更新玩家状态图标
	_update_player_buffs()

	# 敌人承受伤害
	enemy.take_damage(player_result.damage)
	if enemy.get_health() <= 0:
		_on_boss_defeated()
		return

	# 玩家治疗
	if player_result.healing > 0:
		GlobalPlayer.heal(player_result.healing)

	# 玩家未打出的冲动惩罚
	player_ui.punish_unused_impulses()

	# 敌人回合
	enemy.take_turn(player_result.armor)

	# 检查玩家生命
	if GlobalPlayer.health <= 0:
		GlobalScenes.check_game_over()
		return

	# 进入下一回合
	_start_round()

func _update_player_buffs():
	var statuses = player_status_dict.duplicate()
	var accessory_bonus = 0
	for acc in GlobalAccessories.accessories:
		accessory_bonus += acc.attack_bonus
	if accessory_bonus > 0:
		statuses["accessory_attack"] = accessory_bonus
	player_ui.update_buffs(statuses)

func _on_boss_defeated():
	emit_signal("boss_defeated")

func _on_player_defeated():
	GlobalScenes.check_game_over()
