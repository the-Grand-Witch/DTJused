@tool
extends Resource
class_name Generator_accessories

enum PickupType {
	Heal,
	AttackPower,
	WitchBoost,
	WitchSuppress,
	TakeDamage,
	BookPageCDReload,
	BlockCharges,
	HealthUp,
	girl,
}

@export_group("道具配置")
@export var acc_id : int
@export var pickup_type : PickupType = PickupType.AttackPower
@export var name : String
@export var icon : Texture2D
@export var Tooltip : String = ""
@export var tooltip_font_size : int = 14

@export_group("道具效果")
@export var attack_bonus : int = 0
@export var heal_amount : int = 0
@export var damage_amount : int = 0
@export var bookpage_cd_reload : int = 0
@export var block_charges : int = 0
@export var max_health_bonus : int = 0
@export var witch_max_increase : int = 0
@export var witch_progress_increase : int = 0
@export var witch_penalty_reduce : int = 0
@export var witch_impulse_reduce : int = 0

@export_group("稀有度")
@export var rarity : int = 0   # 0=普通, 1=稀有, 2=史诗
@export_group("价格")
@export var price : int = 0
@export_group("效果脚本")
## 饰品的事件型效果脚本，继承 Generator_PassiveEffect
@export var effect_script: Script
