@tool
extends Resource
class_name Generator_PassiveEffect

## 数值修改型：传入值，返回改后的值，调用方累加
func modify_gold_gain(value: int) -> int:
	return value

func modify_damage_multiplier(enemy_witch_power: int) -> float:
	return 1.0

func modify_witch_power_gain(value: int) -> int:
	return value

func modify_max_health(value: int) -> int:
	return value

func modify_armor_per_turn(value: int) -> int:
	return value

func modify_heal_per_turn(value: int) -> int:
	return value

## 事件型：基类默认空实现
func on_battle_start() -> void:
	pass

func on_turn_start(_turn_count: int) -> Array:
	return []

func on_turn_end(_turn_count: int) -> void:
	pass

func on_page_played(_mark: Dictionary) -> void:
	pass

func on_damage_taken(_amount: int) -> void:
	pass

func on_damage_dealt(_amount: int) -> void:
	pass

func on_heal(_amount: int) -> void:
	pass

func on_witch_power_changed(_value: int) -> void:
	pass

func get_description() -> String:
	return ""
