extends Node
## 负责怪物掉落计算和奖励弹窗显示

const REWARD_POPUP_SCENE = preload("res://scenes/RewardPopup.tscn")

func show_rewards(monster: Generator_monster, loot_bonus: int):
	var gold = randi_range(monster.min_gold, monster.max_gold)
	var dropped_accessories: Array[Generator_accessories] = []

	# 固定掉落
	if monster.fixed_drop_id != -1:
		var fixed_acc = _get_any_accessories_by_id(monster.fixed_drop_id)
		if fixed_acc and not GlobalAccessories.has_accessories(fixed_acc.acc_id):
			dropped_accessories.append(fixed_acc)

	# 随机掉落：从全部饰品中筛选 ID 范围内且未拥有的
	var candidates: Array[Generator_accessories] = []
	for acc in GlobalAccessories.all_accessories:
		if acc.acc_id >= monster.accessories_id_min and acc.acc_id <= monster.accessories_id_max:
			if not GlobalAccessories.has_accessories(acc.acc_id):
				candidates.append(acc)

	var count = monster.random_drop_count + loot_bonus
	count = min(count, candidates.size())
	for i in range(count):
		var idx = randi() % candidates.size()
		var acc = candidates[idx]
		candidates.remove_at(idx)
		dropped_accessories.append(acc)

	var popup = REWARD_POPUP_SCENE.instantiate()
	add_child(popup)
	popup.setup_rewards(gold, dropped_accessories)
	popup.closed.connect(func(): GlobalScenes.return_to_previous())

func _get_any_accessories_by_id(acc_id: int) -> Generator_accessories:
	for acc in GlobalAccessories.all_accessories:
		if acc.acc_id == acc_id:
			return acc
	return null
