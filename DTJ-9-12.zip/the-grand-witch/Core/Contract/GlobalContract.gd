extends Node
## 契约全局管理：扫描契约目录加载全部契约，提供随机获取与去重

const CONTRACT_DIR := "res://Data/contracts/"

var all_contracts: Array[Generator_contract] = []
var signed_ids: Array[int] = []

func _ready():
	_load_all_contracts()


func _load_all_contracts():
	all_contracts.clear()
	var files = ResourceLoader.list_directory(CONTRACT_DIR)
	for file_name in files:
		if file_name.ends_with(".tres"):
			var path = CONTRACT_DIR + file_name
			var res = load(path)
			if res is Generator_contract:
				all_contracts.append(res)


func get_contract() -> Generator_contract:
	var pool: Array[Generator_contract] = []
	for c in all_contracts:
		if c.contract_id not in signed_ids:
			pool.append(c)
	if pool.is_empty():
		return null
	return pool[randi() % pool.size()]

func mark_signed(contract_id: int) -> void:
	if contract_id not in signed_ids:
		signed_ids.append(contract_id)

func reset():
	signed_ids.clear()
	_load_all_contracts()
