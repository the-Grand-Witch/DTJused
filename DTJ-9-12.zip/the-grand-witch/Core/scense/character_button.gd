extends Button
class_name CharacterButton

@export var character: Generator_girl
@onready var aima: CharacterButton = $"."
@onready var label: Label = $"../Label"

func _ready():
	pressed.connect(_on_pressed)

func _on_pressed():
	if character == null:
		return
	GlobalPlayer.reset()
	GlobalPlayer.set_character(character)
	label.text = "已选择艾玛"
