extends Control

@onready var button: Button = $Button


func _ready() -> void:
	button.pressed.connect(start_pressed)

func start_pressed():
	GlobalScenes.go_to_main()
