extends Node
# 时间变化信号（供 UI 监听）
signal time_changed(total_minutes: int)
const TIME_UNIT: int = 5
var total_minutes: int = 6 * 60   # 起始 6:00
var day: int = 1
func _ready():
	time_changed.emit(total_minutes)
# 增加时间单位
func add_time_units(units: int) -> void:
	total_minutes += units * TIME_UNIT
	# 更新天数：每 1440 分钟（24小时）为一天
	day = total_minutes / 1440 + 1   # 第1天从0开始
	time_changed.emit(total_minutes)
	GlobalPassive.update_block_charge()
# 获取当前总分钟数
func get_time() -> int:
	return total_minutes
# 获取格式化的时间字符串
func get_formatted_time() -> String:
	var minutes_in_day = total_minutes % 1440
	var hours = minutes_in_day / 60
	var mins = minutes_in_day % 60
	return "%02d:%02d" % [hours, mins]

func set_time(minutes: int) -> void:
	total_minutes = minutes
	day = total_minutes / 1440 + 1
	time_changed.emit(total_minutes)

func reset() -> void:
	total_minutes = 6 * 60
	day = 1
	time_changed.emit(total_minutes)

func get_day() -> int:
	return day
