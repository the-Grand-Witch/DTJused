extends Node
## 全局被动：统一管理角色被动、饰品被动、效果状态、格挡充能、冲动

var character_passive: Generator_PassiveEffect
var accessories_passives: Array[Generator_PassiveEffect] = []
var accessories_passive_map: Dictionary = {}

var block_charges: int = 0
var block_charge_timer: int = 0
var pending_effect: String = ""

func _ready():
	character_passive = Generator_PassiveEffect.new()
	GlobalPlayer.character_changed.connect(_on_character_changed)
	GlobalAccessories.accessories_added.connect(_on_accessories_added)
	GlobalAccessories.accessories_removed.connect(_on_accessories_removed)

func _on_character_changed(character: Generator_girl):
	if character == null:
		return
	if character.passive:
		character_passive = character.passive

func _on_accessories_added(acc: Generator_accessories):
	if acc == null:
		return
	if acc.effect_script:
		var instance = acc.effect_script.new()
		accessories_passives.append(instance)
		accessories_passive_map[acc.acc_id] = instance
	if acc.block_charges > 0:
		block_charges = max(block_charges, 1)

func _on_accessories_removed(acc_id: int):
	if accessories_passive_map.has(acc_id):
		var instance = accessories_passive_map[acc_id]
		accessories_passives.erase(instance)
		accessories_passive_map.erase(acc_id)

# ==================== 被动获取 ====================
func get_passive() -> Generator_PassiveEffect:
	return character_passive

func set_passive(passive: Generator_PassiveEffect) -> void:
	character_passive = passive

# ==================== 事件钩子 ====================
func notify_battle_start() -> void:
	character_passive.on_battle_start()
	for p in accessories_passives:
		p.on_battle_start()

func get_turn_effects(turn_count: int) -> Array:
	var effects: Array = []
	effects.append_array(character_passive.on_turn_start(turn_count))
	for p in accessories_passives:
		effects.append_array(p.on_turn_start(turn_count))
	return effects

func notify_turn_end(turn_count: int) -> void:
	character_passive.on_turn_end(turn_count)
	for p in accessories_passives:
		p.on_turn_end(turn_count)

func notify_page_played(mark: Dictionary) -> void:
	print("[GlobalPassive.notify_page_played] mark=", mark)
	character_passive.on_page_played(mark)
	for p in accessories_passives:
		p.on_page_played(mark)

func notify_damage_taken(amount: int) -> void:
	character_passive.on_damage_taken(amount)
	for p in accessories_passives:
		p.on_damage_taken(amount)

func notify_damage_dealt(amount: int) -> void:
	character_passive.on_damage_dealt(amount)
	for p in accessories_passives:
		p.on_damage_dealt(amount)

func notify_heal(amount: int) -> void:
	character_passive.on_heal(amount)
	for p in accessories_passives:
		p.on_heal(amount)

func notify_witch_power_changed(value: int) -> void:
	character_passive.on_witch_power_changed(value)
	for p in accessories_passives:
		p.on_witch_power_changed(value)

# ==================== 效果执行 ====================
func apply_effect(effect_name: String, mark: Dictionary) -> void:
	if effect_name.ends_with("_pending"):
		pending_effect = effect_name.replace("_pending", "")
		return
	if not mark.has("effects"):
		mark["effects"] = {}
	mark["effects"][effect_name] = true

func consume_pending(mark: Dictionary) -> bool:
	if pending_effect == "":
		return false
	if not mark.has("effects"):
		mark["effects"] = {}
	mark["effects"][pending_effect] = true
	pending_effect = ""
	return true

# ==================== 冲动 ====================
func apply_impulses(cards: Array[BookmarkCard], count: int) -> void:
	clear_impulses(cards)
	if count <= 0:
		return

	var priority_pages: Array[Dictionary] = []
	var normal_pages: Array[Dictionary] = []
	for card in cards:
		for idx in range(card.bookmark_data.pages.size()):
			var page = card.bookmark_data.pages[idx]
			if "疯狂" in page.keywords:
				priority_pages.append({"card": card, "page_index": idx})
			elif page.pickup_type == Generator_bookpage.PickupType.Attack:
				normal_pages.append({"card": card, "page_index": idx})

	var selected_pages: Array[Dictionary] = priority_pages.duplicate()
	while selected_pages.size() < count and not normal_pages.is_empty():
		selected_pages.append(normal_pages.pop_front())

	selected_pages.shuffle()
	for i in range(min(count, selected_pages.size())):
		var entry = selected_pages[i]
		var card: BookmarkCard = entry["card"]
		var idx: int = entry["page_index"]
		var mark = card.get_page_mark(idx)
		if not mark.has("effects"):
			mark["effects"] = {}
		mark["effects"]["impulse"] = true

func clear_impulses(cards: Array[BookmarkCard]) -> void:
	for card in cards:
		for mark in card.get_all_marks():
			if mark.has("effects"):
				mark["effects"].erase("impulse")

func has_impulse(card: BookmarkCard, page_index: int) -> bool:
	var mark = card.get_page_mark(page_index)
	return mark.get("effects", {}).get("impulse", false)

func consume_impulse(card: BookmarkCard, page_index: int) -> bool:
	var mark = card.get_page_mark(page_index)
	if mark.get("effects", {}).get("impulse", false):
		mark["effects"].erase("impulse")
		return true
	return false

func punish_unused_impulses(cards: Array[BookmarkCard]) -> void:
	for card in cards:
		for mark in card.get_all_marks():
			if mark.get("effects", {}).get("impulse", false):
				GlobalPlayer.possessed(GlobalPlayer.get_impulse_punishment())
				mark["effects"].erase("impulse")

# ==================== 格挡 ====================
func try_block() -> bool:
	if block_charges > 0:
		block_charges -= 1
		block_charge_timer = 0
		return true
	return false

func get_block_charge() -> int:
	return block_charges

func update_block_charge() -> void:
	if block_charges <= 0:
		block_charge_timer += 5
		if block_charge_timer >= 60:
			block_charges = 1
			block_charge_timer = 0

# ==================== 重置 ====================
func reset() -> void:
	character_passive = Generator_PassiveEffect.new()
	accessories_passives.clear()
	accessories_passive_map.clear()
	block_charges = 0
	block_charge_timer = 0
	pending_effect = ""
