extends PanelContainer
class_name BookmarkCard

signal selection_changed(selected: bool)
signal card_confirmed(card: BookmarkCard)

@onready var title_label: Label = $TextureRect/TitleLabel
@onready var pages_vbox: VBoxContainer = $TextureRect/PagesVBox

var bookmark_data: BookmarkData
var current_cd: int = 0
var page_marks: Array[Dictionary] = []
var is_selected := false

const BORDER_COLOR := Color(1, 0.8, 0, 1)
const BORDER_WIDTH := 4

var page_labels: Array[Label] = []
var default_style: StyleBox

func _ready() -> void:
	title_label.add_theme_font_size_override("font_size", 28)
	mouse_filter = Control.MOUSE_FILTER_STOP
	default_style = get_theme_stylebox("panel")

func setup(data: BookmarkData) -> void:
	bookmark_data = data
	current_cd = 0
	_init_page_marks()
	_update_cooldown_visual()
	title_label.text = data.title
	_populate_page_labels()

# ==================== 标记 ====================
func _init_page_marks() -> void:
	page_marks.clear()
	var cid = get_instance_id()
	for i in range(bookmark_data.pages.size()):
		var page = bookmark_data.pages[i]
		page_marks.append({
			"card_id": cid,
			"page_index": i,
			"type": page.pickup_type,
			"page_position": "bookmark",
			"cd_remaining": page.cd,
			"usable": current_cd <= 0,
			"effects": {},
		})

func get_page_mark(page_index: int) -> Dictionary:
	if page_index < 0 or page_index >= page_marks.size():
		return {}
	return page_marks[page_index]

func get_all_marks() -> Array[Dictionary]:
	return page_marks

func set_page_position(page_index: int, pos: String) -> void:
	if page_index < 0 or page_index >= page_marks.size():
		return
	page_marks[page_index]["position"] = pos

func get_initial_cd(page_index: int) -> int:
	if page_index < 0 or page_index >= bookmark_data.pages.size():
		return 0
	return bookmark_data.pages[page_index].cd

func _update_usable_marks() -> void:
	for mark in page_marks:
		mark["usable"] = current_cd <= 0

# ==================== CD（书签级，原逻辑） ====================
func is_ready() -> bool:
	return current_cd <= 0

func decrease_cooldown() -> void:
	if current_cd > 0:
		current_cd -= 1
		_update_cooldown_visual()
		_update_usable_marks()

func start_cooldown() -> void:
	current_cd = bookmark_data.get_cd()
	_update_cooldown_visual()
	_update_usable_marks()

func _update_cooldown_visual() -> void:
	var gray: Color
	match current_cd:
		0: gray = Color(1, 1, 1, 1)
		1: gray = Color(0.7, 0.7, 0.7, 1)
		2: gray = Color(0.5, 0.5, 0.5, 1)
		3: gray = Color(0.4, 0.4, 0.4, 1)
		_: gray = Color(0.2, 0.2, 0.2, 1)
	modulate = gray
	mouse_filter = Control.MOUSE_FILTER_IGNORE if current_cd > 0 else Control.MOUSE_FILTER_STOP

# ==================== UI ====================
func _populate_page_labels() -> void:
	for child in pages_vbox.get_children():
		child.queue_free()
	page_labels.clear()
	for page in bookmark_data.pages:
		var label = Label.new()
		label.text = page.page_name
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.add_theme_font_size_override("font_size", 22)
		label.modulate = Color(1, 1, 1)
		pages_vbox.add_child(label)
		page_labels.append(label)

func get_page_label_by_index(idx: int) -> Label:
	if idx >= 0 and idx < page_labels.size():
		return page_labels[idx]
	return null

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if not event.pressed:
			_on_clicked()

func _on_clicked() -> void:
	if not is_ready():
		return
	if not is_selected:
		set_selected(true)
	else:
		card_confirmed.emit(self)

func set_selected(selected: bool) -> void:
	if is_selected == selected:
		return
	is_selected = selected
	_update_visual()
	emit_signal("selection_changed", is_selected)

func _update_visual() -> void:
	if is_selected:
		var style := StyleBoxFlat.new()
		style.bg_color = Color(0, 0, 0, 0)
		style.border_color = BORDER_COLOR
		style.set_border_width_all(BORDER_WIDTH)
		add_theme_stylebox_override("panel", style)
	else:
		add_theme_stylebox_override("panel", default_style)

func refresh_visual() -> void:
	_update_cooldown_visual()
