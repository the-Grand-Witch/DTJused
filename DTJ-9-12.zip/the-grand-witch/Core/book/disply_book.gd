extends Control
## 主场景的卡组互动逻辑

@onready var bookmark_container: Node = $disply_bookmark
@onready var open_book_button: Button = $open

var book_instance: Node = null
var selected_cards: Array[BookmarkCard] = []
var max_selected: int = 1   # 最多选择一张，可修改

# 是否启用选择交互（主场景默认关闭，战斗场景可通过代码开启）
@export var enable_selection: bool = false

func _ready() -> void:
	var bm = GlobalBookMark
	bm.bookmark_added.connect(_on_bookmark_added)
	bm.bookmark_removed.connect(_on_bookmark_removed)
	_refresh_bookmark_display()
	open_book_button.pressed.connect(_on_open_book_pressed)

func _on_bookmark_added(_data) -> void:
	_refresh_bookmark_display()

func _on_bookmark_removed(_data) -> void:
	_refresh_bookmark_display()

func _refresh_bookmark_display() -> void:
	# 清除旧节点
	for child in bookmark_container.get_children():
		bookmark_container.remove_child(child)
		child.queue_free()
	# 清空选择状态
	selected_cards.clear()
	# 横向流式布局重叠效果
	if bookmark_container is HFlowContainer:
		bookmark_container.add_theme_constant_override("separation", -20)
	# 重新构建卡片
	var bm = GlobalBookMark
	for bookmark_data in bm.bookmarks:
		var card = GlobalScenes.BOOKMARK_CARD_SCENE.instantiate()
		bookmark_container.add_child(card)
		card.setup(bookmark_data)
		# 根据开关决定是否启用选择交互
		if enable_selection:
			card.selection_changed.connect(_on_card_selection_changed.bind(card))
		else:
			card.mouse_filter = Control.MOUSE_FILTER_IGNORE

func _on_card_selection_changed(selected: bool, card: BookmarkCard) -> void:
	if selected:
		if selected_cards.size() >= max_selected:
			var oldest_card = selected_cards[0]
			selected_cards.erase(oldest_card)
			oldest_card.set_selected(false)
		selected_cards.append(card)
	else:
		selected_cards.erase(card)

func _on_open_book_pressed() -> void:
	book_instance = GlobalScenes.BOOK_SCENE.instantiate()
	if book_instance is Control:
		book_instance.anchor_left = 0.0
		book_instance.anchor_top = 0.0
		book_instance.anchor_right = 1.0
		book_instance.anchor_bottom = 1.0
		book_instance.offset_left = 0
		book_instance.offset_top = 0
		book_instance.offset_right = 0
		book_instance.offset_bottom = 0
		book_instance.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(book_instance)

func _on_book_closed() -> void:
	book_instance = null
