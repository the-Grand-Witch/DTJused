extends Node
## 全局卡牌库：管理卡牌定义、获得量与可使用量、掉落池与特殊池

var cards: Dictionary = {}                # book_id -> Generator_bookpage（全部）
var drop_pool: Array[Generator_bookpage] = []      # 正常掉落池
var special_pool: Array[Generator_bookpage] = []   # 特殊池（不参与随机）

var owned_cards: Dictionary = {}          # book_id -> Generator_bookpage（获得量>0）
var card_acquired_counts: Dictionary = {} # 获得量
var card_usable_counts: Dictionary = {}   # 可使用量

func _ready() -> void:
	_load_all_cards()

func _load_all_cards() -> void:
	cards.clear()
	drop_pool.clear()
	special_pool.clear()
	_scan_dir("res://Data/bookpage/", drop_pool)
	_scan_dir("res://Data/bookpage/girl's card/", special_pool)
	for card in drop_pool:
		cards[card.book_id] = card
	for card in special_pool:
		cards[card.book_id] = card

func _scan_dir(dir_path: String, target_pool: Array[Generator_bookpage]) -> void:
	var files = ResourceLoader.list_directory(dir_path)
	for file_name in files:
		if file_name.ends_with(".tres"):
			var res = load(dir_path + file_name)
			if res is Generator_bookpage:
				target_pool.append(res)

# ==================== 查询 ====================
func get_all_cards() -> Array[Generator_bookpage]:
	var arr: Array[Generator_bookpage] = []
	for key in cards.keys():
		arr.append(cards[key])
	arr.sort_custom(func(a, b): return a.book_id < b.book_id)
	return arr

## 掉落池：商店、事件随机用，不含特殊页
func get_randomable_cards() -> Array[Generator_bookpage]:
	return drop_pool.duplicate()

func get_owned_cards() -> Array[Generator_bookpage]:
	var arr: Array[Generator_bookpage] = []
	for key in owned_cards.keys():
		if card_acquired_counts.get(key, 0) > 0:
			arr.append(owned_cards[key])
	arr.sort_custom(func(a, b): return a.book_id < b.book_id)
	return arr

func get_card_by_book_id(id: int) -> Generator_bookpage:
	return cards.get(id)

# ==================== 获得量 / 可使用量 ====================
func add_acquired_count(book_id: int, amount: int = 1) -> void:
	card_acquired_counts[book_id] = card_acquired_counts.get(book_id, 0) + amount
	card_usable_counts[book_id] = card_usable_counts.get(book_id, 0) + amount
	if cards.has(book_id) and not owned_cards.has(book_id):
		owned_cards[book_id] = cards[book_id]

func add_acquired_only(book_id: int, amount: int = 1) -> void:
	card_acquired_counts[book_id] = card_acquired_counts.get(book_id, 0) + amount
	if cards.has(book_id) and not owned_cards.has(book_id):
		owned_cards[book_id] = cards[book_id]

func use_card(book_id: int) -> bool:
	if card_usable_counts.get(book_id, 0) > 0:
		card_usable_counts[book_id] -= 1
		return true
	return false

func return_card(book_id: int, amount: int = 1) -> void:
	card_usable_counts[book_id] = card_usable_counts.get(book_id, 0) + amount

func get_acquired_count(book_id: int) -> int:
	return card_acquired_counts.get(book_id, 0)

func get_usable_count(book_id: int) -> int:
	return card_usable_counts.get(book_id, 0)

# ==================== 重置 ====================
func reset() -> void:
	owned_cards.clear()
	card_acquired_counts.clear()
	card_usable_counts.clear()
