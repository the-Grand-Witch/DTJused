extends Node
## 战斗主控制器：通用流程 + 根据场景分派特殊逻辑

@onready var player_ui = $Player
@onready var battle_calculator = $BattleCalculator
@onready var turn_label: Label = $TurnLabel
@onready var end_turn_button: Button = $EndTurnButton

var special: Node

var turn_count: int = 0
var player_attack_bonus: int = 0
var player_selected_cards: Array[BookmarkCard] = []
var player_cards: Array[BookmarkCard] = []
var player_max_selected: int = 1
var player_status_dict: Dictionary = {}
var used_ability_pages: Array[Generator_bookpage] = []

func _ready():
	if has_node("Nomel"):
		special = $Nomel
	elif has_node("Boss"):
		special = $Boss
	special.battle_main = self
	special.setup()

	_create_player_cards()
	end_turn_button.pressed.connect(_on_end_turn_pressed)
	player_ui.cancel_requested.connect(_cancel_all_selections)
	GlobalPassive.notify_battle_start()
	_start_round()
	_update_player_buffs()

func _create_player_cards():
	player_ui.clear_hand()
	player_cards.clear()
	for data in GlobalBookMark.bookmarks:
		var card = GlobalScenes.BOOKMARK_CARD_SCENE.instantiate()
		player_ui.add_card(card)
		card.setup(data)
		card.selection_changed.connect(_on_player_card_selected.bind(card))
		card.card_confirmed.connect(_on_card_confirmed)
		player_cards.append(card)

func _on_player_card_selected(selected: bool, card: BookmarkCard):
	if selected:
		if player_selected_cards.size() >= player_max_selected:
			var oldest = player_selected_cards[0]
			player_selected_cards.erase(oldest)
			oldest.set_selected(false)
		player_selected_cards.append(card)
	else:
		player_selected_cards.erase(card)

func _on_card_confirmed(card: BookmarkCard):
	if card in player_selected_cards:
		_on_end_turn_pressed()

func _cancel_all_selections() -> void:
	for card in player_selected_cards:
		card.set_selected(false)
	player_selected_cards.clear()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_SPACE:
			if not player_selected_cards.is_empty():
				_on_end_turn_pressed()
				get_viewport().set_input_as_handled()
		elif event.keycode == KEY_Q:
			_cancel_all_selections()
			get_viewport().set_input_as_handled()

func _start_round():
	turn_count += 1
	turn_label.text = "回合 %d" % turn_count

	battle_calculator.convert_harmony()
	_update_player_buffs()

	for card in player_cards:
		card.decrease_cooldown()

	var impulse_count = GlobalPlayer.get_impulse_count()
	GlobalPassive.apply_impulses(player_cards, impulse_count)
	player_ui.refresh_impulse_visual(player_cards)

	used_ability_pages.clear()

	var effects = GlobalPassive.get_turn_effects(turn_count)
	_apply_turn_effects(effects)

	special.on_round_start(turn_count)

func _on_end_turn_pressed():
	GlobalTime.add_time_units(1)

	# 消耗 pending 效果：只作用于第一张打出的书页
	for card in player_selected_cards:
		for idx in range(card.bookmark_data.pages.size()):
			GlobalPassive.consume_pending(card.get_page_mark(idx))

	# 收集本回合使用的能力页
	for card in player_selected_cards:
		for page in card.bookmark_data.pages:
			if page.pickup_type == Generator_bookpage.PickupType.Ability:
				player_status_dict[page] = player_status_dict.get(page, 0) + 1

	# 玩家结算
	var player_result = battle_calculator.calculate_player_effects(
		player_selected_cards,
		player_attack_bonus,
		player_ui,
		special.enemy_witch_power()
	)
	player_attack_bonus = battle_calculator.get_player_attack_bonus()
	_update_player_buffs()

	# 敌人承受伤害
	special.enemy_take_damage(player_result.damage)
	if special.is_enemy_dead():
		end_turn_button.disabled = true
		special.on_enemy_defeated()
		return

	# 玩家治疗
	if player_result.healing > 0:
		GlobalPlayer.heal(player_result.healing)

	# 冲动惩罚
	GlobalPassive.punish_unused_impulses(player_cards)
	player_ui.refresh_impulse_visual(player_cards)

	# 疯狂卡惩罚：未打出的疯狂卡每张魔女化+1
	for card in player_cards:
		if card not in player_selected_cards:
			for page in card.bookmark_data.pages:
				if "疯狂" in page.keywords:
					GlobalPlayer.possessed(1)
					break

	# 敌人回合
	special.enemy_take_turn(player_result.armor)

	# 玩家死亡检查
	if GlobalPlayer.health <= 0:
		GlobalScenes.check_game_over()
		return

	# 清空维协层数
	battle_calculator.clear_harmony()
	_update_player_buffs()

	GlobalPassive.notify_turn_end(turn_count)
	_start_round()

func _update_player_buffs():
	var statuses = player_status_dict.duplicate()
	var accessories_bonus = _get_accessories_attack_bonus()
	if accessories_bonus > 0:
		statuses["accessories_attack"] = accessories_bonus
	if battle_calculator.harmony_stacks > 0:
		statuses["harmony"] = battle_calculator.harmony_stacks
	player_ui.update_buffs(statuses)

func _get_accessories_attack_bonus() -> int:
	var bonus = 0
	for acc in GlobalAccessories.accessories:
		bonus += acc.attack_bonus
	return bonus

func _apply_turn_effects(effects: Array) -> void:
	for effect_data in effects:
		var effect_name: String = effect_data["effect"]
		var condition: Dictionary = effect_data.get("condition", {})
		for card in player_cards:
			for mark in card.get_all_marks():
				if _match_condition(mark, condition):
					GlobalPassive.apply_effect(effect_name, mark)

func _match_condition(mark: Dictionary, condition: Dictionary) -> bool:
	for key in condition:
		if mark.get(key) != condition[key]:
			return false
	return true
