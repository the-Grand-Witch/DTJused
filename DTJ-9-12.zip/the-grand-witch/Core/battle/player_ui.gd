extends Node
## 玩家 UI 模块：手牌显示、冲动视觉、状态图标

@onready var hand_container = $player_hand_container
@onready var buff_display = $buff/Buffscenses
@onready var hint_label: Label = $HintLabel
@onready var player_icon: TextureRect = $PlayerIcon

signal cancel_requested

func _ready():
	GlobalPlayer.hint_requested.connect(_on_hint_requested)
	GlobalPlayer.character_changed.connect(_on_character_changed)
	hint_label.visible = false
	if GlobalPlayer.current_character:
		_update_player_icon(GlobalPlayer.current_character)

func _on_character_changed(character: Generator_girl):
	if character == null:
		player_icon.texture = null
		return
	_update_player_icon(character)

func _update_player_icon(character: Generator_girl):
	if character and character.portrait:
		player_icon.texture = character.portrait

func clear_hand():
	for child in hand_container.get_children():
		child.queue_free()

func add_card(card: BookmarkCard):
	hand_container.add_child(card)

func _on_hint_requested(text: String):
	hint_label.text = text
	hint_label.visible = true
	await get_tree().create_timer(3.0).timeout
	hint_label.visible = false

# ==================== 冲动视觉 ====================
func refresh_impulse_visual(cards: Array[BookmarkCard]) -> void:
	for card in cards:
		for idx in range(card.bookmark_data.pages.size()):
			var label = card.get_page_label_by_index(idx)
			if not label:
				continue
			if GlobalPassive.has_impulse(card, idx):
				label.modulate = Color(0.6, 0.2, 1)
			else:
				label.modulate = Color(1, 1, 1)

# ==================== 状态图标 ====================
func update_buffs(statuses: Dictionary):
	buff_display.update_display(statuses)

# ==================== 右键取消 ====================
func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		cancel_requested.emit()
		get_viewport().set_input_as_handled()
