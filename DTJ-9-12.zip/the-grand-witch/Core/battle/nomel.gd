extends Node
## 普通战斗特殊逻辑

signal monster_defeated

@onready var monster_manager = $"../Monster"
@onready var reward_manager = $"../RewardManager"

var battle_main: Node
var loot_bonus: int = 0

func setup():
	monster_manager.load_random_monster()
	monster_manager.setup_ui()

func on_round_start(_turn_count: int):
	pass

func enemy_witch_power() -> int:
	return 0

func enemy_take_damage(amount: int):
	monster_manager.take_damage(amount)

func is_enemy_dead() -> bool:
	return monster_manager.is_dead()

func on_enemy_defeated():
	reward_manager.show_rewards(monster_manager.get_current_monster(), loot_bonus)
	emit_signal("monster_defeated")

func enemy_take_turn(player_armor: int):
	var result = battle_main.battle_calculator.calculate_monster_attack(
		monster_manager.get_attack(),
		player_armor
	)
	if result.damage_dealt > 0:
		GlobalPlayer.take_damage(result.damage_dealt)

func increase_loot_bonus(amount: int):
	loot_bonus += amount
