extends Node
## 负责伤害、治疗、护甲等数值计算

var player_attack_bonus: int = 0
var harmony_stacks: int = 0
var harmony_save: int = 0

func calculate_player_effects(cards: Array[BookmarkCard], attack_bonus: int, player_ui, enemy_witch_power: int) -> Dictionary:
	var result = {"damage": 0, "healing": 0, "armor": 0}
	var accessories_bonus = _get_accessories_attack_bonus()
	var total_attack_bonus = attack_bonus + accessories_bonus

	for card in cards:
		for idx in range(card.bookmark_data.pages.size()):
			var page = card.bookmark_data.pages[idx]
			var mark = card.get_page_mark(idx)
			var has_impulse = GlobalPassive.has_impulse(card, idx)
			var is_double = mark.get("effects", {}).get("double", false)
			var mult = 2.0 if is_double else 1.0

			GlobalPassive.notify_page_played(mark)

			# 关键词
			var kw_damage = 0
			var kw_healing = 0
			var kw_armor = 0
			var kw_attack_bonus = 0
			var kw_strength = 0
			var kw_segments = 0
			for keyword in page.keywords:
				var context = {
					"card": page,
					"bookmark": card.bookmark_data,
					"player_cards": cards,
					"player_attack_bonus": player_attack_bonus,
					"has_impulse": has_impulse,
					"enemy_witch_power": enemy_witch_power,
					"battle_calculator": self,
				}
				var keyword_result = GlobalKeywordDict.execute_keyword(keyword, context)
				kw_damage += keyword_result.get("effect_damage", 0)
				kw_healing += keyword_result.get("effect_healing", 0)
				kw_armor += keyword_result.get("effect_Armor", 0)
				kw_attack_bonus += keyword_result.get("effect_attack_bonus", 0)
				kw_strength += keyword_result.get("effect_strength_power", 0)
				kw_segments += keyword_result.get("effect_attack_segments", 0)

			# 特效脚本（接收返回值）
			var sc_damage = 0
			var sc_healing = 0
			var sc_armor = 0
			var sc_attack_bonus = 0
			if page.effect_script:
				var script_obj = page.effect_script.new()
				if script_obj.has_method("execute"):
					var script_result = script_obj.execute({
						"card": page,
						"bookmark": card.bookmark_data,
						"player_cards": cards,
						"player_attack_bonus": player_attack_bonus,
						"has_impulse": has_impulse,
						"enemy_witch_power": enemy_witch_power,
						"battle_calculator": self,
						"is_double": is_double,
					})
					if script_result is Dictionary:
						sc_damage = script_result.get("damage", 0)
						sc_healing = script_result.get("healing", 0)
						sc_armor = script_result.get("armor", 0)
						sc_attack_bonus = script_result.get("attack_bonus", 0)

			match page.pickup_type:
				Generator_bookpage.PickupType.Attack:
					var base_damage = page.damage + total_attack_bonus + page.strength_power + kw_strength + sc_damage
					var passive_mult = GlobalPlayer.get_damage_multiplier(enemy_witch_power)
					var final_damage = base_damage * passive_mult
					if has_impulse:
						var impulse_mult = GlobalPlayer.get_impulse_damage_multiplier()
						final_damage = final_damage * impulse_mult
						GlobalPassive.consume_impulse(card, idx)
					final_damage = final_damage * mult
					base_damage = int(ceil(final_damage))
					var total_segments = 1 + page.attack_segments + page.effect_attack_segments + int(kw_segments)
					result.damage += base_damage * total_segments
					result.damage += int(kw_damage * mult)
				Generator_bookpage.PickupType.Heal:
					result.healing += int((page.healing + kw_healing + sc_healing) * mult)
				Generator_bookpage.PickupType.Defense:
					result.armor += int((page.Armor + kw_armor + sc_armor) * mult)
				Generator_bookpage.PickupType.Ability:
					player_attack_bonus += int((page.attack_bonus + kw_attack_bonus + sc_attack_bonus) * mult)

	for card in cards:
		card.set_selected(false)
		card.start_cooldown()

	player_ui.refresh_impulse_visual(cards)
	return result

func get_player_attack_bonus() -> int:
	return player_attack_bonus

func calculate_monster_attack(monster_attack: int, player_armor: int) -> Dictionary:
	var actual_damage = max(monster_attack - player_armor, 0)
	return {"damage_dealt": actual_damage}

func _get_accessories_attack_bonus() -> int:
	var bonus = 0
	for acc in GlobalAccessories.accessories:
		bonus += acc.attack_bonus
	return bonus

func convert_harmony() -> void:
	harmony_stacks = harmony_save
	harmony_save = 0

func clear_harmony() -> void:
	harmony_stacks = 0
