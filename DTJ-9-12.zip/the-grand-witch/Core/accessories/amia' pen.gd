extends Generator_PassiveEffect
class_name DoubleNextPageEffect

## 每隔一回合触发一次：该回合下一个打出的书页效果翻倍

func on_turn_start(turn_count: int) -> Array:
	if turn_count % 2 == 1:
		return [{"effect": "double_pending", "condition": {}}]
	return []
