extends Resource
class_name Generator_monster
#声明
enum MonsterType {
	normal,
	elite,
	boss,
	}
#分组
@export_group("怪物配置")
@export var monster_type: MonsterType = MonsterType.normal
@export var display_name: String = ""     
@export var monster_id: int  	
@export var icon_textrue:Texture2D 
@export_group("怪物数值")     
@export var health: int = 0                           
@export var attack: int = 0
@export_group("精英怪物增益")
@export var enable_elite_bonus: bool = false
@export var elite_attack_interval: int = 3   
@export var elite_attack_bonus_multiplier: float = 2
@export var elite_attack_witchpower_bonus: int = 5
@export_group("头目怪物增益")
@export var enable_boss_bonus: bool = false
@export var boss_attack_interval: int = 2
@export var boss_attack_bonus_multiplier: float = 2
@export var boss_attack_witchpower_bonus: int = 7
@export_group("掉落")
@export var fixed_drop_id: int = -1          # 固定掉落道具 ID，-1 表示不使用
@export var accessory_id_min: int = 0       # 随机掉落道具 ID 范围下限（包含）
@export var accessory_id_max: int = 0         # 随机掉落道具 ID 范围上限（包含）
@export var random_drop_count: int = 1             
@export var min_gold: int = 0                # 金币掉落
@export var max_gold: int = 0   
