extends Generator_PassiveEffect
class_name KillWitchPassive

## 覆写伤害倍率方法，实现你的“kill_witch”效果
func modify_damage_multiplier(enemy_witch_power: int) -> float:
	var own_witch = GlobalPlayer.witch_power
	var e = clamp(enemy_witch_power, 0, 100)
	var s = clamp(own_witch, 0, 100)
	var bonus_percent = e * (0.5 + s * 0.005)
	return min(1.0 + bonus_percent / 100.0, 2.0)
