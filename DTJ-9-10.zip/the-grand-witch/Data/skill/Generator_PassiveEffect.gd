extends Resource
class_name Generator_PassiveEffect

# ==================== 金币相关 ====================
## 修改金币获取量（默认返回原值）
func modify_gold_gain(base: int) -> int:
	return base

# ==================== 战斗伤害相关 ====================
## 修改伤害倍率（默认返回 1.0，即无加成）
## 参数 enemy_witch_power 为敌人当前魔女化值，供特定被动使用
func modify_damage_multiplier(enemy_witch_power: int) -> float:
	return 1.0

# ==================== 魔女化相关 ====================
## 修改魔女化增长量（默认返回原值）
func modify_witch_power_gain(amount: int) -> int:
	return amount

# ==================== 生命值相关 ====================
## 修改最大生命值（默认返回原值）
func modify_max_health(base: int) -> int:
	return base

# ==================== 战斗每回合资源 ====================
## 修改每回合获得的护甲量（默认返回原值）
func modify_armor_per_turn(base: int) -> int:
	return base

## 修改每回合回复的生命值（默认返回原值）
func modify_heal_per_turn(base: int) -> int:
	return base

# ==================== 描述 ====================
## 返回被动效果的描述文本（用于 UI 展示）
func get_description() -> String:
	return "无被动效果"
