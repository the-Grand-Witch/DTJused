@tool
extends Resource
class_name Generator_bookpage

enum PickupType {
	Attack = 1,
	Defense = 2,
	Ability = 3,
	Heal = 4
}
const KEYWORD_OPTIONS: Array[StringName] = ["始源", "维协", "强压", "统洁","疯狂"]
@export_group("统洁")
@export var purity_types: Array[PickupType] = []
@export_group("书页配置")
@export var book_id : int
@export var pickup_type : PickupType = PickupType.Attack
@export var page_name : String = "未命名卡牌"
@export var icon : Texture2D
@export var description : String = ""
@export var cd : int

@export_group("书页效果")
@export var damage : int = 0
@export var healing : int = 0
@export var Armor : int = 0
@export var attack_bonus : int = 0
@export var strength_power : int = 0
@export var attack_segments : int = 0

@export_group("稀有度")
@export var rarity : int = 0   # 0=普通, 1=稀有, 2=史诗

@export_group("价格")
@export var price : int = 0    # 由商店或其他系统生成，配置表不自动赋值

# 能力卡专属 buff 配置
@export_group("buff 配置")
@export var buff_icon : Texture2D
@export var buff_icon_size : Vector2 = Vector2(32, 32)
@export var buff_font_size : int = 10

@export_group("特效")
@export var effect_script: Script   # 通用特效脚本接口（可选，所有卡牌均可使用）
# 关键词
@export_group("特效数值")
@export var effect_damage : int = 0
@export var effect_healing : int = 0
@export var effect_Armor : int = 0
@export var effect_attack_bonus : int = 0
@export var effect_strength_power : int = 0
@export var effect_attack_segments : int = 0

@export_group("关键词")
# 关键词数组（隐藏，由复选框控制）
@export var keywords: Array[StringName] = []

func _get_property_list() -> Array[Dictionary]:
	var properties: Array[Dictionary] = []
	# 为每个关键词生成复选框，归入“关键词”分组
	for kw in KEYWORD_OPTIONS:
		properties.append({
			"name": kw,
			"type": TYPE_BOOL,
			"usage": PROPERTY_USAGE_DEFAULT,
			"group": "关键词",
		})
	return properties

func _set(property: StringName, value):
	# 处理关键词复选框
	if property in KEYWORD_OPTIONS:
		var is_checked = value as bool
		if is_checked:
			if not keywords.has(property):
				keywords.append(property)
		else:
			keywords.erase(property)
		return true
	return false

func _get(property: StringName):
	if property in KEYWORD_OPTIONS:
		return property in keywords
	return null

func _validate_property(property: Dictionary):
	# buff 配置仅在能力卡时显示
	if property.name in ["buff_icon", "buff_icon_size", "buff_font_size"]:
		if pickup_type == PickupType.Ability:
			property.usage = PROPERTY_USAGE_DEFAULT
		else:
			property.usage = PROPERTY_USAGE_NONE
	# 隐藏原始 keywords 数组，防止直接编辑
	if property.name == "keywords":
		property.usage = PROPERTY_USAGE_NONE
