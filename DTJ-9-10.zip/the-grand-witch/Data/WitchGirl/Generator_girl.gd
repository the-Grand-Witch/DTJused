extends Resource
class_name Generator_girl

@export_group("角色信息")
@export var character_id: String = ""
@export var character_name: String = "未命名角色"
@export var portrait: Texture2D
@export_multiline var description: String = ""

@export_group("被动效果")
@export var passive: Generator_PassiveEffect

@export_group("独特饰品")
@export var unique_accessory: Generator_accessories

@export_group("起始书签")
@export var starting_bookmarks: Array[BookmarkData] = []
