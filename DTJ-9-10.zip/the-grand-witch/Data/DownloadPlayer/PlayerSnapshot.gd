extends Resource
class_name PlayerSnapshot

enum SnapshotType {
	PLAYER_MIRROR,      # 普通玩家上传镜像
	SPECIAL_CHARACTER   # 开发者设计特殊人物
}

@export var snapshot_id: String = ""
@export var player_name: String = "未知玩家"
@export var max_health: int = 200
@export var current_health: int = 200
@export var witch_power: int = 0
@export var bookmarks: Array[BookmarkData] = []
@export var accessories: Array[Generator_accessories] = []
@export var base_attack: int = 10
@export var portrait: Texture2D

# 类型选择器：决定该快照是普通玩家镜像还是特殊人物
@export var snapshot_type: SnapshotType = SnapshotType.PLAYER_MIRROR

# 特殊角色表现（仅 SPECIAL_CHARACTER 时使用）
@export_group("特殊角色表现")

@export_multiline var dialogue_intro: String = ""      # 入场时
@export_multiline var dialogue_attack: String = ""     # 攻击时
@export_multiline var dialogue_damaged: String = ""    # 受到大量伤害后
@export_multiline var dialogue_powerup: String = ""    # 强化时（形态改变或彼岸之赐触发）
@export_multiline var dialogue_idle: String = ""       # 闲聊/随机待机
