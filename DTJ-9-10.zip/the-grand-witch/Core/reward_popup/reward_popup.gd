extends Control
class_name RewardPopup

signal closed

@onready var background: TextureRect = $Background
@onready var title_label: Label = $Background/TitleLabel
@onready var return_button: Button = $Background/ReturnButton
@onready var loot_vbox: VBoxContainer = $Background/LootVBox

var gold_amount: int = 0
var accessories: Array[Generator_accessories] = []

func _ready():
	return_button.pressed.connect(_on_return_pressed)
	title_label.text = "战利品"

func setup_rewards(gold: int, accs: Array[Generator_accessories]) -> void:
	gold_amount = gold
	accessories = accs
	if is_inside_tree():
		_populate_rewards()
	else:
		call_deferred("_populate_rewards")

func _populate_rewards():
	for child in loot_vbox.get_children():
		child.queue_free()

	if gold_amount > 0:
		var gold_btn = Button.new()
		gold_btn.text = "金币 x%d" % gold_amount
		gold_btn.pressed.connect(_on_gold_pressed.bind(gold_btn))
		loot_vbox.add_child(gold_btn)

	for acc in accessories:
		var btn = Button.new()
		btn.text = acc.name
		btn.icon = acc.icon
		btn.pressed.connect(_on_accessory_pressed.bind(btn, acc))
		loot_vbox.add_child(btn)

func _on_gold_pressed(btn: Button):
	GlobalPlayer.add_gold(gold_amount)
	btn.queue_free()

func _on_accessory_pressed(btn: Button, accessory: Generator_accessories):
	GlobalAccessories.add_accessory(accessory)
	btn.queue_free()

func _on_return_pressed():
	emit_signal("closed")
	queue_free()
