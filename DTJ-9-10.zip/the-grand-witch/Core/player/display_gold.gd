extends Node
@onready var gold: Label = $Gold/Label

func _ready():
	# 初始化显示
	_update_gold_display(GlobalPlayer.gold)
	# 连接金币变化信号（如果 GlobalPlayer 中已定义）
	if GlobalPlayer.has_signal("gold_changed"):
		GlobalPlayer.gold_changed.connect(_update_gold_display)

func _update_gold_display(new_gold: int) -> void:
	gold.text = "金币：%d" % new_gold
