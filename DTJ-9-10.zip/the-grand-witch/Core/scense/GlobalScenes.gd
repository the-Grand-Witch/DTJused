extends Node
var last_scene_path: String = "res://scenes/main.tscn"
var event_manager: Node = null
#全局场景加载
func _ready():
	GlobalPlayer.health_changed.connect(_on_player_health_changed)
#顺便储存场景做到返回效果
func record_current_scene() -> void:
	last_scene_path = get_tree().current_scene.scene_file_path
#战斗场景方法
func enter_battle() -> void:
	record_current_scene()
	get_tree().change_scene_to_file("res://scenes/battle.tscn")
#game——over跳转
func check_game_over() -> void:
	if GlobalPlayer.health <= 0:
		GlobalPlayer.reset()
		GlobalBookMark.reset()
		GlobalAccessories.reset()
		GlobalCardLibrary.reset()
		get_tree().change_scene_to_file("res://scenes/game_over.tscn")
	if GlobalPlayer.health <= 0 or GlobalPlayer.witch_power >= 100:
		GlobalPlayer.reset()
		GlobalBookMark.reset()
		GlobalAccessories.reset()
		GlobalCardLibrary.reset()
		get_tree().change_scene_to_file("res://scenes/game_over.tscn")

#检测玩家状态
func _on_player_health_changed(new_health: int) -> void:
	if new_health <= 0:
		check_game_over()
#刷新
func refresh_events() -> void:
	event_manager.refresh_all_cards()
