extends Control
## 状态显示场景：自动识别卡牌来源与系统来源，按图标聚合显示层数
## 支持卡牌资源指定图标尺寸，系统状态使用默认尺寸或自定义字典

@onready var icon_container: HBoxContainer = $IconContainer

# 系统状态 ID -> 图标路径（非卡牌来源）
const SYSTEM_STATUS_ICONS := {
	"accessory_attack": "res://Assets/Textures/Icons/buffs/accessory_attack.png",
	"armor_per_turn": "res://Assets/Textures/Icons/buffs/armor_per_turn.png",
	"heal_per_turn": "res://Assets/Textures/Icons/buffs/heal_per_turn.png",
	"bian_layers": "res://Assets/Textures/Icons/buffs/bian_layers.png",
	"attack_bonus":"res://Assets/Textures/Icons/buffs/attack_bonus.png",
	"harmony": "res://Assets/Textures/Icons/buffs/WX_turn.png",
}

# 全局默认尺寸（已调大，可继续在 Inspector 中修改）
@export var default_icon_size: Vector2 = Vector2(64, 64)
@export var default_font_size: int = 28 

## 更新状态显示
## statuses: 字典，键为状态标识（卡牌对象或状态ID字符串）
## 值可以是：
##   - int：层数（自动获取图标和尺寸，卡牌来源优先使用卡牌配置）
##   - Dictionary：{"count": int, "icon": Texture2D, "icon_size": Vector2, "font_size": int}
##     其中 icon、icon_size、font_size 均可选，未指定时使用卡牌配置或默认
func update_display(statuses: Dictionary):
	var icon_counts := {}  # 图标资源路径 -> {"texture": Texture2D, "count": int, "size": Vector2, "font": int}

	# 主动询问 GlobalPlayer 维协层数
	var harmony_stacks = GlobalPlayer.harmony_stacks
	if harmony_stacks > 0:
		statuses["harmony"] = harmony_stacks

	for key in statuses:
		var value = statuses[key]
		var count = 0
		var custom_icon: Texture2D = null
		var icon_size = default_icon_size
		var font_size = default_font_size

		# 如果是卡牌来源，尝试从卡牌资源读取尺寸和图标
		if key is Generator_bookpage:
			if key.buff_icon:
				custom_icon = key.buff_icon
			if key.buff_icon_size != Vector2.ZERO:
				icon_size = key.buff_icon_size
			if key.buff_font_size > 0:
				font_size = key.buff_font_size
		elif key is BookmarkCard:
			# 兼容旧数据：查找第一个能力页的配置
			for page in key.bookmark_data.pages:
				if page.buff_icon:
					custom_icon = page.buff_icon
					if page.buff_icon_size != Vector2.ZERO:
						icon_size = page.buff_icon_size
					if page.buff_font_size > 0:
						font_size = page.buff_font_size
					break

		# 解析状态值
		if value is int:
			count = value
		elif value is Dictionary:
			count = value.get("count", 0)
			if value.has("icon"):
				custom_icon = value["icon"]
			if value.has("icon_size"):
				icon_size = value["icon_size"]
			if value.has("font_size"):
				font_size = value["font_size"]
		else:
			print("不支持的状态值类型：", value)
			continue

		if count <= 0:
			continue

		# 获取图标：优先使用自定义图标
		var icon_texture = custom_icon if custom_icon else _get_icon_for_key(key)
		if icon_texture == null:
			print("未获取到图标，跳过：", key)
			continue

		# 使用资源路径作为聚合键
		var icon_key = icon_texture.resource_path
		if icon_key == "":
			icon_key = "tex_%d" % icon_texture.get_instance_id()

		if icon_counts.has(icon_key):
			icon_counts[icon_key]["count"] += count
		else:
			icon_counts[icon_key] = {
				"texture": icon_texture,
				"count": count,
				"size": icon_size,
				"font": font_size
			}

	_clear_icons()
	for icon_key in icon_counts:
		var info = icon_counts[icon_key]
		_add_icon_with_count(info["texture"], info["count"], info["size"], info["font"])

# 清空现有图标
func _clear_icons():
	if icon_container.get_child_count() > 0:
		for child in icon_container.get_children():
			child.queue_free()

# 根据键获取图标纹理（非卡牌或未自定义时使用）
func _get_icon_for_key(key) -> Texture2D:
	if key is Generator_bookpage:
		if key.buff_icon:
			return key.buff_icon
	elif key is BookmarkCard:
		for page in key.bookmark_data.pages:
			if page.buff_icon:
				return page.buff_icon
	elif key is String:
		if SYSTEM_STATUS_ICONS.has(key):
			var path = SYSTEM_STATUS_ICONS[key]
			var tex = load(path)
			if tex:
				return tex
			else:
				print("系统状态图标加载失败：", path)
		else:
			print("未找到系统状态映射：", key)
	return null

# 添加图标和计数器（数字重叠在图标右下角）
func _add_icon_with_count(icon_texture: Texture2D, count: int, icon_size: Vector2, font_size: int):
	var icon_box = Control.new()
	icon_box.custom_minimum_size = icon_size
	icon_box.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var texture_rect = TextureRect.new()
	texture_rect.texture = icon_texture
	texture_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	texture_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	texture_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon_box.add_child(texture_rect)

	var count_label = Label.new()
	count_label.text = str(count)
	count_label.add_theme_font_size_override("font_size", font_size)
	count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	count_label.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	# 设置锚点为右下角，并让标签自动适应文本
	count_label.anchor_left = 1.0
	count_label.anchor_top = 1.0
	count_label.anchor_right = 1.0
	count_label.anchor_bottom = 1.0
	# 偏移到图标内，右下角留出少量边距
	var margin = font_size * 0.5
	count_label.offset_left = -icon_size.x + margin
	count_label.offset_top = -icon_size.y + margin
	count_label.offset_right = -margin
	count_label.offset_bottom = -margin
	count_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# 描边提高可读性
	count_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	count_label.add_theme_constant_override("outline_size", 2)
	icon_box.add_child(count_label)

	icon_container.add_child(icon_box)
