extends Control
## 书签创建/编辑界面控制器

@onready var add_bookmark_button: Button = $AddBookMark
@onready var bookmark_name_input: LineEdit = $BookMarkName
@onready var back_button: Button = $esc
@onready var warning_label: Label = $WarningLabel
@onready var card_grid: GridContainer = $CardScroll/CardGrid
@onready var selected_pages_label: Label = $SelectedPagesLabel
@onready var undo_button: Button = $CancelButton
@onready var delete_bookmark_button: Button = $DeleteBookmarkButton
@onready var delete_panel: PanelContainer = $DeletePanel
@onready var bookmark_option: OptionButton = $DeletePanel/VBoxContainer/BookmarkOption
@onready var confirm_delete_button: Button = $DeletePanel/VBoxContainer/ConfirmDeleteButton
@onready var cancel_delete_button: Button = $DeletePanel/VBoxContainer/CancelDeleteButton

var current_bookmark: BookmarkData

func _ready() -> void:
	add_bookmark_button.pressed.connect(_on_add_bookmark_pressed)
	back_button.pressed.connect(_on_back_pressed)
	undo_button.pressed.connect(_on_undo_pressed)
	bookmark_name_input.max_length = 12
	delete_bookmark_button.pressed.connect(_on_delete_bookmark_button_pressed)
	confirm_delete_button.pressed.connect(_on_confirm_delete_pressed)
	cancel_delete_button.pressed.connect(_on_cancel_delete_pressed)

	delete_panel.visible = false
	bookmark_name_input.alignment = HORIZONTAL_ALIGNMENT_CENTER
	if warning_label:
		warning_label.visible = false

	current_bookmark = BookmarkData.new()
	current_bookmark.icon = preload("res://Assets/Textures/Icons/book/bookmark.png")
	bookmark_name_input.text = "未命名书签%d" % (GlobalBookMark.bookmarks.size() + 1)
	_refresh_card_grid()

## 刷新卡牌选择网格
func _refresh_card_grid() -> void:
	for child in card_grid.get_children():
		card_grid.remove_child(child)
		child.queue_free()

	for card in GlobalCardLibrary.get_owned_cards():
		var card_button := Button.new()
		card_button.icon = card.icon
		card_button.expand_icon = true
		card_button.custom_minimum_size = Vector2(64, 64)
		card_button.tooltip_text = card.page_name + "\n" + card.description

		# 根据可使用量设置按钮状态
		var usable = GlobalCardLibrary.get_usable_count(card.book_id)
		if usable > 0:
			card_button.disabled = false
			card_button.modulate = Color(1, 1, 1)
		else:
			card_button.disabled = true
			card_button.modulate = Color(0.5, 0.5, 0.5)

		card_button.pressed.connect(_on_card_selected.bind(card))
		card_grid.add_child(card_button)

## 选中卡牌逻辑
func _on_card_selected(card: Generator_bookpage) -> void:
	if current_bookmark:
		if current_bookmark.pages.size() >= 5:
			if warning_label:
				warning_label.text = "书签已满，无法添加更多卡牌"
				warning_label.visible = true
			return

		# 检查并消耗可使用量
		if not GlobalCardLibrary.use_card(card.book_id):
			if warning_label:
				warning_label.text = "卡牌数量不足"
				warning_label.visible = true
			return

		current_bookmark.pages.append(card)
		_update_selected_pages_display()
		_refresh_card_grid()
		if warning_label:
			warning_label.visible = false

## 撤销上一步操作
func _on_undo_pressed() -> void:
	if current_bookmark and current_bookmark.pages.size() > 0:
		var removed_page = current_bookmark.pages.pop_back()
		GlobalCardLibrary.return_card(removed_page.book_id, 1)   # 返还数量
		_update_selected_pages_display()
		_refresh_card_grid()
	else:
		if warning_label:
			warning_label.text = "没有可撤销的操作"
			warning_label.visible = true

## 更新已选卡牌文本显示
func _update_selected_pages_display() -> void:
	if not selected_pages_label:
		return
	var names: PackedStringArray = []
	for page in current_bookmark.pages:
		names.append(page.page_name)
	selected_pages_label.text = "\n".join(names)

## 点击返回按钮
func _on_back_pressed() -> void:
	_return_current_pages()
	if get_parent() and get_parent().has_method("_on_book_closed"):
		get_parent()._on_book_closed()
	queue_free()
	get_viewport().set_input_as_handled()

## 全局输入处理（ESC键）
func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if get_parent() and get_parent().has_method("_on_book_closed"):
			get_parent()._on_book_closed()
		queue_free()
		get_viewport().set_input_as_handled()

## 点击保存书签
func _on_add_bookmark_pressed() -> void:
	if GlobalBookMark.bookmarks.size() >= 6:
		if warning_label:
			warning_label.text = "已经写不下了"
			warning_label.visible = true
		return
	var bookmark_text := bookmark_name_input.text.strip_edges()
	if bookmark_text == "":
		bookmark_text = "未命名书签%d" % (GlobalBookMark.bookmarks.size() + 1)
	current_bookmark.title = bookmark_text
	GlobalBookMark.add_bookmark(current_bookmark)
	current_bookmark = BookmarkData.new()
	current_bookmark.icon = preload("res://Assets/Textures/Icons/book/bookmark.png")
	bookmark_name_input.text = "未命名书签%d" % (GlobalBookMark.bookmarks.size() + 1)
	if warning_label:
		warning_label.visible = false
	_update_selected_pages_display()

## 刷新删除面板下拉列表
func _refresh_bookmark_option() -> void:
	bookmark_option.clear()
	var bm = GlobalBookMark
	for bookmark in bm.bookmarks:
		bookmark_option.add_item(bookmark.title)
	if bm.bookmarks.size() == 0:
		bookmark_option.add_item("无书签")
		bookmark_option.disabled = true
	else:
		bookmark_option.disabled = false

## 点击删除按钮
func _on_delete_bookmark_button_pressed() -> void:
	_refresh_bookmark_option()
	delete_panel.visible = true

## 取消删除
func _on_cancel_delete_pressed() -> void:
	delete_panel.visible = false

## 确认删除
func _on_confirm_delete_pressed() -> void:
	var selected_idx = bookmark_option.selected
	if selected_idx == -1:
		if warning_label:
			warning_label.text = "未选择书签"
			warning_label.visible = true
		return
	var bookmark_data = GlobalBookMark.bookmarks[selected_idx]
	# 退还书页
	for page in bookmark_data.pages:
		GlobalCardLibrary.return_card(page.book_id, 1)
	GlobalBookMark.remove_bookmark(bookmark_data)
	delete_panel.visible = false
	# 刷新卡牌网格
	_refresh_card_grid()
	if warning_label:
		warning_label.text = "书签已删除"
		warning_label.visible = true

func _return_current_pages() -> void:
	if current_bookmark:
		for page in current_bookmark.pages:
			GlobalCardLibrary.return_card(page.book_id, 1)
		current_bookmark.pages.clear()   # 清空当前书签，避免重复返还
		
