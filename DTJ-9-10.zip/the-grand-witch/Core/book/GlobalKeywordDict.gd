extends Node
## 全局关键词字典：管理关键词描述、效果逻辑与特效脚本

var keyword_dict: Dictionary = {}

func _ready():
	_register_default_keywords()

func _register_default_keywords():
	keyword_dict["始源"] = {
		"description": "增加卡牌效果，但同一书签内始源越多，效果越弱",
		"execute": _execute_primordial
	}
	keyword_dict["维协"] = {
		"description": "打出后获得维协buff，再次打出时消耗buff获得额外效果",
		"execute": _execute_harmony
	}
	keyword_dict["强压"] = {
		"description": "书签中书页少于上限时，触发额外特效，每缺少2张再触发一次",
		"execute": _execute_pressure
	}
	keyword_dict["统洁"] = {
		"description": "根据上一回合打出的统洁卡数量，触发20%比例的额外数值",
		"execute": _execute_purity
	}
	keyword_dict["疯狂"] = {
		"description": "任何类型可被赋予冲动，优先赋予；攻击卡伤害增幅，非攻击卡触发特效并增加攻击力；未打出时每张魔女化+1",
		"execute": _execute_crazy
}

func get_keyword_description(keyword_name: StringName) -> String:
	if keyword_dict.has(keyword_name):
		return keyword_dict[keyword_name]["description"]
	return ""

func execute_keyword(keyword_name: StringName, context) -> Dictionary:
	if keyword_dict.has(keyword_name):
		var func_ref = keyword_dict[keyword_name]["execute"]
		if func_ref is Callable:
			return func_ref.call(context)
	return {}

# ==================== 关键词效果实现（占位） ====================
##始源
func _execute_primordial(context) -> Dictionary:
	var result = {}
	var bookmark = context.get("bookmark")
	if bookmark:
		var count = 0
		for page in bookmark.pages:
			if "始源" in page.keywords:
				count += 1
		var multiplier = 1.0
		if count > 1:
			multiplier = pow(0.75, count - 1)
		var card = context["card"]
		result["effect_damage"] = card.effect_damage * multiplier
		result["effect_healing"] = card.effect_healing * multiplier
		result["effect_Armor"] = card.effect_Armor * multiplier
		result["effect_attack_bonus"] = card.effect_attack_bonus * multiplier
		result["effect_strength_power"] = card.effect_strength_power * multiplier
		result["effect_attack_segments"] = card.effect_attack_segments * multiplier
	return result
##维协
func _execute_harmony(context) -> Dictionary:
	var result = {}
	var card = context["card"]
	if GlobalPlayer.harmony_stacks > 0:
		GlobalPlayer.harmony_stacks -= 1
		result["effect_damage"] = card.effect_damage
		result["effect_healing"] = card.effect_healing
		result["effect_Armor"] = card.effect_Armor
		result["effect_attack_bonus"] = card.effect_attack_bonus
		result["effect_strength_power"] = card.effect_strength_power
		result["effect_attack_segments"] = card.effect_attack_segments
	GlobalPlayer.harmony_save += 1
	return result
##强压
func _execute_pressure(context) -> Dictionary:
	var result = {}
	var card = context["card"]
	var bookmark = context["bookmark"]
	if bookmark:
		var missing_pages = 5 - bookmark.pages.size()
		var extra_triggers = int(missing_pages / 2)
		if extra_triggers > 0:
			var multiplier = 1.0 + extra_triggers   # 额外触发 = 总倍率 = 1 + 额外次数
			result["effect_damage"] = card.effect_damage * multiplier
			result["effect_healing"] = card.effect_healing * multiplier
			result["effect_Armor"] = card.effect_Armor * multiplier
			result["effect_attack_bonus"] = card.effect_attack_bonus * multiplier
			result["effect_strength_power"] = card.effect_strength_power * multiplier
			result["effect_attack_segments"] = card.effect_attack_segments * multiplier
	return result
##统洁
func _execute_purity(context) -> Dictionary:
	var result = {}
	var card = context["card"]
	var bookmark = context["bookmark"]
	if bookmark == null:
		return result

	for type in card.purity_types:
		var count = 0
		for page in bookmark.pages:
			# 统计时，检查该页面是否拥有与当前类型相同的标签（通过 purity_types 或 pickup_type 判断）
			if type in page.purity_types or page.pickup_type == type:
				count += 1
		var bonus = 1.0 + 0.3 * count
		match type:
			Generator_bookpage.PickupType.Attack:
				result["effect_damage"] = card.effect_damage * bonus
			Generator_bookpage.PickupType.Defense:
				result["effect_Armor"] = card.effect_Armor * bonus
			Generator_bookpage.PickupType.Heal:
				result["effect_healing"] = card.effect_healing * bonus
			Generator_bookpage.PickupType.Ability:
				result["effect_attack_bonus"] = card.effect_attack_bonus * bonus
	return result
##疯狂
func _execute_crazy(context) -> Dictionary:
	var result = {}
	var card = context["card"]
	# 疯狂卡的特效数值直接来自卡牌 effect_* 字段，返回后由战斗系统合并
	result["effect_damage"] = card.effect_damage
	result["effect_healing"] = card.effect_healing
	result["effect_Armor"] = card.effect_Armor
	result["effect_attack_bonus"] = card.effect_attack_bonus
	result["effect_strength_power"] = card.effect_strength_power
	result["effect_attack_segments"] = card.effect_attack_segments
	return result
	
