extends Node

signal bookmark_removed(bookmark_data)
signal bookmark_added(bookmark_data)

var bookmarks: Array[BookmarkData] = []
var card_library: Array[Generator_bookpage] = []

# 角色自定义初始书签（由角色系统设置）
var custom_default_bookmarks: Array[BookmarkData] = []

func _ready():
	_load_card_library()
	# 游戏开始时没有库存书签，等待角色系统设置
	bookmarks.clear()

func _load_card_library():
	card_library.clear()
	var files = ResourceLoader.list_directory("res://Data/bookpage")
	for file in files:
		if file.ends_with(".tres"):
			var res = load("res://Data/bookpage/" + file)
			if res is Generator_bookpage:
				card_library.append(res)

## 设置角色自定义初始书签（供角色系统调用）
func set_custom_default_bookmarks(data: Array[BookmarkData]) -> void:
	bookmarks.clear()
	bookmarks = data.duplicate()
	# 为书签中的每张卡牌增加获得量（不增加可使用量）
	for bookmark in bookmarks:
		for page in bookmark.pages:
			GlobalCardLibrary.add_acquired_only(page.book_id, 1)
	# 发出信号，让 UI 刷新
	bookmark_added.emit(null)

func add_bookmark(data: BookmarkData) -> void:
	bookmarks.append(data)
	emit_signal("bookmark_added", data)

func can_add_bookmark() -> bool:
	return bookmarks.size() < 6

func remove_bookmark(data: BookmarkData) -> void:
	var index = bookmarks.find(data)
	if index != -1:
		bookmarks.remove_at(index)
		# 退还书签内所有书页的可使用量
		for page in data.pages:
			GlobalCardLibrary.return_card(page.book_id, 1)
		emit_signal("bookmark_removed", data)

func reset() -> void:
	bookmarks.clear()
	# 重置时不自动创建书签，等待角色系统重新设置
	bookmark_added.emit(null)
