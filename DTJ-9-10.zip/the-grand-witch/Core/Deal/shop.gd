extends Control
## 商店场景主脚本：负责商品生成、购买逻辑与 UI 交互

# 商品按钮引用
@onready var bundle_button: Button = $item/BundleButton
@onready var accessory_buttons: Array[Button] = [
	$item/AccessoryBox/AccessoryButton1,
	$item/AccessoryBox/AccessoryButton2
]
@onready var card_buttons: Array[Button] = [
	$item/CardBox/CradButton1,
	$item/CardBox/CradButton2,
	$item/CardBox/CradButton3,
	$item/CardBox/CradButton4
]
@onready var potion_button: Button = $item/PotionButton
@onready var close_button: Button = $CloseButton

# 捆绑书签预览标签所在 VBox
@onready var bundle_names_box: VBoxContainer = $item/BundleButton/BundleNamesBox
@onready var bundle_price_label: Label = $item/BundleButton/BundlePriceLabel
@onready var warning_label: Label = $WarningLabel

# 商品数据
var bundle_item: Dictionary = {}
var accessory_items: Array[Dictionary] = []
var card_items: Array[Dictionary] = []
var potion_item: Dictionary = {}
var selected_accessory_ids: Array[int] = []

# 饰品库和卡牌库
var all_accessories: Array[Generator_accessories] = []
var all_cards: Array[Generator_bookpage] = []

var _warning_timer: SceneTreeTimer = null

func _ready():
	_load_all_accessories()
	_load_all_cards()
	_generate_shop_items()
	_update_all_buttons()
	close_button.pressed.connect(_on_close_pressed)
	bundle_button.pressed.connect(_on_bundle_pressed)
	for btn in accessory_buttons:
		btn.pressed.connect(_on_accessory_pressed.bind(btn))
	for btn in card_buttons:
		btn.pressed.connect(_on_card_pressed.bind(btn))
	potion_button.pressed.connect(_on_potion_pressed)
	warning_label.visible = false
	_warning_timer = null

# ==================== 资源加载 ====================
func _load_all_accessories():
	all_accessories.clear()
	var files = ResourceLoader.list_directory("res://Data/accessories/")
	for file_name in files:
		if file_name.ends_with(".tres"):
			var res = load("res://Data/accessories/" + file_name)
			if res is Generator_accessories:
				# 根据稀有度生成价格
				res.price = _get_accessory_price(res.rarity)
				all_accessories.append(res)

func _load_all_cards():
	all_cards.clear()
	var files = ResourceLoader.list_directory("res://Data/bookpage/")
	for file_name in files:
		if file_name.ends_with(".tres"):
			var res = load("res://Data/bookpage/" + file_name)
			if res is Generator_bookpage:
				# 根据稀有度和类型生成价格
				res.price = _get_card_price(res.rarity, res.pickup_type)
				all_cards.append(res)

# ==================== 商品生成 ====================
func _generate_shop_items():
	# 1. 捆绑书签
	bundle_item = _generate_bundle_bookmark()

	# 2. 两个随机饰品（互斥，不重复）
	accessory_items.clear()
	selected_accessory_ids.clear()
	for i in range(2):
		var acc = _get_random_accessory()
		if acc:
			accessory_items.append({
				"type": "accessory",
				"name": acc.name,
				"description": acc.Tooltip if acc.Tooltip else "",
				"price": acc.price,
				"icon": acc.icon,
				"accessory": acc
			})

	# 3. 四张单卡牌
	card_items.clear()
	for i in range(4):
		var card = _get_random_card()
		if card:
			card_items.append({
				"type": "card",
				"name": card.page_name,
				"description": card.description,
				"price": card.price,
				"icon": card.icon,
				"card": card
			})

	# 4. 一个随机药水
	potion_item = _generate_potion_item()

func _get_accessory_price(rarity: int) -> int:
	match rarity:
		0: return randi_range(150-3, 150+3)
		1: return randi_range(215-5, 215+5)
		2: return randi_range(280-7, 280+7)
	return 150

func _get_card_price(rarity: int, pickup_type: int) -> int:
	var base = 0
	var variance = 0
	# 能力/回复卡额外提升一级
	var adjusted_rarity = rarity
	if pickup_type == Generator_bookpage.PickupType.Ability or pickup_type == Generator_bookpage.PickupType.Heal:
		adjusted_rarity += 1
		if adjusted_rarity > 2:
			adjusted_rarity = 2
	match adjusted_rarity:
		0:
			base = 20
			variance = 3
		1:
			base = 35
			variance = 5
		2:
			base = 50
			variance = 7
	return randi_range(base - variance, base + variance)

func _generate_bundle_bookmark() -> Dictionary:
	var epic_cards = all_cards.filter(func(c): return c.rarity == 2)
	var epic_card: Generator_bookpage
	if epic_cards.is_empty():
		epic_card = _create_placeholder_card("史诗卡（待设计）", 2)
	else:
		epic_card = epic_cards[randi() % epic_cards.size()]

	var non_epic_cards = all_cards.filter(func(c): return c.rarity != 2)
	if non_epic_cards.is_empty():
		non_epic_cards = [_create_placeholder_card("普通卡（待设计）", 0)]

	var pages: Array[Generator_bookpage] = [epic_card]
	for i in range(4):
		if randf() < 0.25:
			var rare_cards = non_epic_cards.filter(func(c): return c.rarity == 1)
			if rare_cards.size() > 0:
				pages.append(rare_cards[randi() % rare_cards.size()])
			else:
				pages.append(non_epic_cards[randi() % non_epic_cards.size()])
		else:
			var normal_cards = non_epic_cards.filter(func(c): return c.rarity == 0)
			if normal_cards.size() > 0:
				pages.append(normal_cards[randi() % normal_cards.size()])
			else:
				pages.append(non_epic_cards[randi() % non_epic_cards.size()])

	var price = 120
	return {
		"type": "bundle_bookmark",
		"name": "捆绑书签",
		"description": "包含1张史诗卡牌和4张随机卡牌",
		"price": price,
		"icon": epic_card.icon,
		"pages": pages,
		"card": epic_card
	}

func _create_placeholder_card(card_name: String, rarity: int) -> Generator_bookpage:
	var card = Generator_bookpage.new()
	card.page_name = card_name
	card.rarity = rarity
	card.description = "待设计卡牌"
	card.icon = load("res://Assets/Textures/Icons/placeholder_card.png")
	return card

func _get_random_card() -> Generator_bookpage:
	if all_cards.is_empty():
		return null
	return all_cards[randi() % all_cards.size()]

func _generate_potion_item() -> Dictionary:
	var roll = randf()
	var name = ""
	var desc = ""
	var effect = ""
	if roll < 0.4:
		name = "小型治疗药水"
		desc = "回复30%生命值"
		effect = "heal_30"
	elif roll < 0.7:
		name = "大型治疗药水"
		desc = "回复80%生命值"
		effect = "heal_80"
	elif roll < 0.9:
		name = "净化药水"
		desc = "降低33%魔女化"
		effect = "witch_33"
	else:
		name = "完全净化药水"
		desc = "完全清除魔女化"
		effect = "witch_100"
	return {
		"type": "potion",
		"name": name,
		"description": desc,
		"price": 50,
		"effect": effect
	}

# ==================== 饰品随机 ====================
func _get_random_accessory() -> Generator_accessories:
	var owned_ids = []
	for a in GlobalAccessories.accessories:
		owned_ids.append(a.acc_id)

	var pool: Array[Dictionary] = []
	for acc in all_accessories:
		if acc.acc_id in owned_ids:
			continue
		if acc.acc_id in selected_accessory_ids:
			continue
		if (acc.acc_id >= 666 and acc.acc_id <= 700) or acc.acc_id >= 1000:
			continue
		if acc.acc_id >= 1 and acc.acc_id <= 33:
			pool.append({"acc": acc, "weight": 25})
		elif acc.acc_id >= 34 and acc.acc_id <= 66:
			pool.append({"acc": acc, "weight": 15})
		elif acc.acc_id >= 67 and acc.acc_id <= 99:
			pool.append({"acc": acc, "weight": 10})
		elif acc.acc_id >= 777 and acc.acc_id <= 800:
			pool.append({"acc": acc, "weight": 50})

	if pool.is_empty():
		return null

	var total_weight = 0
	for entry in pool:
		total_weight += entry.weight
	var roll = randi() % total_weight
	var cumulative = 0
	for entry in pool:
		cumulative += entry.weight
		if roll < cumulative:
			var chosen = entry.acc
			selected_accessory_ids.append(chosen.acc_id)
			return chosen
	return null

# ==================== 按钮更新 ====================
func _update_all_buttons():
	if not bundle_item.is_empty():
		bundle_button.visible = true
		if bundle_price_label:
			bundle_price_label.text = "%d金币" % bundle_item["price"]
			bundle_price_label.visible = true
		_update_bundle_preview(bundle_item)
	else:
		bundle_button.visible = false
		if bundle_price_label:
			bundle_price_label.visible = false
		_clear_bundle_preview()

	for i in range(accessory_buttons.size()):
		if i < accessory_items.size():
			_set_button(accessory_buttons[i], accessory_items[i])
		else:
			accessory_buttons[i].visible = false

	for i in range(card_buttons.size()):
		if i < card_items.size():
			_set_button(card_buttons[i], card_items[i])
		else:
			card_buttons[i].visible = false

	if not potion_item.is_empty():
		_set_button(potion_button, potion_item)
	else:
		potion_button.visible = false

func _set_button(btn: Button, item: Dictionary):
	btn.text = "%s\n%d金币" % [item["name"], item["price"]]
	btn.icon = item.get("icon", null)
	btn.tooltip_text = item["description"]
	btn.visible = true

func _update_bundle_preview(item: Dictionary):
	var pages = item.get("pages", [])
	var labels = bundle_names_box.get_children()
	for i in range(labels.size()):
		if i < pages.size():
			labels[i].text = pages[i].page_name
			labels[i].visible = true
		else:
			labels[i].visible = false

func _clear_bundle_preview():
	for label in bundle_names_box.get_children():
		label.visible = false

# ==================== 购买逻辑 ====================
func _on_bundle_pressed():
	if not bundle_item.is_empty():
		_purchase_item(bundle_item)

func _on_accessory_pressed(btn: Button):
	var idx = accessory_buttons.find(btn)
	if idx != -1 and idx < accessory_items.size():
		_purchase_item(accessory_items[idx])

func _on_card_pressed(btn: Button):
	var idx = card_buttons.find(btn)
	if idx != -1 and idx < card_items.size():
		_purchase_item(card_items[idx])

func _on_potion_pressed():
	if not potion_item.is_empty():
		_purchase_item(potion_item)

func _purchase_item(item: Dictionary):
	if GlobalPlayer.gold < item["price"]:
		_show_warning("金币不足")
		return
	GlobalPlayer.gold -= item["price"]
	GlobalPlayer.gold_changed.emit(GlobalPlayer.gold)

	match item["type"]:
		"bundle_bookmark":
			_apply_bundle(item)
			bundle_button.queue_free()
		"accessory":
			GlobalAccessories.add_accessory(item["accessory"])
			var acc_idx = accessory_items.find(item)
			if acc_idx != -1:
				accessory_buttons[acc_idx].queue_free()
				accessory_buttons.remove_at(acc_idx)
				accessory_items.remove_at(acc_idx)
		"card":
			GlobalCardLibrary.add_acquired_count(item["card"].book_id, 1)
			var card_idx = card_items.find(item)
			if card_idx != -1:
				card_buttons[card_idx].queue_free()
				card_buttons.remove_at(card_idx)
				card_items.remove_at(card_idx)
		"potion":
			_apply_potion(item)
			potion_button.queue_free()

func _show_warning(text: String):
	warning_label.text = text
	warning_label.visible = true
	_warning_timer = get_tree().create_timer(3.0)
	_warning_timer.timeout.connect(_hide_warning)

func _hide_warning():
	warning_label.visible = false

func _apply_bundle(item: Dictionary):
	var bookmark = BookmarkData.new()
	bookmark.title = "捆绑书签"
	for page in item["pages"]:
		bookmark.pages.append(page)
	GlobalBookMark.add_bookmark(bookmark)
	print("获得捆绑书签")

func _apply_potion(item: Dictionary):
	match item["effect"]:
		"heal_30":
			GlobalPlayer.heal(int(GlobalPlayer.max_health * 0.3))
		"heal_80":
			GlobalPlayer.heal(int(GlobalPlayer.max_health * 0.8))
		"witch_33":
			GlobalPlayer.possessed(-int(GlobalPlayer.max_witch_power * 0.33))
		"witch_100":
			GlobalPlayer.possessed(-GlobalPlayer.max_witch_power)

func _on_close_pressed():
	var overlay = get_parent()
	queue_free()
	if overlay is Control:
		overlay.visible = false

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_on_close_pressed()
