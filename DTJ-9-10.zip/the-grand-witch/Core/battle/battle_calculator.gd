extends Node
## 负责伤害、治疗、护甲等数值计算

var player_attack_bonus: int = 0

func calculate_player_effects(cards: Array[BookmarkCard], attack_bonus: int, player_ui) -> Dictionary:
	var result = {"damage": 0, "healing": 0, "armor": 0}
	var accessory_bonus = _get_accessory_attack_bonus()
	var total_attack_bonus = attack_bonus + accessory_bonus

	for card in cards:
		print("=== 卡牌：", card.bookmark_data.title, " ===")
		for idx in range(card.bookmark_data.pages.size()):
			var page = card.bookmark_data.pages[idx]
			var has_impulse = player_ui.has_impulse(card, idx)
			print("  页面：", page.page_name, " 类型：", page.pickup_type, " 带冲动：", has_impulse)

			match page.pickup_type:
				Generator_bookpage.PickupType.Attack:
					var base_damage = page.damage + total_attack_bonus + page.strength_power
					if has_impulse:
						var multiplier = GlobalPlayer.get_impulse_damage_multiplier()
						base_damage = int(ceil(base_damage * multiplier))
						player_ui.consume_impulse(card, idx)
					var total_segments = 1 + page.attack_segments + page.effect_attack_segments
					result.damage += base_damage * total_segments
					print("    攻击基础伤害：", base_damage, " 段数：", total_segments, " 小计：", base_damage * total_segments)
				Generator_bookpage.PickupType.Heal:
					result.healing += page.healing
					print("    治疗：", page.healing)
				Generator_bookpage.PickupType.Defense:
					result.armor += page.Armor
					print("    护甲：", page.Armor)
				Generator_bookpage.PickupType.Ability:
					player_attack_bonus += page.attack_bonus
					print("    攻击加成：", page.attack_bonus)

			# 关键词统一执行
			for keyword in page.keywords:
				print("    关键词：", keyword)
				var context = {
					"card": page,
					"bookmark": card.bookmark_data,
					"player_cards": cards,
					"player_attack_bonus": player_attack_bonus,
					"has_impulse": has_impulse,
					"enemy_witch_power": 0,
				}
				var keyword_result = GlobalKeywordDict.execute_keyword(keyword, context)
				print("      关键词返回：", keyword_result)
				result.damage += keyword_result.get("effect_damage", 0)
				result.healing += keyword_result.get("effect_healing", 0)
				result.armor += keyword_result.get("effect_Armor", 0)
				player_attack_bonus += keyword_result.get("effect_attack_bonus", 0)

			# 特效脚本
			if page.effect_script:
				print("    特效脚本：", page.effect_script.resource_path)
				var script_obj = page.effect_script.new()
				if script_obj.has_method("execute"):
					script_obj.execute({
						"card": page,
						"bookmark": card.bookmark_data,
						"player_cards": cards,
						"player_attack_bonus": player_attack_bonus,
						"has_impulse": has_impulse,
						"enemy_witch_power": 0,
					})
				else:
					print("      脚本缺少 execute 方法")

	for card in cards:
		card.set_selected(false)
		card.start_cooldown()
	print("=== 最终结果：伤害=", result.damage, " 治疗=", result.healing, " 护甲=", result.armor, " 攻击加成=", player_attack_bonus, " ===")
	return result

func get_player_attack_bonus() -> int:
	return player_attack_bonus

func calculate_monster_attack(monster_attack: int, player_armor: int) -> Dictionary:
	var actual_damage = max(monster_attack - player_armor, 0)
	return {"damage_dealt": actual_damage}

func _get_accessory_attack_bonus() -> int:
	var bonus = 0
	for acc in GlobalAccessories.accessories:
		bonus += acc.attack_bonus
	return bonus
