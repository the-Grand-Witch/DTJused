extends Node
## 普通战斗主控制器：负责初始化、回合流程与模块协调

signal monster_defeated

@onready var monster_manager = $Monster
@onready var player_ui = $Player
@onready var battle_calculator = $BattleCalculator
@onready var reward_manager = $RewardManager
@onready var turn_label = $TurnLabel
@onready var end_turn_button = $EndTurnButton
@onready var player_buff_display = $Player/buff/Buffscenses
var player_status_dict: Dictionary = {}
const BookmarkCardScene = preload("res://scenes/bookmark.tscn")

var turn_count: int = 0
var player_attack_bonus: int = 0
var player_selected_cards: Array[BookmarkCard] = []
var player_cards: Array[BookmarkCard] = []
var player_max_selected: int = 1
var loot_bonus: int = 0
var previous_scene_path: String = "res://scenes/main.tscn"

# 本回合使用过的能力页（用于状态图标显示）
var used_ability_pages: Array[Generator_bookpage] = []

func _ready():
	previous_scene_path = GlobalScenes.last_scene_path
	monster_manager.load_random_monster()
	monster_manager.setup_ui()
	player_ui.clear_hand()
	_create_player_cards()
	end_turn_button.pressed.connect(_on_end_turn_pressed)
	_start_round()
	_update_player_buffs()
	player_status_dict.clear()
	_update_player_buffs()

func _create_player_cards():
	player_cards.clear()
	for data in GlobalBookMark.bookmarks:
		var card = BookmarkCardScene.instantiate()
		player_ui.add_card(card)
		card.setup(data)
		card.selection_changed.connect(_on_player_card_selected.bind(card))
		player_cards.append(card)

func _on_player_card_selected(selected: bool, card: BookmarkCard):
	if selected:
		if player_selected_cards.size() >= player_max_selected:
			var oldest = player_selected_cards[0]
			player_selected_cards.erase(oldest)
			oldest.set_selected(false)
		player_selected_cards.append(card)
	else:
		player_selected_cards.erase(card)

func _start_round():
	turn_count += 1
	turn_label.text = "回合 %d" % turn_count
	GlobalPlayer.harmony_stacks = GlobalPlayer.harmony_save;
	GlobalPlayer.harmony_save = 0
	# 玩家卡牌冷却递减
	for card in player_cards:
		card.decrease_cooldown()

	# 从全局玩家获取冲动数量，然后赋予冲动
	var impulse_count = GlobalPlayer.get_impulse_count()
	player_ui.apply_impulses(player_cards, impulse_count)

	# 清空本回合能力页记录
	used_ability_pages.clear()

func _on_end_turn_pressed():
	#时间
	GlobalTime.add_time_units(1)

	# 收集本回合使用的能力页，并累加到常驻状态字典
	for card in player_selected_cards:
		for page in card.bookmark_data.pages:
			if page.pickup_type == Generator_bookpage.PickupType.Ability:
				player_status_dict[page] = player_status_dict.get(page, 0) + 1

	# 玩家结算
	var player_result = battle_calculator.calculate_player_effects(
		player_selected_cards,
		player_attack_bonus,
		player_ui
	)
	# 更新玩家攻击加成
	player_attack_bonus = battle_calculator.get_player_attack_bonus()

	# 怪物承受伤害
	monster_manager.take_damage(player_result.damage)
	if monster_manager.is_dead():
		_on_monster_defeated()
		return

	# 玩家治疗
	if player_result.healing > 0:
		GlobalPlayer.heal(player_result.healing)

	# 玩家未打出的冲动惩罚
	player_ui.punish_unused_impulses()
	# 疯狂卡惩罚：所有未打出的疯狂卡，每张魔女化+1
	for card in player_cards:
		if card not in player_selected_cards:
			for page in card.bookmark_data.pages:
				if "疯狂" in page.keywords:
					GlobalPlayer.possessed(1)
					break

	# 怪物反击
	var monster_result = battle_calculator.calculate_monster_attack(
		monster_manager.get_attack(),
		player_result.armor
	)
	if monster_result.damage_dealt > 0:
		# 格挡充能：如果有，则抵消本次伤害
		if GlobalPlayer.get_block_charge() > 0:
			GlobalAccessories.consume_block_charge()
		else:
			GlobalPlayer.take_damage(monster_result.damage_dealt)

	# 检查玩家生命
	if GlobalPlayer.health <= 0:
		GlobalScenes.check_game_over()
		return
	GlobalPlayer.harmony_stacks = 0
	_start_round()
	_update_player_buffs()

func _update_player_buffs():
	# 复制卡牌来源状态（常驻）
	var statuses = player_status_dict.duplicate()
	# 系统来源：饰品攻击加成
	var accessory_bonus = _get_accessory_attack_bonus()
	if accessory_bonus > 0:
		statuses["accessory_attack"] = accessory_bonus
	player_buff_display.update_display(statuses)

func _get_accessory_attack_bonus() -> int:
	var bonus = 0
	for acc in GlobalAccessories.accessories:
		bonus += acc.attack_bonus
	return bonus

func _on_monster_defeated():
	end_turn_button.disabled = true
	reward_manager.show_rewards(monster_manager.get_current_monster(), loot_bonus, previous_scene_path)
	emit_signal("monster_defeated")

func increase_loot_bonus(amount: int):
	loot_bonus += amount
