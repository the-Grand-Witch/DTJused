extends Node
## 负责玩家手牌显示和杀人冲动标记

@onready var hand_container = $player_hand_container

var player_impulse_pages: Array[Dictionary] = []

func clear_hand():
	for child in hand_container.get_children():
		child.queue_free()
	player_impulse_pages.clear()

func add_card(card: BookmarkCard):
	hand_container.add_child(card)

# ==================== 冲动 ====================
func clear_impulses():
	for entry in player_impulse_pages:
		var card: BookmarkCard = entry["card"]
		var page_index: int = entry["page_index"]
		var label = card.get_page_label_by_index(page_index)
		if label:
			label.modulate = Color(1, 1, 1)
	player_impulse_pages.clear()

func apply_impulses(cards: Array[BookmarkCard], count: int):
	clear_impulses()
	if count <= 0:
		return

	# 收集所有可被赋予冲动的页面：优先疯狂卡
	var priority_pages: Array[Dictionary] = []
	var normal_pages: Array[Dictionary] = []
	for card in cards:
		for idx in range(card.bookmark_data.pages.size()):
			var page = card.bookmark_data.pages[idx]
			if "疯狂" in page.keywords:
				priority_pages.append({"card": card, "page_index": idx})
			elif page.pickup_type == Generator_bookpage.PickupType.Attack:
				normal_pages.append({"card": card, "page_index": idx})

	# 先选疯狂页，不足再选普通攻击页
	var selected_pages: Array[Dictionary] = priority_pages.duplicate()
	while selected_pages.size() < count and not normal_pages.is_empty():
		selected_pages.append(normal_pages.pop_front())

	# 随机打乱后取前count个
	selected_pages.shuffle()
	for i in range(min(count, selected_pages.size())):
		var entry = selected_pages[i]
		player_impulse_pages.append(entry)
		var card: BookmarkCard = entry["card"]
		var page_index: int = entry["page_index"]
		var label = card.get_page_label_by_index(page_index)
		if label:
			label.modulate = Color(0.6, 0.2, 1)

func has_impulse(card: BookmarkCard, page_index: int) -> bool:
	for entry in player_impulse_pages:
		if entry["card"] == card and entry["page_index"] == page_index:
			return true
	return false

func consume_impulse(card: BookmarkCard, page_index: int) -> bool:
	for i in range(player_impulse_pages.size()):
		var entry = player_impulse_pages[i]
		if entry["card"] == card and entry["page_index"] == page_index:
			player_impulse_pages.remove_at(i)
			var label = card.get_page_label_by_index(page_index)
			if label:
				label.modulate = Color(1, 1, 1)
			return true
	return false

func punish_unused_impulses():
	if player_impulse_pages.is_empty():
		return
	for entry in player_impulse_pages:
		var card: BookmarkCard = entry["card"]
		GlobalPlayer.possessed(GlobalPlayer.get_impulse_punishment())
		var label = card.get_page_label_by_index(entry["page_index"])
		if label:
			label.modulate = Color(1, 1, 1)
	player_impulse_pages.clear()
