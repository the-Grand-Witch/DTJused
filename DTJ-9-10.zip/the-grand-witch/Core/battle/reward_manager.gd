extends Node
## 负责怪物掉落计算和奖励弹窗显示

const REWARD_POPUP_SCENE = preload("res://scenes/RewardPopup.tscn")

var accessory_library: Array[Generator_accessories] = []
var available_accessories: Array[Generator_accessories] = []

func _ready():
	_load_accessory_library()
	_init_available_accessories()

func _load_accessory_library():
	accessory_library.clear()
	var files = ResourceLoader.list_directory("res://Data/accessories/")
	for file_name in files:
		if file_name.ends_with(".tres"):
			var res = load("res://Data/accessories/" + file_name)
			if res is Generator_accessories:
				accessory_library.append(res)

func _init_available_accessories():
	available_accessories.clear()
	for acc in accessory_library:
		if not _is_accessory_owned(acc):
			available_accessories.append(acc)

func show_rewards(monster: Generator_monster, loot_bonus: int, previous_scene_path: String):
	var gold = randi_range(monster.min_gold, monster.max_gold)
	var dropped_accessories: Array[Generator_accessories] = []

	if monster.fixed_drop_id != -1:
		var fixed_acc = _get_accessory_by_id(monster.fixed_drop_id)
		if fixed_acc and not _is_accessory_owned(fixed_acc):
			dropped_accessories.append(fixed_acc)

	var candidates: Array[Generator_accessories] = []
	for acc in available_accessories:
		if acc.acc_id >= monster.accessory_id_min and acc.acc_id <= monster.accessory_id_max:
			candidates.append(acc)

	var count = monster.random_drop_count + loot_bonus
	count = min(count, candidates.size())
	for i in range(count):
		var idx = randi() % candidates.size()
		var acc = candidates[idx]
		candidates.remove_at(idx)
		available_accessories.erase(acc)
		dropped_accessories.append(acc)

	var popup = REWARD_POPUP_SCENE.instantiate()
	add_child(popup)
	popup.setup_rewards(gold, dropped_accessories)
	popup.closed.connect(func(): get_tree().change_scene_to_file(previous_scene_path))

func _get_accessory_by_id(acc_id: int) -> Generator_accessories:
	for acc in accessory_library:
		if acc.acc_id == acc_id:
			return acc
	return null

func _is_accessory_owned(accessory: Generator_accessories) -> bool:
	for owned in GlobalAccessories.accessories:
		if owned.acc_id == accessory.acc_id:
			return true
	return false
