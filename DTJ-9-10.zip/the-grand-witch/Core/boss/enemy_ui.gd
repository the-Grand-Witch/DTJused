extends Node
## 敌人 UI 模块：负责立绘、血条、意图图标和状态图标

@onready var health_bar = $"../EnemyHealthBar"
@onready var portrait = $"../EnemyPortrait"
@onready var intent_icon = $"../EnemyIntent"
@onready var buff_display =  $"../buff/Buffscenses"

func setup(snapshot, max_health, current_health):
	health_bar.max_value = max_health
	health_bar.value = current_health
	if snapshot.portrait:
		portrait.texture = snapshot.portrait
		portrait.visible = true
	else:
		portrait.visible = false

func update_health(current, max_val):
	health_bar.max_value = max_val
	health_bar.value = current

func show_intent(card, ai_module):
	if card == null:
		intent_icon.texture = null
		return
	var main_type = ai_module.get_main_type(card)
	var path = "res://Assets/Textures/Icons/intent/%s.png" % main_type
	intent_icon.texture = load(path)

## 更新敌人状态图标
func update_buffs(statuses: Dictionary):
	buff_display.update_display(statuses)
