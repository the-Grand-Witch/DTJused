extends Node

func choose_card(cards, enemy_health, enemy_max_health, player_health, player_max_health, witch_power, impulses) -> BookmarkCard:
	var candidates: Array[BookmarkCard] = []
	for card in cards:
		if card.is_ready():
			candidates.append(card)
	if candidates.is_empty():
		return null

	if enemy_health > enemy_max_health * 0.9:
		candidates.sort_custom(func(a,b): return count_type(a, Generator_bookpage.PickupType.Ability) > count_type(b, Generator_bookpage.PickupType.Ability))
	elif player_health < player_max_health * 0.4:
		candidates.sort_custom(func(a,b): return count_type(a, Generator_bookpage.PickupType.Attack) > count_type(b, Generator_bookpage.PickupType.Attack))
	elif enemy_health < enemy_max_health * 0.6:
		candidates.sort_custom(func(a,b):
			var sa = count_type(a, Generator_bookpage.PickupType.Attack) * count_type(a, Generator_bookpage.PickupType.Defense)
			var sb = count_type(b, Generator_bookpage.PickupType.Attack) * count_type(b, Generator_bookpage.PickupType.Defense)
			return sa > sb
		)


	if witch_power > 60:
		candidates.sort_custom(func(a,b): return count_impulses(b, impulses) < count_impulses(a, impulses))
	elif witch_power > 30:
		candidates.sort_custom(func(a,b): return count_impulses(b, impulses)*2 + score(a) < count_impulses(a, impulses)*2 + score(b))
	return candidates[0]

func count_type(card, type) -> int:
	var c = 0
	for p in card.bookmark_data.pages:
		if p.pickup_type == type: c += 1
	return c

func count_impulses(card, impulses) -> int:
	var c = 0
	for entry in impulses:
		if entry["card"] == card: c += 1
	return c

func score(card) -> int:
	return count_type(card, Generator_bookpage.PickupType.Attack) + count_type(card, Generator_bookpage.PickupType.Ability)

func get_main_type(card) -> String:
	var counts = {
		"Attack": count_type(card, Generator_bookpage.PickupType.Attack),
		"Defense": count_type(card, Generator_bookpage.PickupType.Defense),
		"Ability": count_type(card, Generator_bookpage.PickupType.Ability),
		"Heal": count_type(card, Generator_bookpage.PickupType.Heal),
	}
	var max_key = "Attack"
	var max_val = -1
	for k in counts:
		if counts[k] > max_val:
			max_val = counts[k]
			max_key = k
	return max_key
