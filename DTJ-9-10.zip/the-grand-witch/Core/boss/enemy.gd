extends Node
## 敌人根节点，统一管理 AI、魔女化、UI 子模块

# 引用模块
@onready var ai = $enemyAI
@onready var witch = $WitchSystem
@onready var ui = $enemyUI

# 敌人数据
var snapshot: PlayerSnapshot
var health: int
var max_health: int
var base_attack: int
var cards: Array[BookmarkCard] = []
var selected_card: BookmarkCard
var stunned: bool = false

func setup(snap: PlayerSnapshot):
	snapshot = snap
	max_health = snap.max_health
	health = snap.current_health
	base_attack = snap.base_attack
	witch.setup(snap.witch_power)
	ui.setup(snap, max_health, health)
	_create_cards()

func _create_cards():
	cards.clear()
	for data in snapshot.bookmarks:
		var card = preload("res://scenes/bookmark.tscn").instantiate()
		$EnemyHandContainer.add_child(card)
		card.setup(data)
		card.current_cd = 0
		cards.append(card)

func on_round_start(turn_count: int):
	# 冷却递减
	for card in cards:
		card.decrease_cooldown()

	# 魔女化系统：赋予冲动、触发彼岸之赐
	witch.on_round_start(turn_count, cards)

	# 更新敌人状态图标（彼岸之赐可能改变永久效果）
	_update_buff_display()

	# AI 选择书签
	selected_card = ai.choose_card(
		cards,
		health,
		max_health,
		GlobalPlayer.health,
		GlobalPlayer.max_health,
		witch.get_witch_power(),
		witch.get_impulses()
	)
	ui.show_intent(selected_card, ai)

func take_turn(player_armor: int) -> Dictionary:
	var result = {"damage_dealt": 0, "healing": 0, "armor": 0}
	if stunned:
		stunned = false
		return result

	if cards.is_empty():
		var attack_multiplier = witch.get_attack_multiplier()
		var attack_bonus = witch.get_permanent_effect("attack_bonus")
		var damage = int((base_attack + attack_bonus) * attack_multiplier)
		var actual = max(damage - player_armor, 0)
		if actual > 0:
			# 格挡充能：如果有，抵消本次伤害
			if GlobalPlayer.get_block_charge() > 0:
				GlobalAccessories.consume_block_charge()
			else:
				GlobalPlayer.take_damage(actual)
		result["damage_dealt"] = actual
		return result

	# 正常手牌阶段
	if selected_card:
		var card_result = _calculate_enemy_card_effects(selected_card, player_armor)
		result["damage_dealt"] = card_result.damage_dealt
		result["healing"] = card_result.healing
		result["armor"] = card_result.armor

		if card_result.damage_dealt > 0:
			# 格挡充能判断
			if GlobalPlayer.get_block_charge() > 0:
				GlobalAccessories.consume_block_charge()
			else:
				GlobalPlayer.take_damage(card_result.damage_dealt)

		health = min(health + result.healing, max_health)
		ui.update_health(health, max_health)
		witch.update_witch_power_after_played_card(selected_card, card_result.damage_dealt)
		selected_card.start_cooldown()

	# 未打出的冲动惩罚
	witch.punish_unused_impulses(selected_card)

	# 检查魔女化满值
	if witch.get_witch_power() >= 100:
		_transform()

	return result

func _calculate_enemy_card_effects(card: BookmarkCard, player_armor: int) -> Dictionary:
	var result = {"damage_dealt": 0, "healing": 0, "armor": 0}
	var attack_bonus = witch.get_permanent_effect("attack_bonus")
	var attack_multiplier = witch.get_attack_multiplier()
	var total_damage = 0
	for idx in range(card.bookmark_data.pages.size()):
		var page = card.bookmark_data.pages[idx]
		match page.pickup_type:
			Generator_bookpage.PickupType.Attack:
				var base_float = (base_attack + attack_bonus + page.damage) * attack_multiplier
				if witch.has_impulse(card, idx):
					base_float *= (1.0 + float(witch.get_witch_power()) / 100.0)
				total_damage += int(base_float)
			Generator_bookpage.PickupType.Heal:
				result.healing += page.healing
			Generator_bookpage.PickupType.Defense:
				result.armor += page.Armor
	var actual_damage = max(total_damage - player_armor, 0)
	result.damage_dealt = actual_damage
	return result

func _transform():
	cards.clear()
	var transform_result = witch.transform(snapshot, max_health, health)
	max_health = transform_result["max_health"]
	health = transform_result["health"]
	ui.update_health(health, max_health)
	# 更新状态图标
	_update_buff_display()
	stunned = true

## 更新敌人状态图标：从 WitchSystem 获取永久效果和彼岸层数
func _update_buff_display():
	var statuses = {}
	var effects = witch.get_permanent_effects()
	if effects["attack_bonus"] > 0:
		statuses["attack_bonus"] = effects["attack_bonus"]
	if effects["armor_per_turn"] > 0:
		statuses["armor_per_turn"] = effects["armor_per_turn"]
	if effects["heal_per_turn"] > 0:
		statuses["heal_per_turn"] = effects["heal_per_turn"]
	if witch.get_bian_layers() > 0:
		statuses["bian_layers"] = witch.get_bian_layers()
	ui.update_buffs(statuses)

func get_health():
	return health

func get_max_health():
	return max_health

func take_damage(amount: int):
	health -= amount
	ui.update_health(health, max_health)

func heal(amount: int):
	health = min(health + amount, max_health)
	ui.update_health(health, max_health)
