extends Node
## 显示当前天数（第 X 天）
@onready var day_label: Label = $TextureRect/Label

func _ready():
	# 初始化显示
	_update_day(GlobalTime.get_day())
	# 监听时间变化信号，实时更新天数
	GlobalTime.time_changed.connect(_on_time_changed)

func _on_time_changed(_total_minutes: int):
	_update_day(GlobalTime.get_day())

func _update_day(day: int):
	day_label.text = "第 %d 天" % day
