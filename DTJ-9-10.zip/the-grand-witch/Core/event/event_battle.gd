extends Control
#卡牌效果调用，方法一定要是trigger_effect（后续缩写为FE）
#写不下就用这个FE调用别的，因为cardmanaeger只会调用这个方法
func trigger_effect(btn: Button) -> bool:
	GlobalScenes.enter_battle()
	return true
