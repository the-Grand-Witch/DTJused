extends Node

const REWARD_POPUP_SCENE = preload("res://scenes/RewardPopup.tscn")

var btn: Button
var remaining_digs: int = 0
var target_digs: int = 0
var reward_type: String = ""
var accessory_range: Vector2i = Vector2i(1, 19)

func trigger_effect(button: Button) -> bool:
	btn = button
	_roll_reward()
	remaining_digs = target_digs
	
	# 断开按钮原有信号，连接到本脚本的方法
	if btn.pressed.is_connected(_on_button_pressed):
		btn.pressed.disconnect(_on_button_pressed)
	for connection in btn.pressed.get_connections():
		btn.pressed.disconnect(connection["callable"])
	btn.pressed.connect(_on_button_pressed)
	
	return false   # 返回 false，阻止管理器刷新按钮

func _on_button_pressed():
	remaining_digs -= 1
	GlobalTime.add_time_units(1)
	
	if remaining_digs <= 0:
		_give_reward()
		# 恢复按钮信号到管理器
		btn.pressed.disconnect(_on_button_pressed)
		btn.pressed.connect(GlobalScenes.event_manager._on_option_pressed.bind(btn))
		# 刷新按钮
		GlobalScenes.event_manager._create_card(btn)
		queue_free()
	else:
		# 可选的反馈：例如更改按钮文本（但会干扰，故省略）
		pass

func _roll_reward():
	var roll = randf() * 100.0
	if roll < 5.0:
		reward_type = "accessory"
		accessory_range = Vector2i(80, 99)
		target_digs = 8
	elif roll < 22.0:
		reward_type = "accessory"
		accessory_range = Vector2i(20, 40)
		target_digs = randi_range(5, 7)
	elif roll < 55.0:
		reward_type = "accessory"
		accessory_range = Vector2i(1, 19)
		target_digs = randi_range(3, 5)
	else:
		reward_type = "gold"
		target_digs = randi_range(1, 3)

func _give_reward():
	if reward_type == "gold":
		var gold = randi_range(20, 40)
		GlobalPlayer.add_gold(gold)
		print("挖掘完成，获得金币：", gold)
		_show_reward_popup({"type": "gold", "amount": gold})
	else:
		var chosen = _get_random_accessory(accessory_range.x, accessory_range.y)
		if chosen:
			GlobalAccessories.add_accessory(chosen)
			print("挖掘完成，获得饰品：", chosen.name)
			_show_reward_popup({"type": "accessory", "accessory": chosen})
		else:
			var gold = randi_range(20, 40)
			GlobalPlayer.add_gold(gold)
			print("该范围内无可用饰品，降级为金币：", gold)
			_show_reward_popup({"type": "gold", "amount": gold})

func _get_random_accessory(id_min: int, id_max: int) -> Generator_accessories:
	var all_accessories = _load_all_accessories()
	var candidates: Array[Generator_accessories] = []
	for acc in all_accessories:
		if acc.acc_id >= id_min and acc.acc_id <= id_max:
			if not GlobalAccessories.has_accessory(acc.acc_id):
				candidates.append(acc)
	if candidates.is_empty():
		return null
	return candidates[randi() % candidates.size()]

func _load_all_accessories() -> Array[Generator_accessories]:
	var result: Array[Generator_accessories] = []
	var files = ResourceLoader.list_directory("res://Data/accessories/")
	for file_name in files:
		if file_name.ends_with(".tres"):
			var res = load("res://Data/accessories/" + file_name)
			if res is Generator_accessories:
				result.append(res)
	return result

func _show_reward_popup(reward: Dictionary):
	# 创建 CanvasLayer，设置高层级确保弹窗在最上层
	var canvas_layer = CanvasLayer.new()
	canvas_layer.layer = 10
	get_tree().current_scene.add_child(canvas_layer)
	
	var popup = REWARD_POPUP_SCENE.instantiate()
	canvas_layer.add_child(popup)
	
	# 准备奖励数据
	var gold = 0
	var accs: Array[Generator_accessories] = []
	if reward["type"] == "gold":
		gold = reward["amount"]
	else:
		accs.append(reward["accessory"])
	popup.setup_rewards(gold, accs)
	
	# 弹窗关闭后销毁 CanvasLayer，避免内存泄漏
	popup.closed.connect(func():
		canvas_layer.queue_free()
	)
