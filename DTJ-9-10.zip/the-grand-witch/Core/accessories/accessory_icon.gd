extends TextureRect
class_name AccessoryIcon

# 用于存储 Tooltip 字体大小
var tooltip_font_size: int = 14

func _make_custom_tooltip(for_text: String) -> Object:
	var label = Label.new()
	label.text = for_text
	# 设置字体大小
	label.add_theme_font_size_override("font_size", tooltip_font_size)
	# 可选：设置自动换行、最大宽度等
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.custom_minimum_size = Vector2(200, 0)   # 限制最大宽度，防止过长
	return label
