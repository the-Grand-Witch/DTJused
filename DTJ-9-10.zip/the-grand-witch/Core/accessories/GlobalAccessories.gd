extends Node

signal accessory_added(accessory: Generator_accessories)
signal accessory_removed(acc_id: int)

var accessories: Array[Generator_accessories] = []
var block_charges: int = 0         # 当前充能，初始为1
var block_charge_timer: int = 0     # 失去充能后经过的分钟数

func add_accessory(accessory: Generator_accessories) -> void:
	for existing in accessories:
		if existing.acc_id == accessory.acc_id:
			return
	accessories.append(accessory)
	# 首次获得格挡饰品时，立即获得1次格挡充能
	if accessory.block_charges > 0:
		block_charges = max(block_charges, 1)   # 确保至少1次充能
	accessory_added.emit(accessory)

func has_accessory(acc_id: int) -> bool:
	for acc in accessories:
		if acc.acc_id == acc_id:
			return true
	return false

func get_accessory_by_id(acc_id: int) -> Generator_accessories:
	for acc in accessories:
		if acc.acc_id == acc_id:
			return acc
	return null

func remove_accessory(acc_id: int) -> void:
	for i in range(accessories.size()):
		if accessories[i].acc_id == acc_id:
			accessories.remove_at(i)
			accessory_removed.emit(acc_id)
			return

func reset() -> void:
	accessories.clear()
	accessory_added.emit(null)

# ==================== 效果汇总 ====================

## 获取魔女化上限提升
func get_witch_max_increase() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_max_increase
	return total

## 获取魔女化进度提升
func get_witch_progress_increase() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_progress_increase
	return total

## 获取魔女化惩罚降低
func get_witch_penalty_reduce() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_penalty_reduce
	return total

## 获取冲动赋予减少
func get_witch_impulse_reduce() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_impulse_reduce
	return total

## 获取书页冷却缩减
func get_bookpage_cd_reload() -> int:
	var total = 0
	for acc in accessories:
		total += acc.bookpage_cd_reload
	return total

##增加最大生命值
func get_max_health_bonus() -> int:
	var total = 0
	for acc in accessories:
		total += acc.max_health_bonus
	return total
## 每回合开始时调用，根据时间恢复充能
func update_block_charge():
	if block_charges <= 0:
		# 每回合5分钟，恢复需60分钟（12回合），可调整
		block_charge_timer += 5
		if block_charge_timer >= 60:
			block_charges = 1
			block_charge_timer = 0

## 获取格挡充能
func get_block_charge() -> int:
	return block_charges

##消耗格挡
func consume_block_charge() -> bool:
	if block_charges > 0:
		block_charges -= 1
		block_charge_timer = 0   # 开始计时
		return true
	return false
	
