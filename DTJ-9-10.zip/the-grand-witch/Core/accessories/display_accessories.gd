extends Control

@onready var scroll_container: ScrollContainer = $ScrollContainer
@onready var accessory_grid: HBoxContainer = $ScrollContainer/Hbox

const MAX_ITEMS_PER_ROW := 99

func _ready():
	_refresh_accessory_display()
	GlobalAccessories.accessory_added.connect(_on_accessory_added)

func _refresh_accessory_display():
	# 清空 GridContainer 中的所有行（HBoxContainer）
	for child in accessory_grid.get_children():
		child.queue_free()
	
	var current_row: HBoxContainer = null
	var count_in_row := 0
	
	for accessory in GlobalAccessories.accessories:
		# 每99个饰品创建一个新的 HBox 行
		if current_row == null or count_in_row >= MAX_ITEMS_PER_ROW:
			current_row = HBoxContainer.new()
			current_row.add_theme_constant_override("separation", 8)
			accessory_grid.add_child(current_row)
			count_in_row = 0
		
		var icon_rect = AccessoryIcon.new()
		icon_rect.texture = accessory.icon
		icon_rect.custom_minimum_size = Vector2(96, 96)
		icon_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon_rect.mouse_filter = Control.MOUSE_FILTER_STOP
		
		# 设置 Tooltip 文本
		if accessory.Tooltip != "":
			icon_rect.tooltip_text = accessory.Tooltip
		else:
			icon_rect.tooltip_text = accessory.name
		
		# 传递字体大小
		icon_rect.tooltip_font_size = accessory.tooltip_font_size
		
		current_row.add_child(icon_rect)
		count_in_row += 1

func _on_accessory_added(accessory: Generator_accessories):
	_refresh_accessory_display()
