这里是会随着版本更替而变化的readme备注

饰品，卡牌的加载都放进global中了，然后场景没放，但场景增加了last变量用来存储场景，负责返回

把所有的warninglabel取消了，统一交给globalplayer的hintlabel，方便以后统一更改提示

灵魂画手依然在更新，

