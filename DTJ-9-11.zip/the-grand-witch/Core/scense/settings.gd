extends Control
## 设置界面：音量、静音、放弃游戏、百科大全

@onready var volume_slider: HSlider = $TextureRect/voice/HSlider
@onready var mute_check: CheckButton = $TextureRect/voice/CheckButton
@onready var give_up_button: Button = $TextureRect/GiveUpButton
@onready var dict_button: Button = $TextureRect/DictButton
@onready var close_button: Button = $TextureRect/SureButton


func _ready():
	volume_slider.min_value = 0.0
	volume_slider.max_value = 1.0
	volume_slider.step = 0.01
	volume_slider.value = db_to_linear(AudioServer.get_bus_volume_db(0))
	mute_check.button_pressed = AudioServer.is_bus_mute(0)

	volume_slider.value_changed.connect(_on_volume_changed)
	mute_check.toggled.connect(_on_mute_toggled)
	give_up_button.pressed.connect(_on_give_up_pressed)
	dict_button.pressed.connect(_on_dict_pressed)
	close_button.pressed.connect(_on_close_pressed)

func _on_volume_changed(value: float):
	AudioServer.set_bus_volume_db(0, linear_to_db(value))

func _on_mute_toggled(pressed: bool):
	AudioServer.set_bus_mute(0, pressed)

func _on_give_up_pressed():
	GlobalScenes.check_game_over()

func _on_dict_pressed():
	GlobalScenes.open_dict()


func _on_close_pressed():
	queue_free()

func _input(event: InputEvent):
	if event.is_action_pressed("ui_cancel"):
		_on_close_pressed()
		get_viewport().set_input_as_handled()
