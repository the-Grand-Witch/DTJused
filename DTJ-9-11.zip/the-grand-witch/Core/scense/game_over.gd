extends Control
## 游戏结束场景：清空所有数据，按任意键返回开始界面

func _ready():
	# 清空玩家数据
	GlobalPlayer.reset()
	GlobalPlayer.current_character = null
	GlobalPlayer.harmony_stacks = 0
	GlobalPlayer.harmony_save = 0

	# 清空书签
	GlobalBookMark.reset()

	# 清空饰品
	GlobalAccessories.reset()
	GlobalAccessories.block_charges = 0

	# 清空卡牌库计数
	GlobalCardLibrary.reset()

	# 重置时间
	GlobalTime.total_minutes = 6 * 60
	GlobalTime.day = 1
	GlobalTime.time_changed.emit(GlobalTime.total_minutes)

	# 清空场景管理器记录
	GlobalScenes.last_scene_path = "res://scenes/main.tscn"


func _input(event: InputEvent):
	if event is InputEventKey and event.pressed:
		GlobalScenes.go_to_start()
	elif event is InputEventMouseButton and event.pressed:
		GlobalScenes.go_to_start()
