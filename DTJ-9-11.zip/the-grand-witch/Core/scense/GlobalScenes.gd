extends Node
## 全局场景管理：统一场景跳转，自动记录上一场景
signal reward_requested(gold: int, accessories: Array, cards: Array)
signal hint_requested(text: String)

var last_scene_path: String = "res://scenes/main.tscn"
var event_manager: Node = null
const BOOKMARK_CARD_SCENE := preload("res://scenes/bookmark.tscn")
const BOOK_SCENE := preload("res://scenes/book.tscn")
const REWARD_POPUP_SCENE := preload("res://scenes/RewardPopup.tscn")
var _is_changing: bool = false

func _ready():
	GlobalPlayer.health_changed.connect(_on_player_health_changed)
	reward_requested.connect(_on_reward_requested)
# ==================== 通用切换 ====================
## 切换场景并自动记录当前场景为上一场景
func change_scene(target_path: String, record: bool = true) -> void:
	if _is_changing:
		return
	_is_changing = true
	if record:
		var current = get_tree().current_scene
		if current:
			last_scene_path = current.scene_file_path
	get_tree().change_scene_to_file(target_path)
	await get_tree().process_frame
	_is_changing = false

## 返回上一场景
func return_to_previous() -> void:
	print("准备返回：", last_scene_path)
	get_tree().change_scene_to_file(last_scene_path)

# ==================== 具体场景 ====================
# 开始界面
func go_to_start() -> void:
	change_scene("res://scenes/start.tscn")
# 开始界面
func go_to_choose() -> void:
	change_scene("res://scenes/choose.tscn")
# 主场景
func go_to_main() -> void:
	change_scene("res://scenes/main.tscn")

# 普通战斗
func enter_battle() -> void:
	change_scene("res://scenes/battle.tscn")

# Boss战
func enter_boss_battle() -> void:
	change_scene("res://scenes/boss_battle.tscn")

# 胜利
func check_victory() -> void:
	change_scene("res://scenes/end.tscn",false)

# 游戏结束
func check_game_over() -> void:
	change_scene("res://scenes/game_over.tscn",false)

## 通用加载：将场景作为子节点加载到当前场景
func open_node(scene_path: String) -> Node:
	var scene = load(scene_path)
	if scene == null:
		push_error("场景加载失败：" + scene_path)
		return null
	var instance = scene.instantiate()
	get_tree().current_scene.add_child(instance)
	return instance

# ==================== 设置 Overlay ====================
## 打开设置
func open_settings() -> void:
	open_node("res://scenes/settings.tscn")

## 打开百科
func open_dict() -> void:
	open_node("res://scenes/dict.tscn")
# ==================== 事件刷新 ====================
func refresh_events() -> void:
	if event_manager:
		event_manager.refresh_all_cards()

# ==================== 玩家状态检测 ====================
func _on_player_health_changed(new_health: int) -> void:
	if new_health <= 0:
		check_game_over()
		return
# ==================== 掉落 ====================
func _on_reward_requested(gold: int, accessories: Array, cards: Array) -> void:
	var canvas_layer = CanvasLayer.new()
	canvas_layer.layer = 10
	get_tree().current_scene.add_child(canvas_layer)
	var popup = REWARD_POPUP_SCENE.instantiate()
	canvas_layer.add_child(popup)

	var accs: Array[Generator_accessories] = []
	accs.assign(accessories)
	var card_list: Array[Generator_bookpage] = []
	card_list.assign(cards)

	popup.setup_rewards(gold, accs, card_list)
	popup.closed.connect(func(): canvas_layer.queue_free())
