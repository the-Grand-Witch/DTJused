extends Node
## 魔法宝箱：50%掉落34-66（+17魔女化），50%掉落67-99（+24魔女化）

func trigger_effect(btn: Button) -> bool:
	var drop: Generator_accessories
	var witch_cost: int

	# 决定掉落池与魔女化代价
	if randf() < 0.5:
		drop = GlobalAccessories.get_random_accessory_in_range(34, 66)
		witch_cost = 17
	else:
		drop = GlobalAccessories.get_random_accessory_in_range(67, 99)
		witch_cost = 24

	if drop == null:
		return true

	GlobalPlayer.possessed(witch_cost)

	var drops: Array[Generator_accessories] = [drop]
	GlobalScenes.reward_requested.emit(0, drops, [])
	return true
