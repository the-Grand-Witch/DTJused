extends Node
## 挖掘事件：多次点击累计进度，完成后发出掉落信号

var btn: Button
var remaining_digs: int = 0
var target_digs: int = 0
var reward_type: String = ""
var accessory_range: Vector2i = Vector2i(1, 33)

func trigger_effect(button: Button) -> bool:
	btn = button
	_roll_reward()
	remaining_digs = target_digs

	if btn.pressed.is_connected(_on_button_pressed):
		btn.pressed.disconnect(_on_button_pressed)
	for connection in btn.pressed.get_connections():
		btn.pressed.disconnect(connection["callable"])
	btn.pressed.connect(_on_button_pressed)

	return false

func _on_button_pressed():
	remaining_digs -= 1
	GlobalTime.add_time_units(1)

	if remaining_digs <= 0:
		_give_reward()
		btn.pressed.disconnect(_on_button_pressed)
		btn.pressed.connect(GlobalScenes.event_manager._on_option_pressed.bind(btn))
		GlobalScenes.event_manager._create_card(btn)
		queue_free()

func _roll_reward():
	var roll = randf() * 100.0
	if roll < 5.0:
		reward_type = "accessory"
		accessory_range = Vector2i(67, 99)
		target_digs = 8
	elif roll < 22.0:
		reward_type = "accessory"
		accessory_range = Vector2i(34, 66)
		target_digs = randi_range(5, 7)
	elif roll < 55.0:
		reward_type = "accessory"
		accessory_range = Vector2i(1, 33)
		target_digs = randi_range(3, 5)
	else:
		reward_type = "gold"
		target_digs = randi_range(1, 3)

func _give_reward():
	if reward_type == "gold":
		var gold = randi_range(20, 40)
		GlobalScenes.reward_requested.emit(gold, [], [])
	else:
		var chosen = GlobalAccessories.get_random_accessory_in_range(accessory_range.x, accessory_range.y)
		if chosen:
			GlobalScenes.reward_requested.emit(0, [chosen])
		else:
			var gold = randi_range(20, 40)
			GlobalScenes.reward_requested.emit(gold, [], [])
