extends Node
## 宝藏事件：从 1-33 范围内随机掉落一个饰品，由 GlobalScenes 处理奖励弹窗

const DROP_COUNT := 1

func trigger_effect(btn: Button) -> bool:
	var drops = _generate_drops()          # 生成饰品数组
	GlobalScenes.reward_requested.emit(0, drops, [])   # 发出信号，传递饰品
	return true

func _generate_drops(count: int = DROP_COUNT) -> Array[Generator_accessories]:
	var result: Array[Generator_accessories] = []
	for i in range(count):
		var acc = GlobalAccessories.get_random_accessory_in_range(1, 33)
		if acc:
			result.append(acc)   # 只加入结果，不调用 add_accessory
	return result
