extends Node

# ==================== 信号 ====================
signal health_changed(new_health: int)
signal witch_power_changed(new_power: int)
signal gold_changed(new_gold: int)
signal max_health_changed(new_max_health: int)

# ==================== 基础属性 ====================
var player_id: String = "player_" + str(randi())
var base_max_health: int = 200
var max_health: int = 200
var health: int = 200
var witch_power: int = 0
var gold: int = 0
const max_witch_power: int = 100
var harmony_stacks: int = 0
var harmony_save: int = 0
# ==================== 角色与被动 ====================
var current_character: Generator_girl = null
var _default_passive: Generator_PassiveEffect   # 默认空被动实例，用于安全调用

func _ready():
	GlobalAccessories.accessory_added.connect(_on_accessory_changed)
	GlobalAccessories.accessory_removed.connect(_on_accessory_changed)
	# 创建默认被动（无效果）
	_default_passive = Generator_PassiveEffect.new()
	# 临时调试：自动加载默认角色
	var default_character = load("res://Data/WitchGirl/aima.tres") as Generator_girl
	if default_character:
		set_character(default_character)
		print("已加载默认角色：", default_character.character_name)
	recalculate_max_health()

# ==================== 角色设置 ====================
## 设置当前角色（通常在开始新游戏时调用）
func set_character(character: Generator_girl) -> void:
	current_character = character
	recalculate_max_health()
	health_changed.emit(health)
	max_health_changed.emit(max_health)
	GlobalBookMark.set_custom_default_bookmarks(character.starting_bookmarks)

## 获取当前角色被动对象，如果无角色或无被动，返回默认空被动
func get_passive() -> Generator_PassiveEffect:
	if current_character and current_character.passive:
		return current_character.passive
	return _default_passive

# ==================== 属性修改 ====================
func _on_accessory_changed(_accessory = null):
	recalculate_max_health()

func recalculate_max_health():
	# 基础生命 + 饰品生命加成（调用 GlobalAccessories 汇总接口）
	var bonus = GlobalAccessories.get_max_health_bonus()
	# 应用被动修改
	var modified_base = get_passive().modify_max_health(base_max_health + bonus)
	var new_max = modified_base
	var diff = new_max - max_health
	max_health = new_max
	if diff > 0:
		health = min(health + diff, max_health)
	elif diff < 0:
		health = max(health, 0)
	max_health_changed.emit(max_health)
	health_changed.emit(health)

func take_damage(amount: int) -> void:
	health = max(health - amount, 0)
	health_changed.emit(health)

func heal(amount: int = 10) -> void:
	health = min(health + amount, max_health)
	health_changed.emit(health)

func possessed(amount: int = 1) -> void:
	# 应用被动修改
	var final_amount = get_passive().modify_witch_power_gain(amount)
	# 魔女化上限提升
	var current_max = max_witch_power + GlobalAccessories.get_witch_max_increase()
	witch_power = min(witch_power + final_amount, current_max)
	witch_power_changed.emit(witch_power)
	if witch_power >= current_max:
		GlobalScenes.check_game_over()

func add_gold(amount: int) -> void:
	# 应用被动修改
	var final_amount = get_passive().modify_gold_gain(amount)
	gold += final_amount
	gold_changed.emit(gold)

# ==================== 战斗相关接口 ====================
## 获取角色被动提供的伤害倍率（由战斗计算模块调用）
func get_damage_multiplier(enemy_witch_power: int) -> float:
	return get_passive().modify_damage_multiplier(enemy_witch_power)

## 获取角色被动提供的每回合护甲
func get_armor_per_turn(base: int) -> int:
	return get_passive().modify_armor_per_turn(base)

## 获取角色被动提供的每回合回复
func get_heal_per_turn(base: int) -> int:
	return get_passive().modify_heal_per_turn(base)

##格挡次数获取
func get_block_charge() -> int:
	return GlobalAccessories.get_block_charge()
# ==================== 重置 ====================
func reset() -> void:
	health = max_health
	witch_power = 0
	gold = 0
	recalculate_max_health()
	health_changed.emit(health)
	witch_power_changed.emit(witch_power)
	gold_changed.emit(gold)
	max_health_changed.emit(max_health)

# ==================== 冲动相关（保持原有） ====================
func get_impulse_count() -> int:
	# 应用饰品效果：减少冲动赋予数量
	var base_count = witch_power / 10 - GlobalAccessories.get_witch_impulse_reduce()
	return max(0, base_count)

func get_impulse_punishment() -> int:
	return 2

func get_impulse_damage_multiplier() -> float:
	return 1.0 + float(witch_power) / 100.0
	
#====================  可选：保留测试按键，但正式版删除====================
func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_Q:
			heal(-50)
		elif event.keycode == KEY_W:
			GlobalPlayer.possessed(20)
		elif event.keycode == KEY_E:
			GlobalTime.add_time_units(24)
		elif event.keycode == KEY_R:
			GlobalPlayer.add_gold(200)
		elif event.keycode == KEY_T:
			for card in GlobalCardLibrary.get_all_cards():
				GlobalCardLibrary.add_acquired_count(card.book_id, 99)
		elif event.keycode == KEY_A:
			GlobalScenes.refresh_events()
