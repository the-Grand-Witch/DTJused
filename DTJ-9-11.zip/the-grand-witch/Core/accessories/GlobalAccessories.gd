extends Node

signal accessory_added(accessory: Generator_accessories)
signal accessory_removed(acc_id: int)

var accessories: Array[Generator_accessories] = []
var block_charges: int = 0         # 当前充能
var block_charge_timer: int = 0     # 失去充能后经过的分钟数

# ==================== 全部饰品加载与分类 ====================
var all_accessories: Array[Generator_accessories] = []
var low_tier: Array[Generator_accessories] = []      # 1-33
var mid_tier: Array[Generator_accessories] = []      # 34-66
var high_tier: Array[Generator_accessories] = []     # 67-99
var shop_tier: Array[Generator_accessories] = []     # 777-800

func _ready():
	_load_all_accessories()

func _load_all_accessories():
	all_accessories.clear()
	low_tier.clear()
	mid_tier.clear()
	high_tier.clear()
	shop_tier.clear()

	var files = ResourceLoader.list_directory("res://Data/accessories/")
	for file_name in files:
		if file_name.ends_with(".tres"):
			var res = load("res://Data/accessories/" + file_name)
			if res is Generator_accessories:
				all_accessories.append(res)
				if res.acc_id >= 1 and res.acc_id <= 33:
					low_tier.append(res)
				elif res.acc_id >= 34 and res.acc_id <= 66:
					mid_tier.append(res)
				elif res.acc_id >= 67 and res.acc_id <= 99:
					high_tier.append(res)
				elif res.acc_id >= 777 and res.acc_id <= 800:
					shop_tier.append(res)

## 根据等级获取候选饰品池（"low" / "mid" / "high" / "shop"）
func get_tier(tier: String) -> Array[Generator_accessories]:
	match tier:
		"low": return low_tier
		"mid": return mid_tier
		"high": return high_tier
		"shop": return shop_tier
		_: return []

## 根据 ID 范围获取未拥有的随机饰品
func get_random_accessory_in_range(id_min: int, id_max: int) -> Generator_accessories:
	var candidates: Array[Generator_accessories] = []
	for acc in all_accessories:
		if acc.acc_id >= id_min and acc.acc_id <= id_max:
			if not has_accessory(acc.acc_id):
				candidates.append(acc)
	if candidates.is_empty():
		return null
	return candidates[randi() % candidates.size()]

# ==================== 玩家已拥有 ====================
func add_accessory(accessory: Generator_accessories) -> void:
	for existing in accessories:
		if existing.acc_id == accessory.acc_id:
			return
	accessories.append(accessory)
	if accessory.block_charges > 0:
		block_charges = max(block_charges, 1)
	accessory_added.emit(accessory)

func has_accessory(acc_id: int) -> bool:
	for acc in accessories:
		if acc.acc_id == acc_id:
			return true
	return false

func get_accessory_by_id(acc_id: int) -> Generator_accessories:
	for acc in accessories:
		if acc.acc_id == acc_id:
			return acc
	return null

func remove_accessory(acc_id: int) -> void:
	for i in range(accessories.size()):
		if accessories[i].acc_id == acc_id:
			accessories.remove_at(i)
			accessory_removed.emit(acc_id)
			return

func reset() -> void:
	accessories.clear()
	block_charges = 0
	block_charge_timer = 0
	accessory_added.emit(null)

# ==================== 效果汇总 ====================
func get_witch_max_increase() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_max_increase
	return total

func get_witch_progress_increase() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_progress_increase
	return total

func get_witch_penalty_reduce() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_penalty_reduce
	return total

func get_witch_impulse_reduce() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_impulse_reduce
	return total

func get_bookpage_cd_reload() -> int:
	var total = 0
	for acc in accessories:
		total += acc.bookpage_cd_reload
	return total

func get_max_health_bonus() -> int:
	var total = 0
	for acc in accessories:
		total += acc.max_health_bonus
	return total

# ==================== 格挡充能 ====================
func update_block_charge():
	if block_charges <= 0:
		block_charge_timer += 5
		if block_charge_timer >= 60:
			block_charges = 1
			block_charge_timer = 0

func get_block_charge() -> int:
	return block_charges

func consume_block_charge() -> bool:
	if block_charges > 0:
		block_charges -= 1
		block_charge_timer = 0
		return true
	return false
