extends Node
## 玩家 UI 模块：手牌显示、冲动标记、状态图标

@onready var hand_container = $player_hand_container
@onready var buff_display = $buff/Buffscenses
@onready var hint_label: Label = $HintLabel

signal cancel_requested

var player_impulse_pages: Array[Dictionary] = []

func _ready():
	GlobalScenes.hint_requested.connect(_on_hint_requested)
	hint_label.visible = false

func clear_hand():
	for child in hand_container.get_children():
		child.queue_free()
	player_impulse_pages.clear()

func add_card(card: BookmarkCard):
	hand_container.add_child(card)
##说的话
func _on_hint_requested(text: String):
	hint_label.text = text
	hint_label.visible = true
	await get_tree().create_timer(3.0).timeout
	hint_label.visible = false

# ==================== 冲动 ====================
func clear_impulses():
	for entry in player_impulse_pages:
		var card: BookmarkCard = entry["card"]
		var page_index: int = entry["page_index"]
		var label = card.get_page_label_by_index(page_index)
		if label:
			label.modulate = Color(1, 1, 1)
	player_impulse_pages.clear()

func apply_impulses(cards: Array[BookmarkCard], count: int):
	clear_impulses()
	if count <= 0:
		return

	# 收集所有可被赋予冲动的页面：优先疯狂卡
	var priority_pages: Array[Dictionary] = []
	var normal_pages: Array[Dictionary] = []
	for card in cards:
		for idx in range(card.bookmark_data.pages.size()):
			var page = card.bookmark_data.pages[idx]
			if "疯狂" in page.keywords:
				priority_pages.append({"card": card, "page_index": idx})
			elif page.pickup_type == Generator_bookpage.PickupType.Attack:
				normal_pages.append({"card": card, "page_index": idx})

	# 先选疯狂页，不足再选普通攻击页
	var selected_pages: Array[Dictionary] = priority_pages.duplicate()
	while selected_pages.size() < count and not normal_pages.is_empty():
		selected_pages.append(normal_pages.pop_front())

	# 随机打乱后取前count个
	selected_pages.shuffle()
	for i in range(min(count, selected_pages.size())):
		var entry = selected_pages[i]
		player_impulse_pages.append(entry)
		var card: BookmarkCard = entry["card"]
		var page_index: int = entry["page_index"]
		var label = card.get_page_label_by_index(page_index)
		if label:
			label.modulate = Color(0.6, 0.2, 1)

func has_impulse(card: BookmarkCard, page_index: int) -> bool:
	for entry in player_impulse_pages:
		if entry["card"] == card and entry["page_index"] == page_index:
			return true
	return false

func consume_impulse(card: BookmarkCard, page_index: int) -> bool:
	for i in range(player_impulse_pages.size()):
		var entry = player_impulse_pages[i]
		if entry["card"] == card and entry["page_index"] == page_index:
			player_impulse_pages.remove_at(i)
			var label = card.get_page_label_by_index(page_index)
			if label:
				label.modulate = Color(1, 1, 1)
			return true
	return false

func punish_unused_impulses():
	if player_impulse_pages.is_empty():
		return
	for entry in player_impulse_pages:
		var card: BookmarkCard = entry["card"]
		GlobalPlayer.possessed(GlobalPlayer.get_impulse_punishment())
		var label = card.get_page_label_by_index(entry["page_index"])
		if label:
			label.modulate = Color(1, 1, 1)
	player_impulse_pages.clear()

# ==================== 状态图标 ====================
func update_buffs(statuses: Dictionary):
	buff_display.update_display(statuses)

# ==================== 右键取消 ====================
func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		cancel_requested.emit()
		get_viewport().set_input_as_handled()
