extends Node

# 事件资源目录
const EVENT_DIR : = "res://Data/event/"
@onready var option_nodes = [$OptionA, $OptionB, $OptionC]

var cards := {}
var last_event_ids := {}

const ROAD_EVENT_TYPES = [Generator_event.EventType.WALK, Generator_event.EventType.DIG]

var event_pool: Array[Generator_event] = []

func _ready():
	GlobalScenes.event_manager = self
	randomize()
	_load_event_pool()
	for btn in option_nodes:
		btn.pressed.connect(_on_option_pressed.bind(btn))
		_create_card(btn)

func _load_event_pool():
	event_pool.clear()
	var dir = DirAccess.open(EVENT_DIR)
	dir.list_dir_begin()
	var file_name = dir.get_next()
	while file_name != "":
		if not dir.current_is_dir() and file_name.ends_with(".tres"):
			event_pool.append(load(EVENT_DIR + file_name))
		file_name = dir.get_next()
	dir.list_dir_end()

func _create_card(btn):
	for child in btn.get_children():
		child.queue_free()
	btn.icon = null
	btn.text = ""
	btn.tooltip_text = ""
	btn.flat = true
	btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND

	var chosen = _choose_valid_event(btn)
	btn.icon = chosen.icon
	btn.text = chosen.event_name
	btn.tooltip_text = chosen.event_name + "\n" + chosen.description
	btn.set_meta("event_data", chosen)
	cards[btn] = chosen
	last_event_ids[btn] = chosen.event_id

func _choose_valid_event(btn):
	var candidates = event_pool.duplicate()

	if last_event_ids.has(btn):
		var last_id = last_event_ids[btn]
		candidates = candidates.filter(func(e): return e.event_id != last_id)

	if _has_road_event(btn):
		candidates = candidates.filter(func(e): return not (e.event_type in ROAD_EVENT_TYPES))

	if candidates.is_empty():
		candidates = event_pool.duplicate()
		if last_event_ids.has(btn):
			candidates = candidates.filter(func(e): return e.event_id != last_event_ids[btn])
		if candidates.is_empty():
			candidates = event_pool.duplicate()

	return candidates[randi() % candidates.size()]

func _has_road_event(exclude_btn):
	for btn in option_nodes:
		if btn == exclude_btn:
			continue
		if cards.has(btn):
			if cards[btn].event_type in ROAD_EVENT_TYPES:
				return true
	return false

func _on_option_pressed(btn):
	if not cards.has(btn):
		return
	var event_data: Generator_event = cards[btn]
	var completed = _trigger_event(event_data, btn)
	if event_data.unique and completed:
		event_pool.erase(event_data)
	if completed:
		_create_card(btn)

func _trigger_event(event_data: Generator_event, btn: Button) -> bool:
	# 统一时间消耗
	if event_data.time_units > 0:
		GlobalTime.add_time_units(event_data.time_units)

	if event_data.is_special:
		if event_data.effect_script:
			var obj = event_data.effect_script.new()
			add_child(obj)
			if obj.has_method("trigger_effect"):
				return obj.trigger_effect(btn)
			else:
				push_error("特殊事件脚本缺少 trigger_effect 方法：" + event_data.event_name)
				return true
		elif event_data.effect_scene:
			var instance = event_data.effect_scene.instantiate()
			add_child(instance)
			if instance.has_method("trigger_effect"):
				return instance.trigger_effect(btn)
			else:
				push_error("特殊事件场景根节点缺少 trigger_effect 方法：" + event_data.event_name)
				return true
		else:
			push_error("特殊事件未设置效果脚本或场景：" + event_data.event_name)
			return true
	else:
		# 普通事件：应用数值字段
		if event_data.health_change != 0:
			if event_data.health_change > 0:
				GlobalPlayer.heal(event_data.health_change)
			else:
				GlobalPlayer.take_damage(-event_data.health_change)
		if event_data.witch_power_change != 0:
			GlobalPlayer.possessed(event_data.witch_power_change)
		if event_data.gold_change != 0:
			GlobalPlayer.add_gold(event_data.gold_change)
		return true

func refresh_all_cards() -> void:
	for btn in option_nodes:
		_create_card(btn)
