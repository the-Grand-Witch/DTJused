extends Node
# 时间变化信号（供 UI 监听）
signal time_changed(total_minutes: int)
const TIME_UNIT: int = 5
var total_minutes: int = 6 * 60   # 起始 6:00
func _ready():
	time_changed.emit(total_minutes)
# 增加时间单位
func add_time_units(units: int) -> void:
	total_minutes += units * TIME_UNIT
	time_changed.emit(total_minutes)
# 获取当前总分钟数
func get_time() -> int:
	return total_minutes
# 获取格式化的时间字符串
func get_formatted_time() -> String:
	var hours = total_minutes / 60
	var mins = total_minutes % 60
	return "%02d:%02d" % [hours, mins]
