extends TextureProgressBar

func _ready():
	max_value = GlobalPlayer.max_health / 2.0
	value = GlobalPlayer.health / 2.0

	GlobalPlayer.health_changed.connect(_on_health_changed)
	GlobalPlayer.max_health_changed.connect(_on_max_health_changed)
	GlobalPlayer.witch_power_changed.connect(_on_witch_power_changed)

	_update_witch_color(GlobalPlayer.witch_power)

func _on_health_changed(new_health: int) -> void:
	value = new_health / 2.0

func _on_max_health_changed(new_max_health: int) -> void:
	max_value = new_max_health / 2.0

func _on_witch_power_changed(new_witch_power: int) -> void:
	_update_witch_color(new_witch_power)

func _update_witch_color(witch_power: int) -> void:
	var t = clamp(float(witch_power) / 100.0, 0.0, 1.0)
	var green = Color(0, 1, 0)
	var purple = Color(0.5, 0, 1)
	# 只改变前景颜色
	modulate = green.lerp(purple, t)

# 可选：保留测试按键，但正式版删除
func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_Q:
			GlobalPlayer.take_damage(50)
		elif event.keycode == KEY_W:
			GlobalPlayer.possessed(20)
