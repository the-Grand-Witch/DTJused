extends Node

signal health_changed(new_health: int)
signal witch_power_changed(new_power: int)
signal gold_changed(new_gold: int)
signal max_health_changed(new_max_health: int)

var base_max_health: int = 200
var max_health: int = 200
var health: int = 200
var witch_power: int = 0
var gold: int = 0

const max_witch_power: int = 100

func _ready():
	GlobalAccessories.accessory_added.connect(_on_accessory_changed)
	GlobalAccessories.accessory_removed.connect(_on_accessory_changed)
	recalculate_max_health()

func _on_accessory_changed(_accessory = null):
	recalculate_max_health()

func recalculate_max_health():
	var bonus = 0
	for acc in GlobalAccessories.accessories:
		bonus += acc.max_health_bonus
	var new_max = base_max_health + bonus
	var diff = new_max - max_health
	max_health = new_max
	if diff > 0:
		health = min(health + diff, max_health)
	elif diff < 0:
		health = max(health, 0)
	max_health_changed.emit(max_health)
	health_changed.emit(health)

func take_damage(amount: int) -> void:
	health = max(health - amount, 0)
	health_changed.emit(health)

func heal(amount: int = 10) -> void:
	health = min(health + amount, max_health)
	health_changed.emit(health)

func possessed(amount: int = 1) -> void:
	witch_power = min(witch_power + amount, max_witch_power)
	witch_power_changed.emit(witch_power)
	if witch_power >= max_witch_power:
		GlobalScenes.check_game_over()

func add_gold(amount: int) -> void:
	gold += amount
	gold_changed.emit(gold)

func reset() -> void:
	# 重置生命和魔女化
	health = max_health          # 使用当前最大生命值（包含饰品加成）
	witch_power = 0
	gold = 0
	# 重新计算最大生命值（饰品已清空，所以会回到基础值）
	recalculate_max_health()
	# 发射信号让 UI 立即更新
	health_changed.emit(health)
	witch_power_changed.emit(witch_power)
	gold_changed.emit(gold)
	max_health_changed.emit(max_health)
