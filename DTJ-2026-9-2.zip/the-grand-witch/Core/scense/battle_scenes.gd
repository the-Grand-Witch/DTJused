extends Node

@onready var monster_texture: TextureRect = $MonsterTexture
@onready var end_turn_button: Button = $EndTurnButton
@onready var monster_damage_label: Label = $MonsterDamageLabel
@onready var monster_health_bar: TextureProgressBar = $MonsterHealthBar
@onready var bookmark_container: HBoxContainer = $BookmarkContainer
@onready var ability_scroll: ScrollContainer = $AbilityScroll
@onready var ability_list: HBoxContainer = $AbilityScroll/AbilityList

const REWARD_POPUP_SCENE = preload("res://scenes/RewardPopup.tscn")
const BOOKMARK_CARD_SCENE := preload("res://scenes/bookmark.tscn")

var current_monster: Generator_monster
var all_cards: Array[BookmarkCard] = []
var selected_cards: Array[BookmarkCard] = []
var max_selected: int = 1

var turn_count: int = 0
@onready var turn_label: Label = $TurnLabel

var player_attack_bonus: int = 0
var used_ability_cards: Array[Generator_bookpage] = []

var accessory_library: Array[Generator_accessories] = []
var available_accessories: Array[Generator_accessories] = []
var loot_bonus: int = 0

var previous_scene_path: String = "res://scenes/main.tscn"

# 当前回合具有杀人冲动的页面列表，元素格式: {"card": BookmarkCard, "page": Generator_bookpage}
var impulsed_pages: Array[Dictionary] = []

func _ready():
	previous_scene_path = GlobalScenes.last_scene_path
	_load_accessory_library()
	_init_available_accessories()
	load_random_monster()
	setup_monster_ui()
	create_bookmarks()
	end_turn_button.pressed.connect(_on_end_turn_pressed)
	update_ability_list()
	
	_battle_start()
	_round_start()

func _load_accessory_library():
	var dir = DirAccess.open("res://Data/accessories/")
	if dir == null:
		push_error("道具目录不存在：res://Data/accessories/")
		return
	dir.list_dir_begin()
	var file_name = dir.get_next()
	while file_name != "":
		if not dir.current_is_dir() and file_name.ends_with(".tres"):
			var res = load("res://Data/accessories/" + file_name)
			if res is Generator_accessories:
				accessory_library.append(res)
		file_name = dir.get_next()
	dir.list_dir_end()

func _init_available_accessories():
	available_accessories.clear()
	for acc in accessory_library:
		if not _is_accessory_owned(acc):
			available_accessories.append(acc)

func load_random_monster():
	var files = []
	var dir = DirAccess.open("res://Data/monster/")
	dir.list_dir_begin()
	var f = dir.get_next()
	while f != "":
		if f.ends_with(".tres"):
			files.append("res://Data/monster/" + f)
		f = dir.get_next()
	dir.list_dir_end()
	current_monster = load(files[randi() % files.size()])

func setup_monster_ui():
	monster_texture.texture = current_monster.icon_textrue
	monster_health_bar.max_value = current_monster.health
	monster_health_bar.value = current_monster.health
	monster_damage_label.text = "伤害: %d" % current_monster.attack

func create_bookmarks():
	for child in bookmark_container.get_children():
		child.queue_free()
	all_cards.clear()
	selected_cards.clear()
	bookmark_container.add_theme_constant_override("separation", 0)
	for data in GlobalBookMark.bookmarks:
		var card = BOOKMARK_CARD_SCENE.instantiate()
		bookmark_container.add_child(card)
		card.setup(data)
		card.scale = Vector2(1.4, 1.4)
		card.selection_changed.connect(_on_card_selection_changed.bind(card))
		all_cards.append(card)

func _on_card_selection_changed(selected: bool, card: BookmarkCard) -> void:
	if selected:
		if selected_cards.size() >= max_selected:
			var oldest = selected_cards[0]
			selected_cards.erase(oldest)
			oldest.set_selected(false)
		selected_cards.append(card)
	else:
		selected_cards.erase(card)

func _battle_start():
	print("战斗开始阶段")

func _round_start():
	# 回合数增加
	turn_count += 1
	turn_label.text = "回合 %d" % turn_count
	
	_clear_all_kill_impulses()
	for card in all_cards:
		card.decrease_cooldown()
	_apply_kill_impulses_by_witch_count()
	for card in all_cards:
		card.refresh_visual()
	print("回合开始阶段")

func _apply_kill_impulses_by_witch_count():
	var count = GlobalPlayer.witch_power / 10
	if count <= 0:
		return

	# 收集所有攻击页（卡, 索引）
	var all_attack_pages: Array[Dictionary] = []
	for card in all_cards:
		for idx in range(card.bookmark_data.pages.size()):
			var page = card.bookmark_data.pages[idx]
			if page.pickup_type == Generator_bookpage.PickupType.Attack:
				all_attack_pages.append({"card": card, "page_index": idx})

	for i in range(count):
		if all_attack_pages.is_empty():
			break
		var idx = randi() % all_attack_pages.size()
		var entry = all_attack_pages[idx]
		all_attack_pages.remove_at(idx)
		
		var card: BookmarkCard = entry["card"]
		var page_index: int = entry["page_index"]
		var label = card.get_page_label_by_index(page_index)
		if label:
			label.modulate = Color(0.6, 0.2, 1)
		impulsed_pages.append({"card": card, "page_index": page_index})

func _clear_all_kill_impulses():
	for entry in impulsed_pages:
		var card: BookmarkCard = entry["card"]
		var page_index: int = entry["page_index"]
		var label = card.get_page_label_by_index(page_index)
		if label:
			label.modulate = Color(1, 1, 1)
	impulsed_pages.clear()

func _on_end_turn_pressed():
	_punish_unused_kill_impulses()
	GlobalTime.add_time_units(1)
	if selected_cards.is_empty():
		_round_start()
		return

	var result = _calculate_card_effects(selected_cards)

	for card in selected_cards:
		card.set_selected(false)
		card.start_cooldown()
	selected_cards.clear()

	if result.damage > 0:
		current_monster.health -= result.damage
		monster_health_bar.value = current_monster.health
		if current_monster.health <= 0:
			_on_monster_defeated()
			return

	if result.healing > 0:
		GlobalPlayer.heal(result.healing)

	var actual_damage = max(current_monster.attack - result.armor, 0)
	GlobalPlayer.take_damage(actual_damage)

	update_ability_list()
	_round_start()

class CardEffectResult:
	var damage: int = 0
	var healing: int = 0
	var armor: int = 0

func _calculate_card_effects(cards: Array[BookmarkCard]) -> CardEffectResult:
	var result = CardEffectResult.new()
	var accessory_bonus = _get_accessory_attack_bonus()
	var total_attack_bonus = player_attack_bonus + accessory_bonus

	for card in cards:
		for idx in range(card.bookmark_data.pages.size()):
			var page = card.bookmark_data.pages[idx]
			match page.pickup_type:
				Generator_bookpage.PickupType.Attack:
					var damage = page.damage + total_attack_bonus
					if _has_impulse(card, idx):
						var multiplier = 1.0 + float(GlobalPlayer.witch_power) / 100.0
						damage = int(ceil(damage * multiplier))
						print("杀人冲动触发！伤害提升至: ", damage)
					result.damage += damage
				Generator_bookpage.PickupType.Heal:
					result.healing += page.healing
				Generator_bookpage.PickupType.Defense:
					result.armor += page.Armor
				Generator_bookpage.PickupType.Ability:
					player_attack_bonus += page.attack_bonus
					used_ability_cards.append(page)
	return result

func _has_impulse(card: BookmarkCard, page_index: int) -> bool:
	for entry in impulsed_pages:
		if entry["card"] == card and entry["page_index"] == page_index:
			return true
	return false

func _punish_unused_kill_impulses():
	var to_remove = []
	for entry in impulsed_pages:
		var card: BookmarkCard = entry["card"]
		if card not in selected_cards:
			to_remove.append(entry)
			GlobalPlayer.possessed(2)   # 修改为 +2
			print("未打出的杀人冲动，魔女化+2，当前魔女化: ", GlobalPlayer.witch_power)
			var page_index: int = entry["page_index"]
			var label = card.get_page_label_by_index(page_index)
			if label:
				label.modulate = Color(1, 1, 1)
	for entry in to_remove:
		impulsed_pages.erase(entry)

func _get_accessory_attack_bonus() -> int:
	var bonus = 0
	for acc in GlobalAccessories.accessories:
		bonus += acc.attack_bonus
	return bonus

func _is_accessory_owned(accessory: Generator_accessories) -> bool:
	for owned in GlobalAccessories.accessories:
		if owned.acc_id == accessory.acc_id:
			return true
	return false

func _get_accessory_by_id(acc_id: int) -> Generator_accessories:
	for acc in accessory_library:
		if acc.acc_id == acc_id:
			return acc
	return null

func _on_monster_defeated():
	end_turn_button.disabled = true

	var gold = randi_range(current_monster.min_gold, current_monster.max_gold)
	var dropped_accessories: Array[Generator_accessories] = []
	if current_monster.fixed_drop_id != -1:
		var fixed_acc = _get_accessory_by_id(current_monster.fixed_drop_id)
		if fixed_acc and not _is_accessory_owned(fixed_acc):
			dropped_accessories.append(fixed_acc)
	var candidates: Array[Generator_accessories] = []
	for acc in available_accessories:
		if acc.acc_id >= current_monster.accessory_id_min and acc.acc_id <= current_monster.accessory_id_max:
			candidates.append(acc)
	var count = current_monster.random_drop_count + loot_bonus
	count = min(count, candidates.size())
	for i in range(count):
		var idx = randi() % candidates.size()
		var acc = candidates[idx]
		candidates.remove_at(idx)
		available_accessories.erase(acc)
		dropped_accessories.append(acc)

	var popup = REWARD_POPUP_SCENE.instantiate()
	add_child(popup)
	popup.setup_rewards(gold, dropped_accessories)
	popup.closed.connect(func(): get_tree().change_scene_to_file(previous_scene_path))

func increase_loot_bonus(amount: int) -> void:
	loot_bonus += amount

func update_ability_list():
	for child in ability_list.get_children():
		child.queue_free()
	for page in used_ability_cards:
		var texture_rect = TextureRect.new()
		texture_rect.texture = page.icon
		texture_rect.custom_minimum_size = Vector2(64, 64)
		texture_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		texture_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
