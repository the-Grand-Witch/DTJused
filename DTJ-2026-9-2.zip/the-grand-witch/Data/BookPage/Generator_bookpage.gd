extends Resource
class_name Generator_bookpage
#声明
enum PickupType {
	Reply,
	Attack,
	Defense,
	Ability,
	Heal
}

@export_group("书页配置")
@export var book_id : int
@export var pickup_type : PickupType = PickupType.Attack
@export var page_name : String = "未命名卡牌"
@export var icon : Texture2D   
@export var description : String = ""
@export var cd : int
@export_group("书页效果")     
@export var damage : int = 0
@export var healing : int = 0
@export var Armor : int = 0
@export var attack_bonus : int = 0
