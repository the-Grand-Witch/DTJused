extends Resource
class_name Generator_accessories
#声明
enum PickupType {
	Health,
	AttackPower,
	WitchPower,
	TakeDamage,
	SkillReload,
	BlockCharges,
}
#分组
@export_group("道具配置")
@export var acc_id : int
@export var pickup_type : PickupType = PickupType.AttackPower
@export var name : String   
@export var icon : Texture2D   
@export var Tooltip : String = ""
@export var tooltip_font_size : int = 40
@export_group("道具效果")     
@export var attack_bonus : int = 0
@export var heal_amount : int = 0
@export var damage_amount : int = 0        
@export var witch_amount : int = 0
@export var skillreload_amount : int = 0
@export var block_charges : int = 0
@export var max_health_bonus : int = 0
