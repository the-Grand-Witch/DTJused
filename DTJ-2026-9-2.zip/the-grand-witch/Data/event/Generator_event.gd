extends Resource
class_name Generator_event
# 事件类型枚举
enum EventType {
	BATTLE,    # 战斗事件
	SHOP,      # 商店事件
	REST,      # 休息事件
	WALK,      # 道路事件
	DIG,       # 挖掘事件
	SPECIAL,   # 特殊事件（功能复杂、不统一）
}
# === 基础信息 ===
@export_group("基础信息")
@export var event_id: int
@export var event_type: EventType = EventType.WALK
@export var weight: int = 1                # 随机权重，越高越容易抽到
@export var is_special: bool = false       # 是否为特殊事件（决定使用通用处理还是自定义脚本/场景）
@export var unique: bool = false           # 是否一次性事件（触发后移出随机池）
@export_group("显示信息")
@export var event_name: String = "未命名事件"
@export_multiline var description: String = ""
@export var icon: Texture2D
# === 效果调用 ===
@export_group("效果调用")
@export var effect_script: Script          # 效果脚本（可选，所有事件均可使用）
@export var effect_scene: PackedScene      # 效果场景（可选，所有事件均可使用）
@export var health_change: int = 0         # 生命变化（负数为伤害）
@export var witch_power_change: int = 0    # 魔女化变化
@export var gold_change: int = 0           # 金币变化
@export var time_units: int = 1            # 时间流逝单位数
