extends Resource
class_name Generator_bookpage
#声明
enum PickupType {
	Attack = 1,
	Defense = 2,
	Ability = 3,
	Heal = 4,
}

@export_group("书页配置")
@export var book_id : int
@export var pickup_type : PickupType = PickupType.Attack
@export var page_name : String = "未命名卡牌"
@export var icon : Texture2D   
@export var description : String = ""
@export var cd : int
@export var rarity : int = 0  # 稀有度：0=普通，1=稀有，2=史诗（攻击/防御可用0-2，能力/回复用0-1）
@export_group("书页效果")     
@export var damage : int = 0
@export var healing : int = 0
@export var Armor : int = 0
@export var attack_bonus : int = 0
