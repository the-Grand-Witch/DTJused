extends Node
## 负责随机怪物加载、UI更新及怪物状态

@onready var texture_rect = $MonsterTexture
@onready var damage_label = $MonsterDamageLabel
@onready var health_bar = $MonsterHealthBar

var current_monster: Generator_monster
var health: int
var max_health: int
var attack: int

func load_random_monster():
	var files = []
	var dir = DirAccess.open("res://Data/monster/")
	dir.list_dir_begin()
	var f = dir.get_next()
	while f != "":
		if f.ends_with(".tres"):
			var res = load("res://Data/monster/" + f)
			if res is Generator_monster and res.monster_id >= 1 and res.monster_id <= 19:
				files.append(res)
		f = dir.get_next()
	dir.list_dir_end()
	current_monster = files[randi() % files.size()]
	health = current_monster.health
	max_health = current_monster.health
	attack = current_monster.attack

func setup_ui():
	texture_rect.texture = current_monster.icon_textrue
	damage_label.text = "伤害: %d" % attack
	health_bar.max_value = max_health
	health_bar.value = health

func take_damage(amount: int):
	health -= amount
	if health < 0:
		health = 0
	health_bar.value = health

func is_dead() -> bool:
	return health <= 0

func get_attack() -> int:
	return attack

func get_current_monster() -> Generator_monster:
	return current_monster
