extends Node
## 普通战斗主控制器：负责初始化、回合流程与模块协调

signal monster_defeated

@onready var monster_manager = $Monster
@onready var player_ui = $Player
@onready var battle_calculator = $BattleCalcultor
@onready var reward_manager = $RewardManager
@onready var turn_label = $TurnLabel
@onready var end_turn_button = $EndTurnButton

const BookmarkCardScene = preload("res://scenes/bookmark.tscn")

var turn_count: int = 0
var player_attack_bonus: int = 0
var player_selected_cards: Array[BookmarkCard] = []
var player_cards: Array[BookmarkCard] = []
var player_max_selected: int = 1
var loot_bonus: int = 0
var previous_scene_path: String = "res://scenes/main.tscn"

func _ready():
	previous_scene_path = GlobalScenes.last_scene_path
	monster_manager.load_random_monster()
	monster_manager.setup_ui()
	player_ui.clear_hand()
	_create_player_cards()
	end_turn_button.pressed.connect(_on_end_turn_pressed)
	_start_round()

func _create_player_cards():
	player_cards.clear()
	for data in GlobalBookMark.bookmarks:
		var card = BookmarkCardScene.instantiate()
		player_ui.add_card(card)
		card.setup(data)
		card.selection_changed.connect(_on_player_card_selected.bind(card))
		player_cards.append(card)

func _on_player_card_selected(selected: bool, card: BookmarkCard):
	if selected:
		if player_selected_cards.size() >= player_max_selected:
			var oldest = player_selected_cards[0]
			player_selected_cards.erase(oldest)
			oldest.set_selected(false)
		player_selected_cards.append(card)
	else:
		player_selected_cards.erase(card)

func _start_round():
	turn_count += 1
	turn_label.text = "回合 %d" % turn_count

	# 玩家卡牌冷却递减
	for card in player_cards:
		card.decrease_cooldown()

	# 从全局玩家获取冲动数量，然后赋予冲动
	var impulse_count = GlobalPlayer.get_impulse_count()
	player_ui.apply_impulses(player_cards, impulse_count)

func _on_end_turn_pressed():
	# 玩家结算
	var player_result = battle_calculator.calculate_player_effects(
		player_selected_cards,
		player_attack_bonus,
		player_ui
	)
	# 更新玩家攻击加成（能力卡效果）
	player_attack_bonus = battle_calculator.get_player_attack_bonus()

	# 怪物承受伤害
	monster_manager.take_damage(player_result.damage)
	if monster_manager.is_dead():
		_on_monster_defeated()
		return

	# 玩家治疗
	if player_result.healing > 0:
		GlobalPlayer.heal(player_result.healing)

	# 玩家未打出的冲动惩罚
	player_ui.punish_unused_impulses()

	# 怪物反击
	var monster_result = battle_calculator.calculate_monster_attack(
		monster_manager.get_attack(),
		player_result.armor
	)
	if monster_result.damage_dealt > 0:
		GlobalPlayer.take_damage(monster_result.damage_dealt)

	# 检查玩家生命
	if GlobalPlayer.health <= 0:
		GlobalScenes.check_game_over()
		return

	# 进入下一回合
	_start_round()

func _on_monster_defeated():
	end_turn_button.disabled = true
	reward_manager.show_rewards(monster_manager.get_current_monster(), loot_bonus, previous_scene_path)
	emit_signal("monster_defeated")

func increase_loot_bonus(amount: int):
	loot_bonus += amount
