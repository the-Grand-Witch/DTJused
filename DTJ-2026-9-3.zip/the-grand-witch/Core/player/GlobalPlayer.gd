extends Node

# 信号
signal health_changed(new_health: int)
signal witch_power_changed(new_power: int)
signal gold_changed(new_gold: int)
signal max_health_changed(new_max_health: int)

# 玩家唯一ID（可从存档加载，这里临时随机）
var player_id: String = "player_" + str(randi())

# 生命与魔女化
var base_max_health: int = 200
var max_health: int = 200
var health: int = 200
var witch_power: int = 0
var gold: int = 0

const max_witch_power: int = 100

func _ready():
	# 监听饰品变化，重新计算最大生命值
	GlobalAccessories.accessory_added.connect(_on_accessory_changed)
	GlobalAccessories.accessory_removed.connect(_on_accessory_changed)
	recalculate_max_health()

func _on_accessory_changed(_accessory = null):
	recalculate_max_health()

func recalculate_max_health():
	var bonus = 0
	for acc in GlobalAccessories.accessories:
		bonus += acc.max_health_bonus
	var new_max = base_max_health + bonus
	var diff = new_max - max_health
	max_health = new_max
	if diff > 0:
		health = min(health + diff, max_health)
	elif diff < 0:
		health = max(health, 0)
	max_health_changed.emit(max_health)
	health_changed.emit(health)

func take_damage(amount: int) -> void:
	health = max(health - amount, 0)
	health_changed.emit(health)

func heal(amount: int = 10) -> void:
	health = min(health + amount, max_health)
	health_changed.emit(health)

func possessed(amount: int = 1) -> void:
	witch_power = min(witch_power + amount, max_witch_power)
	witch_power_changed.emit(witch_power)
	if witch_power >= max_witch_power:
		GlobalScenes.check_game_over()

func add_gold(amount: int) -> void:
	gold += amount
	gold_changed.emit(gold)

func reset() -> void:
	health = max_health
	witch_power = 0
	gold = 0
	recalculate_max_health()
	health_changed.emit(health)
	witch_power_changed.emit(witch_power)
	gold_changed.emit(gold)
	max_health_changed.emit(max_health)
	
## 获取当前魔女化对应的冲动数量（每10点魔女化赋予1个冲动）
func get_impulse_count() -> int:
	return witch_power / 10

## 获取未打出冲动时的魔女化惩罚值
func get_impulse_punishment() -> int:
	return 2

## 获取冲动伤害倍率（例如魔女化80时倍率为1.8）
func get_impulse_damage_multiplier() -> float:
	return 1.0 + float(witch_power) / 100.0

# 可选：保留测试按键，但正式版删除
func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_Q:
			heal(50)
		elif event.keycode == KEY_W:
			GlobalPlayer.possessed(20)
		elif event.keycode == KEY_E:
			GlobalTime.add_time_units(24)
