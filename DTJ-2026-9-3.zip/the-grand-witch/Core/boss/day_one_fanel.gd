extends Node
## 最终Boss战场景主控制器（测试版，含调试输出）
## 负责初始化顺序、玩家操作、回合流程与模块协调

signal boss_defeated

# 引用场景中的固定节点
@onready var enemy = $Enemy
@onready var player_ui = $Player
@onready var turn_label = $TurnLabel
@onready var end_turn_button = $EndTurnButton
const NORMAL_SNAPSHOT_DIR := "res://Data/DownloadPlayer/"
const SPECIAL_SNAPSHOT_DIR := "res://Data/DownloadPlayer/special/"
const BookmarkCardScene = preload("res://scenes/bookmark.tscn")

# 玩家状态
var player_selected_cards: Array[BookmarkCard] = []
var player_max_selected: int = 1
var player_attack_bonus: int = 0
var turn_count: int = 0
var player_cards: Array[BookmarkCard] = []
# 敌人快照引用（由快照管理器加载）
var player_snapshot: PlayerSnapshot

func _ready():
	player_snapshot = _load_random_snapshot()
	enemy.setup(player_snapshot)
	_create_player_cards()
	end_turn_button.pressed.connect(_on_end_turn_pressed)
	_start_round()

func _load_random_snapshot() -> PlayerSnapshot:
	var dir_path = SPECIAL_SNAPSHOT_DIR if randf() < 0.05 else NORMAL_SNAPSHOT_DIR
	var files: Array[String] = []
	var dir = DirAccess.open(dir_path)
	dir.list_dir_begin()
	var f = dir.get_next()
	while f != "":
		if not dir.current_is_dir() and f.ends_with(".tres"):
			files.append(dir_path + f)
		f = dir.get_next()
	dir.list_dir_end()
	return load(files[randi() % files.size()]) as PlayerSnapshot

func _create_player_cards():
	player_ui.clear_hand()
	player_cards.clear()
	for data in GlobalBookMark.bookmarks:
		var card = BookmarkCardScene.instantiate()
		player_ui.add_card(card)
		card.setup(data)
		card.selection_changed.connect(_on_player_card_selected.bind(card))
		player_cards.append(card)

func _on_player_card_selected(selected: bool, card: BookmarkCard):
	if selected:
		if player_selected_cards.size() >= player_max_selected:
			var oldest = player_selected_cards[0]
			player_selected_cards.erase(oldest)
			oldest.set_selected(false)
		player_selected_cards.append(card)
	else:
		player_selected_cards.erase(card)

func _start_round():
	turn_count += 1
	turn_label.text = "回合 %d" % turn_count
	# 玩家卡牌冷却递减
	for card in player_cards:
		card.decrease_cooldown()
	# 从全局玩家获取冲动数量，然后赋予冲动
	var impulse_count = GlobalPlayer.get_impulse_count()
	player_ui.apply_impulses(player_cards, impulse_count)
	# 敌人回合开始
	enemy.on_round_start(turn_count)

func _on_end_turn_pressed():
	var player_result = _calculate_player_effects()
	enemy.take_damage(player_result.damage)
	if enemy.get_health() <= 0:
		_on_boss_defeated()
		return
	if player_result.healing > 0:
		GlobalPlayer.heal(player_result.healing)
	enemy.take_turn(player_result.armor)
	if GlobalPlayer.health <= 0:
		_on_player_defeated()
		return
	_start_round()

func _calculate_player_effects() -> Dictionary:
	var result = {"damage": 0, "healing": 0, "armor": 0}
	var accessory_bonus = 0
	for acc in GlobalAccessories.accessories:
		accessory_bonus += acc.attack_bonus
	var total_attack_bonus = player_attack_bonus + accessory_bonus
	for card in player_selected_cards:
		for idx in range(card.bookmark_data.pages.size()):
			var page = card.bookmark_data.pages[idx]
			match page.pickup_type:
				Generator_bookpage.PickupType.Attack:
					var dmg = page.damage + total_attack_bonus
					if player_ui.has_impulse(card, idx):
						var multiplier = 1.0 + float(GlobalPlayer.witch_power) / 100.0
						dmg = int(ceil(dmg * multiplier))
						player_ui.consume_impulse(card, idx)
					result["damage"] += dmg
				Generator_bookpage.PickupType.Heal:
					result["healing"] += page.healing
				Generator_bookpage.PickupType.Defense:
					result["armor"] += page.Armor
				Generator_bookpage.PickupType.Ability:
					player_attack_bonus += page.attack_bonus
	for card in player_selected_cards:
		card.set_selected(false)
		card.start_cooldown()
	player_selected_cards.clear()
	return result

func _on_boss_defeated():
	emit_signal("boss_defeated")

func _on_player_defeated():
	GlobalScenes.check_game_over()
