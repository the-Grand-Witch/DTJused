extends Node

@onready var health_bar = $"../EnemyHealthBar"
@onready var portrait = $"../EnemyPortrait"
@onready var intent_icon = $"../EnemyIntent"
@onready var buff_grid = $"../EnemyBuffGrid"

func setup(snapshot, max_health, current_health):
	health_bar.max_value = max_health
	health_bar.value = current_health
	if snapshot.portrait:
		portrait.texture = snapshot.portrait
		portrait.visible = true
	else:
		portrait.visible = false

func update_health(current, max_val):
	health_bar.max_value = max_val
	health_bar.value = current

func show_intent(card, ai_module):
	if card == null:
		intent_icon.texture = null
		return
	var main_type = ai_module.get_main_type(card)
	var path = "res://Assets/Textures/Icons/intent/%s.png" % main_type
	intent_icon.texture = load(path)

func update_buffs(effects, bian_layers):
	for child in buff_grid.get_children():
		child.queue_free()
	if effects["attack_bonus"] > 0:
		_add_label("攻击+" + str(effects["attack_bonus"]))
	if effects["armor_per_turn"] > 0:
		_add_label("护甲/回合+" + str(effects["armor_per_turn"]))
	if effects["heal_per_turn"] > 0:
		_add_label("回血+" + str(effects["heal_per_turn"]) + "%")
	if bian_layers > 0:
		_add_label("彼岸层数:" + str(bian_layers))

func _add_label(text):
	var label = Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 12)
	buff_grid.add_child(label)
