extends Node
## 陌生人事件：先支付固定金币，获得 2-3 张卡牌

const RARITY_WEIGHTS := {0: 3, 1: 2, 2: 1}
const DROP_MIN := 2
const DROP_MAX := 3
const CARD_COST := 180

func trigger_effect(_btn: Button) -> bool:
	if GlobalPlayer.gold < CARD_COST:
		GlobalPlayer.show("金币不足，陌生人摇了摇头")
		return true

	GlobalPlayer.add_gold(-CARD_COST)

	var count = GlobalRng.range(DROP_MIN, DROP_MAX)
	var gained: Array[Generator_bookpage] = []
	for i in range(count):
		var card = _roll_card_by_rarity()
		if card:
			gained.append(card)

	if not gained.is_empty():
		GlobalScenes.reward_requested.emit(0, [], gained)
	return true

func _roll_card_by_rarity() -> Generator_bookpage:
	var total = 0
	for w in RARITY_WEIGHTS.values():
		total += w
	var roll = GlobalRng.range(0, total - 1)
	var cumulative = 0
	var chosen_rarity = 0
	for rarity in RARITY_WEIGHTS:
		cumulative += RARITY_WEIGHTS[rarity]
		if roll < cumulative:
			chosen_rarity = rarity
			break

	var candidates: Array[Generator_bookpage] = []
	for card in GlobalCardLibrary.get_randomable_cards():
		if card.rarity == chosen_rarity:
			candidates.append(card)
	if candidates.is_empty():
		return null
	return candidates[GlobalRng.range(0, candidates.size() - 1)]
