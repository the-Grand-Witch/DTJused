extends Node

func trigger_effect(_btn: Button) -> bool:
	# 刷新所有事件卡牌
	GlobalScenes.refresh_events()
	# 时间消耗：Walk 事件消耗 3 个单位
	# 时间改为由事件资源的 time_units 扣（标准：零头档 3 单位），脚本不再自己扣
	return true
