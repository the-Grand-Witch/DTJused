extends Node
## 选择题选项效果：抽出 RELIC_COUNT 个遗物（跳过已拥有的），玩家挑 PICK_LIMIT 个加入。
## 挂法：Generator_event.choices 里那个选项的 effect_script。
## 档位权重 low : mid : high = 5 : 3 : 1；档位区间由 GlobalAccessories 决定（1-33 / 34-66 / 67-99）。
## 加入 = GlobalAccessories.add_accessories（本身按 acc_id 去重），点选由 RewardPopup 自己完成。

const RELIC_COUNT := 3   # 抽几个
const PICK_LIMIT := 1    # 最多挑几个
const TIER_WEIGHTS := {"low": 5, "mid": 3, "high": 1}

func trigger_effect(btn: Button) -> bool:
	var choice: Generator_event = btn.get_meta("event_data")
	var relics: Array[Generator_accessories] = []
	for i in RELIC_COUNT:
		var acc := _draw_one(relics)
		if acc == null:
			break
		relics.append(acc)
	var title := choice.popup_title if choice.popup_title != "" else choice.event_name
	GlobalScenes.show_choice([], relics, PICK_LIMIT, title)
	queue_free()
	return true

## 抽一个：先滤掉（已拥有 + 本次已抽到）的，再按 5:3:1 选档，档内等概率
func _draw_one(exclude: Array[Generator_accessories]) -> Generator_accessories:
	var tiers: Array = []
	var total_weight := 0
	for tier_name in TIER_WEIGHTS:
		var usable: Array[Generator_accessories] = []
		for acc in GlobalAccessories.get_tier(tier_name):
			if GlobalAccessories.has_accessories(acc.acc_id):
				continue
			if acc in exclude:
				continue
			usable.append(acc)
		if usable.is_empty():
			continue
		tiers.append({"usable": usable, "weight": TIER_WEIGHTS[tier_name]})
		total_weight += TIER_WEIGHTS[tier_name]
	if total_weight == 0:
		return null
	var roll := GlobalRng.range(0, total_weight - 1)
	for t in tiers:
		roll -= t["weight"]
		if roll < 0:
			return t["usable"][GlobalRng.range(0, t["usable"].size() - 1)]
	return null
