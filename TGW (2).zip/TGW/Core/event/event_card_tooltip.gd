extends Button
## 事件卡片的悬浮提示框（1.5 倍）
## ==================================================================
## 具体尺寸/配色在 `Core/ui/big_tooltip.gd`，这里只是把它接到 Button 的
## `_make_custom_tooltip()` 上。纯 Button 需要 1.5 倍提示框时，
## 直接 `set_script(load("res://Core/event/event_card_tooltip.gd"))` 即可。
## ==================================================================

const BigTooltip := preload("res://Core/ui/big_tooltip.gd")

func _make_custom_tooltip(for_text: String) -> Object:
	return BigTooltip.build(for_text)
