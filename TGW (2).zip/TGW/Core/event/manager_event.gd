extends Node

# ==================== 常量 ====================
const EVENT_DIR : = "res://Data/event/"
const BOSS_EVENT_BASE_ID := 100          # Boss 事件基础 ID，100-103 为 Boss
const BOSS_TIME_MINUTES := 21 * 60       # 21:00 允许 Boss 进入随机池
const BOSS_FORCE_MINUTES := 21 * 60 + 30 # 21:30 强制 Boss
const DAY_END_MINUTES := 22 * 60         # 22:00 当天结束，事件不能超过此时间

## Boss 战目前因「场景未完成」而暂缓，但**夜间封锁是刻意的日程设计，保留不动**：
## 21:30 后左右事件仍会空掉，玩家只能挑战当天 Boss，这就是一天的结束点。
## 本开关只控制「Boss 事件是否进入白天的随机池」——Boss 事件始终保留在
## boss_event_pool 里，保证 21:30 一定拿得到。等 scenes/ 下补齐可用的 Boss 场景后，
## 把这里改成 true，白天的随机池也会重新出现 Boss 事件。
const BOSS_BATTLE_ENABLED := false

# ==================== 节点引用 ====================
@onready var option_nodes = [$OptionA, $OptionB, $OptionC]
@onready var overlay_container: Control = $"../OverlayContainer"

# ==================== 状态变量 ====================
var cards := {}
var last_event_ids := {}
var is_boss_time := false

# ==================== 汉娜「漂浮」= 同侧连步（局外经济标准.md §八）====================
## 连着在同侧推进累加层数、换侧清零；第 4 格起满层（上限 4）。
## 减免 = min(0.5, 层数 × 0.20 × 魔女化比例)；实际耗时 = clamp(max(1, round(基础 × (1−减免))), 1, 基础×2)。
const HANNA_CHARACTER_ID := "3"
const SAME_SIDE_MAX_LAYERS := 4
const SAME_SIDE_REDUCE_PER_LAYER := 0.20
const SAME_SIDE_REDUCE_CAP := 0.5

## 事件卡上的名称：从按钮文字挪到**卡片底部**的一个 Label 上
const EVENT_NAME_FONT_SIZE := 44
const EVENT_NAME_HEIGHT := 76.0
const EVENT_NAME_BOTTOM_MARGIN := 16.0

## 上一次落在哪一侧（0/1/2；-1 = 还没走过）
var last_side: int = -1
## 连续同侧推进的层数（换侧清零，上限 4）
var same_side_layers: int = 0
var event_pool: Array[Generator_event] = []
## Boss 事件单独存放：不参与白天随机，但 21:30 的夜间封锁必须能取到
var boss_event_pool: Array[Generator_event] = []

const ROAD_EVENT_TYPES = [Generator_event.EventType.WALK, Generator_event.EventType.DIG]

# ==================== 初始化 ====================
func _ready():
	GlobalScenes.event_manager = self
	# 不在这里 randomize()：影响资源的随机一律走 GlobalRng（种子在开局 reseed），
	# 这行会让「同一种子复现」失效，也会打乱之后的表演性随机序列
	_load_event_pool()
	for btn in option_nodes:
		btn.pressed.connect(_on_option_pressed.bind(btn))
		_create_card(btn)
	
	GlobalTime.time_changed.connect(_check_boss_time)
	_check_boss_time(GlobalTime.get_time())

# ==================== 事件池加载 ====================
func _load_event_pool():
	event_pool.clear()
	boss_event_pool.clear()
	var files = ResourceLoader.list_directory("res://Data/event")
	for file in files:
		if file.ends_with(".tres"):
			var res = load("res://Data/event/" + file)
			if not (res is Generator_event):
				continue
			# enabled 是单个事件的通用下架开关
			if not res.enabled:
				continue
			if _is_boss_event(res):
				# Boss 事件永远留在专用池里，夜间封锁一定取得到
				boss_event_pool.append(res)
				# 白天是否允许随机到 Boss，由总开关决定
				if BOSS_BATTLE_ENABLED:
					event_pool.append(res)
			else:
				event_pool.append(res)

func _is_boss_event(event_data: Generator_event) -> bool:
	return event_data.event_id >= BOSS_EVENT_BASE_ID and event_data.event_id <= BOSS_EVENT_BASE_ID + 3

# ==================== 卡片创建 ====================
func _create_card(btn, forced_event: Generator_event = null):
	if cards.has(btn):
		var old_event: Generator_event = cards[btn]
		_play_animation(btn, old_event.anim_destroy_frames, old_event.anim_duration)
		for child in btn.get_children():
			child.queue_free()
	
	var chosen: Generator_event
	if forced_event:
		chosen = forced_event
	else:
		chosen = _choose_valid_event(btn)

	# 兜底：实在挑不出事件时保留原牌面，不要让按钮拿到 null
	if chosen == null:
		push_warning("[EventManager] 没有可用事件可刷新：%s" % btn.name)
		return

	btn.icon = chosen.icon
	# 名称不画在按钮中间了：清空按钮文字，改由底部的 Label 显示（见 _add_event_name）
	btn.text = ""
	_add_event_name(btn, chosen.event_name)
	# 悬浮框只显示事件的介绍文本，不重复卡片上已有的名称
	btn.tooltip_text = chosen.description
	btn.flat = true
	btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	btn.set_meta("event_data", chosen)
	cards[btn] = chosen
	last_event_ids[btn] = chosen.event_id
	
	_play_animation(btn, chosen.anim_join_frames, chosen.anim_duration)

## 把事件名放到卡片**最下面**：一个铺满底部、鼠标穿透的 Label。
## ⚠️ 不按名字取旧 Label：_create_card 开头是 queue_free（本帧还没释放），
##    按名字找会拿到正在销毁的那个，所以每次都新建。
func _add_event_name(btn: Button, event_name: String) -> void:
	if event_name == "":
		return
	var label := Label.new()
	label.text = event_name
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", EVENT_NAME_FONT_SIZE)
	btn.add_child(label)
	label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	label.offset_top = -(EVENT_NAME_HEIGHT + EVENT_NAME_BOTTOM_MARGIN)
	label.offset_bottom = -EVENT_NAME_BOTTOM_MARGIN

# ==================== 事件选择逻辑 ====================
func _choose_valid_event(btn):
	var candidates = event_pool.duplicate()
	var current_minutes = GlobalTime.get_time()

	# 时间限制
	candidates = candidates.filter(func(e):
		var event_end_time = current_minutes + e.time_units * 5
		return event_end_time <= DAY_END_MINUTES
	)

	# 21:00 之前排除 Boss 事件
	if current_minutes < BOSS_TIME_MINUTES:
		candidates = candidates.filter(func(e): return not _is_boss_event(e))

	# 排除与上次相同的事件
	if last_event_ids.has(btn):
		var last_id = last_event_ids[btn]
		candidates = candidates.filter(func(e): return e.event_id != last_id)

	# 如果其他按钮已有道路事件，排除道路事件
	if _has_road_event(btn):
		candidates = candidates.filter(func(e): return not (e.event_type in ROAD_EVENT_TYPES))

	# 剔除权重为0的事件，避免除零
	candidates = candidates.filter(func(e): return e.weight > 0)

	# 放宽条件（如果候选为空，逐步放宽）
	if candidates.is_empty():
		candidates = event_pool.duplicate()
		candidates = candidates.filter(func(e):
			var event_end_time = current_minutes + e.time_units * 5
			return event_end_time <= DAY_END_MINUTES
		)
		if current_minutes < BOSS_TIME_MINUTES:
			candidates = candidates.filter(func(e): return not _is_boss_event(e))
		if last_event_ids.has(btn):
			candidates = candidates.filter(func(e): return e.event_id != last_event_ids[btn])
		# 再次剔除权重为0
		candidates = candidates.filter(func(e): return e.weight > 0)
		if candidates.is_empty():
			candidates = event_pool.duplicate()
			# 最后兜底：权重为0也允许参与等概率随机
			if candidates.is_empty():
				return null
	# 保底：宁可不换牌，也不要让按钮拿到 null 事件
	if candidates.is_empty():
		return null
	# 使用加权随机选择
	return _weighted_random(candidates)

# 加权随机函数
func _weighted_random(events: Array[Generator_event]) -> Generator_event:
	var total_weight := 0
	for event in events:
		total_weight += event.weight

	var roll := GlobalRng.range(0, total_weight - 1)
	var cumulative := 0
	for event in events:
		cumulative += event.weight
		if roll < cumulative:
			return event
	return events[0]

func _has_road_event(exclude_btn):
	for btn in option_nodes:
		if btn == exclude_btn:
			continue
		if cards.has(btn):
			if cards[btn].event_type in ROAD_EVENT_TYPES:
				return true
	return false

# ==================== 点击处理 ====================
func _on_option_pressed(btn):
	if not cards.has(btn):
		return
	var event_data: Generator_event = cards[btn]
	
	_play_animation(btn, event_data.anim_execute_frames, event_data.anim_duration)
	
	# 记落点：汉娜的同侧连步层数要在这格的时间结算之前更新
	note_side(btn)
	# 时间取「进节点那一刻」：_trigger_event 里第一件事就是推进时间，所以必须记在它前面
	GlobalJourney.add_node(event_data.event_name)
	var completed = _trigger_event(event_data, btn)
	
	if completed and event_data.anim_end_frames:
		_play_animation(btn, event_data.anim_end_frames, event_data.anim_duration)
	
	if event_data.unique and completed:
		event_pool.erase(event_data)
	
	if completed:
		_create_card(btn)

# ==================== 事件效果触发 ====================
# ==================== 事件效果触发 ====================
func _trigger_event(event_data: Generator_event, btn: Button) -> bool:
	# 格子事件结算完成的**统一出口**：所有分支（特殊事件脚本 / 场景 / 普通数值）都从它进出。
	# ⚠️ 通知只能发在这里：绝大多数事件是 is_special（走 effect_script），
	#    直接 return，根本不经过 apply_event_changes —— 汉娜的存钱罐就是靠这里 +3 金币。
	var result := _trigger_event_inner(event_data, btn)
	GlobalPassive.notify_event_done()
	return result

func _trigger_event_inner(event_data: Generator_event, btn: Button) -> bool:
	if event_data.time_units > 0:
		GlobalTime.add_time_units(reduced_time_units(event_data.time_units))
	
	if event_data.is_special:
		if event_data.effect_script:
			var obj = event_data.effect_script.new()
			add_child(obj)
			return obj.trigger_effect(btn)
		elif event_data.effect_scene:
			# 根据 is_full_scene 决定加载方式
			if event_data.is_full_scene:
				GlobalScenes.change_scene(event_data.effect_scene.resource_path)
			else:
				open_overlay(event_data.effect_scene, event_data)
			return true
	else:
		apply_event_changes(event_data)
		return true
	return false

## 数值效果的统一入口：普通事件与选择题选项都走这里
func apply_event_changes(event_data: Generator_event) -> void:
	if event_data.health_change != 0:
		if event_data.health_change > 0:
			GlobalPlayer.heal(event_data.health_change)
		else:
			GlobalPlayer.take_damage(-event_data.health_change)
	if event_data.witch_power_change != 0:
		GlobalPlayer.possessed(event_data.witch_power_change)
	if event_data.gold_change != 0:
		GlobalPlayer.add_gold(event_data.gold_change)


# ==================== 动画播放 ====================
func _play_animation(btn: Button, frames: SpriteFrames, duration: float):
	if frames:
		var sprite = AnimatedSprite2D.new()
		sprite.sprite_frames = frames
		sprite.centered = false
		sprite.position = Vector2.ZERO
		btn.add_child(sprite)
		sprite.play()
		sprite.animation_finished.connect(func(): sprite.queue_free())
	else:
		var tween = create_tween()
		tween.tween_property(btn, "modulate:a", 0.0,0.2 )  # 淡出 0.3 秒
		tween.tween_property(btn, "modulate:a", 1.0, 0.0)  # 淡入 0 秒

# ==================== 深夜 Boss 封锁 ====================
# 这是刻意的日程设计：21:30 之后左右两个事件空掉，通往 Boss 的路只剩中间一格，
# 一天到此结束。注意本段**不受 BOSS_BATTLE_ENABLED 影响**，夜间封锁始终生效。
func _check_boss_time(minutes: int):
	if minutes >= BOSS_FORCE_MINUTES and not is_boss_time:
		is_boss_time = true
		_refresh_for_boss_time()

func _refresh_for_boss_time():
	var empty_event = _get_empty_event()
	var boss_event = _get_boss_event_by_day()

	# 左右按钮设置为透明占位空事件，保持布局
	for i in [0, 2]:
		var btn = option_nodes[i]
		_create_card(btn, empty_event)
		btn.disabled = true
		btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
		btn.modulate = Color(1, 1, 1, 0)   # 完全透明，但保留占位

	# 中间按钮切换到当天 Boss 事件
	var middle_btn = option_nodes[1]
	if boss_event == null:
		# 理论上不会发生：boss_event_pool 里应当总有 100-103
		push_error("[EventManager] 找不到任何 Boss 事件，Data/event 里缺少 100-103")
		return
	_create_card(middle_btn, boss_event)

func _get_boss_event_by_day() -> Generator_event:
	var day = GlobalTime.get_day()
	var boss_id = BOSS_EVENT_BASE_ID + day
	if boss_id > BOSS_EVENT_BASE_ID + 3:
		boss_id = BOSS_EVENT_BASE_ID + (day % 4)  # 循环使用 100-103
	for event in boss_event_pool:
		if event.event_id == boss_id:
			return event
	# 如果找不到，随机选一个 Boss 事件
	return _get_random_boss_event()

func _get_random_boss_event() -> Generator_event:
	if boss_event_pool.is_empty():
		return null
	return GlobalRng.pick(boss_event_pool)

func _get_empty_event() -> Generator_event:
	var empty = Generator_event.new()
	empty.event_id = -1
	empty.event_name = ""
	empty.description = ""
	empty.icon = null
	empty.time_units = 0
	empty.is_special = false
	empty.unique = false
	return empty

# ==================== Overlay 管理 ====================
## 打开一个覆盖场景（商店 / 选择题 …），并把触发它的事件资源一并交给场景。
## ⚠️ 必须先 set_meta 再 add_child：add_child 会立刻触发场景自己的 _ready()，晚了就拿不到。
func open_overlay(scene: PackedScene, event_data: Generator_event):
	# 清空旧内容
	for child in overlay_container.get_children():
		child.queue_free()
	# 实例化新场景
	var instance = scene.instantiate()
	instance.set_meta("event_data", event_data)
	overlay_container.add_child(instance)
	overlay_container.visible = true

## 关闭覆盖层
## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func close_overlay():
	for child in overlay_container.get_children():
		child.queue_free()
	overlay_container.visible = false

# ==================== 汉娜「漂浮」====================
## 记录这一次落在哪一侧，并更新同侧连步层数（换侧清零，第 1 格就是 1 层）
func note_side(btn: Button) -> void:
	var side: int = option_nodes.find(btn)
	if side == -1:
		return
	if side == last_side:
		same_side_layers = mini(same_side_layers + 1, SAME_SIDE_MAX_LAYERS)
	else:
		same_side_layers = 1
		last_side = side

## 这一次格子实际消耗的时间单位。只有汉娜会变（其它角色原样返回）。
## 减免 = min(0.5, 层数 × 0.20 × 魔女化比例)，再 clamp 到 [1, 基础×2]。
func reduced_time_units(base_units: int) -> int:
	if base_units <= 0 or not is_floating_character():
		return base_units
	var wp := 0.0
	if GlobalPlayer.max_witch_power > 0:
		wp = clampf(float(GlobalPlayer.witch_power) / float(GlobalPlayer.max_witch_power), 0.0, 1.0)
	var reduction: float = minf(SAME_SIDE_REDUCE_CAP, float(same_side_layers) * SAME_SIDE_REDUCE_PER_LAYER * wp)
	var scaled: int = int(round(float(base_units) * (1.0 - reduction)))
	return clampi(maxi(1, scaled), 1, base_units * 2)

## 当前角色会不会「漂浮」（按 character_id 认，改名不影响）
func is_floating_character() -> bool:
	var girl = GlobalPlayer.current_character
	return girl != null and girl.character_id == HANNA_CHARACTER_ID

# ==================== 外部接口 ====================
func refresh_all_cards() -> void:
	for btn in option_nodes:
		_create_card(btn)
