extends Node
## 选择题选项效果：亮出 CARD_COUNT 张书页（本局可掉落池里随机、不重复），玩家最多挑 PICK_LIMIT 张加入。
## 挂法：Generator_event.choices 里那个选项的 effect_script。
## 入口沿用卡片事件那套 trigger_effect(btn)，btn 上的 meta("event_data") 就是这个选项资源。
## 加入 = GlobalCardLibrary.add_acquired_count（获得 + 可用），点选由 RewardPopup 自己完成。

const CARD_COUNT := 8   # 亮出几张
const PICK_LIMIT := 2   # 最多挑几张

func trigger_effect(btn: Button) -> bool:
	var choice: Generator_event = btn.get_meta("event_data")
	var pool: Array[Generator_bookpage] = GlobalCardLibrary.get_randomable_cards()
	pool.shuffle()
	var cards: Array[Generator_bookpage] = []
	for i in mini(CARD_COUNT, pool.size()):
		cards.append(pool[i])
	var title := choice.popup_title if choice.popup_title != "" else choice.event_name
	GlobalScenes.show_choice(cards, [], PICK_LIMIT, title)
	queue_free()
	return true
