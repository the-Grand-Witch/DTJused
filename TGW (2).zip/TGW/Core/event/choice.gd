extends Control
## 选择题事件场景（scenes/event/choice.tscn 的根脚本）
## 由 manager_event.open_overlay() 作为子节点挂进 OverlayContainer，
## 事件资源通过 set_meta("event_data", ...) 传进来 —— 本场景不自己找数据。

@onready var icon_rect: TextureRect = $Icon
@onready var text_label: Label = $Text
@onready var option_nodes: Array[Button] = [
	$Choices/Option1,
	$Choices/Option2,
	$Choices/Option3,
	$Choices/Option4,
	$Choices/Option5,
]

func _ready() -> void:
	var event_data: Generator_event = get_meta("event_data")
	icon_rect.texture = event_data.icon
	text_label.text = event_data.description
	for i in option_nodes.size():
		var btn: Button = option_nodes[i]
		if i < event_data.choices.size():
			var choice: Generator_event = event_data.choices[i]
			btn.visible = true
			btn.text = choice.event_name
			btn.set_meta("event_data", choice)
			btn.pressed.connect(_on_option_pressed.bind(btn))
		else:
			btn.visible = false

## 选完执行该选项的数值效果，再把自己从 OverlayContainer 收掉（关法照 Core/shop/shop.gd）
func _on_option_pressed(btn: Button) -> void:
	var choice: Generator_event = btn.get_meta("event_data")
	if choice.effect_script:
		# 走和卡片事件一样的路：脚本实例挂在 manager 上，免得跟着本场景一起被 free
		var obj = choice.effect_script.new()
		GlobalScenes.event_manager.add_child(obj)
		obj.trigger_effect(btn)
	else:
		GlobalScenes.event_manager.apply_event_changes(choice)
	var overlay := get_parent()
	queue_free()
	if overlay is Control:
		overlay.visible = false
