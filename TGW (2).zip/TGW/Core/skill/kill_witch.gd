@tool
extends Generator_PassiveEffect
class_name KillWitchPassive

## 艾玛的被动：敌我魔女化越接近满值，伤害倍率越高。
##   multiplier = 1 + (敌人魔女化 × 自己魔女化) / 10000
##
## ⚠️ 取数一律走 owner（见 Generator_PassiveEffect 顶部说明）。
##    之前直接读 GlobalPlayer，导致同一个脚本没法给镜像用。
func modify_damage_multiplier(enemy_witch_power: int) -> float:
	var max_wp = owner_max_witch_power()
	if max_wp <= 0:
		return 1.0
	var e = clamp(enemy_witch_power, 0, max_wp)
	var s = clamp(owner_witch_power(), 0, max_wp)
	return 1.0 + (e * s) / 10000.0
