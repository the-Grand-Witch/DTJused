extends Node
## 全局被动：注册被动、广播钩子、转发查询

var character_passive: Generator_PassiveEffect
var accessories_passives: Array[Generator_PassiveEffect] = []
var accessories_passive_map: Dictionary = {}

## 当前正在战斗的 owner（无战斗时为 null）。由 BattleState.bind_owner 写入，
## 用途是让「战斗中新增的饰品被动实例」也能拿到 owner。
## 存 WeakRef：战斗场景销毁后这个引用会自然失效，不会吊着一个已释放的节点。
var _active_owner_ref: WeakRef = null

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func set_active_owner(owner_node: Node) -> void:
	if owner_node == null:
		_active_owner_ref = null
	else:
		_active_owner_ref = weakref(owner_node)

func clear_active_owner() -> void:
	_active_owner_ref = null

func get_active_owner() -> Node:
	if _active_owner_ref == null:
		return null
	var obj = _active_owner_ref.get_ref()
	if obj is Node and is_instance_valid(obj):
		return obj
	return null

func _ready():
	character_passive = Generator_PassiveEffect.new()
	GlobalPlayer.character_changed.connect(_on_character_changed)
	GlobalAccessories.accessories_added.connect(_on_accessories_added)
	GlobalAccessories.accessories_removed.connect(_on_accessories_removed)
	GlobalTime.time_units_added.connect(_on_time_units_added)

func _on_character_changed(character: Generator_girl):
	if character == null:
		return
	if character.passive:
		character_passive = character.passive

func _on_accessories_added(acc: Generator_accessories):
	if acc == null:
		return
	if acc.effect_script:
		var instance = acc.effect_script.new()
		if instance.has_method("setup"):
			instance.setup(acc)
		accessories_passives.append(instance)
		accessories_passive_map[acc.acc_id] = instance
		# 战斗中捡到饰品时，新实例也要拿到 owner，否则它的钩子会取不到数
		# （取不到会静默退化为 0/1.0，不报错但结果是错的）
		var active = get_active_owner()
		if active != null and instance.has_method("set_battle_owner"):
			instance.set_battle_owner(active)

func _on_accessories_removed(acc_id: int):
	if accessories_passive_map.has(acc_id):
		var instance = accessories_passive_map[acc_id]
		accessories_passives.erase(instance)
		accessories_passive_map.erase(acc_id)

# ==================== 被动获取 ====================
func get_passive() -> Generator_PassiveEffect:
	return character_passive

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func set_passive(passive: Generator_PassiveEffect) -> void:
	character_passive = passive

## 收集全部被动实例：角色被动 + 所有饰品被动。
## 供 GlobalStats 统一取乘数用；新类型的被动（能力/技能来源）以后也加进这个列表即可。
func collect_passives() -> Array:
	var list: Array = []
	if character_passive != null:
		list.append(character_passive)
	list.append_array(accessories_passives)
	return list

# ==================== 事件钩子广播 ====================
func is_page_available(page: Generator_bookpage) -> bool:
	if not character_passive.is_page_available(page):
		return false
	for p in accessories_passives:
		if not p.is_page_available(page):
			return false
	return true

func notify_battle_start() -> void:
	# 冲动免疫已改由 BattleState.passive_values 存放，被动会在 on_battle_start 里写。
	# 这里不再重置它 —— 重置的职责在 BattleState.reset_battle()。
	character_passive.on_battle_start()
	for p in accessories_passives:
		p.on_battle_start()

func get_turn_effects(turn_count: int) -> Array:
	var effects: Array = []
	effects.append_array(character_passive.on_turn_start(turn_count))
	for p in accessories_passives:
		effects.append_array(p.on_turn_start(turn_count))
	return effects

## 局外：一个格子事件结算完成。角色被动与饰品被动都收到（汉娜的存钱罐靠它）。
func notify_event_done() -> void:
	character_passive.on_event_done()
	for p in accessories_passives:
		if p != null and p.has_method("on_event_done"):
			p.on_event_done()

func notify_turn_end(turn_count: int) -> void:
	character_passive.on_turn_end(turn_count)
	for p in accessories_passives:
		p.on_turn_end(turn_count)

func notify_page_played(mark: Dictionary) -> void:
	character_passive.on_page_played(mark)
	for p in accessories_passives:
		p.on_page_played(mark)

func notify_damage_taken(amount: int) -> void:
	character_passive.on_damage_taken(amount)
	for p in accessories_passives:
		p.on_damage_taken(amount)

func notify_damage_dealt(amount: int) -> void:
	character_passive.on_damage_dealt(amount)
	for p in accessories_passives:
		p.on_damage_dealt(amount)

func notify_heal(amount: int) -> void:
	character_passive.on_heal(amount)
	for p in accessories_passives:
		p.on_heal(amount)

func notify_witch_power_changed(value: int) -> void:
	character_passive.on_witch_power_changed(value)
	for p in accessories_passives:
		p.on_witch_power_changed(value)

func _on_time_units_added(units: int) -> void:
	character_passive.on_time_changed(units)
	for p in accessories_passives:
		p.on_time_changed(units)

## 敌人这回合用了哪些类型的书页。
## 角色被动与饰品被动都要收到——「看破」类效果（雪莉的帽子）就是靠这个和
## 玩家自己打出的页类型做比对的，漏掉角色被动等于这类效果永远不会触发。
func notify_enemy_page_used(types: Array) -> void:
	if character_passive.has_method("on_enemy_page_used"):
		character_passive.on_enemy_page_used(types)
	for p in accessories_passives:
		if p.has_method("on_enemy_page_used"):
			p.on_enemy_page_used(types)

# ==================== 查询转发 ====================
func try_consume_block() -> bool:
	for p in accessories_passives:
		if p.has_method("try_consume_block"):
			if p.try_consume_block():
				return true
	return false

func get_block_charge() -> int:
	var total = 0
	for p in accessories_passives:
		if p.has_method("get_block_charge"):
			total += p.get_block_charge()
	return total

## 每回合护甲 / 回复的被动修正。
## base 是「本回合靠书页打出来的护甲/回复」（battle_state.armor_count / heal_count），
## 没有基础值时传 0，被动返回值就是最终值。
## 返回值同样按「乘数 1.0 / 加算 0」的约定来，缺省不实现就是原样返回。
func get_armor_per_turn(base: int = 0) -> int:
	var value := base
	for p in collect_passives():
		if p.has_method("modify_armor_per_turn"):
			value = int(p.modify_armor_per_turn(value))
	return value

func get_heal_per_turn(base: int = 0) -> int:
	var value := base
	for p in collect_passives():
		if p.has_method("modify_heal_per_turn"):
			value = int(p.modify_heal_per_turn(value))
	return value

## 「看破」层数已搬进 BattleState.passive_values（见本文件末尾说明）。
## 这里原先还声明过 insight_stacks 字段与 get/add_insight / get_heart_failure，
## 都已删除 —— 它们本质是「战斗态」，留在单例上会让玩家与镜像共用同一份。

func is_heal_disabled() -> bool:
	if character_passive.has_method("is_heal_disabled"):
		return character_passive.is_heal_disabled()
	return false

# ==================== 掉落屏蔽：来源方接口 ====================
## 被动侧目前没有屏蔽规则。要加的话在这里返回规则数组即可，
## 结构与 GlobalContract.get_reward_effects() 一致（见该处注释）。
func get_reward_effects() -> Array:
	return []

## 解析器：奖励流程逐件掉落来问「要不要屏蔽」，认领就返回 true。
func consume_reward_block(_context: Dictionary) -> bool:
	return false

# ==================== 注意：冲动 / 看破 / 冲动免疫已搬走 ====================
## 这些原本存在本单例上，导致玩家与镜像会共用同一份。现已搬进 BattleState
## （见 Core/battle/battle_state.gd 的「冲动（战斗态）」与「被动具名战斗态」两节）：
##   impulse_immune / insight_stacks → battle_state.passive_values
##   apply_impulses / clear_impulses / has_impulse / consume_impulse / punish_unused_impulses
## 本文件不再保留这些字段与方法，请勿在这里重新加回来。

# ==================== 重置 ====================
func reset() -> void:
	character_passive = Generator_PassiveEffect.new()
	accessories_passives.clear()
	accessories_passive_map.clear()
	clear_active_owner()
