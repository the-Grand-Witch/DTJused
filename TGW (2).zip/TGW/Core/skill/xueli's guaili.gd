@tool
extends Generator_PassiveEffect
class_name XueliPassive

## 雪莉的被动：心衰
## ==================================================================
## heart_failure = 魔女化 / 10，分六档逐步剥夺能力。
##
## ⚠️ heart_failure 存在 **owner 的具名战斗态**里（battle_state.passive_values），
##    不存在本实例上：实例挂在全局管理器上，玩家与镜像会共用同一份。
##    本字段只作为「没有 owner 时」的兜底值。
## ==================================================================

var heart_failure: int = 0

# 心衰六档
const HF_ABILITY_DISABLE := 22
const HF_ARMOR_HALF := 29
const HF_HEAL_DISABLE := 37
const HF_DAMAGE_075 := 52
const HF_ARMOR_ZERO := 60
const HF_DAMAGE_ZERO := 90

const HF_KEY := "heart_failure"

## 取当前心衰档位：优先问 owner，拿不到才用本地兜底值
func get_heart_failure() -> int:
	var value = owner_get_value(HF_KEY, null)
	if value == null:
		return heart_failure
	return int(value)

func on_battle_start() -> void:
	var owner_state = battle_owner
	if owner_state != null and owner_state.has_method("set_impulse_immune"):
		owner_state.set_impulse_immune(true)

func on_turn_start(_turn_count: int) -> Array:
	var hf = int(owner_witch_power() / 10)
	heart_failure = hf
	owner_set_value(HF_KEY, hf)
	return []

func is_page_available(page: Generator_bookpage) -> bool:
	if Generator_bookpage.PickupType.Ability in page.page_type:
		if get_heart_failure() >= HF_ABILITY_DISABLE:
			return false
	return true

# ==================== 数值接口 ====================
## 所有基础伤害 ×1.5，心衰 52 再 ×0.75，心衰 90 归 0
func modify_damage_multiplier(_enemy_witch_power: int) -> float:
	var hf = get_heart_failure()
	if hf >= HF_DAMAGE_ZERO:
		return 0.0
	var mult = 1.5
	if hf >= HF_DAMAGE_075:
		mult *= 0.75
	return mult

## 【能力来源示例 · 当前默认关闭，故意不产生数值影响】
## 这是「把某个修正做成能力乘数」的模板：返回 {维度: 增量}，+1.0 表示最终 ×2.0。
## 想启用就把下面那行注释掉——它会在心衰未到「能力失效」档时额外给一次伤害翻倍。
## 之所以默认不生效，是为了不擅自改动雪莉既有的数值曲线（现有心衰惩罚已经在
## modify_damage_multiplier() 里表达完了），避免这次接入顺手把她改强。
## 维度名见 GlobalStats.STATS；卡片脚本侧则用 context["add_damage_multiplier"](delta)。
func get_ability_multipliers() -> Dictionary:
	var result := {}
	# if get_heart_failure() < HF_ABILITY_DISABLE:
	# 	result["damage"] = 1.0
	return result

## 护甲倍率：心衰 29 减半，心衰 60 归 0
func modify_armor_multiplier() -> float:
	var hf = get_heart_failure()
	if hf >= HF_ARMOR_ZERO:
		return 0.0
	if hf >= HF_ARMOR_HALF:
		return 0.5
	return 1.0

## 心衰 22 起 ability 失效
func is_ability_disabled() -> bool:
	return get_heart_failure() >= HF_ABILITY_DISABLE

## 心衰 37 起 heal 不可用
func is_heal_disabled() -> bool:
	return get_heart_failure() >= HF_HEAL_DISABLE
