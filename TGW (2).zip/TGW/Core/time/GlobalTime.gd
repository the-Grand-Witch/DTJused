extends Node
## 游戏内时间与天数
##
## 时间轴：每天 06:00 开局，走到 24:00 视为跨天，重置回 06:00 且 day + 1。
## 日循环时序（与 manager_event 配合）：
##   06:00 起            → 普通事件三选一
##   21:30               → 夜间封锁：左右事件空掉，只能挑战当天 Boss
##   24:00（跨天）        → 重置回 06:00，day + 1，广播 day_changed

signal time_changed(total_minutes)
signal time_units_added(units)
## 跨天时广播：参数为新的一天（1 起）
signal day_changed(new_day: int)

## 一局的总天数：打完第 TOTAL_DAYS 天的 Boss 就算通关（路由见 `GlobalScenes.scene_after_boss`）
const TOTAL_DAYS := 3

const TIME_UNIT := 5
const DAY_START_MINUTES := 6 * 60    # 每天的起点 06:00
const MINUTES_PER_DAY := 24 * 60     # 一天的分钟数，超过即跨天

var total_minutes: int = DAY_START_MINUTES
var day: int = 1

func add_time_units(units: int) -> void:
	if units <= 0:
		return
	total_minutes += units * TIME_UNIT
	_roll_over()
	time_changed.emit(total_minutes)
	time_units_added.emit(units)

func reset() -> void:
	total_minutes = DAY_START_MINUTES
	day = 1
	time_changed.emit(total_minutes)
	day_changed.emit(day)

## 跨天处理：把时间归一化到 [06:00, 次日 06:00) 区间内，并推进天数。
## 以 06:00 为锚点做整除取模，而不是反复「减去一天」——后者在「一天内跨多次」的极端情况下会算偏。
## 天数推进用循环，是为了让一次大步长（例如 set_time 或调试）也能逐天广播 day_changed。
## 返回 true 表示本次调用推进过天数（调用方可据此避免重复广播）。
func _roll_over() -> bool:
	if total_minutes < MINUTES_PER_DAY:
		return false
	var minutes_since_day_start := total_minutes - DAY_START_MINUTES
	if minutes_since_day_start < 0:
		minutes_since_day_start = 0
	var passed_days := minutes_since_day_start / MINUTES_PER_DAY
	total_minutes = DAY_START_MINUTES + (minutes_since_day_start % MINUTES_PER_DAY)
	for i in range(passed_days):
		day += 1
		day_changed.emit(day)
	return true

## 调试用：把时钟直接拨到某天的某个时刻。
## minutes 以当天的 06:00 为 0 点计（例如 set_time(2, 900) → 第 2 天 21:00）。
func set_time(new_day: int, minutes: int) -> void:
	day = max(1, new_day)
	total_minutes = DAY_START_MINUTES + max(0, minutes)
	var rolled := _roll_over()
	time_changed.emit(total_minutes)
	if not rolled:
		day_changed.emit(day)

func get_time() -> int:
	return total_minutes

func get_formatted_time() -> String:
	var h = total_minutes / 60
	var m = total_minutes % 60
	return "%02d:%02d" % [h, m]

## 第 day_number 天是不是最后一天（静态：不依赖当前时钟，方便单测/路由）
static func is_last_day_of(day_number: int) -> bool:
	return day_number >= TOTAL_DAYS

## 当前这天是不是最后一天
func is_last_day() -> bool:
	return is_last_day_of(day)

func get_day() -> int:
	return day
