extends Node
## 显示当前天数（第 X 天）
@onready var day_label: Label = $TextureRect/Label

func _ready():
	# 初始化显示
	_update_day(GlobalTime.get_day())
	# 跨天信号：天数真的变了才刷新
	GlobalTime.day_changed.connect(_update_day)

func _update_day(day: int):
	day_label.text = "第 %d 天" % day
