extends Node

@onready var time_label: Label = $TimeLabel

func _ready():
	# 连接全局时间信号
	GlobalTime.time_changed.connect(_on_time_changed)
	_on_time_changed(GlobalTime.get_time())
func _on_time_changed(minutes: int):
	time_label.text= GlobalTime.get_formatted_time()
