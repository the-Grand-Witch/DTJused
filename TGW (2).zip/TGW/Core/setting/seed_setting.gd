extends LineEdit
## 设置界面里的「本局种子」显示框（脚本直接挂在输入框节点上）
## ==================================================================
## ⚠️ **只读**：玩家不能填种子 ✗（否则等于"看到商店货架不满意就换种子"）
##    但可以**选中复制** ✓ —— 拿去复盘 / 分享 / 记录。
##
## 显示内容 = GlobalRng.run_seed；换局时由 GlobalRng.seed_changed 自动刷新。
## 种子的唯一来源是开局那一刻的 GlobalRng.reseed()（见 GlobalPlayer.reset()）。
## ==================================================================

func _ready() -> void:
	# 只读三连：不可编辑 / 不弹虚拟键盘 / 不闪光标（选中复制仍然可用）
	editable = false
	virtual_keyboard_enabled = false
	caret_blink = false
	tooltip_text = "本局种子（只读，可选中复制）"
	text = str(GlobalRng.run_seed)
	GlobalRng.seed_changed.connect(_on_seed_changed)
	# 点一下全选，方便直接 Ctrl+C
	focus_entered.connect(select_all)

func _on_seed_changed(seed_value: int) -> void:
	text = str(seed_value)
