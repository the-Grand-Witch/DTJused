extends Control
## 商店场景主脚本：只保留基础交互，商品逻辑已拆分到各子脚本

@onready var close_button: Button = $CloseButton

func _ready():
	close_button.pressed.connect(_on_close_pressed)

## 关掉商店：自己是 OverlayContainer 的子节点，free 自己之后再隐藏容器。
## ⚠️ 必须 consume 掉输入（`set_input_as_handled`），否则 Esc 会在关商店的同时
##    继续传给主场景的 `_unhandled_input`，把设置界面一起打开。
##    其它覆盖层（dict / settings / book / 奖励弹窗）都是这么写的，商店以前漏了。
func _on_close_pressed():
	var overlay = get_parent()
	queue_free()
	if overlay is Control:
		overlay.visible = false
	get_viewport().set_input_as_handled()

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_on_close_pressed()
