extends Control
## 卡牌商品子脚本：负责随机卡牌生成、显示、购买

## 卡面脚本：用 preload 而不是全局类名（新脚本要等编辑器扫过才进类缓存）
const PageFaceScript := preload("res://Core/book/page_face.gd")
## 价目表（和饰品/药水共用一份，改价只改它）
const ShopPricing := preload("res://Core/shop/shop_pricing.gd")
## 1.5 倍悬浮框（纯 Button，直接换脚本即可）
const BigTooltipScript := preload("res://Core/event/event_card_tooltip.gd")
## 商品行文本（名称 + cd + 效果）与价格的字号
## ⚠️ 2026-10：32 → 42 → 54 → 70 之后「太大了」，按 0.8 倍收到 56。
##    卡位已拉长（CardBox 高 1045、间距 12、每格约 252 高），56 号名称 + 说明正好排得开。
const CARD_FONT_SIZE := 56
## 价格字号（放在卡面下方，所以可以放大）
const PRICE_FONT_SIZE := 40
## 卡面底部给价格留出的条带高度
const PRICE_STRIP_HEIGHT := 60.0
## 价格距按钮底边还留多少（「再往下一点」）
const PRICE_BOTTOM_MARGIN := 2.0
## 卡区（本节点就是 CardBox 这个 VBoxContainer）的总高与卡间距。
## ⚠️ 在**代码里**定，而不是只改 .tscn —— 编辑器一保存场景就会把里的改动冲掉，
##    代码设置每次加载都会重新应用，稳。4 张卡 → 每格 (1045 − 3×12) / 4 ≈ 252 高。
const CARD_BOX_HEIGHT := 1045.0
const CARD_SEPARATION := 12

@onready var buttons: Array[Button] = [
	$CradButton1,
	$CradButton2,
	$CradButton3,
	$CradButton4
]

var items: Array[Dictionary] = []
var all_cards: Array[Generator_bookpage] = []

func _ready():
	_apply_card_layout()
	all_cards = GlobalCardLibrary.get_randomable_cards()
	for card in all_cards:
		card.price = _get_price(card.rarity)
	_generate_items()
	for btn in buttons:
		btn.set_script(BigTooltipScript)
		btn.pressed.connect(_on_button_pressed.bind(btn))
	_update_buttons()

## 卡位高度/间距：本节点就是 CardBox（VBoxContainer）。
## `separation` 只有容器吃；这里直接写主题覆盖即可（脚本 extends Control，
## 不能用 `is VBoxContainer` 判断 —— 静态类型不允许）。
func _apply_card_layout() -> void:
	add_theme_constant_override("separation", CARD_SEPARATION)
	offset_bottom = offset_top + CARD_BOX_HEIGHT

## 书页售价 = 稀有度基准区间 + 全局加价（表在 Core/shop/shop_pricing.gd）
func _get_price(rarity: int) -> int:
	return ShopPricing.card_price(rarity)

func _generate_items():
	items.clear()
	for i in range(4):
		var card = _get_random_card()
		if card:
			items.append({
				"type": "card",
				"name": card.page_name,
				"description": card.description,
				"price": card.price,
				"icon": card.icon,
				"card": card
			})

func _get_random_card() -> Generator_bookpage:
	if all_cards.is_empty():
		return null
	return GlobalRng.pick(all_cards)

func _update_buttons():
	for i in range(buttons.size()):
		if i < items.size() and items[i] != null:
			var item = items[i]
			# 商品格子 = 卡面（底板 + 稀有度画框），卡面文字换成「名称 + cd + 效果」一行，编号不显示
			var face := PageFaceScript.attach_to_button(buttons[i], item["card"], CARD_FONT_SIZE)
			# 说明**写在书页自身**（卡面下半行），不再在外面挂横幅；卡面只让出底部价格条
			face.offset_bottom = -PRICE_STRIP_HEIGHT
			face.set_detail(item["card"].description)
			_add_price_label(buttons[i], item["price"])
			buttons[i].visible = true
		else:
			PageFaceScript.clear_button(buttons[i])
			buttons[i].visible = false

## 价格放在**卡面下方**那条带子里（居中、靠着底边），不再压在画面上。
func _add_price_label(btn: Button, price: int) -> void:
	var label := Label.new()
	label.text = "%d 金币" % price
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_font_size_override("font_size", PRICE_FONT_SIZE)
	label.add_theme_color_override("font_color", PageFaceScript.INK)
	btn.add_child(label)
	label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	label.offset_top = -PRICE_STRIP_HEIGHT
	label.offset_bottom = -PRICE_BOTTOM_MARGIN

func _on_button_pressed(btn: Button):
	var idx = buttons.find(btn)
	if idx == -1 or idx >= items.size():
		return
	var item = items[idx]
	if item.is_empty():
		return
	if GlobalPlayer.gold < item["price"]:
		GlobalPlayer.show("金币不足")
		return
	GlobalPlayer.add_gold(-item["price"])
	GlobalCardLibrary.add_acquired_count(item["card"].book_id, 1)
	btn.disabled = true
	btn.modulate.a = 0
	items[idx] = {}
