extends Button
## 药水商品子脚本：负责随机药水生成、显示、购买

const BigTooltip := preload("res://Core/ui/big_tooltip.gd")
## 价目表（药水档位在 Core/shop/shop_pricing.gd 的 POTION_PRICE）
const ShopPricing := preload("res://Core/shop/shop_pricing.gd")

var item: Dictionary = {}

func _ready():
	item = _generate_potion_item()
	_update_button()
	pressed.connect(_on_pressed)

func _generate_potion_item() -> Dictionary:
	var roll = GlobalRng.rand_float()
	var potion_name = ""
	var desc = ""
	var effect = ""
	if roll < 0.4:
		potion_name = "小型治疗药水"
		desc = "回复30%生命值"
		effect = "heal_30"
	elif roll < 0.7:
		potion_name = "大型治疗药水"
		desc = "回复80%生命值"
		effect = "heal_80"
	elif roll < 0.9:
		potion_name = "净化药水"
		desc = "降低33%魔女化"
		effect = "witch_33"
	else:
		potion_name = "完全净化药水"
		desc = "完全清除魔女化"
		effect = "witch_100"
	var price: int = ShopPricing.potion_price(effect)
	return {
		"type": "potion",
		"name": potion_name,
		"description": desc,
		"price": price,
		"effect": effect
	}

## 1.5 倍悬浮框（自己就是 Button，不能 set_script，直接实现这个虚函数）
func _make_custom_tooltip(for_text: String) -> Object:
	return BigTooltip.build(for_text)

func _update_button():
	if item.is_empty():
		visible = false
		return
	# 点击 = 购买，所以效果直接写进按钮文字（触屏没有悬停也能看到）
	text = "%s\n%s\n%d金币" % [item["name"], item["description"], item["price"]]
	tooltip_text = item["description"]
	visible = true

func _on_pressed():
	if item.is_empty():
		return
	if GlobalPlayer.gold < item["price"]:
		GlobalPlayer.show("金币不足")
		return
	GlobalPlayer.add_gold(-item["price"])
	_apply_potion(item)
	item = {}
	visible = false

func _apply_potion(potion_item: Dictionary):
	match potion_item["effect"]:
		"heal_30":
			GlobalPlayer.heal(int(GlobalPlayer.max_health * 0.3))
		"heal_80":
			GlobalPlayer.heal(int(GlobalPlayer.max_health * 0.8))
		"witch_33":
			GlobalPlayer.possessed(-int(GlobalPlayer.max_witch_power * 0.33))
		"witch_100":
			GlobalPlayer.possessed(-GlobalPlayer.max_witch_power)
