extends RefCounted
## 商店价目表：**改价只改这一处**。
## ==================================================================
## 以前书页价在 `shop_card.gd`、饰品价在 `shop_acc.gd`、药水价在 `shop_potion.gd`
## 各写一份，改一档要翻三个文件、还容易漏改（审计 P1-4）。
## 现在统一成三张表 + 取价函数；区间用 `GlobalRng` ⇒ 同一颗种子跑出同一批价格，
## 复盘「这局为什么这么贵」时才有据可查。
## ==================================================================

## 书页：稀有度 → **基准价**区间（0 普通 / 1 稀 / 2 史诗）
const CARD_BASE_RANGE := {0: Vector2i(17, 23), 1: Vector2i(30, 40), 2: Vector2i(43, 57)}
## 书页**全局加价**（所有卡牌统一，原来是 `shop_card.PRICE_BONUS = 30`）
const CARD_BONUS := 30
## 饰品：稀有度 → 价格区间
const ACC_RANGE := {0: Vector2i(147, 153), 1: Vector2i(210, 220), 2: Vector2i(273, 287)}
## 药水：效果 id → 售价（数值沿用 2026-10 的档位：治疗 90/140、净化 50）
const POTION_PRICE := {"heal_30": 90, "heal_80": 140, "witch_33": 50, "witch_100": 50}
## 兜底价：稀有度/效果没登记时用它（不是「平衡数值」，是防御性上界）
const CARD_FALLBACK := 20
const ACC_FALLBACK := 150
const POTION_FALLBACK := 50

## 书页基准价（不含全局加价）
static func card_base_price(rarity: int) -> int:
	return _range_price(CARD_BASE_RANGE, rarity, CARD_FALLBACK)

## 书页实际售价 = 基准价 + 全局加价
static func card_price(rarity: int) -> int:
	return card_base_price(rarity) + CARD_BONUS

## 饰品售价
static func acc_price(rarity: int) -> int:
	return _range_price(ACC_RANGE, rarity, ACC_FALLBACK)

## 药水售价（按效果 id；没登记的按 50）
static func potion_price(effect: String) -> int:
	return int(POTION_PRICE.get(effect, POTION_FALLBACK))

static func _range_price(table: Dictionary, rarity: int, fallback: int) -> int:
	var r: Vector2i = table.get(clampi(rarity, 0, 2), Vector2i(fallback, fallback))
	return GlobalRng.range(r.x, r.y)
