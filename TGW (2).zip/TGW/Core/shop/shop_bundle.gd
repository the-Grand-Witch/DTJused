extends Button
## 捆绑书签商品子脚本：负责捆绑内容生成、显示、购买

const BigTooltip := preload("res://Core/ui/big_tooltip.gd")

## 卡面脚本：用 preload 而不是全局类名（新脚本要等编辑器扫过才进类缓存）
const PageFaceScript := preload("res://Core/book/page_face.gd")
## 预览里每张卡面的字号（卡面上是「名称（能力页 + 强化）+ 基础效果 + cd」一行）
## ⚠️ 2026-10：捆 3 页后每页有 ~118 高，字号从 14 / 11 放大到这里（仍会按高度自动缩）
const PREVIEW_FONT_SIZE := 26
## 预览里说明那一行的字号
const BUNDLE_DETAIL_FONT_SIZE := 16

@onready var bundle_names_box: VBoxContainer = $BundleNamesBox
@onready var bundle_price_label: Label = $BundlePriceLabel

var item: Dictionary = {}
var all_cards: Array[Generator_bookpage] = []

## 1.5 倍悬浮框（自己就是 Button，不能 set_script，直接实现这个虚函数）
func _make_custom_tooltip(for_text: String) -> Object:
	return BigTooltip.build(for_text)

func _ready():
	all_cards = GlobalCardLibrary.get_randomable_cards()
	# 内框一变（窗口大小/布局变了）就重新等分各页高度
	bundle_names_box.resized.connect(_fit_preview_heights)
	_generate_item()
	_update_button()
	pressed.connect(_on_pressed)

## 捆绑内容：**1 张史诗 + 2 张随机 = 共 3 页**
## （2026-10 改：原来 1 史诗 + 4 随机 = 5 页，页数太多、预览也挤）
const BUNDLE_SIZE := 3
## 史诗页之外再随机几张
const BUNDLE_RANDOM_COUNT := BUNDLE_SIZE - 1

func _generate_item():
	var epic_cards = all_cards.filter(func(c): return c.rarity == 2)
	if epic_cards.is_empty():
		return
	var epic_card: Generator_bookpage = GlobalRng.pick(epic_cards)

	var non_epic_cards = all_cards.filter(func(c): return c.rarity != 2)
	if non_epic_cards.is_empty():
		return

	var pages: Array[Generator_bookpage] = [epic_card]
	for i in range(BUNDLE_RANDOM_COUNT):
		if GlobalRng.chance(0.25):
			var rare_cards = non_epic_cards.filter(func(c): return c.rarity == 1)
			if rare_cards.size() > 0:
				pages.append(GlobalRng.pick(rare_cards))
			else:
				pages.append(GlobalRng.pick(non_epic_cards))
		else:
			var normal_cards = non_epic_cards.filter(func(c): return c.rarity == 0)
			if normal_cards.size() > 0:
				pages.append(GlobalRng.pick(normal_cards))
			else:
				pages.append(GlobalRng.pick(non_epic_cards))

	item = {
		"type": "bundle_bookmark",
		"name": "捆绑书签",
		"description": "包含1张史诗卡牌和2张随机卡牌（共3页）",
		"price": 120,
		"pages": pages,
		"card": epic_card
	}

func _update_button():
	if item.is_empty():
		visible = false
		return
	tooltip_text = item["description"]
	visible = true
	if bundle_price_label:
		# 只显示数值，不带「金币」两个字（前缀有图标）
		bundle_price_label.text = "%d" % item["price"]
		bundle_price_label.visible = true
	_update_preview()

## 预览 = 每页一张**卡面**（底板 + 稀有度画框照旧留着），
## 卡面上写「名称 + cd + 效果」一行，编号不显示。
## 排版：**从最上面往下排**（`ALIGNMENT_BEGIN`），每页拿到**同一个高度**
## =（内框高 − 间距）÷ 页数；内容再长的那页也不会比别人高（见 `_fit_preview_heights`）。
func _update_preview():
	for child in bundle_names_box.get_children():
		child.queue_free()
	# 场景里原来是居中：页少或内框变矮时，整摞会浮在中间、看着没对齐
	bundle_names_box.alignment = BoxContainer.ALIGNMENT_BEGIN
	for page in item.get("pages", []):
		var face := PageFaceScript.new()
		face.name_font_size = PREVIEW_FONT_SIZE
		face.setup(page)
		face.size_flags_vertical = Control.SIZE_EXPAND_FILL
		# 说明写进书页自身（点击=购买，触屏没有悬停）
		face.set_detail(page.description, BUNDLE_DETAIL_FONT_SIZE)
		bundle_names_box.add_child(face)
	# 内框高度要等布局跑完才有，所以延后一帧统一各页高度
	_fit_preview_heights.call_deferred()

## 各页等高：高度取「等分值」和「最高那页的最小高度」里的大者，写进 `custom_minimum_size`。
## ⚠️ 只靠 `SIZE_EXPAND_FILL` 不够：容器给每个 expand 子节点的是**等分份额**，
##    某一页内容的最小高度比份额还大时它就单独长高 —— 也就是「高度不统一」。
func _fit_preview_heights() -> void:
	var count: int = bundle_names_box.get_child_count()
	if count == 0:
		return
	var sep: int = bundle_names_box.get_theme_constant("separation")
	var even: float = (bundle_names_box.size.y - sep * (count - 1)) / float(count)
	var tallest: float = 0.0
	for child in bundle_names_box.get_children():
		tallest = maxf(tallest, child.get_combined_minimum_size().y)
	var target: float = floorf(maxf(even, tallest))
	for child in bundle_names_box.get_children():
		child.custom_minimum_size.y = target

func _on_pressed():
	if item.is_empty():
		return
	if GlobalPlayer.gold < item["price"]:
		GlobalPlayer.show("金币不足")
		return
	GlobalPlayer.add_gold(-item["price"])
	var bookmark = Generator_bookmark.new()
	bookmark.title = "捆绑书签"
	for page in item["pages"]:
		# 买下来 = **真的获得这一页**：获得量 +1（同时进 owned_cards 与图鉴）；
		# 这一份当场就写进书签里，所以立刻把可用量扣掉 —— 净结果是获得量 +1、可用量 0。
		# ⚠️ 不登记的话，删除这个书签时 `return_card()` 加出来的可用量不属于任何「已拥有」页，
		#    玩家在书库里根本看不到那几张卡（就是「删除书签后没返回购买的卡牌」）。
		GlobalCardLibrary.add_acquired_count(page.book_id, 1)
		GlobalCardLibrary.use_card(page.book_id)
		bookmark.pages.append(page)
	GlobalBookMark.add_bookmark(bookmark)
	item = {}
	visible = false
