extends Control
## 饰品商品子脚本：负责随机饰品生成、显示、购买

## 1.5 倍悬浮框（纯 Button，直接换脚本即可）
const BigTooltipScript := preload("res://Core/event/event_card_tooltip.gd")
## 饰品文字口径（名称 + 效果）与商店/奖励/Boss 共用
const AccessoryTextScript := preload("res://Core/accessories/accessory_text.gd")
## 价目表（和书页/药水共用一份，改价只改它）
const ShopPricing := preload("res://Core/shop/shop_pricing.gd")
## 商店货架的抽取权重：段 → 权重（段的划分见 `GlobalAccessories.TIER_*`）
const POOL_WEIGHT := {"low": 25, "mid": 15, "high": 10, "shop": 50}


@onready var buttons: Array[Button] = [
	$AccessoryButton1,
	$AccessoryButton2
]

var items: Array[Dictionary] = []
var selected_ids: Array[int] = []
var all_accessories: Array[Generator_accessories] = []

func _ready():
	all_accessories = GlobalAccessories.all_accessories.duplicate()
	for acc in all_accessories:
		acc.price = _get_price(acc.rarity)
	_generate_items()
	for btn in buttons:
		btn.set_script(BigTooltipScript)
		btn.pressed.connect(_on_button_pressed.bind(btn))
	_update_buttons()

func _get_price(rarity: int) -> int:
	return ShopPricing.acc_price(rarity)

func _generate_items():
	items.clear()
	selected_ids.clear()
	for i in range(2):
		var acc = _get_random_accessory()
		if acc:
			items.append({
				"type": "accessory",
				"name": acc.name,
				"description": acc.Tooltip if acc.Tooltip else "",
				"price": acc.price,
				"icon": acc.icon,
				"accessory": acc
			})

func _get_random_accessory() -> Generator_accessories:
	var owned_ids = []
	for a in GlobalAccessories.accessories:
		owned_ids.append(a.acc_id)

	var pool: Array[Dictionary] = []
	for acc in all_accessories:
		if acc.acc_id in owned_ids:
			continue
		if acc.acc_id in selected_ids:
			continue
		# 666-700 / ≥1000 是特殊用品，不进随机货架
		if (acc.acc_id >= 666 and acc.acc_id <= 700) or acc.acc_id >= 1000:
			continue
		# 段 → 权重（段的边界在 GlobalAccessories.TIER_*，这里只管权重）
		var pool_tier := GlobalAccessories.tier_of(acc.acc_id)
		if pool_tier != "":
			pool.append({"acc": acc, "weight": int(POOL_WEIGHT[pool_tier])})

	if pool.is_empty():
		return null

	var total_weight = 0
	for entry in pool:
		total_weight += entry.weight
	var roll = GlobalRng.range(0, total_weight - 1)
	var cumulative = 0
	for entry in pool:
		cumulative += entry.weight
		if roll < cumulative:
			var chosen = entry.acc
			selected_ids.append(chosen.acc_id)
			return chosen
	return null

func _update_buttons():
	for i in range(buttons.size()):
		if i < items.size() and not items[i].is_empty():
			var item = items[i]
			# 点击 = 购买，所以**效果直接写在按钮文字里**（触屏没有悬停也能看清）
			buttons[i].text = "%s\n%d金币" % [
				AccessoryTextScript.button_line(item.get("accessory", null)), item["price"]]
			# 图标统一缩到 GlobalAccessories.ICON_DISPLAY_SIZE，否则 512×512 原图会把按钮顶大
			buttons[i].icon = GlobalAccessories.display_icon(item.get("icon", null))
			buttons[i].tooltip_text = AccessoryTextScript.tooltip_text(item.get("accessory", null))
			buttons[i].visible = true
		else:
			buttons[i].visible = false

func _on_button_pressed(btn: Button):
	var idx = buttons.find(btn)
	if idx == -1 or idx >= items.size():
		return
	var item = items[idx]
	if item.is_empty():
		return
	if GlobalPlayer.gold < item["price"]:
		GlobalPlayer.show("金币不足")
		return
	GlobalPlayer.add_gold(-item["price"])
	GlobalAccessories.add_accessories(item["accessory"])
	btn.visible = false
	items[idx] = {}
