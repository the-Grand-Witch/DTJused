extends Control
## 胜利场景：显示击败Boss的信息，清空所有数据，可返回开始界面


func _ready():
	GlobalPlayer.reset()

	# 场景管理器记录
	GlobalScenes.last_scene_path = "res://scenes/main.tscn"


func _input(event: InputEvent):
	# 监控键盘按键（按下，非持续触发）
	if event is InputEventKey and event.pressed and not event.echo:
		_return_to_main()
	# 监控鼠标按键
	elif event is InputEventMouseButton and event.pressed:
		_return_to_main()


func _return_to_main():
	GlobalScenes.go_to_start()
