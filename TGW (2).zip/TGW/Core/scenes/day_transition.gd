extends Control
## 跨天转场：打赢 Boss 后先进这个场景，回顾今天走过的路程，再进第二天。
## ⚠️ 只在「还没到最后一天」时进来；最后一天直接进 end.tscn（见 `GlobalScenes.scene_after_boss`）。
##
## 内容 = 标题 + 今日路程列表（数据来自 GlobalJourney）。
## GlobalJourney 是**按天分组全部保留**的，这里只展示刚结束的那一天；
## 进场景时 GlobalTime 还停在旧的一天，所以 ended_day 要在这里先抓住，
## 点击才把时钟拨到第二天 06:00。
##
## 事件卡 / 夜间封锁 / 天数显示都挂在主场景的节点上，主场景重建时会按 GlobalTime
## 重新初始化，所以这里只管拨时间，不用手动刷新。

const ENTRY_FONT_SIZE := 44
const EMPTY_COLOR := Color(0.5, 0.5, 0.5)
## 进场后这一小段时间内不响应点击：Boss 战最后一刀的连点不该直接把转场点掉，
## 也保证列表至少被看到一眼。
const CLICK_GUARD := 0.4

@onready var title_label: Label = $Title
@onready var entries_box: VBoxContainer = $Scroll/Entries

## 刚结束的那一天（进场景时 GlobalTime 还停在这一天）
var ended_day: int = 1
var _can_click := false

func _ready() -> void:
	ended_day = GlobalTime.get_day()
	title_label.text = "第 %d 天 · 路程" % ended_day
	_fill_entries()
	await get_tree().create_timer(CLICK_GUARD).timeout
	_can_click = true

func _fill_entries() -> void:
	for child in entries_box.get_children():
		child.queue_free()
	var entries := GlobalJourney.get_day_entries(ended_day)
	if entries.is_empty():
		_add_line("今天什么都没做", EMPTY_COLOR)
		return
	for entry in entries:
		_add_line(GlobalJourney.format_entry(entry))

func _add_line(text: String, color: Color = Color(1, 1, 1)) -> void:
	var line := Label.new()
	line.text = text
	line.add_theme_font_size_override("font_size", ENTRY_FONT_SIZE)
	line.add_theme_color_override("font_color", color)
	entries_box.add_child(line)

## 用 _input 而不是 _unhandled_input：ScrollContainer 会把落在它身上的点击吃掉，
## 而「点击前往下一天」必须整屏都能点。滚轮只用来滚列表，不受这里影响。
func _input(event: InputEvent) -> void:
	if not _can_click:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_go_next_day()
	elif event is InputEventKey and event.pressed and not event.echo:
		_go_next_day()

func _go_next_day() -> void:
	_can_click = false
	GlobalTime.set_time(ended_day + 1, 0)
	GlobalScenes.go_to_main()
