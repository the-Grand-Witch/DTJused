extends Node
## 全局场景管理：统一场景跳转，自动记录上一场景
signal reward_requested(gold: int, accessories: Array, cards: Array)
## 打赢当天 Boss 之后的两条去向（`scene_after_boss` 决定走哪条）
const DAY_TRANSITION_PATH := "res://scenes/day_transition.tscn"
const END_SCENE_PATH := "res://scenes/end.tscn"

const REWARD_SCENE := preload("res://scenes/RewardPopup.tscn")
var last_scene_path: String = "res://scenes/main.tscn"
var event_manager: Node = null
const BOOKMARK_CARD_SCENE := preload("res://scenes/bookmark.tscn")
const BOOK_SCENE := preload("res://scenes/book.tscn")
var _is_changing: bool = false

func _ready():
	GlobalPlayer.health_changed.connect(_on_player_health_changed)
	reward_requested.connect(_on_reward_requested)
# ==================== 通用切换 ====================
## 切换场景并自动记录当前场景为上一场景
func change_scene(target_path: String, record: bool = true) -> void:
	if _is_changing:
		return
	_is_changing = true
	if record:
		var current = get_tree().current_scene
		if current:
			last_scene_path = current.scene_file_path
	get_tree().change_scene_to_file(target_path)
	await get_tree().process_frame
	_is_changing = false

## 返回上一场景
func return_to_previous() -> void:
	get_tree().change_scene_to_file(last_scene_path)

# ==================== 具体场景 ====================
# 开始界面
func go_to_start() -> void:
	change_scene("res://scenes/start.tscn")
# 开始界面
func go_to_choose() -> void:
	change_scene("res://scenes/choose.tscn")
# 主场景
func go_to_main() -> void:
	change_scene("res://scenes/main.tscn")

# 普通战斗 / Boss 战都由事件资源直接 change_scene（battle.tscn / boss.tscn），这里不再包一层。

## 打赢当天 Boss 之后去哪：最后一天 = 通关场景，其它天 = 跨天转场。
## 抽成纯函数是为了能单测（`Tools/dev_smoke.gd` 直接断言三条路径）。
static func scene_after_boss(day_number: int) -> String:
	return END_SCENE_PATH if GlobalTime.is_last_day_of(day_number) else DAY_TRANSITION_PATH

# 跨天：Boss 战打赢 = 这一天结束。打的是最后一天（`GlobalTime.TOTAL_DAYS`）⇒ 直接进通关场景；否则进转场。
func go_to_next_day() -> void:
	change_scene(scene_after_boss(GlobalTime.get_day()), false)

## 通关：打完最后一天的 Boss（`go_to_next_day` 按 `scene_after_boss` 路由到这里）。
## end.tscn 会 GlobalPlayer.reset()（清空本局数据），点任意键回开始界面
func check_victory() -> void:
	change_scene(END_SCENE_PATH, false)

# 游戏结束
func check_game_over() -> void:
	change_scene("res://scenes/game_over.tscn",false)

## 通用加载：将场景作为子节点加载到当前场景
func open_node(scene_path: String) -> Node:
	var scene = load(scene_path)
	var instance = scene.instantiate()
	get_tree().current_scene.add_child(instance)
	return instance

# ==================== 设置 Overlay ====================
## 打开设置
func open_settings() -> void:
	open_node("res://scenes/settings.tscn")

## 打开百科
func open_dict() -> void:
	open_node("res://scenes/dict.tscn")
# ==================== 事件刷新 ====================
func refresh_events() -> void:
	if event_manager:
		event_manager.refresh_all_cards()

# ==================== 玩家状态检测 ====================
func _on_player_health_changed(new_health: int) -> void:
	if new_health > 0:
		return
	# 只有「局内」血量归零才算死亡。
	# GlobalPlayer.reset() 会把血量清成 0 并广播一次（空状态，只为刷新 UI），
	# 那不是阵亡 —— 否则「选完角色」、「进胜利界面」都会被立刻踢去 game over。
	if not GlobalPlayer.in_run:
		return
	check_game_over()
# ==================== 掉落 ====================
## 统一的奖励入口。
## 参数顺序与 RewardPopup（reward_manager.gd）的 setup() 严格对应：
##   (gold, accessories, cards, on_closed)
## 注意：这里不再传 monster，掉落内容由调用方提前算好后传进来，
## 避免「同一个 Callable 位被两种签名占用」导致参数错位。
func show_reward(gold: int, accessories: Array, cards: Array, on_closed: Callable = Callable()) -> void:
	var canvas_layer = CanvasLayer.new()
	canvas_layer.layer = 10
	get_tree().current_scene.add_child(canvas_layer)
	_spawn_reward_scene(canvas_layer, gold, accessories, cards, on_closed)

func _spawn_reward_scene(canvas_layer: CanvasLayer, gold: int, accessories: Array, cards: Array, on_closed: Callable) -> void:
	var scene = REWARD_SCENE.instantiate()
	canvas_layer.add_child(scene)
	# 该 Callable 只在奖励弹窗关闭时被调用一次，签名固定为 func(triggered: bool)
	scene.setup(gold, accessories, cards, func(triggered: bool):
		scene.queue_free()
		if triggered:
			# 契约触发的「目标饰品」作为追加奖励再弹一次
			var target = GlobalContract.get_target_accessory()
			var accs: Array[Generator_accessories] = []
			if target:
				accs.append(target)
			_spawn_reward_scene(canvas_layer, 0, accs, [], on_closed)
		else:
			canvas_layer.queue_free()
			if on_closed.is_valid():
				on_closed.call()
	)

func _on_reward_requested(gold: int, accessories: Array, cards: Array) -> void:
	show_reward(gold, accessories, cards)

# ==================== 选择题 ====================
## 选择题的展示/挑选入口：复用 RewardPopup 那套牌面与遗物条目。
## max_picks > 0 表示最多点选这么多个（选满自动关闭）；title 由事件资源给。
## 注意：这里**不走**掉落屏蔽管道 —— 选择不是掉落，契约之类不该拦它。
func show_choice(cards: Array, accessories: Array, max_picks: int, title: String, on_closed: Callable = Callable()) -> void:
	var canvas_layer = CanvasLayer.new()
	canvas_layer.layer = 10
	get_tree().current_scene.add_child(canvas_layer)
	var scene = REWARD_SCENE.instantiate()
	canvas_layer.add_child(scene)
	scene.setup_choice(cards, accessories, max_picks, title, func():
		canvas_layer.queue_free()
		if on_closed.is_valid():
			on_closed.call()
	)
