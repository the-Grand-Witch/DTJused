extends Control
## 选人界面（按 `Assets/Textures/UI/选人界面/选人界面示意.png` 的版式）
## ==================================================================
## 左侧自上而下：姓名（中/英）→ 介绍 → 起始饰品 → 先天技能 → 起始卡组（最多 5 张卡）
## 右侧：立绘；最右一列：菱形角色选择器；右上「返回」、右下「开始游戏」
##
## 全界面只有**一张**文本框底皮（`Assets/Textures/UI/选人界面/文本框.png`，556×286），
## 一切框都是它九宫格反复拉伸出来的（框多大都不糊、圆角与边框粗细不变）：
##   · 行框 / 按钮框 —— 在 choose.tscn 里以 StyleBoxTexture 写死（编辑器里看得见）
##   · 卡面里的小行   —— 本文件里现搭（卡是运行时按角色数据生成的），同一张图、边距小一号
##
## 数据都来自 `Data/WitchGirl/*.tres`：
##   character_name / flavor（顶部「介绍」，空则整行隐藏）/ description（先天技能，格式「技能名：说明」）
##   / full_body（立绘）/ portrait（菱形头像）/ unique_accessories / starting_bookmarks
## 英文名还没有数据字段，TitleEn 目前恒为空（自动隐藏）。
## ==================================================================

const GIRL_DIR := "res://Data/WitchGirl/"
const MAX_CARDS := 5                      ## 起始卡组最多铺几张卡
## 选人界面「书签预览卡」的字号（标题 / 每页那一行）
const CARD_TITLE_FONT_SIZE := 26
const CARD_ROW_FONT_SIZE := 18

const MAX_ROWS := 5                       ## 每张卡最多列几行效果
const CARD_SIZE := Vector2(233, 395)
## 菱形选择器的**尺寸与对齐全部在场景里**：`Selector/SlotTemplate` 是一个手调的实体标本
## （Hit / Avatar / Frame / Empty 四层），代码只 duplicate 它、按 slot_step 往下排。
## 想调大小、头像在框里的位置、框的比例 —— 在编辑器里动那个模板节点就行，不用改代码。
@export var slot_count := 6               ## 槽位总数；角色不够的位置用黑块占位（角色少时不然一列太散）
@export var slot_step := 176.0            ## 槽位纵向间距

const EFFECT_FRAME := preload("res://Assets/Textures/UI/选人界面/文本框.png")
const PAGE_ART := preload("res://Assets/Textures/UI/选人界面/书页.png")
## 先天技能文本「技能名：技能说明」的分隔符（先用中文全角冒号，找不到再退回半角）
const SKILL_SEPARATOR := "："

## 配色（跟示意图对齐）
## 名字 / 英文名 / 描述**统一**用这一支粉
const COLOR_PINK := Color(0.94, 0.78, 0.78)
const COLOR_ROW_TITLE := Color(0.96, 0.93, 0.92)
const COLOR_ROW_DESC := Color(0.91, 0.78, 0.80)
const COLOR_CARD_TITLE := Color(0.42, 0.16, 0.16)
const COLOR_CARD_TEXT := Color(0.96, 0.90, 0.84)
## 未解锁槽位（黑块）被选中/未选中时的框亮度：空槽没有框，只有黑块，用不到
const COLOR_FRAME_ON := Color(1, 1, 1)
const COLOR_FRAME_OFF := Color(0.45, 0.42, 0.42)
## 未解锁角色（`hidden = true`）的头像灰显色
const LOCKED_AVATAR_MODULATE := Color(0.35, 0.35, 0.38, 1.0)

@onready var title_label: Label = $Title
@onready var title_en_label: Label = $TitleEn
@onready var desc_label: Label = $Desc
@onready var acc_icon: TextureRect = $AccBox/HBox/Icon
@onready var acc_name: Label = $AccBox/HBox/VBox/AccName
@onready var acc_desc: Label = $AccBox/HBox/VBox/AccDesc
@onready var skill_icon: TextureRect = $SkillBox/HBox/Icon
@onready var skill_name: Label = $SkillBox/HBox/VBox/SkillName
@onready var skill_desc: Label = $SkillBox/HBox/VBox/SkillDesc
@onready var deck: HBoxContainer = $Deck
@onready var portrait: TextureRect = $Portrait
@onready var selector: Control = $Selector
## 手调标本：编辑器里摆好这一个，运行时按它复制出每个槽
@onready var slot_template: Control = $Selector/SlotTemplate
@onready var back_button: Button = $BackButton
@onready var start_button: Button = $StartButton

var girls: Array[Generator_girl] = []
## 每个槽（含空槽）的点击按钮与头像框；slot_girls[i] == null 表示这个槽是黑块占位
var diamonds: Array[Button] = []
var frames: Array[TextureRect] = []
var slot_girls: Array[Generator_girl] = []

func _ready() -> void:
	_apply_label_colors()
	back_button.pressed.connect(_on_back_pressed)
	start_button.pressed.connect(_on_start_pressed)

	girls = _load_girls()
	_build_selector()
	var first_unlocked: Generator_girl = null
	for girl in girls:
		if not girl.hidden:
			first_unlocked = girl
			break
	if first_unlocked == null:
		_clear_info()
		return
	_select(first_unlocked)

## 扫 Data/WitchGirl/ 拿角色，**按 `character_id` 编号升序**排（1 艾玛 / 2 雪莉 / 3 汉娜 / 4 梅露露…），
## 不是按文件名 —— 文件名只是资源命名习惯，编号才是给玩家看的顺序。
## `hidden = true`（未解锁、还没做完）的角色**仍然占一个槽**，只显示灰掉的头像、不可选中。
func _load_girls() -> Array[Generator_girl]:
	var result: Array[Generator_girl] = []
	for file in ResourceLoader.list_directory(GIRL_DIR):
		if not file.ends_with(".tres"):
			continue
		var loaded = load(GIRL_DIR + file)
		if loaded is Generator_girl:
			result.append(loaded)
	result.sort_custom(func(a, b): return int(a.character_id) < int(b.character_id))
	return result

func _apply_label_colors() -> void:
	# 名字 / 英文名 / 描述：同一个粉色
	title_label.add_theme_color_override("font_color", COLOR_PINK)
	title_en_label.add_theme_color_override("font_color", COLOR_PINK)
	desc_label.add_theme_color_override("font_color", COLOR_PINK)
	acc_name.add_theme_color_override("font_color", COLOR_ROW_TITLE)
	acc_desc.add_theme_color_override("font_color", COLOR_ROW_DESC)
	skill_name.add_theme_color_override("font_color", COLOR_ROW_TITLE)
	skill_desc.add_theme_color_override("font_color", COLOR_ROW_DESC)

# ==================== 菱形选择器 ====================
## 每个槽 = 把场景里那个手调标本 `Selector/SlotTemplate` **复制一份**，只改纵向位置。
## 标本内部四层（顺序即层级）：
##   Hit（Button，吃点击）/ Avatar（头像）/ Frame（红菱形头像框）/ Empty（黑块，默认隐藏）
## 所以「框和头像怎么对」全交给编辑器：动标本，所有槽一起跟着变。
func _build_selector() -> void:
	for child in selector.get_children():
		if child != slot_template:
			child.queue_free()
	diamonds.clear()
	frames.clear()
	slot_girls.clear()
	slot_template.visible = false          # 标本只在编辑器里摆，运行时不留一份

	var total: int = maxi(slot_count, girls.size())
	for i in range(total):
		var slot: Control = slot_template.duplicate()
		slot.visible = true
		slot.position = slot_template.position + Vector2(0.0, slot_step * float(i))
		selector.add_child(slot)

		var hit: Button = slot.get_node("Hit")
		var avatar: TextureRect = slot.get_node("Avatar")
		var frame: TextureRect = slot.get_node("Frame")
		var empty: Control = slot.get_node("Empty")

		var girl: Generator_girl = girls[i] if i < girls.size() else null
		slot_girls.append(girl)
		diamonds.append(hit)
		frames.append(frame)

		if girl == null:
			# 空槽：黑块盖住、不可点（角色少时把这一列填满，不然分得太散）
			avatar.visible = false
			frame.visible = false
			empty.visible = true
			hit.disabled = true
		elif girl.hidden:
			# 未完成角色（hidden = true）：头像照露，但**灰掉 + 不可选**
			avatar.texture = girl.portrait
			avatar.modulate = LOCKED_AVATAR_MODULATE
			empty.visible = false
			frame.visible = true
			frame.modulate = COLOR_FRAME_OFF
			hit.disabled = true
			hit.tooltip_text = "%s（未解锁）" % girl.character_name
		else:
			avatar.texture = girl.portrait
			empty.visible = false
			hit.pressed.connect(_select.bind(girl))

func _refresh_selector(selected: Generator_girl) -> void:
	for i in range(diamonds.size()):
		if i >= slot_girls.size() or slot_girls[i] == null or i >= frames.size():
			continue
		# 未解锁的槽保持灰显，不参与高亮
		if slot_girls[i].hidden:
			continue
		var on: bool = slot_girls[i] == selected
		frames[i].modulate = COLOR_FRAME_ON if on else COLOR_FRAME_OFF

# ==================== 选中角色 ====================
func _select(girl: Generator_girl) -> void:
	if girl == null:
		return
	GlobalPlayer.reset()
	GlobalPlayer.set_character(girl)
	# 新的一局：清空路程记录（必须放在 set_character 之后，见 GlobalJourney.begin_run 的注释）
	GlobalJourney.begin_run()
	_refresh_selector(girl)
	_fill_info(girl)

func _fill_info(girl: Generator_girl) -> void:
	title_label.text = girl.character_name
	portrait.texture = girl.full_body

	# 英文名：数据里还没有这个字段，留给以后（空字符串时整行隐藏，不占位）
	title_en_label.text = ""
	title_en_label.visible = title_en_label.text != ""

	# 顶部「介绍」= girl.flavor（角色介绍文案）。
	# ⚠️ 不要拿 girl.description 填这里 —— 那个字段存的是**先天技能**（见下），填上来就是「技能和描述接反」。
	desc_label.text = girl.flavor
	desc_label.visible = girl.flavor != ""

	var acc: Generator_accessories = girl.unique_accessories
	if acc != null:
		acc_icon.texture = acc.icon
		acc_icon.visible = true
		acc_name.text = acc.name
		acc_desc.text = acc.Tooltip
	else:
		acc_icon.texture = null
		acc_icon.visible = false
		acc_name.text = "无独特饰品"
		acc_desc.text = ""

	# 先天技能：就是 girl.description，数据里写成「技能名：技能说明」的形式，按第一个冒号拆开。
	var skill_title: String = girl.description
	var skill_text: String = ""
	var sep: int = girl.description.find(SKILL_SEPARATOR)
	if sep < 0:
		sep = girl.description.find(":")
	if sep >= 0:
		skill_title = girl.description.substr(0, sep).strip_edges()
		skill_text = girl.description.substr(sep + 1).strip_edges()
	skill_name.text = skill_title
	skill_desc.text = skill_text
	# 技能图标还没有美术资源
	skill_icon.texture = null
	skill_icon.visible = false

	_fill_deck(girl)

func _clear_info() -> void:
	title_label.text = ""
	title_en_label.text = ""
	title_en_label.visible = false
	desc_label.text = ""
	desc_label.visible = false
	portrait.texture = null
	acc_icon.texture = null
	acc_icon.visible = false
	acc_name.text = ""
	acc_desc.text = ""
	skill_icon.texture = null
	skill_icon.visible = false
	skill_name.text = ""
	skill_desc.text = ""
	for child in deck.get_children():
		deck.remove_child(child)
		child.queue_free()

# ==================== 起始卡组 ====================
func _fill_deck(girl: Generator_girl) -> void:
	for child in deck.get_children():
		deck.remove_child(child)
		child.queue_free()
	for i in range(mini(girl.starting_bookmarks.size(), MAX_CARDS)):
		deck.add_child(_make_card(girl.starting_bookmarks[i]))

## 一张卡 = 书页底图 + 书名 + 每页一行「书页效果 文本框」（同一张图拉伸）
## 卡宽用 EXPAND_FILL 铺满那一行（3 本就三张宽的，5 本就五张窄的），
## 底图用 TextureRect 等比裁切铺满，避免 667×1000 的书页被拉扁。
func _make_card(bookmark: Generator_bookmark) -> Control:
	var card := PanelContainer.new()
	card.custom_minimum_size = CARD_SIZE
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	var bg := TextureRect.new()
	bg.texture = PAGE_ART
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	card.add_child(bg)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	card.add_child(box)

	var name_label := Label.new()
	name_label.text = bookmark.title
	name_label.add_theme_font_size_override("font_size", CARD_TITLE_FONT_SIZE)
	name_label.add_theme_color_override("font_color", COLOR_CARD_TITLE)
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(name_label)

	for i in range(mini(bookmark.pages.size(), MAX_ROWS)):
		var page = bookmark.pages[i]
		var row := PanelContainer.new()
		# 同一个文本框，边距取小一号（卡里的小行只有 ~44 px 高，用大框的边距会把中间挤没）
		var row_style := StyleBoxTexture.new()
		row_style.texture = EFFECT_FRAME
		row_style.texture_margin_left = 16.0
		row_style.texture_margin_top = 10.0
		row_style.texture_margin_right = 16.0
		row_style.texture_margin_bottom = 16.0
		row_style.content_margin_left = 12.0
		row_style.content_margin_right = 12.0
		row_style.content_margin_top = 4.0
		row_style.content_margin_bottom = 6.0
		row.add_theme_stylebox_override("panel", row_style)

		var text := Label.new()
		# 每行写成「名称  效果」：光有效果看不出是哪个页
		text.text = page.page_name if page.description == "" else "%s  %s" % [page.page_name, page.description]
		text.add_theme_font_size_override("font_size", CARD_ROW_FONT_SIZE)
		text.add_theme_color_override("font_color", COLOR_CARD_TEXT)
		text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		row.add_child(text)
		box.add_child(row)
	return card

# ==================== 按钮 ====================
func _on_start_pressed() -> void:
	# 没选角色就直接开局会让 current_character 一路为 null
	if GlobalPlayer.current_character == null:
		return
	GlobalScenes.go_to_main()

func _on_back_pressed() -> void:
	GlobalScenes.go_to_start()
