extends Button
class_name CharacterButton
## 选人界面的「卷轴」槽位：竖向列表里的一行，一行一个角色。
## 槽位由 choose.gd 按 Data/WitchGirl/ 里的资源生成，不足 12 个的用 setup_empty() 灰显「未解锁」。

## 这个槽位对应的角色；空槽为 null
@export var character: Generator_girl
## 卷轴底图（占位为空，素材到了在 character_slot.tscn 的 Scroll 节点上填图即可）
@export var scroll_texture: Texture2D

@onready var icon_rect: TextureRect = $Icon
@onready var scroll_rect: TextureRect = $Scroll
## 名字用独立 Label 显示（Button 自带的 text 会从最左边开始画，和头像重叠）
@onready var name_label: Label = $Name

## 填一个可用角色
func setup(girl: Generator_girl) -> void:
	character = girl
	name_label.text = girl.character_name
	icon_rect.texture = girl.portrait
	disabled = false
	set_chosen(false)

## 空槽：灰显「未解锁」，不可点
func setup_empty() -> void:
	character = null
	name_label.text = "未解锁"
	icon_rect.texture = null
	disabled = true
	modulate = Color(0.4, 0.4, 0.4, 1.0)

## 选中高亮（空槽保持灰显）
func set_chosen(chosen: bool) -> void:
	if character == null:
		modulate = Color(0.4, 0.4, 0.4, 1.0)
		return
	modulate = Color(1, 1, 1, 1) if chosen else Color(0.68, 0.68, 0.68, 1.0)
