extends Generator_PassiveEffect
## 魔法教典·樱（acc_id 40，稀有）
## ==================================================================
## 治疗量 ×1.3。
## 走 GlobalStats 的 heal 乘数通道（与角色被动、能力乘数累乘），
## 卡片结算与 heal() 都会吃到；heal_raw() 是「已经乘过」的通道，不吃这里的加成。
## ==================================================================

const HEAL_MULTIPLIER := 1.3

func modify_heal_multiplier() -> float:
	return HEAL_MULTIPLIER
