extends Generator_PassiveEffect
## 零落成泥碾作尘（acc_id 69，史诗）
## ==================================================================
## 这一回合受过伤 → 下回合开始挂一次「下一张打出的书页数值 +3」。
## ==================================================================
## 为什么用 overall_sum_pending（和艾玛的钢笔同一条通道）：
##   apply_effect 收到 `xxx_pending` 只写进 BattleState 的单槽 pending_effect / pending_value，
##   之后由 battle_main 在出牌时逐页 consume_pending() 消费 —— 消费一次即清空，
##   所以天然就是「下一张打出的页」。
##
## 回合顺序：玩家出牌 → 敌人行动（这里记 _hurt）→ 下一回合 _start_round 收 on_turn_start 的效果。
## 因为被动实例在战斗内是 PassiveRuntime，_hurt 只在这个战斗里有效，不用手动清。
## ==================================================================

const BONUS := 3

var _hurt := false

func on_damage_taken(amount: int) -> void:
	if amount > 0:
		_hurt = true

func on_turn_start(_turn_count: int) -> Array:
	if not _hurt:
		return []
	_hurt = false
	return [{"effect": "overall_sum_pending", "condition": {}, "value": BONUS}]
