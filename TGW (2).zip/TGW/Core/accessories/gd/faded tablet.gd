extends Generator_PassiveEffect
## 褪去色彩的泡腾片（acc_id 43，稀有）
## ==================================================================
## 魔女化增长 ×0.7（四舍五入，至少保留 1）。
## 挂在 modify_witch_power_gain 上 —— 这是「涨魔女化时的加算修正」，
## 出口在 GlobalPlayer.possessed()：final = round(修正后 × GlobalStats 的魔女化乘数)。
## 降魔女化（value < 0）不受影响，别让它变成"降得也少"。
## ==================================================================

const WITCH_GAIN_MULTIPLIER := 0.7

func modify_witch_power_gain(value: int) -> int:
	if value <= 0:
		return value
	return maxi(1, int(round(float(value) * WITCH_GAIN_MULTIPLIER)))
