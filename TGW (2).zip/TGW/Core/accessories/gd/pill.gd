extends Generator_PassiveEffect
## 药片（acc_id 6，普通）
## ==================================================================
## 每场战斗开始时回复 10 生命。
## 血量是**跨战斗存活**的（GlobalPlayer.health），所以「带着半血进战斗」时这条才有意义。
## 战斗开始时调 GlobalPassive.notify_battle_start() → on_battle_start()。
## ==================================================================

const HEAL_ON_BATTLE := 10

func on_battle_start() -> void:
	GlobalPlayer.heal(HEAL_ON_BATTLE)
