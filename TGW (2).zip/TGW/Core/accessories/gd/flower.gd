extends Generator_PassiveEffect
## 每执行完一个格子事件 → 回复 2 生命（当前挂在「Flower」，acc_id 4）。
## ==================================================================
## 和「存钱罐」（每格 +3 金币）是同一套触发点：manager_event 在事件结算完成后
## 调 GlobalPassive.notify_event_done()。
## ⚠️ 走 heal()（吃回复乘数，与药水/事件回血同口径），不是 heal_raw()。
## ==================================================================

const HEAL_PER_EVENT := 2

func on_event_done() -> void:
	GlobalPlayer.heal(HEAL_PER_EVENT)
