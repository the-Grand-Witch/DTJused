extends Generator_PassiveEffect
## 存钱罐（汉娜的独特饰品，acc_id 1003）
## ==================================================================
## 每执行完一个格子事件 → 获得 3 金币。
## ⚠️ 每次只有 3 金币，**低于金币音效的 20 阈值** ⇒ 不会吵（见 GlobalAudio）。
## ⚠️ 触发点：manager_event 在一个事件结算完成后调 GlobalPassive.notify_event_done()。
## ==================================================================

## 每格给的金币（按局外经济标准：约等于 1/7 个钱袋子，弱但稳）
const GOLD_PER_EVENT := 3

func on_event_done() -> void:
	GlobalPlayer.add_gold(GOLD_PER_EVENT)