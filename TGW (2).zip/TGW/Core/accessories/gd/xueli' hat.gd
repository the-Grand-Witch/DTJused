extends Generator_PassiveEffect
class_name DetectiveHatEffect

## 雪莉的帽子：记录自己打出的书页类型，敌人用到相同类型时累积「看破」。
## 看破每层让伤害 ×1.1（实际乘数在 modify_damage_multiplier 里读，见下）。
##
## 接线说明：
##   1. on_page_played(mark)        —— 由 BattleCalculator 在每次「使用」页时广播，mark 里带 page_type
##   2. on_enemy_page_used(types)   —— 由 Nomel/Boss 在敌人出牌后广播
##   3. 看破层数存在 **owner** 上（不存本对象）。
##      原因：GlobalStats 调 modify_damage_multiplier() 时只传敌人魔女化，
##      被动拿不到「这一次是第几层」的上下文；而算式能直接问 owner 要层数。
##      （旧实现把这个值放在本对象里，导致伤害乘数永远是 1.0。）
##   4. clear_insight() 由 battle_main 在每个玩家行动结算后调用，看破不跨回合累积。
##
## ⚠️ 取数一律走 owner（见 Generator_PassiveEffect 顶部说明），
##    这样同一个脚本既能给玩家用，也能给镜像用。

## 每次比对命中记录的类型时累积的层数
const INSIGHT_PER_HIT := 1
## 每层看破提供的伤害加成
const DAMAGE_PER_STACK := 0.1

## 本回合记录下来的页类型（on_page_played 写入，on_enemy_page_used 比对）
## ⚠️ 这个字段必须声明，否则 on_page_played 里会直接报「不存在的成员」。
var recorded_types: Array = []

func modify_damage_multiplier(_enemy_wp: int) -> float:
	var stacks = 0
	if battle_owner != null and battle_owner.has_method("get_insight_stacks"):
		stacks = int(battle_owner.get_insight_stacks())
	if stacks > 0:
		return 1.0 + DAMAGE_PER_STACK * stacks
	return 1.0

## 记录这次打出的页都带了哪些类型
func on_page_played(mark: Dictionary) -> void:
	recorded_types.clear()
	for t in mark.get("page_type", []):
		recorded_types.append(t)

## 敌人用了同类型的页 → 累积看破
func on_enemy_page_used(types: Array) -> void:
	for t in types:
		if t in recorded_types:
			if battle_owner != null and battle_owner.has_method("add_insight"):
				battle_owner.add_insight(INSIGHT_PER_HIT)
			break

## 保留接口：层数由 owner 持有，这里只清本地的类型记录
func clear_insight() -> void:
	recorded_types.clear()
