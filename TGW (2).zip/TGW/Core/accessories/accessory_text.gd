extends RefCounted
## 饰品的「玩家端」文字：效果摘要 + 完整说明。
## 商店 / 奖励 / Boss 饰品栏共用这一份，避免三处各写一套口径对不上。
## ⚠️ 数值字段改名时只改这里。

## 数值效果摘要（攻击加算 / 防御页 / 伤害 / 回血 / 页冷却 / 挡伤 / 血上限 / 魔女化…）。
## 有事件脚本但没有数值时写「特殊效果」；完全没效果返回空串。
static func effect_text(acc) -> String:
	if acc == null:
		return ""
	var parts: PackedStringArray = []
	if acc.attack_bonus != 0:
		parts.append("攻击加算 +%d" % acc.attack_bonus)
	if acc.defense_page_bonus != 0:
		parts.append("防御页 +%d" % acc.defense_page_bonus)
	if acc.damage_amount != 0:
		parts.append("伤害 +%d" % acc.damage_amount)
	if acc.heal_amount != 0:
		parts.append("回血 +%d" % acc.heal_amount)
	if acc.bookpage_cd_reload != 0:
		parts.append("页冷却 -%d" % acc.bookpage_cd_reload)
	if acc.block_charges != 0:
		parts.append("挡伤 %d 次" % acc.block_charges)
	if acc.max_health_bonus != 0:
		parts.append("血上限 +%d" % acc.max_health_bonus)
	if acc.witch_max_increase != 0:
		parts.append("魔女化上限 +%d" % acc.witch_max_increase)
	if acc.witch_progress_increase != 0:
		parts.append("魔女化增速 +%d" % acc.witch_progress_increase)
	if acc.witch_penalty_reduce != 0:
		parts.append("魔女化代价 -%d" % acc.witch_penalty_reduce)
	if acc.witch_impulse_reduce != 0:
		parts.append("冲动减免 %d" % acc.witch_impulse_reduce)
	if acc.bookmark_page_limit_up != 0:
		parts.append("书签页上限 +%d" % acc.bookmark_page_limit_up)
	if acc.bookmark_limit_up != 0:
		parts.append("书签上限 +%d" % acc.bookmark_limit_up)
	if acc.effect_script != null:
		parts.append("特殊效果")
	return "、".join(parts)

## 完整说明：名称 + 一句效果（优先用美术写的 `Tooltip`，没有就用数值摘要）
static func tooltip_text(acc) -> String:
	if acc == null:
		return ""
	var detail: String = acc.Tooltip if acc.Tooltip != "" else effect_text(acc)
	if detail == "":
		return acc.name
	return "%s\n%s" % [acc.name, detail]

## 按钮上直接显示的一行效果（点击=购买/获得的地方用它，不用悬停也能看清）
static func button_line(acc) -> String:
	var effect := effect_text(acc)
	if effect == "" and acc != null and acc.Tooltip != "":
		effect = acc.Tooltip
	if effect == "":
		return acc.name if acc != null else ""
	return "%s\n%s" % [acc.name, effect]
