extends Node

signal accessories_added(accessories: Generator_accessories)
signal accessories_removed(acc_id: int)

var accessories: Array[Generator_accessories] = []

# ==================== 全部饰品加载与分类 ====================
var all_accessories: Array[Generator_accessories] = []
## 饰品 id 分段（闭区间；换段只改这四行，商店权重表在 `shop_acc.gd`）
const TIER_LOW := Vector2i(1, 33)
const TIER_MID := Vector2i(34, 66)
const TIER_HIGH := Vector2i(67, 99)
const TIER_SHOP := Vector2i(777, 800)

var low_tier: Array[Generator_accessories] = []
var mid_tier: Array[Generator_accessories] = []
var high_tier: Array[Generator_accessories] = []
var shop_tier: Array[Generator_accessories] = []

func _ready():
	_load_all_accessories()
	GlobalPlayer.character_changed.connect(_on_character_changed)

func _on_character_changed(character: Generator_girl):
	if character == null:
		return
	if character.unique_accessories:
		add_accessories(character.unique_accessories)

func _load_all_accessories():
	all_accessories.clear()
	low_tier.clear()
	mid_tier.clear()
	high_tier.clear()
	shop_tier.clear()

	var files = ResourceLoader.list_directory("res://Data/accessories/")
	for file_name in files:
		if file_name.ends_with(".tres"):
			var res = load("res://Data/accessories/" + file_name)
			if res is Generator_accessories:
				all_accessories.append(res)
				if _in_tier(res.acc_id, TIER_LOW):
					low_tier.append(res)
				elif _in_tier(res.acc_id, TIER_MID):
					mid_tier.append(res)
				elif _in_tier(res.acc_id, TIER_HIGH):
					high_tier.append(res)
				elif _in_tier(res.acc_id, TIER_SHOP):
					shop_tier.append(res)

## id 是否落在某个分段里（闭区间）
## 分段名（"low"/"mid"/"high"/"shop"；不在任何段返回空串）——商店权重表按它取
static func tier_of(acc_id: int) -> String:
	if _in_tier(acc_id, TIER_LOW): return "low"
	if _in_tier(acc_id, TIER_MID): return "mid"
	if _in_tier(acc_id, TIER_HIGH): return "high"
	if _in_tier(acc_id, TIER_SHOP): return "shop"
	return ""

static func _in_tier(acc_id: int, tier: Vector2i) -> bool:
	return acc_id >= tier.x and acc_id <= tier.y

## 根据等级获取候选饰品池（"low" / "mid" / "high" / "shop"）
func get_tier(tier: String) -> Array[Generator_accessories]:
	match tier:
		"low": return low_tier
		"mid": return mid_tier
		"high": return high_tier
		"shop": return shop_tier
		_: return []

## 根据 ID 范围获取未拥有的随机饰品
func get_random_accessories_in_range(id_min: int, id_max: int) -> Generator_accessories:
	var candidates: Array[Generator_accessories] = []
	for acc in all_accessories:
		if acc.acc_id >= id_min and acc.acc_id <= id_max:
			if not has_accessories(acc.acc_id):
				candidates.append(acc)
	if candidates.is_empty():
		return null
	return candidates[GlobalRng.range(0, candidates.size() - 1)]

# ==================== 玩家已拥有 ====================
func add_accessories(new_acc: Generator_accessories) -> void:
	for existing in accessories:
		if existing.acc_id == new_acc.acc_id:
			return
	accessories.append(new_acc)
	accessories_added.emit(new_acc)
	GlobalJourney.add_accessory(new_acc.name)

func has_accessories(acc_id: int) -> bool:
	for acc in accessories:
		if acc.acc_id == acc_id:
			return true
	return false

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func get_accessories_by_id(acc_id: int) -> Generator_accessories:
	for acc in accessories:
		if acc.acc_id == acc_id:
			return acc
	return null

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func remove_accessories(acc_id: int) -> void:
	for i in range(accessories.size()):
		if accessories[i].acc_id == acc_id:
			accessories.remove_at(i)
			accessories_removed.emit(acc_id)
			return

func reset() -> void:
	accessories.clear()

# ==================== 效果汇总 ====================
## 防御页数值加算（手牌里每张防御页 +N）：消费点在 BattleFlow 的 aggregate / final_value
func get_defense_page_bonus() -> int:
	var total = 0
	for acc in accessories:
		total += acc.defense_page_bonus
	return total

func get_witch_max_increase() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_max_increase
	return total

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func get_witch_progress_increase() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_progress_increase
	return total

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func get_witch_penalty_reduce() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_penalty_reduce
	return total

func get_witch_impulse_reduce() -> int:
	var total = 0
	for acc in accessories:
		total += acc.witch_impulse_reduce
	return total

func get_bookpage_cd_reload() -> int:
	var total = 0
	for acc in accessories:
		total += acc.bookpage_cd_reload
	return total

func get_max_health_bonus() -> int:
	var total = 0
	for acc in accessories:
		total += acc.max_health_bonus
	return total

func get_bookmark_page_limit_up() -> int:
	var total = 0
	for acc in accessories:
		total += acc.bookmark_page_limit_up
	return total

func get_bookmark_limit_up() -> int:
	var total = 0
	for acc in accessories:
		total += acc.bookmark_limit_up
	return total

# ==================== 掉落屏蔽：来源方接口 ====================
## 饰品侧目前没有屏蔽规则。要加的话在这里返回规则数组即可，
## 结构与 GlobalContract.get_reward_effects() 一致（见该处注释）。
func get_reward_effects() -> Array:
	return []

## 解析器：奖励流程逐件掉落来问「要不要屏蔽」，认领就返回 true。
func consume_reward_block(_context: Dictionary) -> bool:
	return false

# ==================== 图标显示尺寸 ====================
## 饰品原图是 512×512（重绘版），但 UI 里各处按钮/格子只想要一个小图标。
## **把原图直接塞进 Button.icon 会让按钮最小尺寸被顶到 512**，所以显示层统一过这里缩一次，
## UI 排版就与美术分辨率解耦了（以后换多大尺寸的图都不用改界面）。
const ICON_DISPLAY_SIZE := 96

## 按纹理实例缓存，避免每次开商店/掉落都重新缩一遍
var _display_icon_cache: Dictionary = {}

func display_icon(tex: Texture2D) -> Texture2D:
	if tex == null:
		return null
	if tex.get_width() <= ICON_DISPLAY_SIZE and tex.get_height() <= ICON_DISPLAY_SIZE:
		return tex
	var key := tex.get_instance_id()
	if _display_icon_cache.has(key):
		return _display_icon_cache[key]
	var img: Image = tex.get_image()
	if img == null:
		return tex
	img.resize(ICON_DISPLAY_SIZE, ICON_DISPLAY_SIZE, Image.INTERPOLATE_LANCZOS)
	var scaled := ImageTexture.create_from_image(img)
	_display_icon_cache[key] = scaled
	return scaled
