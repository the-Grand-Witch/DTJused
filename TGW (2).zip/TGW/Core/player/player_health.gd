extends TextureProgressBar

## 血条上的「当前/最大」血量数字（main / battle / boss 三个场景共用这个脚本）
const HealthBarText := preload("res://Core/ui/health_bar_text.gd")

## 数字字号：血槽在 394×216 贴图里高约 62px，40 号字 + 描边正好塞得下
const HP_TEXT_FONT_SIZE := 40
## 血条贴图 394×216，但血槽只在 y≈62..124（中心 ≈ 93/216），不是正中间
const HP_TEXT_CENTER_RATIO := 0.43

func _ready():
	max_value = 100
	value = _calculate_health_percent()

	GlobalPlayer.health_changed.connect(_on_health_changed)
	GlobalPlayer.max_health_changed.connect(_on_max_health_changed)
	GlobalPlayer.witch_power_changed.connect(_on_witch_power_changed)

	_update_witch_color(GlobalPlayer.witch_power)
	# 这条血条是百分比条（max_value=100），数字要取 GlobalPlayer 的真实血量
	HealthBarText.attach(self, _hp_values, HP_TEXT_FONT_SIZE, HP_TEXT_CENTER_RATIO)

func _hp_values() -> Vector2i:
	return Vector2i(GlobalPlayer.health, GlobalPlayer.max_health)

func _on_health_changed(new_health: int) -> void:
	value = _calculate_health_percent()

func _on_max_health_changed(new_max_health: int) -> void:
	value = _calculate_health_percent()

func _on_witch_power_changed(new_witch_power: int) -> void:
	_update_witch_color(new_witch_power)

func _calculate_health_percent() -> float:
	if GlobalPlayer.max_health <= 0:
		return 0.0
	return (float(GlobalPlayer.health) / float(GlobalPlayer.max_health)) * 100.0

func _update_witch_color(witch_power: int) -> void:
	var max_wp = GlobalPlayer.max_witch_power + GlobalAccessories.get_witch_max_increase()
	if max_wp <= 0:
		modulate = Color(0, 1, 0)
		return
	var t = clamp(float(witch_power) / float(max_wp), 0.0, 1.0)
	var green = Color(0, 1, 0)
	var purple = Color(0.5, 0, 1)
	modulate = green.lerp(purple, t)
