extends Node

# 当前加载的敌人快照
var current_boss_snapshot: PlayerSnapshot = null

# 保存当前玩家数据为快照，使用玩家ID+时间戳作为唯一标识
func save_player_snapshot() -> void:
	var snapshot = PlayerSnapshot.new()
	snapshot.snapshot_id = GlobalPlayer.player_id + "_" + str(Time.get_unix_time_from_system())
	snapshot.player_name = "玩家镜像"
	snapshot.max_health = GlobalPlayer.max_health
	snapshot.current_health = GlobalPlayer.health
	snapshot.witch_power = GlobalPlayer.witch_power
	snapshot.bookmarks = GlobalBookMark.bookmarks.duplicate()
	snapshot.accessories = GlobalAccessories.accessories.duplicate()
	snapshot.base_attack = 10

	var dir_path = "user://Data/PlayerSnapshots/"
	DirAccess.make_dir_recursive_absolute(dir_path)
	var file_path = dir_path + snapshot.snapshot_id + ".tres"
	ResourceSaver.save(snapshot, file_path)

# 下载指定ID的快照（预留接口）
## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func download_player_data(snapshot_id: String) -> PlayerSnapshot:
	# 未来实现：从服务器下载并加载为PlayerSnapshot
	# 暂时从本地加载演示
	var path = "res://Data/PlayerSnapshots/" + snapshot_id + ".tres"
	if ResourceLoader.exists(path):
		return load(path) as PlayerSnapshot
	return null
