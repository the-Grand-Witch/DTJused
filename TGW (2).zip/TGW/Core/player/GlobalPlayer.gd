extends Node

# ==================== 信号 ====================
signal character_changed(character: Generator_girl)
signal health_changed(new_health: int)
signal witch_power_changed(new_power: int)
signal gold_changed(new_gold: int)
signal max_health_changed(new_max_health: int)
signal hint_requested(text: String)
# ==================== 基础属性 ====================
## 只是个显示用 id（不是玩法随机，不进种子）；名字重复不影响任何结算
var player_id: String = "player_" + str(randi())
var max_health: int = 0
var health: int = 0
var witch_power: int = 0
var gold: int = 0
## 魔女化上限（卡牌设计稿 §二）
const MAX_WITCH_POWER := 100
## 冲动条数 = 魔女化 ÷ 这个除数（改它必须同时重算所有涨魔牌的数值）
const IMPULSE_DIVISOR := 18
## 冲动惩罚的基础值（`魇蚀-B2` 会把它改成负数）
const IMPULSE_PUNISHMENT := 2

var max_witch_power: int = MAX_WITCH_POWER
# ==================== 角色与被动 ====================
var current_character: Generator_girl = null
## 是否处于「一局进行中」。
## reset() 之后是 false（空状态：没有角色、血量为 0，等 set_character 重算），
## set_character() 之后是 true。
## 血量 0 只有在这个状态下才代表「死亡」—— reset() 广播的那个 0 只是刷新 UI 用的，
## 监听者（GlobalScenes）必须靠这个标志把两者区分开。
var in_run: bool = false
var _default_passive: Generator_PassiveEffect   # 默认空被动实例，用于安全调用

## 本场战斗的 owner（BattleState）。战斗外为 null。
## 由 BattleState.bind_owner() 写入；用它来取「当前战斗的乘数」，
## 这样 GlobalPlayer 不必自己去猜当前是哪场战斗。
var battle_owner: Node = null

func bind_battle_owner(owner_node: Node) -> void:
	battle_owner = owner_node

## 取本场战斗的 owner；战斗场景已销毁时返回 null（避免拿到已释放的节点）
func get_ability_owner() -> Node:
	if battle_owner != null and is_instance_valid(battle_owner):
		return battle_owner
	return null

func _ready():
	GlobalAccessories.accessories_added.connect(_on_accessories_changed)
	GlobalAccessories.accessories_removed.connect(_on_accessories_changed)

# ==================== 角色设置 ====================
## 设置当前角色（通常在开始新游戏时调用）
func set_character(character: Generator_girl) -> void:
	in_run = true
	current_character = character
	max_witch_power = character.base_max_witch_power
	character_changed.emit(character)
	recalculate_max_health()
	health = max_health
	# 初始金币：角色的基础属性（reset() 已清零，这里按角色设）
	gold = character.starting_gold
	# 这是「发初始金币」不是入账：把音效的金币基准掰过来，否则开局就响一声「金币」
	GlobalAudio.sync_gold()
	GlobalBookMark.set_custom_default_bookmarks(character.starting_bookmarks)
	GlobalCardLibrary.build_current_pool(character.pool_keywords)
	
## 获取当前角色被动对象，如果无角色或无被动，返回默认空被动
func get_passive() -> Generator_PassiveEffect:
	return GlobalPassive.get_passive()
# ==================== 属性修改 ====================
func _on_accessories_changed(_accessories = null):
	recalculate_max_health()

## 重算血量上限。
## 每次都从 current_character.base_max_health 重新算起，
## 而不是拿新值和「当前 max_health」求差 —— 后者一旦 max_health 被别处改过（reset 硬写、契约扣血等）就算错。
func recalculate_max_health():
	var base := 0
	if current_character != null:
		base = current_character.base_max_health
	var bonus = GlobalAccessories.get_max_health_bonus()
	max_health = get_passive().modify_max_health(base + bonus)

	if max_health <= 0:
		health = 0
		max_health_changed.emit(max_health)
		return

	if health <= 0:
		health = max_health          # 空状态（reset 之后）→ 视为满血
	else:
		health = min(health, max_health)   # 已有血量 → 只夹上限
	max_health_changed.emit(max_health)
	health_changed.emit(health)

## 承受伤害。伤害量在这里乘上「承受伤害乘数」（owner = 本场战斗的 BattleState）。
func take_damage(amount: int) -> void:
	var owner_state = get_ability_owner()
	if _consume_block(owner_state):
		return
	var final_amount = int(ceil(amount * GlobalStats.get_damage_taken_multiplier(owner_state)))
	if final_amount <= 0:
		return
	health = max(health - final_amount, 0)
	health_changed.emit(health)
	_notify_passives("notify_damage_taken", final_amount, owner_state)

## 通用回血：这类血量来自事件 / 药水 / 每回合被动，需要乘上回复乘数。
## 卡片结算出来的回血已经由 BattleCalculator 乘过一次，请改用 heal_raw()。
func heal(amount: int = 10) -> void:
	if is_heal_disabled():
		return
	var final_amount = int(ceil(amount * GlobalStats.get_heal_multiplier(get_ability_owner())))
	_apply_heal(final_amount)

## 直接回血，不再乘倍率（给「已结算过」的来源使用）
func heal_raw(amount: int) -> void:
	if is_heal_disabled():
		return
	_apply_heal(amount)

func _apply_heal(amount: int) -> void:
	if amount <= 0:
		return
	var before = health
	health = min(health + amount, max_health)
	var healed = health - before
	health_changed.emit(health)
	# 被动钩子：按**实际回复量**广播（满血时不虚报）
	if healed > 0:
		_notify_passives("notify_heal", healed, get_ability_owner())

## 魔女化增减。
## 正数走角色被动的 modify_witch_power_gain（治疗量式的加算修正），
## 之后的总额再乘 GlobalStats 的魔女化乘数（被动 × 饰品 × 能力）。
func possessed(amount: int = 1) -> void:
	var final_amount = get_passive().modify_witch_power_gain(amount)
	final_amount = int(round(final_amount * GlobalStats.get_witch_power_multiplier(get_ability_owner())))
	# 魔女化上限提升
	var current_max = max_witch_power + GlobalAccessories.get_witch_max_increase()
	witch_power = clamp(witch_power + final_amount, 0, current_max)
	witch_power_changed.emit(witch_power)
	if witch_power >= current_max:
		GlobalScenes.check_game_over()
	_notify_passives("notify_witch_power_changed", witch_power, get_ability_owner())

## 被动钩子广播：战斗中有 owner 就走 owner（本场战斗的被动实例），
## 战斗外退回全局被动管理器（行为与以前一致）。
func _notify_passives(method: String, value, owner_state) -> void:
	var target = _passive_target(owner_state)
	if target != null and target.has_method(method):
		target.call(method, value)

## 格挡消耗：同样优先走本场战斗的被动实例
func _consume_block(owner_state) -> bool:
	var target = _passive_target(owner_state)
	if target != null and target.has_method("try_consume_block"):
		return bool(target.call("try_consume_block"))
	return false

## 取被动容器：优先本场战斗的 PassiveRuntime，其次全局管理器
func _passive_target(owner_state):
	if owner_state is BattleState:
		return owner_state.passives
	return GlobalPassive

func add_gold(amount: int) -> void:
	# 应用被动修改
	var final_amount = get_passive().modify_gold_gain(amount)
	gold += final_amount
	gold_changed.emit(gold)
# ==================== 提示 ====================
func show(text: String) -> void:
	hint_requested.emit(text)
# ==================== 战斗相关接口 ====================
## 注意：以下乘数/加算全部转发给 GlobalStats 的**纯函数**，公式只在那边一份。
## owner 传的是「本场战斗的 BattleState」（战斗外为 null，此时乘数退化为 1.0 / 0）。
## 新增乘数维度时请改 GlobalStats，不要在这里另开分支。

## 伤害乘数（角色被动 × 饰品被动 × 能力临时修正）
func get_damage_multiplier(enemy_witch_power: int, owner = null) -> float:
	return GlobalStats.get_damage_multiplier(_resolve_owner(owner), enemy_witch_power, owner)

func get_armor_multiplier(owner = null) -> float:
	return GlobalStats.get_armor_multiplier(_resolve_owner(owner), owner)

func get_heal_multiplier(owner = null) -> float:
	return GlobalStats.get_heal_multiplier(_resolve_owner(owner), owner)

func get_witch_power_multiplier(owner = null) -> float:
	return GlobalStats.get_witch_power_multiplier(_resolve_owner(owner), owner)

func get_damage_taken_multiplier(owner = null) -> float:
	return GlobalStats.get_damage_taken_multiplier(_resolve_owner(owner), owner)

## 攻击力加算（来自所有已拥有饰品 + 被动提供的加算）
func get_attack_bonus(owner = null) -> int:
	return GlobalStats.get_attack_bonus(_resolve_owner(owner))

func is_ability_disabled() -> bool:
	return GlobalStats.is_ability_disabled(get_ability_owner())

func is_heal_disabled() -> bool:
	return get_passive().is_heal_disabled()

## owner 解析：显式传入优先，否则用本场战斗的 BattleState
func _resolve_owner(owner) -> Node:
	if owner is Node and is_instance_valid(owner):
		return owner
	return get_ability_owner()

## 获取每回合护甲（战斗中走本场战斗的被动实例，战斗外走全局管理器）
func get_armor_per_turn(base: int = 0) -> int:
	var target = _passive_target(get_ability_owner())
	if target != null and target.has_method("get_armor_per_turn"):
		return int(target.call("get_armor_per_turn", base))
	return base

## 获取每回合回复（同上）
func get_heal_per_turn(base: int = 0) -> int:
	var target = _passive_target(get_ability_owner())
	if target != null and target.has_method("get_heal_per_turn"):
		return int(target.call("get_heal_per_turn", base))
	return base

##格挡次数获取
func get_block_charge() -> int:
	var target = _passive_target(get_ability_owner())
	if target != null and target.has_method("get_block_charge"):
		return int(target.call("get_block_charge"))
	return 0
# ==================== 重置 ====================
func reset() -> void:
	# 开局换一颗新种子（种子只在这一刻生成，玩家不能中途指定）
	GlobalRng.reseed()
	# 1. 清其他全局
	GlobalTime.reset()
	GlobalCardLibrary.reset()
	GlobalAccessories.reset()
	GlobalBookMark.reset()
	GlobalContract.reset()
	GlobalPassive.reset()

	# 2. 清自身（血量留空，等 set_character 按角色基准重算）
	#    in_run 先置 false：这样下面广播的 health=0 是「空状态」而不是「死亡」，
	#    否则 GlobalScenes 会把它当成玩家阵亡，立刻跳 game_over。
	in_run = false
	current_character = null
	max_health = 0
	health = 0
	witch_power = 0
	gold = 0
	max_witch_power = MAX_WITCH_POWER

	# 3. 发信号刷新 UI
	character_changed.emit(null)
	health_changed.emit(health)
	max_health_changed.emit(max_health)
	witch_power_changed.emit(witch_power)
	gold_changed.emit(gold)
	# 清零同样不是「花钱」：掰一下音效基准，否则重开时会响一声「购买」
	GlobalAudio.sync_gold()

# ==================== 冲动相关（保持原有） ====================
## ⚠️ 除数是 **18**（卡牌设计稿 §二：魔女化 → 冲动条数 = 魔女化 ÷ 18）。
##    改这个数必须同时重算所有涨魔牌的数值，两者不能分开调。
func get_impulse_count() -> int:
	# 应用饰品效果：减少冲动赋予数量
	var base_count = witch_power / IMPULSE_DIVISOR - GlobalAccessories.get_witch_impulse_reduce()
	return max(0, base_count)

func get_impulse_punishment() -> int:
	return IMPULSE_PUNISHMENT

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func get_impulse_damage_multiplier() -> float:
	return 1.0 + float(witch_power) / 100.0
	
#====================  可选：保留测试按键，但正式版删除====================
func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_Q:
			heal(50)
		elif event.keycode == KEY_W:
			GlobalPlayer.possessed(20)
		elif event.keycode == KEY_E:
			GlobalTime.add_time_units(24)
		elif event.keycode == KEY_R:
			GlobalPlayer.add_gold(200)
		elif event.keycode == KEY_T:
			for card in GlobalCardLibrary.get_all_cards():
				GlobalCardLibrary.add_acquired_count(card.book_id, 99)
		elif event.keycode == KEY_A:
			GlobalScenes.refresh_events()
