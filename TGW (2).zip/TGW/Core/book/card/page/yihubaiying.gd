extends RefCounted
## 联动：一呼百应（book_id 12）
## 使用时：同一书签内所有攻击页的伤害 +2。
##
## 新 API 说明（旧版用的是已废弃的 context.modifiers / mark.type，已重写）：
##   context["add_of"](card, idx, 字段, 增量)   给目标页的数值字典加值
##   页类型要用 page.page_type（数组）判断，不存在 pickup_type 这个字段
##
## 注意：这是**加算**，与「终为一」的最终乘区是两层，互不干扰。
const ATTACK_BONUS := 2

func on_use(context: Dictionary) -> void:
	var card = context.get("self_card")
	var battle_state = context.get("battle_state")
	if card == null:
		return

	# 每次「使用」都会跑一遍（play_count > 1 时会多次），用标记保证整页只生效一次
	var idx = int(context.get("self_index", 0))
	var self_mark = card.get_page_mark(idx)
	var flag = "yihubaiying_applied"
	if self_mark.get("effects", {}).get(flag, false):
		return
	if not self_mark.has("effects"):
		self_mark["effects"] = {}
	self_mark["effects"][flag] = true

	var add_of = context.get("add_of")
	var pages = card.Generator_bookmark.pages
	for i in range(pages.size()):
		if Generator_bookpage.PickupType.Attack in pages[i].page_type:
			if add_of is Callable:
				add_of.call(card, i, "damage", ATTACK_BONUS)
