extends RefCounted
## 怪物页「硬骨」（牛的专属）
## ==================================================================
## 生效时机 = **预告那一刻**（敌人回合开始），不是打出那一刻。
##
## 为什么：野怪的回合在玩家行动**之后**。如果等野怪出牌时才写 flag，
## 玩家这回合的行动已经结算完了，效果只能落到下一回合 —— 而下一回合的
## 意图标签已经换成另一张书签，看上去就像「意图和实际出的牌对不上」
## （预告硬骨的那回合页照打，下一回合才作废）。
## 所以挂在 `on_intent`：野怪选中这本书签、把意图显示给玩家的同一刻就写 flag，
## 玩家的这次行动立刻吃到它；玩家结算完由
## `battle_calculator.calculate_player_effects()` 通过 `clear_monster_debuffs()` 清掉。
##
## 消费点：`BattleFlow.aggregate()`（伤害通道逐页判定）
## ==================================================================

const FLAG := "monster_hardbone"
## 最终伤害「≤ 这个值」的攻击页整页无效（5 → 5 点及以下都作废，6 点起照常打）
const THRESHOLD := 5

func on_intent(context: Dictionary) -> void:
	var state = context.get("battle_state")
	if state == null:
		return
	var target = state.enemy_side
	if target == null:
		return
	target.set_passive_value(FLAG, THRESHOLD)
