extends RefCounted
## 怪物页「吼叫」（龙的专属）
## ==================================================================
## 生效时机 = **预告那一刻**（敌人回合开始），不是打出那一刻（原因同 `monster_hardbone.gd`）。
##
## 写成对手 state 上的具名战斗态：
##   · 效果要跨阵营（敌人出牌 → 影响玩家结算）；
##   · 要在**玩家这次行动**里就生效 —— 野怪回合在玩家之后，晚一步就只能等下一回合，
##     而下一回合的意图标签已经换成别的书签，会显得「意图和实际对不上」；
##   · `BattleState.reset_battle()` 会清空 `passive_values`，所以不会跨战斗残留。
## 消费点：`BattleFlow.aggregate()`（跳过每个书签的最后一张页）
## 清空点：`battle_calculator.calculate_player_effects()`（结算完只作用一次）
## ==================================================================

const FLAG := "monster_roar"

func on_intent(context: Dictionary) -> void:
	var state = context.get("battle_state")
	if state == null:
		return
	var target = state.enemy_side
	if target == null:
		return
	target.set_passive_value(FLAG, true)
