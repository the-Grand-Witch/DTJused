extends RefCounted
class_name AttackUpEffect

## 攻击力提升：读取当前 count 值，输出为攻击加成

func on_ability(context: Dictionary) -> Dictionary:
	var count = context.get("count", 0)
	return {"attack_bonus": int(count)}
