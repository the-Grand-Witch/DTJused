extends Node
## 放大镜（雪莉的 friend 页，book_id 1002）
## ==================================================================
## 效果：打出后**把本页收到的加成再算一遍** ⇒ **只翻 buff、不翻面板**（自己做的那 5 点不动）。
##
## 为什么不在 on_use 里翻 ✗：
##   on_use 跑在关键词之前，那时别的页/关键词给的加成还没加进来 ⇒ 会漏 buff。
##
## 为什么不用 multiply_overall / add_overall ✗：
##   它们只改 mark，而汇总（aggregate）读的是 play_page 阶段就拍好的**快照** `snap["sum"]`
##   （见 BattleFlow.gd 的 (base + effect + snap["sum"]) × snap["mult"]）⇒ 改了等于没改。
##
## 所以正确姿势：在 "end" 阶段（关键词之后、aggregate 之前）用 `context["add_of"]`
##   把 overall_sum 给每个字段再加一遍 —— add_of 走 battle_state.add_page_value，
##   它会**回填已采集的快照**，汇总才看得到。
##
## ⚠️ 本页没有收到任何加成时（overall_sum == 0）什么都不做：它就是一张 5 伤 friend 页。
## ==================================================================

## 要补一遍的字段（与 aggregate 里逐字段 (base + effect + sum) × mult 对齐）
const FIELDS := ["damage", "armor", "healing", "witchpower", "count"]

func on_end(context: Dictionary) -> void:
	var card = context.get("self_card")
	if card == null:
		return
	var idx := int(context.get("self_index", 0))
	# overall_sum = 本页收到的所有「加算」加成（关键词 / 其它页给的）
	var buffs := int(card.get_page_mark(idx).get("overall_sum", 0))
	if buffs == 0:
		return
	var add_of = context.get("add_of")
	for field in FIELDS:
		add_of.call(card, idx, field, buffs)
