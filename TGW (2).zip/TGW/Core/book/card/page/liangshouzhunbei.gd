extends RefCounted
## 联动：两手准备（book_id 13）
## 使用阶段：让前后相邻两张书页的伤害 +1。
##
## 新 API 说明（旧版用的是已废弃的 context.modifiers / self_mark，已重写）：
##   context["add_of"](card, idx, 字段, 增量)   给目标页的数值字典加值
##
## 为什么放在「使用」阶段而不是「编入」：
##   使用阶段的顺序是逐页依次执行的，所以本页强化后面那张页是有效的；
##   而前面的页已经结算完快照，不会再变。若想改成「双向都一定生效」，
##   需要把该效果挪到编入阶段并保证目标页的快照在其之后采集——目前不做过度设计。
const NEIGHBOR_BONUS := 1

func on_use(context: Dictionary) -> void:
	var card = context.get("self_card")
	if card == null:
		return

	# 整页只生效一次（play_count > 1 时不重复叠加）
	var idx = int(context.get("self_index", 0))
	var self_mark = card.get_page_mark(idx)
	var flag = "liangshou_applied"
	if self_mark.get("effects", {}).get(flag, false):
		return
	if not self_mark.has("effects"):
		self_mark["effects"] = {}
	self_mark["effects"][flag] = true

	var add_of = context.get("add_of")
	if not (add_of is Callable):
		return
	var count = card.Generator_bookmark.pages.size()
	for offset in [-1, 1]:
		var target = idx + offset
		if target < 0 or target >= count:
			continue
		add_of.call(card, target, "damage", NEIGHBOR_BONUS)
