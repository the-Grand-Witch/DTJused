extends RefCounted
## 联动：终为一（book_id 11）
## 使用时：让本页后面一张书页的最终数值 ×1.5。
##
## 新 API 说明（旧版用的是已废弃的 context.modifiers / self_mark，已重写）：
##   context["self_index"]        本页在书签中的下标
##   context["self_card"]         本页所属的 BookmarkCard
##   context["multiply_overall"](card, idx, 倍率)   给目标页的最终乘区加乘数
##   context["battle_state"]      取页标记（打一次性标记，避免重复打出时叠加）
##
## 倍率写在「结算乘区」（overall_multiplier）而不是直接改数值，
## 这样它和关键词的加成分属两层，先后顺序清楚，也不会被快照重复计入。
const MULTIPLIER := 1.5

func on_use(context: Dictionary) -> void:
	var card = context.get("self_card")
	var idx = int(context.get("self_index", 0))
	var battle_state = context.get("battle_state")
	if card == null or battle_state == null:
		return

	var target = idx + 1
	if target < 0 or target >= card.Generator_bookmark.pages.size():
		return

	# 同一回合内只强化一次（多重打出时不叠加）
	var self_mark = card.get_page_mark(idx)
	var flag = "zhongweiyi_boosted"
	if self_mark.get("effects", {}).get(flag, false):
		return
	if not self_mark.has("effects"):
		self_mark["effects"] = {}
	self_mark["effects"][flag] = true

	var multiply_overall = context.get("multiply_overall")
	if multiply_overall is Callable:
		multiply_overall.call(card, target, MULTIPLIER)
