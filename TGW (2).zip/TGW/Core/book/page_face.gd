extends PanelContainer
class_name PageFace

## 「一张卡的占位卡面」＝ **关键词底色 + 稀有度画框 + 卡名（能力页多一个「强化」）+ 基础效果 + cd**。
##
## 2026-09-23 定：48 张卡图短期内补不齐，所以**凡是要显示"一张卡"的地方都用这个**，
## 不要再依赖 `page.icon`（书签行 / 书库选择 / 商店 / 奖励弹窗）。
## 美术资源在 `Assets/Textures/Icons/book/`（一行两张图，都是 400×100）：
##   外层 = 关键词底板（铺满）· 内层 = 稀有度画框（中心透明，只画边框）
##
## 用法：
##     var face := PageFace.new()
##     face.name_font_size = 13          # 可选，放小格子里时调小
##     face.setup(page)
##     some_container.add_child(face)
## 塞进 Button 里当卡面时，记得 `face.set_anchors_and_offsets_preset(PRESET_FULL_RECT)`
## 且 `face.mouse_filter = MOUSE_FILTER_IGNORE`（让点击落到按钮上）。

const BOOK_ART_ROOT := "res://Assets/Textures/Icons/book/"
const KEYWORD_PLATES := {
	&"normal": "Normal.png",
	&"PX": "PX.png",
	&"XX": "XX.png",
	&"YS": "YS.png",
	&"ZM": "ZM.png",
}
const PLATE_FALLBACK := "Normal.png"
## 0 普通 / 1 银 / 2 金（旧名 `gold .png` 带空格，`_resolve_art_name()` 两种都认）
const RARITY_FRAMES := ["ordinary.png", "silver.png", "gold.png"]
## 卡面那一行里各段（名称 / 基础效果 / cd）的间距
const INNER_SEPARATION := 4
## 亮底上的字色（都用同一支墨色：行尾试过浅灰，但在魇蚀那块紫底上掉到 4 以下）
const INK := Color(0.078, 0.063, 0.047)     ## #14100C
## 量画框边框厚度时的 alpha 门槛（0~1）与上限（源图像素）
const FRAME_ALPHA_THRESHOLD := 0.39
const MAX_FRAME_INSET := 24
## 放得下的判定余量（比例）：超出不到 6% 就不缩，免得为 1~2px 白缩一号字
const FIT_TOLERANCE_RATIO := 1.06
## 自动缩字号的下限：一直缩到「放得下」为止，但不再小于这个绝对字号
const MIN_FONT_SIZE := 8

var name_font_size := 18

var frame: PanelContainer
var row: HBoxContainer
var name_label: Label
## 画框贴图的原始尺寸 + 量出来的边框厚度（源图像素，x = 左右取大者，y = 上下取大者）
var _frame_tex_size := Vector2.ZERO
var _frame_inset := Vector2.ZERO

func _init() -> void:
	# ⚠️ 卡面自己**不吃点击**：它是盖在按钮/书签上的装饰，吃了的话按钮收不到 pressed、
	#    书签本体也收不到 `_gui_input`（书签就点不动了）。
	#    下面**每个子节点都显式设成 IGNORE** —— 光设自己不够，Label / PanelContainer
	#    的默认 mouse_filter 是 STOP，照样会把点击截走。
	mouse_filter = Control.MOUSE_FILTER_IGNORE

	frame = PanelContainer.new()
	frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(frame)

	row = HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", INNER_SEPARATION)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	frame.add_child(row)

	name_label = Label.new()
	name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	# 卡面**一行到底、不换行**：放不下就自动缩字号（见 _apply_fitted_fonts）
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	# ⚠️ **必须裁字**：不裁的话 Label 的最小宽度 = 文字的宽度，会把整张卡面顶到比格子还宽
	#    （实测 148 宽的格子被顶成 197.9），于是卡面压到隔壁格子上 —— 这就是「书页超宽、没对齐」。
	#    裁了之后卡面永远等于父格子，放不下由缩字号解决，缩到下限还放不下才真的被裁掉。
	name_label.clip_text = true
	name_label.add_theme_color_override("font_color", INK)
	row.add_child(name_label)

	# 卡面大小一变就重算两件事：字要退多少（不压到画框上）、字号要不要缩（塞不进就缩）
	resized.connect(_on_resized)
	# ⚠️ 还要盯**行容器**：卡面尺寸没变但行的宽度是布局时才定下来的，
	#    只在 `resized` 里算会用到过期的宽度（表现为"本来放得下也被缩小"）。
	row.resized.connect(_apply_fitted_fonts)

## 把一张页资源铺到卡面上：
## 卡面文字 = **名称 + 基础效果 + cd**（不显示编号，也不写特效说明）；
## 特效说明（`description` 与 `effect_*`）走悬浮提示，由 `attach_to_button` 写到宿主按钮上。
func setup(page) -> void:
	add_theme_stylebox_override("panel", _texture_style(_load_art(keyword_plate(page.keywords))))
	var frame_tex: Texture2D = _load_art(rarity_frame(page.rarity))
	frame.add_theme_stylebox_override("panel", _texture_style(frame_tex))
	_measure_frame_inset(frame_tex)
	name_label.text = page_line(page)
	_on_resized()

## 卡面那一行：**名称（+ 强化）+ 基础效果 + cd**。
## ⚠️ 基础效果必须由卡面自己拼出来：`description` 里只写了关键词效果，
##    像「起澈 伤害5」的基础数值在描述里根本没有，只看名字看不出这张卡打多少。
## ⚠️ 页的 `code`（PX-A1 这种）是**给作者看的序号**，任何玩家可见的地方都不要出现。
## ⚠️ **能力页多一个「强化」标记**（2026-10-18 用户定）：能力页（`page_type` 含 `Ability`）
##    打出去是「强化动作」，不是攻击/防御，所以卡名后面跟一个「强化」，一眼能认出来。
static func page_line(page) -> String:
	var parts: Array[String] = []
	if page.page_name != "":
		parts.append(page.page_name)
	if Generator_bookpage.PickupType.Ability in page.page_type:
		parts.append("强化")
	var base: String = base_effect_text(page)
	if base != "":
		parts.append(base)
	parts.append("cd%d" % page.cd)
	return "  ".join(parts)

## 悬浮提示的正文：特效数值（若填了）+ `description`，最上面一行只放**名称**。
## ⚠️ 不显示 `code`：那是作者序号，玩家端一律不出现。
static func effect_tooltip(page) -> String:
	var head: String = page.page_name
	var lines: Array[String] = []
	var effect: String = effect_number_text(page)
	if effect != "":
		lines.append(effect)
	if page.description != "":
		lines.append(page.description)
	if head != "":
		lines.insert(0, head)
	return "\n".join(lines)

## 基础效果摘要：伤害 / 护甲 / 回复 / 魔女化 / 次数（全 0 返回空串）
static func base_effect_text(page) -> String:
	var parts: Array[String] = []
	if page.damage != 0:
		parts.append("伤害%d" % page.damage)
	if page.armor != 0:
		parts.append("护甲%d" % page.armor)
	if page.healing != 0:
		parts.append("回复%d" % page.healing)
	if page.witchpower != 0:
		parts.append("魔女化%+d" % page.witchpower)
	if page.count != 0:
		parts.append("次数%d" % page.count)
	return " ".join(parts)

## 「特效数值」栏位的摘要（`effect_*`，带正负号；全 0 返回空串）
static func effect_number_text(page) -> String:
	var parts: Array[String] = []
	if page.effect_damage != 0:
		parts.append("伤害%+d" % page.effect_damage)
	if page.effect_armor != 0:
		parts.append("护甲%+d" % page.effect_armor)
	if page.effect_healing != 0:
		parts.append("回复%+d" % page.effect_healing)
	if page.effect_witchpower != 0:
		parts.append("魔女化%+d" % page.effect_witchpower)
	if page.effect_count != 0:
		parts.append("次数%+d" % page.effect_count)
	if page.effect_play_count != 0:
		parts.append("额外使用%+d" % page.effect_play_count)
	if parts.is_empty():
		return ""
	return "特效 " + " ".join(parts)

## 改字号（书签放大时由 `display_bookmark` 按缩放倍数调用）
func set_font_sizes(size: int) -> void:
	name_font_size = size
	_refresh_detail_font()
	_apply_fitted_fonts()

# ==================== 说明写进书页自身 ====================
## 商店书页 / 掉落条目这种「点击就是购买/获得、没有机会先悬停」的地方：
## 把效果说明写在**这一页里面**，而不是在外面另挂一条横幅。
##   卡面 = 上「名称 + 基础效果 + cd」（`name_font_size`）
##          下「说明」（默认 `name_font_size × DETAIL_RATIO`，可用第二个参数指定）
## 实现：结构只改一次 —— 把原来的名字行挪进一个 VBox，再补一行说明 Label。
const DETAIL_RATIO := 0.62

var _detail_text := ""
var _detail_font_size := -1
var _stack: VBoxContainer
## 说明 Label 的外套：普通 Control（min 尺寸 0）+ `clip_contents`
## —— 这样说明再长也**不会把卡面顶大**，更不会压到卡面下面的价格条，最多被裁掉。
var _detail_box: Control
var _detail_label: Label

func set_detail(text: String, font_size: int = -1) -> void:
	_detail_text = text
	_detail_font_size = font_size
	if _stack == null:
		_build_detail_stack()
	_detail_label.text = text
	_detail_box.visible = text != ""
	_detail_label.visible = text != ""
	_refresh_detail_font()
	_apply_fitted_fonts()
	# 布局还没跑完时先按「可能的」高度再挑一次，等 `resized` 到了会再算
	_fit_detail_font.call_deferred()

func _build_detail_stack() -> void:
	# 卡面自己裁一刀：说明文字再多也不许画到卡面外面去（外面就是价格）
	frame.clip_contents = true
	_stack = VBoxContainer.new()
	_stack.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_stack.alignment = BoxContainer.ALIGNMENT_CENTER
	_stack.add_theme_constant_override("separation", 0)
	frame.add_child(_stack)
	frame.remove_child(row)
	_stack.add_child(row)
	row.size_flags_vertical = Control.SIZE_SHRINK_CENTER

	_detail_box = Control.new()
	_detail_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_detail_box.clip_contents = true
	_detail_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_stack.add_child(_detail_box)
	# 说明格子的高度是布局时才定下来的 —— 它一变就重新挑字号（否则第一次算的时候拿到 0）
	_detail_box.resized.connect(_fit_detail_font)

	_detail_label = Label.new()
	_detail_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_detail_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_detail_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_detail_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_detail_label.add_theme_color_override("font_color", INK)
	_detail_box.add_child(_detail_label)
	_detail_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _refresh_detail_font() -> void:
	if _detail_label == null:
		return
	var size := _detail_font_size
	if size <= 0:
		size = int(round(name_font_size * DETAIL_RATIO))
	_detail_label.add_theme_font_size_override("font_size", maxi(MIN_FONT_SIZE, size))

func _on_resized() -> void:
	_apply_frame_inset()
	_apply_fitted_fonts()

## 卡面**不换行**：放不下就按宽度逐级缩字号，直到**真的**放得下（下限 8px）。
## ⚠️ 可用宽度**不能取 size.x**：文字会把这个 PanelContainer 的最小宽度顶大，
##    算出来永远「刚好放得下」，于是就永远不缩。改取**父节点给的区域宽度**，
##    再和自身宽度取较小值（有些场合父区域拿不到）。
## ⚠️ 这里**不吃 6% 容差**：容差会让字号停在「还差几个像素」那一档，
##    格子窄的时候（创建书签的 148px 格子）就是它顶着卡面溢出、压到邻卡上。
func _apply_fitted_fonts() -> void:
	if name_font_size <= 0 or size.x <= 1.0:
		return
	var ref_width: float = size.x
	var parent_width: float = get_parent_area_size().x
	if parent_width > 1.0:
		ref_width = minf(ref_width, parent_width)
	var inset_px: float = 0.0
	if _frame_tex_size.x > 0.0:
		inset_px = _frame_inset.x * ref_width / _frame_tex_size.x
	var avail: float = ref_width - inset_px * 2.0
	if avail <= 1.0:
		return
	var floor_size: int = MIN_FONT_SIZE
	var fs: int = name_font_size
	while fs > floor_size and text_width(name_label, fs) > avail:
		fs -= 1
	name_label.add_theme_font_size_override("font_size", fs)
	_fit_detail_font()

## 说明行的最小字号：再小就没人看得清了，宁可裁掉
const DETAIL_MIN_FONT_SIZE := 14

## 说明行按**能用的高度**再缩一次：卡面矮的时候（商店格子被压扁）宁可字小一点，
## 也不能让说明顶出卡面压到价格上；缩到下限还放不下就由 `_detail_box` 裁掉。
func _fit_detail_font() -> void:
	if _detail_label == null or not _detail_label.visible:
		return
	var base := _detail_font_size
	if base <= 0:
		base = int(round(name_font_size * DETAIL_RATIO))
	base = maxi(DETAIL_MIN_FONT_SIZE, base)
	_detail_label.add_theme_font_size_override("font_size", base)
	# 可用高度：说明格子给的高度 vs「卡面高度 − 名称行高度」，取小的一边才稳
	var avail_by_face: float = size.y - name_label.get_minimum_size().y - 6.0
	var avail: float = avail_by_face
	if _detail_box != null and _detail_box.size.y > 4.0:
		avail = minf(_detail_box.size.y, avail_by_face)
	if avail <= 4.0:
		return
	var fs: int = base
	while fs > DETAIL_MIN_FONT_SIZE:
		_detail_label.add_theme_font_size_override("font_size", fs)
		if _detail_label.get_minimum_size().y <= avail - 2.0:
			break
		fs -= 1

## 一段文字在某个字号下的宽度（用标签自己的字体；拿不到字体就返回 0 ⇒ 不缩）
static func text_width(label: Label, font_size: int) -> float:
	if font_size <= 0:
		return 0.0
	var font: Font = label.get_theme_font("font")
	if font == null:
		return 0.0
	return font.get_string_size(label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x

## 通用：把一个 Label 的字号缩到在 `avail_width` 内放得下（单行、不换行）。
## 标题、价格这类一行文字都用它。`base_size` 是理想字号，最多缩到 `min_ratio`。
static func fit_label_width(label: Label, base_size: int, avail_width: float, min_ratio := 0.6) -> void:
	if label == null or base_size <= 0 or avail_width <= 1.0:
		return
	var floor_size: int = maxi(6, int(ceil(float(base_size) * min_ratio)))
	var size: int = base_size
	while size > floor_size and text_width(label, size) > avail_width * FIT_TOLERANCE_RATIO:
		size -= 1
	label.add_theme_font_size_override("font_size", size)

## 把一张卡面嵌进 Button 里当内容（按钮自己的 `text` / `icon` 会清空）。
## 商铺格子这种要额外叠价格的，拿返回的 face 继续往上加子节点即可。
## **悬浮提示**（特效说明）在这里一并写到按钮上：卡面本身 mouse_filter = IGNORE，
## 自己弹不出 tooltip，只能由宿主按钮来弹。
static func attach_to_button(btn: Button, page, name_size := 16) -> PageFace:
	clear_button(btn)
	var face := PageFace.new()
	face.name_font_size = name_size
	face.setup(page)
	btn.add_child(face)
	face.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	face.mouse_filter = Control.MOUSE_FILTER_IGNORE
	btn.tooltip_text = effect_tooltip(page)
	return face

# ==================== 只读展示：自己弹提示框 ====================
const BigTooltipScript := preload("res://Core/ui/big_tooltip.gd")

## 只读展示（敌人意图卡面这种「点了也没用」的地方）：让这一行**自己吃鼠标**并弹 1.5 倍提示框。
## ⚠️ 手牌 / 商店里不要用它 —— 那些地方点击要落到宿主按钮上（见 `attach_to_button`）。
## 传空字符串 = 关掉提示并恢复 `MOUSE_FILTER_IGNORE`。
func set_hover_tooltip(text: String) -> void:
	tooltip_text = text
	mouse_filter = Control.MOUSE_FILTER_STOP if text != "" else Control.MOUSE_FILTER_IGNORE

func _make_custom_tooltip(for_text: String) -> Object:
	return BigTooltipScript.build(for_text)

## 触屏/不想悬停时：点一下弹全局说明面板（`GlobalTip`）。
## 只在 `set_hover_tooltip` 打开时生效 —— 手牌/商店的页行是 IGNORE，点击照旧落到宿主按钮。
const TooltipPanelScript := preload("res://Core/ui/tooltip_panel.gd")

func _gui_input(event: InputEvent) -> void:
	if tooltip_text == "":
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var at := get_global_rect().position + Vector2(0.0, size.y)
		TooltipPanelScript.show_near(self, tooltip_text, at)
		accept_event()

## 清掉按钮里之前嵌的卡面（刷新列表前用）
static func clear_button(btn: Button) -> void:
	for child in btn.get_children():
		child.queue_free()
	btn.text = ""
	btn.icon = null

## 这一行铺哪张底板：取页的第一个认得出的关键词，认不出用 normal 那张。
static func keyword_plate(keywords: Array[StringName]) -> String:
	for kw in keywords:
		if KEYWORD_PLATES.has(kw):
			return KEYWORD_PLATES[kw]
	return PLATE_FALLBACK

## 稀有度 → 画框文件名（0 普通 / 1 银 / 2 金），越界按最接近的那档。
static func rarity_frame(rarity: int) -> String:
	return RARITY_FRAMES[clampi(rarity, 0, RARITY_FRAMES.size() - 1)]

## 美术那边 `gold .png` 名字里带了个空格；两种写法都认（改名了也不会突然变空）。
static func _resolve_art_name(file_name: String) -> String:
	if ResourceLoader.exists(BOOK_ART_ROOT + file_name):
		return file_name
	var squeezed: String = file_name.replace(" ", "")
	if ResourceLoader.exists(BOOK_ART_ROOT + squeezed):
		return squeezed
	return file_name

static func _load_art(file_name: String) -> Texture2D:
	return load(BOOK_ART_ROOT + _resolve_art_name(file_name))

## 用一张图当底板/画框：`StyleBoxTexture` 会跟着卡面大小拉伸，格子大小随便变。
static func _texture_style(tex: Texture2D) -> StyleBoxTexture:
	var style := StyleBoxTexture.new()
	style.texture = tex
	return style

## 量画框的边框有多厚：沿中线从四条边往里扫，扫到透明处为止。
## 画框是**整体拉伸**的（不做 9-slice），所以边框在屏幕上的厚度 = 源图厚度 × 缩放比，
## 内容内边距就按同一个比例算 —— 美术把边框加粗/改细都不用动代码。
func _measure_frame_inset(tex: Texture2D) -> void:
	_frame_inset = Vector2.ZERO
	_frame_tex_size = Vector2.ZERO
	if tex == null:
		return
	var img: Image = tex.get_image()
	if img == null:
		return
	var w: int = img.get_width()
	var h: int = img.get_height()
	if w <= 0 or h <= 0:
		return
	_frame_tex_size = Vector2(w, h)
	var mid_x: int = w / 2
	var mid_y: int = h / 2
	var left := 0
	while left < mid_x and img.get_pixel(left, mid_y).a > FRAME_ALPHA_THRESHOLD:
		left += 1
	var right := 0
	while right < mid_x and img.get_pixel(w - 1 - right, mid_y).a > FRAME_ALPHA_THRESHOLD:
		right += 1
	var top := 0
	while top < mid_y and img.get_pixel(mid_x, top).a > FRAME_ALPHA_THRESHOLD:
		top += 1
	var bottom := 0
	while bottom < mid_y and img.get_pixel(mid_x, h - 1 - bottom).a > FRAME_ALPHA_THRESHOLD:
		bottom += 1
	_frame_inset = Vector2(
		mini(maxi(left, right), MAX_FRAME_INSET),
		mini(maxi(top, bottom), MAX_FRAME_INSET))

## 内容内边距 = 边框厚度 × 当前缩放比（卡面尺寸未知时先不动，等 `resized` 再来一次）
func _apply_frame_inset() -> void:
	if _frame_tex_size.x <= 0.0 or _frame_tex_size.y <= 0.0:
		return
	var sb: StyleBoxTexture = frame.get_theme_stylebox("panel")
	if sb == null:
		return
	var inset := Vector2(
		_frame_inset.x * size.x / _frame_tex_size.x,
		_frame_inset.y * size.y / _frame_tex_size.y)
	sb.content_margin_left = inset.x
	sb.content_margin_right = inset.x
	sb.content_margin_top = inset.y
	sb.content_margin_bottom = inset.y
