extends Node
## 全局卡牌库：管理卡牌定义、获得量与可使用量、掉落池与特殊池

const BOOKPAGE_DIR := "res://Data/bookpage/"
const SPECIAL_DIR := "res://Data/bookpage/girl's card/"
## 基础页（1 攻击 / 2 防御）单独一个目录。
## ⚠️ 它**必须**被扫进 `cards`，但**不能**进 `drop_pool`：
##    - 不进 cards → `add_acquired_only()` 里 `cards.has(book_id)` 为假，
##      书页会被静默丢掉，书签管理界面的可选列表里永远看不到它们（实际踩过的 bug）；
##    - 进 drop_pool → 它们会从商店/奖励里掉出来，而那两张是开局赠卡，不该掉落。
const BASE_DIR := "res://Data/bookpage/base/"
## 怪物专用页（`Data/bookpage/monster/`）：给野怪/Boss 的手牌用的特殊书页。
## 与 `base/` 同一个待遇 —— **必须**扫进 `cards`（资源能被解析、book_id 能被索引），
## 但**绝对不能**进 `drop_pool`：玩家不该从商店/奖励里抽到怪物的页。
## 取用入口是 `get_monster_pool()`（敌人建牌时按 book_id 从这里取）。
const MONSTER_DIR := "res://Data/bookpage/monster/"
## 目录名同时也是角色 pool_keywords 里写的 key，两边必须完全一致。
## ⚠️ 不在这里 = 不参与掉落。`base/` 刻意不在表内（见上）。
## ⚠️ 旧关键词（始源/维协/强压/统洁）的实现与旧卡已在 2026-10-18 清掉，`_retired/` 目录不再存在。
## 2026-09-23 改名：关键词 = 类别名（谱序 / 汐信 / 魇蚀 / 振鸣）
## 2026-09-25：**标识一律 ASCII** —— 关键词 id、目录名、文件编号前缀都用拼音缩写，
##   中文只做显示（`GlobalKeywordDict.display_name()`），不进逻辑（开发规范 §中文边界）。
## 关键词 id 同时就是目录名（`Data/bookpage/<id>/` 与 `Assets/Textures/Icons/bookpage/<id>/`）。
const KEYWORD_KEYS: Array[String] = ["normal", "PX", "XX", "YS", "ZM"]

var cards: Dictionary = {}                # book_id -> Generator_bookpage（全部）
var drop_pool: Array[Generator_bookpage] = []          # 全部正常卡
var current_drop_pool: Array[Generator_bookpage] = []  # 本局可掉落池
var special_pool: Array[Generator_bookpage] = []       # 特殊池
## 怪物专用页（不进掉落池，见 MONSTER_DIR 的注释）
var monster_pool: Array[Generator_bookpage] = []
var keyword_pools: Dictionary = {}         # keyword -> Array[Generator_bookpage]

var owned_cards: Dictionary = {}
var card_acquired_counts: Dictionary = {}
var card_usable_counts: Dictionary = {}

func _ready() -> void:
	_load_all_cards()

func _load_all_cards() -> void:
	cards.clear()
	drop_pool.clear()
	current_drop_pool.clear()
	special_pool.clear()
	monster_pool.clear()
	keyword_pools.clear()

	# 基础页：只登记进 cards（拿得到对象、能进 owned_cards），
	# **不**进 drop_pool / keyword_pools —— 它们是开局赠卡，不走商店与掉落。
	var base_pool: Array[Generator_bookpage] = []
	_scan_dir(BASE_DIR, base_pool)
	for card in base_pool:
		cards[card.book_id] = card

	for key in KEYWORD_KEYS:
		var pool: Array[Generator_bookpage] = []
		_scan_dir(BOOKPAGE_DIR + key + "/", pool)
		keyword_pools[key] = pool
		drop_pool.append_array(pool)

	_scan_dir(SPECIAL_DIR, special_pool)
	# 怪物专用页：登记进 cards（能被 load/索引），但不进 drop_pool / keyword_pools
	_scan_dir(MONSTER_DIR, monster_pool)

	for card in drop_pool:
		cards[card.book_id] = card
	for card in special_pool:
		cards[card.book_id] = card
	for card in monster_pool:
		cards[card.book_id] = card

func _scan_dir(dir_path: String, target_pool: Array[Generator_bookpage]) -> void:
	var files = ResourceLoader.list_directory(dir_path)
	for file_name in files:
		if file_name.ends_with(".tres"):
			var res = load(dir_path + file_name)
			if res is Generator_bookpage:
				target_pool.append(res)

# ==================== 本局掉落池 ====================
func build_current_pool(pool_keywords: Array[String]) -> void:
	current_drop_pool.clear()
	for key in pool_keywords:
		if keyword_pools.has(key):
			current_drop_pool.append_array(keyword_pools[key])

# ==================== 查询 ====================
func get_all_cards() -> Array[Generator_bookpage]:
	var arr: Array[Generator_bookpage] = []
	for key in cards.keys():
		arr.append(cards[key])
	arr.sort_custom(func(a, b): return a.book_id < b.book_id)
	return arr

func get_randomable_cards() -> Array[Generator_bookpage]:
	return current_drop_pool.duplicate()

func get_owned_cards() -> Array[Generator_bookpage]:
	var arr: Array[Generator_bookpage] = []
	for key in owned_cards.keys():
		if card_acquired_counts.get(key, 0) > 0:
			arr.append(owned_cards[key])
	arr.sort_custom(func(a, b): return a.book_id < b.book_id)
	return arr

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func get_card_by_book_id(id: int) -> Generator_bookpage:
	return cards.get(id)

## 怪物专用页全表（敌人建牌 / 调试用）。**不是**掉落池，玩家拿不到。
func get_monster_pool() -> Array[Generator_bookpage]:
	return monster_pool

## 按 book_id 列表取怪物页（敌人数据里写 id，比直接挂资源引用更好改）。
## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func get_monster_pages(book_ids: Array) -> Array[Generator_bookpage]:
	var arr: Array[Generator_bookpage] = []
	for id in book_ids:
		var page = cards.get(int(id))
		if page != null:
			arr.append(page)
	return arr

# ==================== 获得量 / 可使用量 ====================
func add_acquired_count(book_id: int, amount: int = 1) -> void:
	card_acquired_counts[book_id] = card_acquired_counts.get(book_id, 0) + amount
	card_usable_counts[book_id] = card_usable_counts.get(book_id, 0) + amount
	if cards.has(book_id) and not owned_cards.has(book_id):
		owned_cards[book_id] = cards[book_id]
	if cards.has(book_id):
		GlobalJourney.add_card(cards[book_id].page_name, amount)

func add_acquired_only(book_id: int, amount: int = 1) -> void:
	card_acquired_counts[book_id] = card_acquired_counts.get(book_id, 0) + amount
	if cards.has(book_id) and not owned_cards.has(book_id):
		owned_cards[book_id] = cards[book_id]

func use_card(book_id: int) -> bool:
	if card_usable_counts.get(book_id, 0) > 0:
		card_usable_counts[book_id] -= 1
		return true
	return false

func return_card(book_id: int, amount: int = 1) -> void:
	card_usable_counts[book_id] = card_usable_counts.get(book_id, 0) + amount

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func get_acquired_count(book_id: int) -> int:
	return card_acquired_counts.get(book_id, 0)

func get_usable_count(book_id: int) -> int:
	return card_usable_counts.get(book_id, 0)

# ==================== 重置 ====================
func reset() -> void:
	owned_cards.clear()
	card_acquired_counts.clear()
	card_usable_counts.clear()
	current_drop_pool.clear()
