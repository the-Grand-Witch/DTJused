extends Control
## 主场景的卡组互动逻辑
## ==================================================================
## 卡组**统一显示在玩家的手牌容器**里（`Player/player_hand_container`），
## 与战斗是完全同一套：选中 → 书签上移半张 + 右侧按页展开介绍框 + 手牌重新排布。
## 所以卡必须走 `player_ui.add_card()` 加进去 —— 那里会接上展开信号并触发排布。
##
## ⚠️ 以前这里另有一个 `Book/disply_bookmark` 容器（在场景里还是 `visible = false`），
##    已删除：两套显示会不同步，而且那套看不见手牌。
## ==================================================================

@onready var player: Node = $"../Player"
@onready var open_book_button: Button = $open

var book_instance: Node = null

func _ready() -> void:
	var bm = GlobalBookMark
	bm.bookmark_added.connect(_on_bookmark_added)
	bm.bookmark_removed.connect(_on_bookmark_removed)
	# 延迟一帧再刷新：Player 的 @onready（hand_container）要等它自己的 _ready 才赋值，
	# 而 _ready 顺序由节点在场景里的先后决定 —— Book 排在 Player 之前时同步调用会拿到 null。
	_refresh_bookmark_display.call_deferred()
	open_book_button.pressed.connect(_on_open_book_pressed)

func _on_bookmark_added(_data) -> void:
	# 延迟一帧再刷新：Player 的 @onready（hand_container）要等它自己的 _ready 才赋值，
	# 而 _ready 顺序由节点在场景里的先后决定 —— Book 排在 Player 之前时同步调用会拿到 null。
	_refresh_bookmark_display.call_deferred()

func _on_bookmark_removed(_data) -> void:
	# 延迟一帧再刷新：Player 的 @onready（hand_container）要等它自己的 _ready 才赋值，
	# 而 _ready 顺序由节点在场景里的先后决定 —— Book 排在 Player 之前时同步调用会拿到 null。
	_refresh_bookmark_display.call_deferred()

func _refresh_bookmark_display() -> void:
	player.clear_hand()
	for data in GlobalBookMark.bookmarks:
		var card = GlobalScenes.BOOKMARK_CARD_SCENE.instantiate()
		player.add_card(card)
		card.setup(data)

func _on_open_book_pressed() -> void:
	book_instance = GlobalScenes.BOOK_SCENE.instantiate()
	if book_instance is Control:
		book_instance.anchor_left = 0.0
		book_instance.anchor_top = 0.0
		book_instance.anchor_right = 1.0
		book_instance.anchor_bottom = 1.0
		book_instance.offset_left = 0
		book_instance.offset_top = 0
		book_instance.offset_right = 0
		book_instance.offset_bottom = 0
		book_instance.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(book_instance)

func _on_book_closed() -> void:
	book_instance = null
