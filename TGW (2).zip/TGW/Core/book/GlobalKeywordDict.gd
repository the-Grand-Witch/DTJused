extends Node
## 全局关键词字典：管理关键词描述与效果逻辑

var keyword_dict: Dictionary = {}

## 关键词显示名：中文**只**出现在这里与描述文本里；逻辑、资源、存档一律用 id（拼音缩写）。
const KEYWORD_NAMES := {
	"normal": "普通",
	"PX": "谱序",
	"XX": "汐信",
	"YS": "魇蚀",
	"ZM": "振鸣",
}

static func display_name(keyword: StringName) -> String:
	return KEYWORD_NAMES.get(String(keyword), String(keyword))

func _ready():
	_register_default_keywords()

func _register_default_keywords():
	keyword_dict["YS"] = {
		"description": "操作冲动与魔女化（力量来自魔女化 / 冲动）",
		"execute": _execute_declared
	}
	# ---- 现役四组：机制写在页资源的 keyword_ops 里，由声明式执行器跑 ----
	keyword_dict["PX"] = {
		"description": "按结算位置（段首 / 段中 / 段尾 / 孤立）触发",
		"execute": _execute_declared
	}
	keyword_dict["XX"] = {
		"description": "不打它，攒着，之后一次放",
		"execute": _execute_declared
	}
	keyword_dict["ZM"] = {
		"description": "页读它自己所在的那本书签",
		"execute": _execute_declared
	}

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func get_keyword_description(keyword_name: StringName) -> String:
	if keyword_dict.has(keyword_name):
		return keyword_dict[keyword_name]["description"]
	return ""

func execute_keyword(keyword_name: StringName, context) -> Dictionary:
	if keyword_dict.has(keyword_name):
		var func_ref = keyword_dict[keyword_name]["execute"]
		if func_ref is Callable:
			return func_ref.call(context)
	return {}

# ==================== 声明式执行器（谱序 / 汐信 / 振鸣） ====================
## 机制写在页资源的 keyword_ops 里，格式（卡牌设计稿.md §八.11）：
##   { "keyword": &"PX", "when": "left_is_attack", "then": { "add": {"damage": 4} } }
## 本执行器只做两件事：**筛出属于当前关键词的声明**、**把 when/then 里的表达式求值**。
## 真正的落地（改谁的什么值）由 BattleFlow.apply_keyword_result 做 —— 所以这里不认识
## 任何具体机制，加新卡只加 .tres 数据。
func _execute_declared(context) -> Dictionary:
	var page = context.get("self_page")
	var kw: StringName = context.get("keyword")
	var vars: Dictionary = context.get("kw_vars")
	var phase: String = context.get("keyword_phase", "use")
	var result := {}
	for op in page.keyword_ops:
		var op_dict: Dictionary = op
		# at 留空 = 打出时（use）；另有 round_end / round_start 两个回合级时机
		if String(op_dict.get("at", "use")) != phase:
			continue
		# keyword 留空 = 这一页的任意关键词都吃它（一页通常只有一个关键词，省得手填错）
		var op_keyword: StringName = op_dict.get("keyword", "")
		if op_keyword != &"" and op_keyword != kw:
			continue
		if not _condition_holds(op_dict.get("when", ""), vars):
			continue
		_merge_then(result, op_dict.get("then", {}), vars)
	return result

## when 留空 = 无条件；其余按表达式求值（真值判定按类型分开做）
## ⚠️ 不能写 `value != 0 and value != false`：表达式可能返回 bool（`a == b`）或数字
##    （`attack_pages`），拿 int 与 bool 比较会直接报错、整条声明失效。
func _condition_holds(expr, vars: Dictionary) -> bool:
	if expr is String and expr.strip_edges() == "":
		return true
	var value = _eval(expr, vars)
	if value == null:
		return false
	if value is bool:
		return value
	if value is int or value is float:
		return value != 0
	return false

## 数值槽位求值：字符串 = 表达式，数字 = 字面量
func _eval(expr, vars: Dictionary):
	if not (expr is String):
		return expr
	var e := Expression.new()
	if e.parse(expr, vars.keys()) != OK:
		push_error("[GlobalKeywordDict] 表达式解析失败：%s —— %s" % [expr, e.get_error_text()])
		return null
	return e.execute(vars.values(), null, true)

## 把 then 合并进结果。同名数值相加（多条声明同时成立时累计），数组类追加。
## 每个 match 分支都用各自局部的变量名，避免同名声明带来的歧义。
## then 里的一批声明 → 并进 `result`。**只做分派**（原来 106 行，审计 P1-3）：
##   数值类 `_merge_value_ops` / 目标类 `_merge_target_ops` / 其它 `_merge_misc_ops`。
func _merge_then(result: Dictionary, then_dict: Dictionary, vars: Dictionary) -> void:
	for key in then_dict:
		match key:
			"add", "set", "witch_power", "add_persistent", "set_persistent", "impulse":
				_merge_value_ops(key, then_dict[key], vars, result)
			"add_to", "set_to", "multiply_to", "extra_play", "page_cd", "card_cd":
				_merge_target_ops(key, then_dict[key], vars, result)
			_:
				_merge_misc_ops(key, then_dict[key], vars, result)

## 数值类：直接加/覆盖到自己的某个**具名字典**（add / set / add_persistent / set_persistent / impulse / witch_power）
func _merge_value_ops(key: String, spec, vars: Dictionary, result: Dictionary) -> void:
	# 语义按动词分两派：add / add_persistent / witch_power / impulse 都是「累加」，
	# set / set_persistent 是「覆盖」——和拆分前逐字一致，别合并这两派。
	var bucket: Dictionary = result.get(key, {})
	for field in spec:
		var field_value = _eval(spec[field], vars)
		if key in ["add", "add_persistent", "witch_power", "impulse"]:
			bucket[field] = bucket.get(field, 0) + field_value
		else:
			bucket[field] = field_value
	result[key] = bucket

## 目标类：作用于**别的页**，结果是一组「谁 + 值」的条目数组（回填在 apply_keyword_result 里做）
func _merge_target_ops(key: String, spec, vars: Dictionary, result: Dictionary) -> void:
	var list: Array = result.get(key, [])
	match key:
		"add_to", "set_to", "multiply_to":
			for item in _dict_entries(spec):
				list.append(_eval_entry(item, vars))
		"extra_play":
			for item in _number_entries(spec, "n"):
				var play_spec: Dictionary = item
				list.append({"who": play_spec.get("who", "self"), "n": _eval(play_spec.get("n", 1), vars)})
		"page_cd":
			for item in _number_entries(spec, "add"):
				var cd_spec: Dictionary = item
				var cd_entry: Dictionary = {"who": cd_spec.get("who", "self")}
				if cd_spec.has("set"):
					cd_entry["set"] = _eval(cd_spec["set"], vars)
				else:
					cd_entry["add"] = _eval(cd_spec.get("add", 0), vars)
				list.append(cd_entry)
		"card_cd":
			for item in _number_entries(spec, "set"):
				var card_cd_spec: Dictionary = item
				list.append({"who": card_cd_spec.get("who", "self"), "set": _eval(card_cd_spec.get("set", 0), vars)})
	result[key] = list

## 其它：重触发 / 延迟 / 标记 / 主类型加算 / 关键词重放 / 对调 / 日志；不认识的键原样保留
func _merge_misc_ops(key: String, spec, vars: Dictionary, result: Dictionary) -> void:
	match key:
		"retrigger":
			var chain: Array = result.get("retrigger", [])
			for item in _who_entries(spec):
				var chain_spec: Dictionary = item
				chain.append({"who": chain_spec.get("who", "self")})
			result["retrigger"] = chain
		"pending", "flags", "add_main":
			var list: Array = result.get(key, [])
			for item in _dict_entries(spec):
				var item_spec: Dictionary = item.duplicate()
				if item_spec.has("value"):
					item_spec["value"] = _eval(item_spec["value"], vars)
				if item_spec.has("main"):
					item_spec["main"] = _eval(item_spec["main"], vars)
				list.append(item_spec)
			result[key] = list
		"repeat_keyword":
			var repeats: Array = result.get("repeat_keyword", [])
			for item in _who_entries(spec):
				var repeat_spec: Dictionary = item
				repeats.append({"who": repeat_spec.get("who", "self"), "times": _eval(repeat_spec.get("times", 1), vars)})
			result["repeat_keyword"] = repeats
		"swap":
			result["swap"] = spec
		"log":
			result["log"] = spec
		_:
			result[key] = spec

## 数组类的声明统一成字典数组：单个字典 / 数组都收
func _dict_entries(spec) -> Array:
	var out: Array = []
	if spec is Array:
		for item in spec:
			var entry: Dictionary = item
			out.append(entry)
	else:
		var single: Dictionary = spec
		out.append(single)
	return out

## 数值型声明：字符串 / 数字 = 只填数值槽（who 默认 self）
func _number_entries(spec, number_key: String) -> Array:
	var out: Array = []
	var items: Array = spec if spec is Array else [spec]
	for item in items:
		if item is Dictionary:
			var entry: Dictionary = item
			out.append(entry)
		else:
			var bare: Dictionary = {"who": "self"}
			bare[number_key] = item
			out.append(bare)
	return out

## 目标型声明：字符串 = 只填 who
func _who_entries(spec) -> Array:
	var out: Array = []
	var items: Array = spec if spec is Array else [spec]
	for item in items:
		if item is Dictionary:
			var entry: Dictionary = item
			out.append(entry)
		else:
			out.append({"who": item})
	return out

## add_to / set_to / multiply_to 的条目：who 与 field 是字面量，value 求值
func _eval_entry(entry: Dictionary, vars: Dictionary) -> Dictionary:
	var out: Dictionary = entry.duplicate()
	if out.has("value"):
		out["value"] = _eval(out["value"], vars)
	return out
