extends PanelContainer
class_name BookmarkDisplay

@onready var card: BookmarkCard = get_parent()
@onready var title_label: Label = $TextureRect/TitleLabel
@onready var pages_vbox: VBoxContainer = $TextureRect/PagesVBox
@onready var page_info_vbox: VBoxContainer = $"../PageInfoVBox"

## 卡面脚本：用 preload 而不是全局类名 —— 新建的脚本要等编辑器扫一遍才会进
## `.godot/global_script_class_cache.cfg`，headless 里靠类名会直接 `Identifier not found`。
const PageFaceScript := preload("res://Core/book/page_face.gd")

const BORDER_COLOR := Color(1, 0.8, 0, 1)
const BORDER_WIDTH := 4

## 每页在书签里占**一行**：一行就是一张 `PageFace`（关键词底色 + 稀有度画框 + 卡名（+强化）+ 效果 + cd）。
## 每一行 size_flags_vertical = EXPAND_FILL，所以 VBox 会把可用高度**等分**给各页。
## ⚠️ 2026-09-23：48 张卡图短期补不齐，行内**不再显示卡图**（原来这里放 150×200 的 icon），
##    一律显示上面那四样；要放图也是以后画好之后的事。
const PAGE_NAME_FONT_SIZE := 18
const TITLE_FONT_SIZE := 28

## 选中展开：书签上移自身高度的这个比例，右侧列出每页的介绍框
const LIFT_RATIO := 0.5
const PAGE_INFO_FONT_SIZE := 18
const PAGE_INFO_SEPARATION := 2
const NO_DESCRIPTION := "（无说明）"

var default_style: StyleBox
var page_rows: Array[Control] = []      ## 每页一行（就是一个 `PageFace`；冲动高亮 modulate 染它 ⇒ 底色与画框一起被染）
var page_labels: Array[Label] = []      ## 行里的名字标签，留给需要单独改文字的地方
var page_info_boxes: Array[Control] = []  ## 右侧每页一个介绍框
var _expanded := false

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	# 未选中时**不画面板**（场景里已经把 panel 覆盖成 StyleBoxEmpty）——
	# 否则会露出 Godot 默认主题那个深色方框，就是书签后面那圈黑边。
	default_style = get_theme_stylebox("panel")
	# 书签本体（画贴图 + 每一行的那块）宽 = **场景里定义的宽度**，高跟着卡片。
	# ⚠️ 选中展开时**只把卡片节点拉宽**（给右侧介绍框留位置），
	#    本体绝不跟着拉伸 —— 不然书签会被"额外黑框"一起拽宽。
	anchor_right = 0.0
	anchor_bottom = 1.0
	offset_left = 0.0
	offset_top = 0.0
	offset_right = card.collapsed_width
	offset_bottom = 0.0
	page_info_vbox.visible = false
	page_info_vbox.add_theme_constant_override("separation", PAGE_INFO_SEPARATION)
	# 书签名一行显示：放不下先缩字号（`_refresh_font_scale`），缩到下限还放不下就**裁掉超出部分**，
	# 保证它永远不会溢出书签本体。
	title_label.clip_text = true
	resized.connect(_refresh_font_scale)
	_refresh_font_scale()

	card.selection_changed.connect(_on_selection_changed)
	card.cd_changed.connect(_on_cd_changed)
	card.data_changed.connect(_on_data_changed)

	if card.Generator_bookmark:
		_refresh_all()
		_on_cd_changed(card.current_cd)

func _refresh_all() -> void:
	title_label.text = card.Generator_bookmark.title
	_rebuild_pages()
	if _expanded:
		_rebuild_page_info()
		_align_page_info.call_deferred()
	# 页数变了 ⇒ 书签高度要跟着变（固定部分 + 行高 × 页数）
	_apply_row_metrics.call_deferred()
	# 名字/标题都可能换了，重算一次字号（含"放不下就缩"）
	_refresh_font_scale.call_deferred()

## **固定部分** = 页区上边距 + 下边距 —— 这两个都是 `PagesVBox` 的**像素偏移**（锚点只负责跟随卡片宽高），
## 所以它跟页数、跟卡片当前高度都无关，随时算都一致。
## 总高则交给卡片：`固定部分 + 行高 × 页数`（行高是 `BookmarkCard.row_height`，检查器可调）。
func _apply_row_metrics() -> void:
	if card.Generator_bookmark == null:
		return
	var count: int = card.Generator_bookmark.pages.size()
	if count <= 0:
		return
	var fixed: float = pages_vbox.offset_top - pages_vbox.offset_bottom
	card.apply_row_metrics(fixed, count)
	_refresh_font_scale()

## 字号缩放：跟着**行高**走（不跟总高）—— 页数少了书签变短，字不会跟着缩小
func _font_scale() -> float:
	return clampf(card.ui_scale(), 0.5, 4.0)

func _refresh_font_scale() -> void:
	var s: float = _font_scale()
	var title_size: int = int(round(TITLE_FONT_SIZE * s))
	title_label.add_theme_font_size_override("font_size", title_size)
	# 书签名放不下就自动缩小（单行不换行）
	PageFaceScript.fit_label_width(title_label, title_size, _label_avail_width(title_label))
	for row in page_rows:
		row.set_font_sizes(int(round(PAGE_NAME_FONT_SIZE * s)))
	for box in page_info_boxes:
		var label := box.get_child(0)
		if label is Label:
			label.add_theme_font_size_override("font_size", int(round(PAGE_INFO_FONT_SIZE * s)))

## 标签**能用的宽度**：按锚点算，**不能用 `label.size.x`** ——
## 文字变长会把 Label 自己的最小尺寸顶大（`size.x` 跟着变长），拿它当上限等于永远放得下。
func _label_avail_width(label: Label) -> float:
	var parent_w: float = label.get_parent_area_size().x
	return parent_w * (label.anchor_right - label.anchor_left) + label.offset_right - label.offset_left

## 重建每一页的**卡面行**（关键词底色 + 稀有度画框 + 卡名 + 编号·cd，见 `PageFace`）
func _rebuild_pages() -> void:
	for child in pages_vbox.get_children():
		child.queue_free()
	page_rows.clear()
	page_labels.clear()

	for page in card.Generator_bookmark.pages:
		# 一行就是一张卡面；`page_rows` 里存它 ⇒ 冲动高亮 modulate 时底色与画框一起被染。
		var face := PageFaceScript.new()
		face.setup(page)
		face.set_font_sizes(_scaled(PAGE_NAME_FONT_SIZE))
		face.size_flags_vertical = Control.SIZE_EXPAND_FILL
		pages_vbox.add_child(face)
		page_rows.append(face)
		page_labels.append(face.name_label)
	# 只读展示时，新行建好后要把悬浮说明重新挂上
	_apply_page_tooltips()

## 基准字号 × 当前缩放倍数（四舍五入到整数）
func _scaled(base_size: int) -> int:
	return int(round(base_size * _font_scale()))

func get_page_row_by_index(idx: int) -> Control:
	if idx >= 0 and idx < page_rows.size():
		return page_rows[idx]
	return null

# ==================== 只读展示：每页悬浮说明 ====================
## 敌人意图卡面这种地方用：鼠标放到某一页上就弹这一页的效果说明（1.5 倍提示框）。
## 默认关（手牌里点击要落到书签本体上，页行不能吃鼠标）。
var page_tooltips_enabled := false

func set_page_tooltips(enabled: bool) -> void:
	page_tooltips_enabled = enabled
	_apply_page_tooltips()

## 书签名是否显示。镜像的书签标题会带角色名（「汉娜的书签」），
## Boss 的意图卡面统一不显示名称，避免剧透镜像是谁。
var title_visible := true

func set_title_visible(enabled: bool) -> void:
	title_visible = enabled
	title_label.visible = enabled
	if not enabled:
		title_label.text = ""

func _apply_page_tooltips() -> void:
	if card.Generator_bookmark == null:
		return
	var pages: Array = card.Generator_bookmark.pages
	for i in range(page_rows.size()):
		if i >= pages.size():
			continue
		var row = page_rows[i]
		if page_tooltips_enabled:
			row.set_hover_tooltip(PageFaceScript.effect_tooltip(pages[i]))
		else:
			row.set_hover_tooltip("")

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if not event.pressed:
			card._on_clicked()

# ==================== 信号响应 ====================
func _on_selection_changed(selected: bool) -> void:
	if selected:
		var style := StyleBoxFlat.new()
		style.bg_color = Color(0, 0, 0, 0)
		style.border_color = BORDER_COLOR
		style.set_border_width_all(BORDER_WIDTH)
		add_theme_stylebox_override("panel", style)
		_expand()
	else:
		add_theme_stylebox_override("panel", default_style)
		_collapse()

# ==================== 选中展开 ====================
## 选中：书签本体上移自身高度的 LIFT_RATIO，右侧按页数列出介绍框。
## 卡片加宽交给 BookmarkCard.set_expanded()——它会发 expand_changed，手牌据此重排
## （排布规则见 BookmarkCard.layout_row）。
func _expand() -> void:
	_expanded = true
	var lift: float = size.y * LIFT_RATIO
	offset_top = -lift
	offset_bottom = -lift
	_rebuild_page_info()
	page_info_vbox.visible = true
	card.set_expanded(true)
	await get_tree().process_frame      # 等手牌把位置排完，再对齐介绍框
	_align_page_info()

func _collapse() -> void:
	_expanded = false
	offset_top = 0.0
	offset_bottom = 0.0
	page_info_vbox.visible = false
	card.set_expanded(false)

## 介绍框底色：**必须不透明** —— 介绍框是盖在手牌/别的书签上的，透底就看不清字了。
## 换纸色改这里。
const PAGE_INFO_BG := Color(0.976471, 0.956863, 0.898039, 1.0)
## 介绍框文字颜色（黑字配纸色底）
const PAGE_INFO_FONT_COLOR := Color(0, 0, 0, 1.0)
## 介绍框左右内边距（文字不要顶边）
const PAGE_INFO_PAD := 8.0

## 每页一个介绍框。用和书页行相同的 separation + EXPAND_FILL，
## 于是介绍框的行高与书签里的书页行一一对应。
func _rebuild_page_info() -> void:
	for child in page_info_vbox.get_children():
		child.queue_free()
	page_info_boxes.clear()
	for page in card.Generator_bookmark.pages:
		# 介绍框只用来显示，**一律不吃点击**（它是盖在手牌上的，吃了会挡住别的书签）
		var box := PanelContainer.new()
		# 不透明底：默认主题的面板是半透明的，盖在别的书签上会透出来
		var style := StyleBoxFlat.new()
		style.bg_color = PAGE_INFO_BG
		style.content_margin_left = PAGE_INFO_PAD
		style.content_margin_right = PAGE_INFO_PAD
		box.add_theme_stylebox_override("panel", style)
		box.size_flags_vertical = Control.SIZE_EXPAND_FILL
		box.mouse_filter = Control.MOUSE_FILTER_IGNORE

		var label := Label.new()
		label.text = page.description if page.description != "" else NO_DESCRIPTION
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		label.add_theme_font_size_override("font_size", PAGE_INFO_FONT_SIZE)
		label.add_theme_color_override("font_color", PAGE_INFO_FONT_COLOR)
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(label)

		page_info_vbox.add_child(box)
		page_info_boxes.append(box)

## 把介绍框区摆到书签本体右侧，纵向直接**复用书页行的范围** ——
## 上下边界与 separation 都一致，所以第 i 个框天然与第 i 行书页平行。
func _align_page_info() -> void:
	if not _expanded:
		return
	var rows := pages_vbox.get_global_rect()
	var card_origin := card.get_global_position()
	page_info_vbox.position = Vector2(
		card.collapsed_width + card.page_info_gap(),
		rows.position.y - card_origin.y)
	page_info_vbox.size = Vector2(card.page_info_width(), rows.size.y)

func _on_cd_changed(cd: int) -> void:
	var gray: Color
	match cd:
		0: gray = Color(1, 1, 1, 1)
		1: gray = Color(0.7, 0.7, 0.7, 1)
		2: gray = Color(0.5, 0.5, 0.5, 1)
		3: gray = Color(0.4, 0.4, 0.4, 1)
		_: gray = Color(0.2, 0.2, 0.2, 1)
	modulate = gray
	mouse_filter = Control.MOUSE_FILTER_IGNORE if cd > 0 else Control.MOUSE_FILTER_STOP

func _on_data_changed() -> void:
	_refresh_all()
