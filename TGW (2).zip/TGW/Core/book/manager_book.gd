extends Control
## 书签创建/编辑界面控制器

## 卡面脚本：用 preload 而不是全局类名（新脚本要等编辑器扫过才进类缓存）
const PageFaceScript := preload("res://Core/book/page_face.gd")

## 书页格子的大小（**想放大书页就改这里**）。列数按滚动区宽度算 ⇒ 面板变宽变窄时
## 书页只会变多/变少，不会被压扁。（取 148 是让 619 宽的滚动区刚好排下 4 列。）
const CARD_CELL_SIZE := Vector2(148, 48)
const CARD_NAME_FONT_SIZE := 18

@onready var add_bookmark_button: Button = $AddBookMark
@onready var bookmark_name_input: LineEdit = $BookMarkName
@onready var back_button: Button = $esc
@onready var card_scroll: ScrollContainer = $CardScroll
@onready var card_grid: GridContainer = $CardScroll/CardGrid
@onready var selected_pages_label: Label = $SelectedPagesLabel
@onready var undo_button: Button = $CancelButton
@onready var delete_bookmark_button: Button = $DeleteBookmarkButton
@onready var delete_panel: PanelContainer = $DeletePanel
@onready var bookmark_option: OptionButton = $DeletePanel/VBoxContainer/BookmarkOption
@onready var confirm_delete_button: Button = $DeletePanel/VBoxContainer/ConfirmDeleteButton
@onready var cancel_delete_button: Button = $DeletePanel/VBoxContainer/CancelDeleteButton

var current_bookmark: Generator_bookmark

func _ready() -> void:
	add_bookmark_button.pressed.connect(_on_add_bookmark_pressed)
	back_button.pressed.connect(_on_back_pressed)
	undo_button.pressed.connect(_on_undo_pressed)
	bookmark_name_input.max_length = 12
	delete_bookmark_button.pressed.connect(_on_delete_bookmark_button_pressed)
	confirm_delete_button.pressed.connect(_on_confirm_delete_pressed)
	cancel_delete_button.pressed.connect(_on_cancel_delete_pressed)

	delete_panel.visible = false
	bookmark_name_input.alignment = HORIZONTAL_ALIGNMENT_CENTER

	current_bookmark = Generator_bookmark.new()
	current_bookmark.icon = preload("res://Assets/Textures/Icons/book/bookmark.png")
	bookmark_name_input.text = "未命名书签%d" % (GlobalBookMark.bookmarks.size() + 1)
	# 列数按滚动区宽度算（首次布局前宽度还是 0，所以也挂到 resized 上重算一次）
	card_scroll.resized.connect(_update_grid_columns)
	_update_grid_columns()
	_refresh_card_grid()

## 书页格子**保持这个尺寸**，列数按滚动区宽度算 —— 面板变宽变窄时书页不会被压扁。
func _update_grid_columns() -> void:
	var sep: float = float(card_grid.get_theme_constant("h_separation"))
	var w: float = card_scroll.size.x - 8.0        # 给滚动条留一点
	card_grid.columns = maxi(1, int((w + sep) / (CARD_CELL_SIZE.x + sep)))

## 刷新卡牌选择网格
func _refresh_card_grid() -> void:
	for child in card_grid.get_children():
		card_grid.remove_child(child)
		child.queue_free()

	for card in GlobalCardLibrary.get_owned_cards():
		# 卡图还没画（48 张短期补不齐）：格子里直接嵌一张卡面 = 关键词底色 + 稀有度画框 + 卡名（能力页带「强化」）+ 效果 + cd
		var card_button := Button.new()
		card_button.custom_minimum_size = CARD_CELL_SIZE
		PageFaceScript.attach_to_button(card_button, card, CARD_NAME_FONT_SIZE)

		var usable = GlobalCardLibrary.get_usable_count(card.book_id)
		if usable > 0:
			card_button.disabled = false
			card_button.modulate = Color(1, 1, 1)
		else:
			card_button.disabled = true
			card_button.modulate = Color(0.5, 0.5, 0.5)

		card_button.pressed.connect(_on_card_selected.bind(card))
		card_grid.add_child(card_button)

## 选中卡牌逻辑
func _on_card_selected(card: Generator_bookpage) -> void:
	if current_bookmark:
		var page_limit = GlobalBookMark.BASE_PAGE_LIMIT + GlobalAccessories.get_bookmark_page_limit_up()
		if current_bookmark.pages.size() >= page_limit:
			GlobalPlayer.show("书签已满，无法添加更多卡牌")
			return

		if not GlobalCardLibrary.use_card(card.book_id):
			GlobalPlayer.show("卡牌数量不足")
			return

		current_bookmark.pages.append(card)
		_update_selected_pages_display()
		_refresh_card_grid()

## 撤销上一步操作
func _on_undo_pressed() -> void:
	if current_bookmark and current_bookmark.pages.size() > 0:
		var removed_page = current_bookmark.pages.pop_back()
		GlobalCardLibrary.return_card(removed_page.book_id, 1)
		_update_selected_pages_display()
		_refresh_card_grid()
	else:
		GlobalPlayer.hint_requested.emit("没有可撤销的操作")

## 更新已选卡牌文本显示
func _update_selected_pages_display() -> void:
	if not selected_pages_label:
		return
	var names: PackedStringArray = []
	for page in current_bookmark.pages:
		names.append(page.page_name)
	selected_pages_label.text = "\n".join(names)

## 点击返回按钮
func _on_back_pressed() -> void:
	_return_current_pages()
	if get_parent() and get_parent().has_method("_on_book_closed"):
		get_parent()._on_book_closed()
	queue_free()
	get_viewport().set_input_as_handled()

## 全局输入处理（ESC键）
func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_return_current_pages()
		if get_parent() and get_parent().has_method("_on_book_closed"):
			get_parent()._on_book_closed()
		queue_free()
		get_viewport().set_input_as_handled()

## 点击保存书签
func _on_add_bookmark_pressed() -> void:
	var bookmark_limit = GlobalBookMark.BASE_BOOKMARK_LIMIT + GlobalAccessories.get_bookmark_limit_up()
	if GlobalBookMark.bookmarks.size() >= bookmark_limit:
		GlobalPlayer.show("已经写不下了")
		return
	var bookmark_text := bookmark_name_input.text.strip_edges()
	if bookmark_text == "":
		bookmark_text = "未命名书签%d" % (GlobalBookMark.bookmarks.size() + 1)
	current_bookmark.title = bookmark_text
	GlobalBookMark.add_bookmark(current_bookmark)
	current_bookmark = Generator_bookmark.new()
	current_bookmark.icon = preload("res://Assets/Textures/Icons/book/bookmark.png")
	bookmark_name_input.text = "未命名书签%d" % (GlobalBookMark.bookmarks.size() + 1)
	_update_selected_pages_display()

## 刷新删除面板下拉列表
func _refresh_bookmark_option() -> void:
	bookmark_option.clear()
	var bm = GlobalBookMark
	for bookmark in bm.bookmarks:
		bookmark_option.add_item(bookmark.title)
	if bm.bookmarks.size() == 0:
		bookmark_option.add_item("无书签")
		bookmark_option.disabled = true
	else:
		bookmark_option.disabled = false

## 点击删除按钮
func _on_delete_bookmark_button_pressed() -> void:
	_refresh_bookmark_option()
	delete_panel.visible = true

## 取消删除
func _on_cancel_delete_pressed() -> void:
	delete_panel.visible = false

## 确认删除
## ⚠️ 返还书页**只由 `GlobalBookMark.remove_bookmark()` 做一处**：
##    以前这里先 return_card 再 remove_bookmark（里面又 return 一次）⇒ 每页白涨 2 点可用量。
func _on_confirm_delete_pressed() -> void:
	var selected_idx = bookmark_option.selected
	if selected_idx == -1:
		GlobalPlayer.hint_requested.emit("未选择书签")
		return
	var Generator_bookmark = GlobalBookMark.bookmarks[selected_idx]
	GlobalBookMark.remove_bookmark(Generator_bookmark)
	delete_panel.visible = false
	_refresh_card_grid()
	GlobalPlayer.hint_requested.emit("书签已删除")

func _return_current_pages() -> void:
	if current_bookmark:
		for page in current_bookmark.pages:
			GlobalCardLibrary.return_card(page.book_id, 1)
		current_bookmark.pages.clear()
