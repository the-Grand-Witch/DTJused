extends Control
class_name BookmarkCard

signal selection_changed(selected: bool)
signal card_confirmed(card: BookmarkCard)
signal cd_changed(current_cd: int)
signal data_changed()
## 选中展开 / 收起。手牌据此重新排布（见 layout_row）
signal expand_changed(expanded: bool)
## 行高 / 总高变了（手牌据此重新排布）
signal metrics_changed

# ==================== 手牌几何 ====================
## 尺寸规则（2026-09-25 最终）：
##   **宽** = `bookmark.tscn` 根节点摆的宽度（`_enter_tree()` 从场景读）；
##   **高** = **头部固定 + 行高 × 页数** —— 页数变了书签自己变长/变短（下半部分伸缩）。
##   头部与行高由显示层**量一次参考布局**得到（见 `apply_row_metrics`），
##   所以场景里摆的那个高度＝「参考页数下的高度」，摆多少就是多少，不用改代码。
const BASE_WIDTH := 150.0          ## 字号基准宽度（150 宽时就是 display_bookmark 里那套字号）
const BASE_HEIGHT := 270.0         ## 行高还没量出来时的兜底高度基准
const BASE_ROW_HEIGHT := 38.0      ## 字号基准**行高**：行高 38px 时字号就是基准（标题 28 / 卡名 18 / cd 14）
								   ## 字号按行高缩放，**与页数无关**（页数只改书签多长，不改字多大）
const PAGE_INFO_GAP := 12.0        ## 书签本体与右侧介绍框之间的间距
const PAGE_INFO_WIDTH := 260.0     ## 介绍框宽度
const HAND_SEPARATION := 8.0       ## 手牌里卡片之间的间距

var collapsed_width := BASE_WIDTH      ## 收起时的宽度（`_enter_tree()` 从场景读）
var collapsed_height := BASE_HEIGHT    ## 收起时的高度（= 固定部分 + 行高 × 页数）
## **一行（一张卡面）的高度** —— "下半部分"伸缩的单位：
##   总高 = 固定部分（头部 + 底部留白）+ 行高 × 页数，页数变了书签自己变长/变短。
## 在编辑器里选中 `bookmark.tscn` 的根节点，这个值就在检查器里，可以直接调。
@export var row_height := 46.0
var _fixed_height := 0.0               ## 头部 + 底部留白（不随页数变，从场景量一次）
var _metrics_ready := false

var Generator_bookmark: Generator_bookmark
var current_cd: int = 0
var page_marks: Array[Dictionary] = []
var is_selected := false
## 本书签在本场战斗里被打出过几次（振鸣的「振鸣度」读它）。setup() 时清零。
var battle_play_count: int = 0
## 冷却缩减的来源。默认 -1 = 现读玩家的 GlobalAccessories（玩家侧保持原行为）；
## 镜像的卡由 enemy.gd 在 setup() 时传自己的值，否则「玩家的钢笔会给镜像减 CD」，
## 而镜像自己的钢笔反而无效。
var cd_reload: int = -1

func _enter_tree() -> void:
	# 尺寸**以 `bookmark.tscn` 上摆的为准**，而且**用节点自己的 size 读**
	#   （在编辑器里拖边框改的是 anchors/offsets ⇒ 反映到 `size`；只读 `custom_minimum_size` 会漏掉拖动）。
	# ⚠️ 必须在这里读、不能放 `_ready()`：**子节点的 `_ready()` 先于父节点执行**，
	#    放 `_ready()` 的话子节点（BookmarkDisplay）拿到的还是默认 150。
	# 手牌容器只决定"能摆多大地方"，**不拉伸书签**。
	collapsed_width = size.x if size.x > 0.0 else custom_minimum_size.x
	collapsed_height = size.y if size.y > 0.0 else BASE_HEIGHT
	# 归一：让 `custom_minimum_size` 与读到的宽度一致（`set_expanded()` / `layout_row()` 都看它）
	custom_minimum_size = Vector2(collapsed_width, custom_minimum_size.y)
	# 场景里摆的这个高度是**参考页数下的高度**，行高/头部要等显示层量完才定（见 apply_row_metrics）

func _ready() -> void:
	# ⚠️ 卡片自己**要能收点击**：正常路径是书签本体（`BookmarkDisplay`，STOP）先接住，
	#    轮不到这里；但万一本体的 rect 没盖住某处（尺寸/锚点被改乱），
	#    下面这个 `_gui_input` 就是兜底 —— 保证"点书签"这件事一定有人接。
	mouse_filter = Control.MOUSE_FILTER_STOP

## 兜底点击：只有点在本体范围（x < 本体宽）才算点书签；
## 右侧那块是给介绍框留的位置，点它不该把书签打出去。
func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb: InputEventMouseButton = event
		if mb.button_index == MOUSE_BUTTON_LEFT and not mb.pressed and mb.position.x <= collapsed_width:
			_on_clicked()
			accept_event()

## 字号缩放：**按行高算**（不是按总高）—— 页数少了书签变短，字不会跟着变小。
func ui_scale() -> float:
	if row_height > 0.0:
		return row_height / BASE_ROW_HEIGHT
	return collapsed_height / BASE_HEIGHT

## 显示层量完参考布局后回调：`fixed_height` = 头部 + 底部留白（不随页数变）。
## 总高 = 固定部分 + `row_height` × 页数 —— 页数增删时书签下半部分自己伸缩。
func apply_row_metrics(fixed_height: float, page_count: int) -> void:
	if not _metrics_ready:
		_fixed_height = fixed_height
		_metrics_ready = true
	var wanted: float = _fixed_height + row_height * float(maxi(1, page_count))
	if is_equal_approx(collapsed_height, wanted):
		return
	collapsed_height = wanted
	metrics_changed.emit()

## 展开后的总宽（书签本体 + 间距 + 介绍框，后两者一起缩放）
func expanded_width() -> float:
	return collapsed_width + page_info_gap() + page_info_width()

func page_info_gap() -> float:
	return PAGE_INFO_GAP * ui_scale()

func page_info_width() -> float:
	return PAGE_INFO_WIDTH * ui_scale()

func setup(data: Generator_bookmark, reload: int = -1) -> void:
	Generator_bookmark = data
	cd_reload = reload
	current_cd = 0
	battle_play_count = 0
	_init_page_marks()
	data_changed.emit()
	cd_changed.emit(current_cd)

func _cd_reload() -> int:
	if cd_reload >= 0:
		return cd_reload
	return GlobalAccessories.get_bookpage_cd_reload()

# ==================== 标记 ====================
## page_marks[i] 的三类分区（见 卡牌设计稿.md §八.4）：
##   · 本回合区（每回合被 reset_round_modifiers 清）：cd_remaining / play_count /
##     overall_* / snapshots / effects / pending / retriggered / page_type
##   · 本场区（只被 setup 清）：use_count / persistent
##   · ⚠️ page_type 是**运行态副本**（可被 振鸣-A3 这类效果改），必须 duplicate ——
##     直接引用的话改它会写进 .tres 资源，跨战斗残留并且玩家与镜像互相污染。
func _init_page_marks() -> void:
	page_marks.clear()
	var cid = get_instance_id()
	for i in range(Generator_bookmark.pages.size()):
		var page = Generator_bookmark.pages[i]
		page_marks.append({
			"card_id": cid,
			"page_index": i,
			"page_type": page.page_type.duplicate(),
			"page_position": "bookmark",
			"cd_remaining": max(0, page.cd - _cd_reload()),
			"usable": current_cd <= 0,
			"used": false,
			"use_count": 0,
			"play_count": 1,
			"overall_multiplier": 1.0,
			"overall_sum": 0,
			"snapshots": [],
			"effects": {},
			"pending": [],
			"retriggered": false,
			"persistent": {},
			"values": {
				"damage": page.damage,
				"healing": page.healing,
				"armor": page.armor,
				"witchpower": page.witchpower,
				"count": page.count,
				"effect_damage": page.effect_damage,
				"effect_healing": page.effect_healing,
				"effect_armor": page.effect_armor,
				"effect_witchpower": page.effect_witchpower,
				"effect_count": page.effect_count,
				"effect_play_count": page.effect_play_count,
			},
		})

func get_page_mark(page_index: int) -> Dictionary:
	if page_index < 0 or page_index >= page_marks.size():
		return {}
	return page_marks[page_index]

func get_all_marks() -> Array[Dictionary]:
	return page_marks

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func set_page_position(page_index: int, pos: String) -> void:
	if page_index < 0 or page_index >= page_marks.size():
		return
	page_marks[page_index]["page_position"] = pos

## 运行态类型（关键词可以改它；每回合被 reset_round_modifiers 回滚到资源的 page_type）
func get_runtime_types(page_index: int) -> Array:
	return page_marks[page_index]["page_type"]

## 本页的本场持久区（汐信的层数这类跨回合累计放这里）
func get_persistent(page_index: int) -> Dictionary:
	return page_marks[page_index]["persistent"]

func _update_usable_marks() -> void:
	for mark in page_marks:
		mark["usable"] = current_cd <= 0

# ==================== values 只读 ====================
func get_values(page_index: int) -> Dictionary:
	if page_index < 0 or page_index >= page_marks.size():
		return {}
	return page_marks[page_index].get("values", {})

func get_value(page_index: int, field: String):
	var v = get_values(page_index)
	return v.get(field, 0)

# ==================== 回合重置 ====================
## 把本回合区全部回滚到资源初始值。
## ⚠️ use_count（本页本场打出次数）与 persistent（本场持久区）**不在这里清**。
func reset_round_modifiers() -> void:
	for i in range(page_marks.size()):
		var page = Generator_bookmark.pages[i]
		page_marks[i]["page_type"] = page.page_type.duplicate()
		page_marks[i]["play_count"] = 1
		page_marks[i]["overall_multiplier"] = 1.0
		page_marks[i]["overall_sum"] = 0
		page_marks[i]["snapshots"] = []
		page_marks[i]["effects"] = {}
		page_marks[i]["pending"] = []
		page_marks[i]["retriggered"] = false
		page_marks[i]["values"] = {
			"damage": page.damage,
			"healing": page.healing,
			"armor": page.armor,
			"witchpower": page.witchpower,
			"count": page.count,
			"effect_damage": page.effect_damage,
			"effect_healing": page.effect_healing,
			"effect_armor": page.effect_armor,
			"effect_witchpower": page.effect_witchpower,
			"effect_count": page.effect_count,
			"effect_play_count": page.effect_play_count,
		}
# ==================== CD ====================
func is_ready() -> bool:
	return current_cd <= 0

func decrease_cooldown() -> void:
	if current_cd > 0:
		current_cd -= 1
		_update_usable_marks()
		cd_changed.emit(current_cd)

func start_cooldown() -> void:
	if page_marks.is_empty():
		current_cd = 0
	else:
		var total = 0
		for mark in page_marks:
			total += mark["cd_remaining"]
		current_cd = int(round(float(total) / page_marks.size()))
	for i in range(page_marks.size()):
		var page = Generator_bookmark.pages[i]
		page_marks[i]["cd_remaining"] = max(0, page.cd - _cd_reload())
	_update_usable_marks()
	cd_changed.emit(current_cd)

# ==================== 选择 ====================
func _on_clicked() -> void:
	if not is_ready():
		return
	if not is_selected:
		set_selected(true)
	else:
		card_confirmed.emit(self)

func set_selected(selected: bool) -> void:
	if is_selected == selected:
		return
	is_selected = selected
	selection_changed.emit(is_selected)

# ==================== 选中展开 ====================
## 由 BookmarkDisplay 在选中/取消时调用：把卡片加宽，给右侧的介绍框腾出位置。
## 手牌收到 expand_changed 后会重新排布（见 layout_row）。
func set_expanded(expanded: bool) -> void:
	var target: float = expanded_width() if expanded else collapsed_width
	if is_equal_approx(custom_minimum_size.x, target):
		return
	custom_minimum_size.x = target
	expand_changed.emit(expanded)

## 总宽超出容器、退化成堆叠时，每张**最少**让出的宽度（像素）
const MIN_STACK_STEP := 40.0

# ==================== 手牌排布（静态工具） ====================
## 把一列卡片在 container 里摆开。玩家手牌与主场景卡组都调它。
##
## ⚠️ container 必须是**普通 Control**（不能是 HBoxContainer）——
##    容器每次重排都会覆盖子节点的 position，压不住这里手动摆的位置。
##
## 规则：
##   · **槽位一律按「收起宽度」算**：选中抽出的那张只是自己变宽并压在上面，
##     **绝不推开别人**（位置只取决于序号，与谁被选中无关）
##   · **够宽就正常平铺**：每张占自己的槽位 + HAND_SEPARATION，彼此不重叠
##   · **总槽位宽超出容器才重叠**：全体压缩成堆叠，最少留 MIN_STACK_STEP 一条，
##     末张的右边缘保持在容器内
##   · **卡片上沿对齐**（2026-10-18 改）：所有卡片的上边缘对齐到「最高那张」的上边缘 ——
##     页数不同的书签放在一起时，第一页在同一水平线上（以前是按下沿对齐，页数少的会矮一截）
static func layout_row(cards: Array, container: Control) -> void:
	if cards.is_empty():
		return
	var n := cards.size()
	var slots: Array[float] = []
	var natural := 0.0
	for card in cards:
		slots.append(card.collapsed_width)
	for i in range(n):
		natural += slots[i]
	natural += HAND_SEPARATION * (n - 1)

	# step > 0 = 堆叠模式（每张只让出 step）；step < 0 = 平铺模式（逐张按槽位宽度走）
	var step := -1.0
	if n > 1 and natural > container.size.x:
		step = maxf(MIN_STACK_STEP, (container.size.x - slots[n - 1]) / float(n - 1))

	# 上沿基准 = 最高那张卡的上边缘：页数少的书签不再往下沉，第一页与别人对齐
	var tallest := 0.0
	for card in cards:
		tallest = maxf(tallest, card.collapsed_height)
	var top_y: float = container.size.y - tallest
	# 容器贴得比屏幕底还低时整排抬上来：否则最高的那张会探到屏幕外，最下面几页被切掉
	# （实测手牌区底边在 y=1583、画布高 1440 ⇒ 会被切 143px）
	var screen_bottom: float = container.get_viewport_rect().size.y
	var overflow: float = container.global_position.y + top_y + tallest - screen_bottom
	if overflow > 0.0:
		top_y -= overflow
	var x := 0.0
	for i in range(n):
		var card = cards[i]
		var h: float = card.collapsed_height
		# 尺寸按卡片自己的宽度（选中的那张是展开宽度），槽位按收起宽度
		card.size = Vector2(card.custom_minimum_size.x, h)
		card.position = Vector2(x, top_y)
		card.z_index = n - i
		x += step if step > 0.0 else slots[i] + HAND_SEPARATION
