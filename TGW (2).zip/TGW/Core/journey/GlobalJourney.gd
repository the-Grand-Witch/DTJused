extends Node
## 今日路程记录：记录每天做了什么，按天分组全部保留。
##   1) 选了哪个节点（进节点那一刻的时间）
##   2) 获得了哪些书页
##   3) 获得了哪些饰品
##
## 写入点一共三处（都在真实获得的那一步，不在结算 UI 上）：
##   Core/event/manager_event.gd          选节点 → add_node()
##   Core/book/GlobalCardLibrary.gd       add_acquired_count() → add_card()
##   Core/accessories/GlobalAccessories.gd add_accessories() → add_accessory()
## 展示点：scenes/day_transition.tscn（打赢 Boss 后的跨天转场）
##
## ⚠️ 跨天**不清空**：days 按天分组保存全部历史。
##    只有新开一局才清空（choose.gd 选人时调 begin_run()）。

enum EntryKind { NODE, CARD, ACCESSORY }

## day(int) -> Array[Dictionary]，每条 = {time: String, kind: EntryKind, name: String, amount: int}
var days: Dictionary = {}

# ==================== 写入 ====================
## 新的一局：清空全部记录。
## ⚠️ 必须在 GlobalPlayer.set_character() **之后**调用 —— 起始饰品是在 set_character
##    里通过 character_changed 发的，先清后发的话那条「获得饰品」会挂在新一局第 1 天开头。
func begin_run() -> void:
	days.clear()

## 选了一个节点：时间取调用当下，所以要在事件推进时间（add_time_units）之前记。
func add_node(node_name: String) -> void:
	_record(EntryKind.NODE, node_name, 1)

func add_card(page_name: String, amount: int = 1) -> void:
	_record(EntryKind.CARD, page_name, amount)

func add_accessory(acc_name: String) -> void:
	_record(EntryKind.ACCESSORY, acc_name, 1)

func _record(kind: EntryKind, entry_name: String, amount: int) -> void:
	var day := GlobalTime.get_day()
	if not days.has(day):
		days[day] = []
	days[day].append({
		"time": GlobalTime.get_formatted_time(),
		"kind": kind,
		"name": entry_name,
		"amount": amount,
	})

# ==================== 查询 / 展示 ====================
func get_day_entries(day: int) -> Array:
	if not days.has(day):
		return []
	return days[day]

## 有记录的全部天数（升序）：按天分组的界面用它遍历
## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func get_all_days() -> Array:
	var arr := days.keys()
	arr.sort()
	return arr

## 一条记录 → 一行文本（转场界面直接摆 Label 用）
func format_entry(entry: Dictionary) -> String:
	var amount: int = entry["amount"]
	var suffix: String = "" if amount <= 1 else " ×%d" % amount
	match entry["kind"]:
		EntryKind.NODE:
			return "%s  %s" % [entry["time"], entry["name"]]
		EntryKind.CARD:
			return "%s  获得书页「%s」%s" % [entry["time"], entry["name"], suffix]
		EntryKind.ACCESSORY:
			return "%s  获得饰品「%s」%s" % [entry["time"], entry["name"], suffix]
	return "%s  %s" % [entry["time"], entry["name"]]
