extends "res://Core/battle/enemy_controller.gd"
## 镜像（Boss）根节点
## ==================================================================
## 敌人就是**玩家的镜像**：一份 PlayerSnapshot，带着那个人的血量、魔女化、书签和饰品。
## 加载后它独立运行，与玩家共用同一套公式与流程，但状态完全隔离：
##
##   EnemyState            —— 镜像的状态（血量/魔女化/被动实例），继承 BattleState
##   BattleFlow            —— 与玩家共用的流程（页脚本、关键词、快照、结算）
##   GlobalStats           —— 与玩家共用的纯函数公式（传的 side 是 EnemyState）
##
## 建牌 / 回合回滚 / 结算落地 / 护甲池 这些「阵营无关」的部分在基类
## `Core/battle/enemy_controller.gd` 里；本文件只剩镜像特有的三件事：
##   1. 牌来自快照、出牌由 AI 选（enemy_ai.gd）；
##   2. 魔女化随威胁值自然增长，满值后「吃书」transform（witch_system.gd）；
##   3. 意图图标（手牌刻意隐藏，只通过 EnemyIntent 告诉玩家它要出什么类型）。
## ==================================================================

# 引用模块
@onready var ai = $enemyAI
@onready var ui = $enemyUI
@onready var witch = $WitchSystem
@onready var calculator: Control = $EnemyCalculator

# 镜像数据
var snapshot: PlayerSnapshot

func setup(snap: PlayerSnapshot):
	snapshot = snap
	base_attack = snap.base_attack

	# 状态：血量/魔女化/自己的被动实例（继承 BattleState，与玩家同接口）
	enemy_state = EnemyState.new()
	add_child(enemy_state)
	enemy_state.name = "EnemyState"
	enemy_state.reset_battle()
	enemy_state.setup_from_snapshot(snap)

	# 彼岸之赐：本模块不自己存魔女化，改为回读 EnemyState，保证只有一个真相
	witch.set_witch_power_provider(func(): return enemy_state.get_witch_power())
	witch.reset()

	ui.setup(snap, enemy_state.get_max_health(), enemy_state.get_health())
	# 敌人左侧的饰品说明：镜像的饰品会改战斗数值，摆出来让玩家能算账
	ui.show_accessories(enemy_state.get_accessories())
	_create_cards()

	DebugOutput.say("[Boss] 镜像已加载：%s｜威胁值 %d｜饰品[%s]｜%s" % [
		snap.player_name,
		GlobalThreat.calculate_threat(snap)["threat"],
		_accessory_names(snap.accessories),
		enemy_state.passives.get_summary(),
	])

func _accessory_names(acc_list: Array) -> String:
	var names: PackedStringArray = []
	for acc in acc_list:
		if acc is Generator_accessories:
			names.append(acc.name)
	return ", ".join(names)

## 调试开关：把镜像手牌摊开显示。
## 设计上镜像手牌是**刻意隐藏**的——只通过 EnemyIntent 图标告诉玩家「它要出什么类型」。
## 调试阶段需要肉眼看牌时再打开；正式版保持 false。
const DEBUG_SHOW_ENEMY_HAND := false

## 调试输出：每个回合打印镜像的选牌与冲动赋值（这两件事没有 UI 显示，只能靠日志看）。
## 开关在 Core/debug_output.gd；导出 release 自动静音。

## 镜像的牌来自快照里的书签；建牌本身是基类的公共流程。
func _create_cards():
	build_cards(snapshot.bookmarks, $EnemyHandContainer)
	var hand: HBoxContainer = $EnemyHandContainer
	# 可见性由调试开关决定；不显示时仍然创建，逻辑照常跑
	hand.visible = DEBUG_SHOW_ENEMY_HAND
	# 把「手牌内容」注入 state，这样调试输出不依赖 UI 是否可见
	enemy_state.hand_describer = Callable(self, "describe_hand")
	DebugOutput.say("[Boss] 镜像手牌 %d 张（显示=%s）" % [cards.size(), str(hand.visible)])

## 镜像手牌的文字描述：给调试输出用，不依赖 UI 是否可见
func describe_hand() -> String:
	if cards.is_empty():
		return "（无手牌）"
	var lines: PackedStringArray = []
	for i in range(cards.size()):
		var card = cards[i]
		if card.Generator_bookmark == null:
			lines.append("  [%d] <未设置书签>" % i)
			continue
		var page_names: PackedStringArray = []
		for page in card.Generator_bookmark.pages:
			page_names.append(page.page_name)
		lines.append("  [%d] %s（%d 页）: %s   冷却=%d %s" % [
			i,
			card.Generator_bookmark.title,
			card.Generator_bookmark.pages.size(),
			", ".join(page_names),
			card.current_cd,
			"可出" if card.is_ready() else "冷却中",
		])
	return "\n".join(lines)

func on_round_start(turn_count: int):
	enemy_state.turn_count = turn_count

	# 页数值每回合回滚 + 冷却 -1（基类公共流程；玩家侧在 battle_main._start_round 里做同样的事）
	reset_cards_for_round()

	# 回合边界：先换挡「本回合 → 上回合」，再跑镜像自己的汐信 tick
	# （第 1 回合不 tick，与玩家侧同口径）
	enemy_state.shift_turn_flags()
	if turn_count > 1:
		BattleFlow.run_keyword_pass(enemy_state, GlobalPlayer.witch_power, "round_start")

	if not enemy_state.is_transformed():
		# 魔女化：每回合自然增长的**基准值** = 威胁值 / WITCH_GAIN_DIVISOR
		# （威胁值每 100 点 → 每回合 +1）。镜像不靠扣血涨魔女化。
		# 用**这一战选中的镜像**的威胁值，不是当天区间中心。
		# 吃书之后停掉：否则会一路涨回上限，而那时已不会再触发 transform。
		var threat: int = GlobalThreat.calculate_threat(snapshot)["threat"]
		enemy_state.gain_witch_power(int(threat / GlobalThreat.WITCH_GAIN_DIVISOR))

	# 每回合回复：彼岸之赐的 heal_per_turn + 上一回合书页能力给的 heal_count
	heal(witch.get_permanent_effect("heal_per_turn") + enemy_state.heal_count)

	# 彼岸之赐：清算冲动 + 按层数触发祝福
	# 冲动减免用**镜像自己的**饰品（玩家侧对应 GlobalPlayer.get_impulse_count() 的减免）
	# extra = 魇蚀那一组的「每回合 +1 冲动」与「下回合额外赋予一次」
	var impulse_extra: int = enemy_state.impulse_per_turn_bonus + enemy_state.consume_impulse_next_turn()
	witch.on_round_start(turn_count, cards, enemy_state.get_witch_impulse_reduce(), impulse_extra)
	_update_buff_display()

	# 彻底疯狂的镜像不再使用书页，只用基础攻击（take_turn 里会走那条分支）
	if enemy_state.is_transformed():
		selected_card = null
		ui.show_intent(null, ai)
		ui.show_intent_card(null)
		if DebugOutput.enabled():
			DebugOutput.say("[Boss] 回合 %d：已彻底疯狂（书已吃掉），只用基础攻击" % turn_count)
		return

	selected_card = ai.choose_card(
		cards,
		enemy_state.get_health(),
		enemy_state.get_max_health(),
		GlobalPlayer.health,
		GlobalPlayer.max_health,
		witch.get_impulses()
	)
	ui.show_intent(selected_card, ai)
	# 意图图标旁边摆出「这回合要打的那本书签」整张卡面
	ui.show_intent_card(selected_card)

	# 调试：选牌与冲动都是「看不见」的（手牌刻意隐藏、冲动没有 UI），所以打日志
	if DebugOutput.enabled():
		var intent := "—"
		if selected_card != null:
			intent = ai.get_main_type(selected_card)
		DebugOutput.say("[Boss] 回合 %d 选牌：%s｜意图=%s" % [
			turn_count, _card_title(selected_card), intent])
		DebugOutput.say("[Boss] 回合 %d 冲动赋值：%d 个（失去量 %d + 魔女化/18 %d）" % [
			turn_count,
			witch.get_impulses().size(),
			1 + (turn_count - 1) / 2,
			enemy_state.get_witch_power() / 18,
		])
		DebugOutput.say(describe_impulses())

func _card_title(card) -> String:
	if card == null or card.Generator_bookmark == null:
		return "（无可出的牌）"
	return card.Generator_bookmark.title

## 把当前挂着的冲动列出来：哪张牌的哪一页、是哪一页
func describe_impulses() -> String:
	var impulses = witch.get_impulses()
	if impulses.is_empty():
		return "  镜像冲动：（无）"
	var lines: PackedStringArray = ["  镜像冲动 %d 个：" % impulses.size()]
	for entry in impulses:
		var card = entry["card"]
		var idx: int = entry["page_index"]
		var title: String = "?"
		var page_name: String = "?"
		if card != null and card.Generator_bookmark != null:
			title = card.Generator_bookmark.title
			if idx < card.Generator_bookmark.pages.size():
				page_name = card.Generator_bookmark.pages[idx].page_name
		lines.append("    %s 第 %d 页（%s）" % [title, idx, page_name])
	return "\n".join(lines)

# ==================== 基类钩子（镜像特有的部分）====================
## 没有可出的牌时的兜底攻击：仍吃彼岸之赐的攻击加成与倍率
func direct_attack_amount() -> int:
	return calculator.calculate_direct_attack(
		base_attack,
		witch.get_permanent_effect("attack_bonus"),
		witch.get_attack_multiplier()
	)

## 兜底攻击之后：冲动惩罚照样要结算，否则「没有可出的牌」时惩罚会永久失效
func _on_direct_attack() -> void:
	enemy_state.gain_witch_power(witch.get_unused_impulse_penalty(selected_card, []))
	enemy_state.armor_count += witch.get_permanent_effect("armor_per_turn")

## 一次出牌结算完之后：回合防御 + 彼岸之赐的冲动清算 + 满值 transform
func _after_card_played(card_result: Dictionary, played: Array) -> void:
	enemy_state.armor_count += witch.get_permanent_effect("armor_per_turn")

	# 带冲动出牌却没打出伤害 → 魔女化上涨；未打出的冲动也有惩罚
	var wp_from_impulse: int = witch.update_witch_power_after_played_card(selected_card, played, last_damage_dealt)
	var wp_from_penalty: int = witch.get_unused_impulse_penalty(selected_card, played)
	enemy_state.gain_witch_power(wp_from_impulse)
	enemy_state.gain_witch_power(wp_from_penalty)

	# 调试：出了什么牌、冲动结算了多少魔女化
	if DebugOutput.enabled():
		DebugOutput.say("[Boss] 出牌：%s｜伤害 %d（护甲后）｜回复 %d｜护甲 %d｜魔女化 +%d" % [
			_card_title(selected_card),
			last_damage_dealt,
			card_result.healing,
			card_result.armor,
			card_result.witch_power,
		])
		DebugOutput.say("[Boss] 冲动结算：带冲动出牌未造成伤害 +%d，未打出的冲动惩罚 +%d → 魔女化 %d/%d" % [
			wp_from_impulse, wp_from_penalty,
			enemy_state.get_witch_power(), enemy_state.get_max_witch_power(),
		])

	# 魔女化满值 → 彼岸之赐 transform
	if enemy_state.is_overloaded():
		_transform()

## 魔女化满值 → 吃书：
##   把**当前整副手牌**逐页换算成永久成长（换算表见 witch_system.gd 顶部），
##   然后**销毁整副手牌**——这就是「彻底疯狂把自己的书吃了」。
##   之后魔女化清零、眩晕一回合，并标记 `EnemyState.transformed`：
##   on_round_start 据此不再出牌，take_turn 走基础攻击分支。
func _transform():
	var gained = witch.transform(cards, enemy_state)
	enemy_state.set_max_health(int(gained["max_health"]))
	enemy_state.set_health(int(gained["health"]))
	enemy_state.clear_witch_power()
	enemy_state.set_transformed(true)
	# 立绘：灰色遮罩 → 紫色（认不出是本人，魔女化后更明显）
	ui.set_transformed(true)

	# 吃书：销毁手牌的卡节点（cards 与 enemy_state.cards 是同一个数组引用）
	for card in cards:
		card.queue_free()
	cards.clear()
	$EnemyHandContainer.visible = false

	ui.update_health(enemy_state.get_health(), enemy_state.get_max_health())
	_update_buff_display()
	stunned()
	witch.printf_transform(gained)

## 更新镜像状态图标（图标表见 Core/scenes/buffscenses.gd 的 SYSTEM_STATUS_ICONS）
func _update_buff_display():
	var statuses := {}
	var effects = witch.get_permanent_effects()
	if effects["attack_bonus"] > 0:
		statuses["attack_bonus"] = effects["attack_bonus"]
	# 与玩家侧同一口径：这个图标显示的是**当前护甲池**，不是彼岸之赐的回合防御加成
	if enemy_state.armor_count > 0:
		statuses["armor_per_turn"] = enemy_state.armor_count
	if effects["heal_per_turn"] > 0:
		statuses["heal_per_turn"] = effects["heal_per_turn"]
	if witch.get_bian_layers() > 0:
		statuses["bian_layers"] = witch.get_bian_layers()
	ui.update_buffs(statuses)
	if DebugOutput.enabled():
		witch.printf_state()

# ==================== 基类钩子：UI 与日志 ====================
func _on_health_changed() -> void:
	ui.update_health(enemy_state.get_health(), enemy_state.get_max_health())

func _on_damage_taken(amount: int, absorbed: int) -> void:
	if not DebugOutput.enabled():
		return
	DebugOutput.say("[Boss] 受击 %d：护甲挡下 %d，实掉 %d → %d/%d（剩余护甲 %d）" % [
		amount, absorbed, amount - absorbed,
		enemy_state.get_health(), enemy_state.get_max_health(),
		enemy_state.armor_count])
