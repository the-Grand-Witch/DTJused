extends Node
## 镜像的出牌 AI
## ==================================================================
## ⚠️ 注意：书页类型是 **page_type: Array[PickupType]**（多标签数组），
##    没有 pickup_type 这个字段。判断必须用 `type in page.page_type`。
##
## 设计：镜像就是玩家本人，所以它的决策也应该像「会玩的人」。
##
## 两层决策：
##
##   **第一层（硬优先）**：只要手上还有带冲动的牌，就只在「冲动页最多」的那几张里挑。
##     冲动页的惩罚是「未打出 +2/页、打出但未造伤 +3/页、打出且造伤 +0」，
##     所以它只想把冲动甩出去 —— 但这是赌：玩家格挡下来是 +3（比不打的 +2 更亏），
##     玩家硬吃才是 +0。玩家的选择在这里生效。
##
##   **第二层（软评分）**：同一冲动数里按局面打分，取最高；并列时由 shuffle 决定。
##     攻分 = Σ 攻击页（伤害 + 特效伤害）
##     防分 = Σ 防御页（护甲 + 特效护甲）
##     回分 = Σ 回复页（回复 + 特效回复）
##
## ⚠️ 这里读到的是**书页当前数值**，关键词在结算时才加的那部分
##    看不到，所以带关键词的牌会被低估一些 —— 这是有意的简化。
## ==================================================================

## 第二层的基础权重
const W_ATTACK := 1.0
const W_DEFENSE := 1.0
const W_HEAL := 1.0

## 自己血量低于这个比例 → 加防、加血
const SELF_LOW_RATIO := 0.6
const SELF_LOW_DEFENSE_BONUS := 1.0
const SELF_LOW_HEAL_BONUS := 1.0

## 玩家血量低于这个比例 → 压攻击
const PLAYER_LOW_RATIO := 0.4
const PLAYER_LOW_ATTACK_BONUS := 2.0

func choose_card(cards, enemy_health, enemy_max_health, player_health, player_max_health, impulses) -> BookmarkCard:
	var candidates: Array[BookmarkCard] = []
	for card in cards:
		if card.is_ready():
			candidates.append(card)
	if candidates.is_empty():
		return null

	# ========== 第一层（硬优先）：冲动页最多的那几张 ==========
	# 理由见 witch_system：冲动页的惩罚是「未打出 +2/页、打出但未造伤 +3/页、打出且造伤 +0」，
	# 所以只要手上还有带冲动的牌，它就只想把冲动甩出去。
	# 注意这是**赌**：玩家格挡下来就是 +3（比不打的 +2 更亏），玩家硬吃才是 +0。
	var most := 0
	for card in candidates:
		most = max(most, count_impulses(card, impulses))
	if most > 0:
		var pooled: Array[BookmarkCard] = []
		for card in candidates:
			if count_impulses(card, impulses) == most:
				pooled.append(card)
		candidates = pooled

	# ========== 第二层（软评分）：同冲动数里按局面挑 ==========
	var w_attack := W_ATTACK
	var w_defense := W_DEFENSE
	var w_heal := W_HEAL

	if enemy_health < enemy_max_health * SELF_LOW_RATIO:
		w_defense += SELF_LOW_DEFENSE_BONUS
		w_heal += SELF_LOW_HEAL_BONUS
	if player_health < player_max_health * PLAYER_LOW_RATIO:
		w_attack += PLAYER_LOW_ATTACK_BONUS

	# 先打乱，这样并列时选出的是随机的那个（而不是永远第一张）
	candidates.shuffle()
	var best: BookmarkCard = candidates[0]
	var best_score := -1.0
	for card in candidates:
		var s := 0.0
		s += w_attack * attack_score(card)
		s += w_defense * defense_score(card)
		s += w_heal * heal_score(card)
		if s > best_score:
			best_score = s
			best = card
	return best

# ==================== 分值 ====================
func attack_score(card) -> float:
	return _sum_values(card, Generator_bookpage.PickupType.Attack, "damage", "effect_damage")

func defense_score(card) -> float:
	return _sum_values(card, Generator_bookpage.PickupType.Defense, "armor", "effect_armor")

func heal_score(card) -> float:
	return _sum_values(card, Generator_bookpage.PickupType.Heal, "healing", "effect_healing")

## 把某类页的（基础值 + 特效值）加起来。
## values 每回合由 BookmarkCard.reset_round_modifiers() 回滚，
## 所以这里读到的是「这张牌现在大概能打多少」。
func _sum_values(card, type, base_field: String, effect_field: String) -> float:
	if card == null or card.Generator_bookmark == null:
		return 0.0
	var total := 0.0
	for idx in range(card.Generator_bookmark.pages.size()):
		var page = card.Generator_bookmark.pages[idx]
		if not (type in page.page_type):
			continue
		var values = card.get_values(idx)
		total += float(values.get(base_field, 0)) + float(values.get(effect_field, 0))
	return total

# ==================== 类型统计 ====================
## 一张书签里有几张该类型的页
## 带空值保护：卡片可能是 null（无可用书签）或还没 setup 过
func count_type(card, type) -> int:
	if card == null or card.Generator_bookmark == null:
		return 0
	var c = 0
	for page in card.Generator_bookmark.pages:
		if type in page.page_type:
			c += 1
	return c

func count_impulses(card, impulses) -> int:
	if card == null or impulses == null:
		return 0
	var c = 0
	for entry in impulses:
		if entry["card"] == card: c += 1
	return c

func get_main_type(card) -> String:
	if card == null or card.Generator_bookmark == null:
		return ""
	var counts = {
		"Attack": count_type(card, Generator_bookpage.PickupType.Attack),
		"Defense": count_type(card, Generator_bookpage.PickupType.Defense),
		"Ability": count_type(card, Generator_bookpage.PickupType.Ability),
		"Heal": count_type(card, Generator_bookpage.PickupType.Heal),
		"Witch": count_type(card, Generator_bookpage.PickupType.Witch),
	}
	var max_key = "Attack"
	var max_val = -1
	for k in counts:
		if counts[k] > max_val:
			max_val = counts[k]
			max_key = k
	return max_key
