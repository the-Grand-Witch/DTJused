extends Node
## Boss战特殊逻辑
## ==================================================================
## 接口约定与 battle_main.gd 的 special 一致：
##   setup() / on_round_start(turn) / enemy_witch_power() / enemy_take_damage(dmg)
##   is_enemy_dead() / on_enemy_defeated() / enemy_take_turn(player_armor)
##
## 敌人来源：按**目标区间**（天数决定）从整个镜像库里挑威胁值最接近中心的那个。
##   威胁值算法见 Core/boss/GlobalThreat.gd 的 calculate_threat()，
##   目录结构见 Data/DownloadPlayer/README.md
## ==================================================================

@onready var enemy = $Enemy
@onready var hit_performance = $Enemy/HitPerformance

var battle_main: Node
var player_snapshot: PlayerSnapshot
## 这一战的选人结果（含威胁值 / 区间 / 全部候选），开战时快照一次
var battle_pick: Dictionary = {}

func setup():
	battle_pick = GlobalThreat.pick_mirror()
	if battle_pick.is_empty():
		push_error("[BossBattle] 镜像库里没有任何快照，Boss 战无法开始")
		return
	player_snapshot = battle_pick["snapshot"]
	GlobalThreat.printf(battle_pick)
	enemy.setup(player_snapshot)
	hit_performance.setup($Enemy/EnemyPortrait, $Enemy/EnemyHealthBar, $Enemy/HitDamageLabel, $Enemy/AttackFx)
	# Boss 展示：战斗一开场敲夜晚决战钟声
	GlobalAudio.play("夜晚决战钟声")

func on_round_start(turn_count: int):
	if enemy == null:
		return
	enemy.on_round_start(turn_count)

func enemy_witch_power() -> int:
	if enemy == null:
		return 0
	return enemy.get_witch_power()

## 对手（镜像）那一侧的 state：魇蚀 `魇蚀-W1` 的跨阵营魔女化写口要用它。
## 镜像还没 setup 时返回 null（空场）。
func get_battle_state():
	if enemy == null:
		return null
	return enemy.enemy_state

func enemy_take_damage(amount: int):
	if enemy == null:
		return
	enemy.take_damage(amount)

func is_enemy_dead() -> bool:
	if enemy == null:
		return true
	return enemy.get_health() <= 0

## 命中演出：与普通怪同一套（Core/battle/hit_performance.gd），伤害在命中那一下才落地。
func play_hit(amount: int, hits: Array) -> void:
	await hit_performance.play(amount, hits, func(): enemy.take_damage(amount))

## 打赢 Boss = 这一天结束：最后一天（`GlobalTime.TOTAL_DAYS`）⇒ 通关场景 end.tscn；
## 其它天 ⇒ 空场景转场，拨到第二天再回主场景（路由在 `GlobalScenes.scene_after_boss`）
func on_enemy_defeated():
	# 打赢 = 这一天结束；最后一天会由 GlobalScenes 路由到 end.tscn
	GlobalScenes.go_to_next_day()

func enemy_take_turn(player_armor: int):
	if enemy == null:
		return
	enemy.take_turn(player_armor)

## 回合结束调试输出（由 battle_main 调用）。镜像对玩家造成伤害，所以
## 「敌人魔女化」这一项传玩家的魔女化——与 enemy.gd 里的结算口径保持一致。
func debug_round() -> void:
	if not DebugOutput.enabled():
		return
	if enemy == null or enemy.enemy_state == null:
		return
	enemy.enemy_state.debug_round(GlobalPlayer.witch_power)
