extends BattleState
class_name EnemyState

## ==================================================================
## 镜像阵营的战斗态
## ==================================================================
## 继承 BattleState：页结算、关键词、冲动、具名战斗态等流程都在基类里，
## 本类只负责「镜像这一侧的数从哪来」：
##   血量 / 魔女化 / 上限 → 自己的字段（从镜像快照初始化）
##   饰品被动            → 自己的 PassiveRuntime 实例（不与玩家共用）
##
## 这样 GlobalStats 的纯函数、BattleFlow 的流程，两边传进来的是不同的 state，
## 公式一致但数据完全隔离。
## ==================================================================

## 是否已经「彻底疯狂」（完成过 transform）。
## 疯掉的镜像已经把自己的书吃掉（手牌销毁），此后只用基础攻击 + 吃书换来的永久成长。
var transformed: bool = false

func set_transformed(value: bool) -> void:
	transformed = value

func is_transformed() -> bool:
	return transformed

var _health: int = 0
var _max_health: int = 0
var _witch_power: int = 0
var _max_witch_power: int = 100
var _accessories: Array = []

func _init() -> void:
	party = Party.ENEMY

# ==================== 初始化 ====================
## 从镜像快照初始化，并用自己的饰品建立被动运行器。
## ⚠️ 快照的 max_health 是「那个人原本的血量」，镜像自己饰品的加成必须在这里加进去 ——
##    否则苹果这类纯数值饰品会被静默丢掉
##    （玩家侧是靠 GlobalPlayer.recalculate_max_health() 加 GlobalAccessories.get_max_health_bonus()）。
func setup_from_snapshot(snap: PlayerSnapshot) -> void:
	_accessories = snap.accessories.duplicate()
	var health_bonus := get_max_health_bonus()
	_max_health = snap.max_health + health_bonus
	_health = snap.current_health + health_bonus
	_witch_power = snap.witch_power
	_max_witch_power = snap.max_witch_power

	passives.side = self
	passives.build_from_accessories(_accessories)
	# 角色先天技能（艾玛 kill_witch / 雪莉 心衰）：只在快照带了的才装，并重新绑 owner
	passives.character_passive = snap.character_passive
	passives.bind_side(self)
	invalidate_attack_bonus()

## 从**怪物数据**初始化（野怪用：没有快照、没有饰品、不参与魔女化）。
## 与 `setup_from_snapshot()` 的区别：
##   · 血量直接取怪物数据的 `health`
##   · `_witch_power` 恒 0（野怪的「敌方魔女化」由 `wild_monster.enemy_witch_power()` 恒返 100）
func setup_from_monster(mon: Generator_monster) -> void:
	_accessories = []
	_max_health = mon.health
	_health = mon.health
	_witch_power = 0
	# 上限留 100 只为让 `is_overloaded()` 判 false；野怪不会涨魔女化
	_max_witch_power = 100

	passives.side = self
	passives.build_from_accessories(_accessories)
	# 野怪没有角色先天技能，也没有饰品被动
	passives.bind_side(self)
	invalidate_attack_bonus()

# ==================== owner 读口：血量 / 魔女化 ====================
func get_health() -> int:
	return _health

func set_health(value: int) -> void:
	_health = max(0, value)

func get_max_health() -> int:
	return _max_health

func set_max_health(value: int) -> void:
	_max_health = max(1, value)

func get_witch_power() -> int:
	return _witch_power

func set_witch_power(value: int) -> void:
	_witch_power = max(0, value)

## 魔女化上限 = 快照给的基础值 + 镜像**自己**饰品的提升。
## 与 PlayerState.get_max_witch_power() 完全对称（那边是 GlobalPlayer.max_witch_power + 玩家饰品）。
func get_max_witch_power() -> int:
	return _max_witch_power + get_witch_max_increase()

## 镜像涨魔女化：只改自己的数，不碰玩家的。
## 顺便记下本回合增量（与玩家侧同口径，`魇蚀-D3` 要读）
func gain_witch_power(amount: int) -> void:
	var before: int = _witch_power
	_witch_power = clamp(_witch_power + amount, 0, get_max_witch_power())
	note_witch_change(_witch_power - before)

func get_accessories() -> Array:
	return _accessories

func get_impulse_punishment() -> int:
	return 2

func is_overloaded() -> bool:
	return _witch_power >= get_max_witch_power()

# ==================== 镜像自有的临时修正 ====================
## 彼岸之赐的清零（魔女化归零、保留永久效果）
func clear_witch_power() -> void:
	_witch_power = 0

func reset() -> void:
	health_reset()
	transformed = false

func health_reset() -> void:
	_health = _max_health

# ==================== 调试来源说明 ====================
func _witch_power_source() -> String:
	return "EnemyState 自有（从镜像快照初始化）"

func _passive_source() -> String:
	return "PassiveRuntime 自建（镜像自己的饰品 effect_script）"

## 镜像手牌的文字描述（由 enemy.gd 注入）。
## 手牌在 UI 上是刻意隐藏的（只显示意图），所以调试要看牌只能靠这段文字。
var hand_describer: Callable = Callable()

## 覆写基类的调试输出：先打基类那一份，再补镜像手牌
## （彼岸之赐的永久效果不在这里——那份数由 witch_system 持有，见 enemy.gd 的 printf）
func debug_round(enemy_witch_power: int = 0) -> void:
	if not DebugOutput.enabled():
		return
	super.debug_round(enemy_witch_power)
	var lines: PackedStringArray = []

	if hand_describer.is_valid():
		lines.append("  镜像手牌 %d 张：" % cards.size())
		lines.append(str(hand_describer.call()))
	else:
		lines.append("  镜像手牌 %d 张：（未注入描述器）" % cards.size())

	DebugOutput.say("\n".join(lines))
