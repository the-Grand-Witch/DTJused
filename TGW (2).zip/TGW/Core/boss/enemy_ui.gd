extends Node
## 敌人 UI 模块：负责立绘、血条、意图图标和状态图标
##
## 镜像的立绘 = **玩家本人的全身立绘**，但「认不出是谁」：
## 立绘上盖一层**圆形径向渐变**（`EnemyPortrait/EnemyPortraitTint`）——
## 中间浓、边缘淡，常态灰、魔女化后紫。圆的位置与大小在编辑器里手动摆。

@onready var health_bar = $"../EnemyHealthBar"
@onready var portrait = $"../EnemyPortrait"
@onready var portrait_tint: TextureRect = $"../EnemyPortrait/EnemyPortraitTint"
@onready var intent_icon = $"../EnemyIntent"
@onready var buff_display =  $"../buff/Buffscenses"
## 意图书签卡面：boss.tscn 里的固定节点（`scenes/bookmark.tscn` 的实例），
## 每回合由代码 `setup()` 填充成「它这回合要打的那本书签」。
@onready var intent_card = $"../EnemyIntentCard"
## 敌人左侧的饰品图标条：boss.tscn 里的固定 HBoxContainer，代码只往里填图标按钮。
@onready var accessory_list: HBoxContainer = $"../EnemyAccessoryList"
## 悬浮提示用的大提示框脚本（按钮直接 set_script 上去）
const BigTooltipScript := preload("res://Core/event/event_card_tooltip.gd")
## 点击说明面板（触屏没有悬停，点一下弹同一个说明）
const TooltipPanelScript := preload("res://Core/ui/tooltip_panel.gd")
## 饰品文字的共用口径（商店 / 奖励 / 这里同一份）
const AccessoryTextScript := preload("res://Core/accessories/accessory_text.gd")



## 意图图标表：key 是 enemy_ai.get_main_type() 的返回值。
## 磁盘上的文件名大小写不统一（attack 小写、其余首字母大写），所以显式列出来，不要拼字符串。
const INTENT_ICONS := {
	"Attack": "res://Assets/Textures/Icons/intent/Attack.png",
	"Defense": "res://Assets/Textures/Icons/intent/Defense.png",
	"Heal": "res://Assets/Textures/Icons/intent/Heal.png",
	"Ability": "res://Assets/Textures/Icons/intent/Ability.png",
	"Witch": "res://Assets/Textures/Icons/intent/Ability.png",
}

## 圆形滤镜层（`EnemyPortrait/EnemyPortraitTint`，径向渐变白图）：常态灰、魔女化后紫
## 位置与大小由美术在编辑器里手动摆，这里只管换颜色。
## ⚠️ 第 4 个分量是**浓度**：调小 → 更清透（立绘透出来更多），调大 → 更实。
const TINT_NORMAL := Color(0.20, 0.20, 0.24, 0.85)
const TINT_TRANSFORMED := Color(0.58, 0.26, 0.95, 0.9)

## 血条上的「当前/最大」血量数字（Boss 血条 679×72）
const HealthBarText := preload("res://Core/ui/health_bar_text.gd")
const HP_TEXT_FONT_SIZE := 36

func _ready() -> void:
	HealthBarText.attach(health_bar, _hp_values, HP_TEXT_FONT_SIZE, 0.5)
	if intent_card != null:
		intent_card.visible = false

func _hp_values() -> Vector2i:
	return Vector2i(int(round(health_bar.value)), int(round(health_bar.max_value)))

func setup(snapshot, max_health, current_health):
	health_bar.max_value = max_health
	health_bar.value = current_health
	if snapshot.portrait:
		portrait.texture = snapshot.portrait
		portrait.visible = true
	else:
		portrait.visible = false
	portrait_tint.visible = portrait.visible
	_apply_tint(false)

## 魔女化（彻底疯狂）后：圆形滤镜灰 → 紫
func set_transformed(enabled: bool) -> void:
	_apply_tint(enabled)

func _apply_tint(transformed: bool) -> void:
	portrait_tint.modulate = TINT_TRANSFORMED if transformed else TINT_NORMAL

func update_health(current, max_val):
	health_bar.max_value = max_val
	health_bar.value = current

func show_intent(card, ai_module):
	# card 可能为 null（无可用书签 / 已彻底疯狂），此时清掉意图图标
	if card == null:
		intent_icon.texture = null
		return
	if ai_module == null or not ai_module.has_method("get_main_type"):
		intent_icon.texture = null
		return
	var main_type = ai_module.get_main_type(card)
	if main_type == "" or not INTENT_ICONS.has(main_type):
		intent_icon.texture = null
		return
	var path: String = INTENT_ICONS[main_type]
	if ResourceLoader.exists(path):
		intent_icon.texture = load(path)
	else:
		intent_icon.texture = null
		push_warning("[EnemyUI] 缺少意图图标：%s" % path)

## 更新敌人状态图标
func update_buffs(statuses: Dictionary):
	buff_display.update_display(statuses)

# ==================== 意图书签卡面 ====================
## 把「这回合要打的那本书签」整张摆出来（页名/效果/cd 都在卡面上），
## 比一个意图图标透明得多。节点是 boss.tscn 里固定的 `EnemyIntentCard`，这里只填内容。
## 刷新用固定节点自带的 `setup()`：传入 `reload = 0`，避免吃到**玩家**饰品的页冷却缩减。
func show_intent_card(card) -> void:
	if intent_card == null:
		return
	if card == null or card.Generator_bookmark == null:
		intent_card.visible = false
		return
	intent_card.setup(card.Generator_bookmark, 0)
	intent_card.visible = true
	# 这张只是展示：书签本体的点击不要（它会让卡片进选中态），但**每一页要留鼠标**——
	# 页行自己要弹悬浮说明（`BookmarkDisplay.set_page_tooltips`）。
	intent_card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var display = intent_card.get_node_or_null("BookmarkDisplay")
	if display != null:
		display.mouse_filter = Control.MOUSE_FILTER_IGNORE
		if display.has_method("set_page_tooltips"):
			display.set_page_tooltips(true)
		# 镜像的书签名会带角色名（「汉娜的书签」），这里统一**不显示名称**
		if display.has_method("set_title_visible"):
			display.set_title_visible(false)

# ==================== 敌人饰品（图标 + 悬浮说明） ====================
## 填充固定的 `EnemyAccessoryList`（HBoxContainer）：每件饰品一个图标按钮，
## 悬浮弹 1.5 倍提示框（名称 + 数值效果 / 事件说明）。
## 饰品会实实在在改战斗数值（攻击加算/防御页加成/页冷却…），摆出来玩家才能算账。
const ACCESSORY_ICON_SIZE := 96

func show_accessories(accessories: Array) -> void:
	if accessory_list == null:
		return
	for child in accessory_list.get_children():
		child.queue_free()
	for acc in accessories:
		if not (acc is Generator_accessories):
			continue
		var btn := Button.new()
		btn.name = "Acc_%d" % acc.acc_id
		btn.flat = true
		btn.focus_mode = Control.FOCUS_NONE
		btn.custom_minimum_size = Vector2(ACCESSORY_ICON_SIZE, ACCESSORY_ICON_SIZE)
		btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		# 图标统一缩到 96，否则 512×512 原图会把按钮顶大（与商店同一套口径）
		btn.icon = GlobalAccessories.display_icon(acc.icon)
		btn.expand_icon = btn.icon != null
		if btn.icon == null:
			btn.text = acc.name
		btn.tooltip_text = AccessoryTextScript.tooltip_text(acc)
		btn.set_script(BigTooltipScript)
		# 点击也弹说明（PC 悬停、触屏点击），点击不执行别的动作，所以不冲突
		btn.pressed.connect(_on_accessory_pressed.bind(btn))
		accessory_list.add_child(btn)

func _on_accessory_pressed(btn: Button) -> void:
	var at := btn.get_global_rect().position + Vector2(0.0, btn.size.y)
	TooltipPanelScript.show_near(btn, btn.tooltip_text, at)

## 悬停/点击提示正文：统一走 `Core/accessories/accessory_text.gd`（商店、奖励、Boss 共用一份口径）
