extends Node
## 全局威胁值：决定去哪个强度区间找镜像当敌人
## ==================================================================
## 两个概念分清楚：
##   镜像的威胁值 —— 由**它自己的内容**算出来的固定值（见 calculate_threat）
##   目标区间     —— 由**天数**算出来的一个区间（见 get_target_range）
## 选人规则：整个 Data/DownloadPlayer/ 递归扫一遍，取「威胁值离区间中心最近」的那个。
##
## 镜像放哪个目录**不影响强度**，目录只是给你自己肉眼归档用的。
## ⚠️ 目录结构改了要同步 Data/DownloadPlayer/README.md。
## ==================================================================

## 镜像库根目录：递归扫描（所以 low/ mid/ high/ special/ 都会被扫到）
const MIRROR_ROOT := "res://Data/DownloadPlayer"

## 下载来的镜像**优先**：这些目录里的快照会先参与选人。
##   user://  —— `GlobalMirror.save_player_snapshot()` 写的地方（本机玩家镜像）
##   res://  —— 打包进项目的下载数据
const DOWNLOAD_USER_DIR := "user://Data/PlayerSnapshots"
const DOWNLOAD_RES_DIR := "res://Data/PlayerSnapshots"

## **没有下载数据时的固定默认 Boss：按天分三档**，每档的数值贴近「那一天玩家能到的强度」。
## 下标 = 天数 - 1；超过 3 天一直用最后一档。
## 这三份不参与 "res" 库的按威胁值挑选（见 load_project_mirrors 的过滤）。
const DEFAULT_BOSS_BY_DAY: Array[String] = [
	"res://Data/DownloadPlayer/default/boss_day1.tres",
	"res://Data/DownloadPlayer/default/boss_day2.tres",
	"res://Data/DownloadPlayer/default/boss_day3.tres",
]
const DEFAULT_BOSS_DIR := "res://Data/DownloadPlayer/default"
## 三档都读不到时的最后兜底
const DEFAULT_MIRROR_PATH := "res://Data/DownloadPlayer/default/boss_day1.tres"

## 威胁值公式的权重
##   威胁值 = BASE + ACCESSORY_WEIGHT × Σ系数(饰品稀有度) + PAGE_WEIGHT × Σ系数(书页稀有度)
##   系数：稀有度 0 → 1.0，1 → 1.5，2 → 2.0（0 是第一级，不是「无」）
const THREAT_BASE := 200
const ACCESSORY_WEIGHT := 20
const PAGE_WEIGHT := 5
const RARITY_COEF := [1.0, 1.5, 2.0]

## 目标区间：中心 = RANGE_BASE + RANGE_STEP × (天数 - 1)，半宽 RANGE_HALF_WIDTH
##   一局共 3 天：天数 1 → 中心 100，天数 2 → 中心 300，天数 3 → 中心 500
const RANGE_BASE := 100
const RANGE_STEP := 200
const RANGE_HALF_WIDTH := 50

## 镜像每回合自然增长的**基准值** = 威胁值 / WITCH_GAIN_DIVISOR。
## DIVISOR = 100 就是「威胁值每 100 点 → 每回合多涨 1 点魔女化」。
## ⚠️ 这**不是**转化节奏的主因：冲动页的惩罚（未打出 +2/页、打出但未造伤 +3/页）才是。
##    实测（威胁值 370、起始 37、上限 100）：`1 + 威胁/80` → 第 5 回合；只靠惩罚 → 第 7 回合（地板）。
const WITCH_GAIN_DIVISOR := 100

## 角色修正（按角色给威胁值加减）。
##
## ⚠️ **角色先天技能本身视为中性**：每个角色都有被动，所以在威胁公式里
##    「有被动」不加分、也不减分（`所有角色都有被动 = 都没有`）。
##    以后按实际强度表现再逐个修这张表，而不是给被动统一加权。
##
## 目前只有汉娜是明显例外：她的先天能力是「漂浮」（地图向：连续在同一位置前进时
## 消耗的时间变少，见 `Data/WitchGirl/hanna.tres` 的 description），战斗里完全无用 → −80。
## ⚠️ 漂浮不是 `Generator_PassiveEffect`，所以镜像侧本来也拿不到它，这条修正只针对威胁值。
##
## 梅露露目前既没有先天技能也没有独特饰品，镜像要比另三位弱一档，
## 等她有了能力再从这里补修正。
const CHARACTER_THREAT_ADJUST := {
	"hanna": -80,
}

## 调试：>= 0 时直接钉死「目标区间中心」，忽略天数
var range_center_override: int = -1

# ==================== 镜像的威胁值 ====================
## 由快照内容算出这个镜像有多强。纯计算，无副作用。
## 返回 { threat, base, accessory_sum, page_sum, accessory_count, page_count }
func calculate_threat(snapshot: PlayerSnapshot) -> Dictionary:
	var accessory_sum := 0.0
	var accessory_count := 0
	for acc in snapshot.accessories:
		accessory_sum += _coefficient(acc.rarity)
		accessory_count += 1

	var page_sum := 0.0
	var page_count := 0
	for bookmark in snapshot.bookmarks:
		for page in bookmark.pages:
			page_sum += _coefficient(page.rarity)
			page_count += 1

	var base_threat := int(THREAT_BASE + ACCESSORY_WEIGHT * accessory_sum + PAGE_WEIGHT * page_sum)
	var character_adjust: int = int(CHARACTER_THREAT_ADJUST.get(snapshot.character_id, 0))
	var threat := maxi(0, base_threat + character_adjust)
	return {
		"threat": threat,
		"character_adjust": character_adjust,
		"base": THREAT_BASE,
		"accessory_sum": accessory_sum,
		"page_sum": page_sum,
		"accessory_count": accessory_count,
		"page_count": page_count,
	}

## 稀有度系数：0 → 1.0，1 → 1.5，2 → 2.0；越界就退回边界值
func _coefficient(rarity: int) -> float:
	if rarity < 0:
		return RARITY_COEF[0]
	if rarity >= RARITY_COEF.size():
		return RARITY_COEF[RARITY_COEF.size() - 1]
	return RARITY_COEF[rarity]

# ==================== 目标区间 ====================
## 当前该找的强度区间，由天数决定。返回 { center, min, max, day }
func get_target_range() -> Dictionary:
	var day := 1
	if GlobalTime != null:
		day = GlobalTime.get_day()
	var center := RANGE_BASE + RANGE_STEP * (day - 1)
	if range_center_override >= 0:
		center = range_center_override
	return {
		"center": center,
		"min": center - RANGE_HALF_WIDTH,
		"max": center + RANGE_HALF_WIDTH,
		"day": day,
	}

## 调试用：钉死区间中心（传 -1 恢复按天数算）
## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func set_range_center_override(value: int) -> void:
	range_center_override = value

# ==================== 选镜像 ====================
## 递归扫出所有镜像快照（含 default/ 的三档默认 Boss）
func load_all_mirrors() -> Array[PlayerSnapshot]:
	var result: Array[PlayerSnapshot] = []
	_scan_dir(MIRROR_ROOT, result)
	return result

## 项目内「真正的镜像库」：排除 default/ 下的三档默认 Boss（它们是按天取的，不参与按威胁值挑选）
func load_project_mirrors() -> Array[PlayerSnapshot]:
	var out: Array[PlayerSnapshot] = []
	for snap in load_all_mirrors():
		if String(snap.resource_path).begins_with(DEFAULT_BOSS_DIR):
			continue
		out.append(snap)
	return out

## 当天该用的默认 Boss（按天数取档，超过 3 天用最后一档）
func get_default_boss_for_day() -> PlayerSnapshot:
	var day: int = 1
	if GlobalTime != null:
		day = GlobalTime.get_day()
	var idx: int = clampi(day - 1, 0, DEFAULT_BOSS_BY_DAY.size() - 1)
	var snap = load(DEFAULT_BOSS_BY_DAY[idx])
	if snap is PlayerSnapshot:
		return snap
	var fallback = load(DEFAULT_MIRROR_PATH)
	return fallback if fallback is PlayerSnapshot else null

## 下载来的镜像（用户目录 + 打包目录）。没有就返回空数组。
func load_downloaded_mirrors() -> Array[PlayerSnapshot]:
	var result: Array[PlayerSnapshot] = []
	_scan_user_dir(DOWNLOAD_USER_DIR, result)
	_scan_dir(DOWNLOAD_RES_DIR, result)
	return result

## `user://` 用 DirAccess 扫（`ResourceLoader.list_directory` 只认 res://）
func _scan_user_dir(dir_path: String, out: Array[PlayerSnapshot]) -> void:
	var dir := DirAccess.open(dir_path)
	if dir == null:
		return
	dir.list_dir_begin()
	var entry := dir.get_next()
	while entry != "":
		if dir.current_is_dir():
			if not entry.begins_with("."):
				_scan_user_dir(dir_path.path_join(entry), out)
		elif entry.ends_with(".tres"):
			var res = load(dir_path.path_join(entry))
			if res is PlayerSnapshot:
				out.append(res)
		entry = dir.get_next()
	dir.list_dir_end()

func _scan_dir(dir_path: String, out: Array[PlayerSnapshot]) -> void:
	if not DirAccess.dir_exists_absolute(dir_path):
		return
	for name in ResourceLoader.list_directory(dir_path):
		var path := dir_path.path_join(name)
		if name.ends_with("/"):
			_scan_dir(path, out)
		elif name.ends_with(".tres"):
			var res = load(path)
			if res is PlayerSnapshot:
				out.append(res)

## 选一个镜像当敌人：取威胁值离区间中心最近的那个。
## 优先级：**下载来的镜像** → 项目内镜像库 → 固定默认 Boss（`DEFAULT_MIRROR_PATH`）。
## 返回值带上是第几个、威胁值、区间、来源，供调试输出。
func pick_mirror() -> Dictionary:
	var target := get_target_range()

	var mirrors := load_downloaded_mirrors()
	var source := "download"
	if mirrors.is_empty():
		mirrors = load_project_mirrors()
		source = "res"
	if mirrors.is_empty():
		# 没有下载数据、项目库里也没有自制镜像 → 用「当天那档默认 Boss」
		var default_boss := get_default_boss_for_day()
		if default_boss != null:
			mirrors = [default_boss]
			source = "default"
	if mirrors.is_empty():
		push_error("[GlobalThreat] %s 下没有任何镜像快照，且默认 Boss（%s）也读不到" % [MIRROR_ROOT, DEFAULT_MIRROR_PATH])
		return {}

	var best: PlayerSnapshot = null
	var best_index := -1
	var best_distance := 0
	var best_threat := 0

	for i in range(mirrors.size()):
		var snap: PlayerSnapshot = mirrors[i]
		var threat: int = calculate_threat(snap)["threat"]
		var distance: int = abs(threat - int(target["center"]))
		if best == null or distance < best_distance:
			best = snap
			best_index = i
			best_distance = distance
			best_threat = threat

	GlobalMirror.current_boss_snapshot = best
	return {
		"snapshot": best,
		"index": best_index,
		"total": mirrors.size(),
		"source": source,
		"threat": best_threat,
		"distance": best_distance,
		"target": target,
		"all_threats": _all_threats(mirrors),
	}

func _all_threats(mirrors: Array[PlayerSnapshot]) -> Array[int]:
	var list: Array[int] = []
	for snap in mirrors:
		list.append(int(calculate_threat(snap)["threat"]))
	return list

func reset() -> void:
	range_center_override = -1

# ==================== 调试 ====================
func printf(debug: Dictionary) -> void:
	if not DebugOutput.enabled():
		return
	var lines: PackedStringArray = ["──────── [GlobalThreat] ────────"]
	var day := 1
	if GlobalTime != null:
		day = GlobalTime.get_day()
	lines.append("  第 %d 天" % day)
	if debug.is_empty():
		lines.append("  （没有可用镜像）")
		DebugOutput.say("\n".join(lines))
		return
	var target: Dictionary = debug["target"]
	lines.append("  目标区间 %d~%d（中心 %d）" % [target["min"], target["max"], target["center"]])
	var snap: PlayerSnapshot = debug["snapshot"]
	var detail := calculate_threat(snap)
	lines.append("  选中镜像 %s（第 %d / %d 个，来源：%s）" % [snap.player_name, int(debug["index"]) + 1, debug["total"], debug.get("source", "?")])
	lines.append("    威胁值 %d（距中心 %d）" % [debug["threat"], debug["distance"]])
	var adjust: int = int(detail.get("character_adjust", 0))
	if adjust != 0:
		lines.append("    角色特赦 %+d（%s 的能力在战斗里没用）" % [adjust, snap.character_id])
	lines.append("    构成 %d + %d×%.1f（饰品 %d 件）+ %d×%.1f（书页 %d 页）" % [
		detail["base"], ACCESSORY_WEIGHT, detail["accessory_sum"], detail["accessory_count"],
		PAGE_WEIGHT, detail["page_sum"], detail["page_count"]])
	lines.append("    全部镜像威胁值 %s" % str(debug["all_threats"]))
	DebugOutput.say("\n".join(lines))
