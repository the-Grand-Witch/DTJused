extends Node
## 镜像的纯计算工具
## ==================================================================
## `calculate_direct_attack()` 给「镜像没有可用书签」时的兜底攻击用，
## 仍吃彼岸之赐的攻击加成与倍率。
##
## 书页结算走 `BattleFlow.resolve_bookmark()`（与玩家**共用流程与公式**，
## 传进去的 side 是 `EnemyState`），本文件只剩这一个兜底公式。
## ==================================================================

## 没有可用书签时的兜底攻击（仍吃彼岸之赐的攻击加成与倍率）
func calculate_direct_attack(base_attack: int, attack_bonus: int, attack_multiplier: float) -> int:
	return int((base_attack + attack_bonus) * attack_multiplier)
