extends Node
## 彼岸之赐（Boss 侧的魔女化系统）
## ==================================================================
## 与 enemy.gd 的分工：
##   enemy.gd   负责「镜像这一侧」的血量、书签、出牌与卡牌结算
##   witch_system.gd 负责「魔女化」这一条线：冲动、彼岸层数、满值后的 transform
##
## 接线（由 enemy.gd 调用）：
##   on_round_start(turn_count, cards)  回合开始：清算冲动 + 触发彼岸之赐
##   transform(cards, enemy_state)      魔女化满值时「吃书」：按被销毁的那副手牌换算永久成长
##   printf_transform / printf_state    调试输出（本文件末尾）
##
## ⚠️ 设计取舍（与原逻辑的差异，是有意的）：
##   原版把 npc 的魔女化单独放在这里（enemy_witch_power 字段），
##   而 enemy.gd 又自己维护一份 witch_power，两个值会互相不同步。
##   现在 **enemy.gd 的 witch_power 是唯一真相**，本模块只在需要时读它，
##   不再自己存一份。所以这里的 get_witch_power() 只是个只读查询。
## ==================================================================

# ==================== 吃书换算表 ====================
## 下标 = 页的稀有度（0 / 1 / 2）。按 page_type 的**第一个类型**取一行，
## friend 与空 page_type 不参与换算。
const ATTACK_GAIN := [3, 4, 5]           ## Attack  → 攻击加算
const DEFENSE_GAIN := [1, 2, 3]          ## Defense → 回合防御
const ABILITY_GAIN := [0, 1, 2]          ## Ability → 彼岸之赐层数
const HEAL_PERCENT := [0.0, 5.0, 7.5]    ## Heal    → 最大生命值 %
const WITCH_PERCENT := [0.0, 0.5, 1.0]   ## Witch   → 最大生命值 %
const RARITY_MAX := 2
## 彼岸之赐每层带来的每回合回复
const HEAL_PER_BIAN_LAYER := 2

var enemy_bian_layers: int = 0
var enemy_attack_multiplier: float = 1.0
var enemy_impulse_pages: Array[Dictionary] = []
var enemy_permanent_effects = {"attack_bonus": 0, "armor_per_turn": 0, "max_health_bonus": 0, "heal_per_turn": 0}

## 由 enemy.gd 注入的「读取当前魔女化」回调（返回 int）
var _witch_power_provider: Callable = Callable()

func set_witch_power_provider(provider: Callable) -> void:
	_witch_power_provider = provider

func get_witch_power() -> int:
	if _witch_power_provider.is_valid():
		return int(_witch_power_provider.call())
	return 0

func get_impulses() -> Array[Dictionary]:
	return enemy_impulse_pages

func get_attack_multiplier() -> float:
	return enemy_attack_multiplier

func get_permanent_effect(key: String):
	return enemy_permanent_effects.get(key, 0)

func get_permanent_effects() -> Dictionary:
	return enemy_permanent_effects

func get_bian_layers() -> int:
	return enemy_bian_layers

func has_impulse(card, page_index: int) -> bool:
	for entry in enemy_impulse_pages:
		if entry["card"] == card and entry["page_index"] == page_index:
			return true
	return false

# ==================== 回合开始 ====================
## impulse_reduce = 镜像**自己**饰品的冲动减免（由 enemy.gd 从 EnemyState 取，默认 0）
## extra          = 额外条数（魇蚀那一组的「每回合 +1」/「下回合额外一次」）
## 与玩家侧 GlobalPlayer.get_impulse_count() 对称，除数同为 **18**（卡牌设计稿 §二）：
## 两边各自读各自阵营的饰品，互不影响。
func on_round_start(turn_count: int, cards: Array, impulse_reduce: int = 0, extra: int = 0) -> void:
	_clear_impulses()
	# 失去的冲动随回合增长，再加上魔女化带来的部分
	var lost = 1 + (turn_count - 1) / 2
	var normal = get_witch_power() / 18
	_apply_impulses(max(0, lost + normal - impulse_reduce + extra), cards)
	_trigger_bian_effects()

func _clear_impulses() -> void:
	enemy_impulse_pages.clear()

## 给镜像的攻击页挂冲动标记（与其他系统一致，挂在 BookmarkCard 的页标记上）
func _apply_impulses(total: int, cards: Array) -> void:
	var attack_pages: Array[Dictionary] = []
	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			if Generator_bookpage.PickupType.Attack in card.Generator_bookmark.pages[idx].page_type:
				attack_pages.append({"card": card, "page_index": idx})
	for i in range(total):
		if attack_pages.is_empty():
			break
		var r = GlobalRng.range(0, attack_pages.size() - 1)
		var entry: Dictionary = attack_pages[r]
		attack_pages.remove_at(r)
		enemy_impulse_pages.append(entry)
		# 与玩家侧一致：标记写进 BookmarkCard 的 page_marks
		var mark = entry["card"].get_page_mark(entry["page_index"])
		if not mark.has("effects"):
			mark["effects"] = {}
		mark["effects"]["impulse"] = true

# ==================== 彼岸之赐 ====================
## 每层彼岸层数触发一次随机祝福。
## ⚠️ 掷到 3 会**再叠一层**（层数自我增殖）是**刻意设计**，不要"修"：
##    吃书之后敌人会越滚越强，玩家必须抢在失控前打死它，否则必败。
func _trigger_bian_effects() -> void:
	for i in range(enemy_bian_layers):
		var roll = GlobalRng.range(0, 3)
		match roll:
			0: enemy_attack_multiplier *= 1.1
			1: enemy_permanent_effects["armor_per_turn"] += 2
			2: enemy_permanent_effects["heal_per_turn"] += 2
			3: enemy_bian_layers += 1

## 打出带冲动的页但没造成伤害时，魔女化上涨。
## ⚠️ 判定粒度是**逐页**：只有在 `played_indices`（这次真的进了结算的页）里的冲动才算「打出了」。
##    旧实现只比「哪张牌」，只要牌上有冲动就全部豁免，会高估命中数。
func update_witch_power_after_played_card(card, played_indices: Array, damage_dealt: int) -> int:
	var impulses_hit = 0
	for entry in enemy_impulse_pages:
		if entry["card"] != card:
			continue
		if int(entry["page_index"]) in played_indices:
			impulses_hit += 1
	if impulses_hit == 0:
		return 0
	if damage_dealt <= 0:
		return 3 * impulses_hit
	return 0

## 没打出的冲动带来的魔女化惩罚。
## ⚠️ 同样按页判：已进入结算的页不算「未打出」。
func get_unused_impulse_penalty(selected_card, played_indices: Array = []) -> int:
	var penalty = 0
	for entry in enemy_impulse_pages:
		if entry["card"] != selected_card:
			penalty += 2
		elif not (int(entry["page_index"]) in played_indices):
			penalty += 2
	return penalty

# ==================== 满值 transform（吃书） ====================
## 魔女化满值时「吃书」：把镜像**当前整副手牌**逐页换算成永久成长。
## 手牌的销毁由 enemy.gd 负责（这里只做换算，不碰 UI）。
##
## 为什么读手牌而不是快照：吃掉的正是它手上那副书，换算的就是**被销毁的那些页**。
##
## 换算后 max_health_bonus 累加百分比一次性生效，并把涨幅同时补进当前血量。
## enemy.gd 负责应用返回值（改血量、清魔女化、销毁手牌、眩晕）。
func transform(cards: Array, enemy_state) -> Dictionary:
	var gained := {"attack_bonus": 0, "armor_per_turn": 0, "bian_layers": 0, "health_percent": 0.0}
	var page_count := 0
	for card in cards:
		for page in card.Generator_bookmark.pages:
			page_count += 1
			_accumulate_page(page, gained)

	enemy_permanent_effects["attack_bonus"] += gained["attack_bonus"]
	enemy_permanent_effects["armor_per_turn"] += gained["armor_per_turn"]
	enemy_permanent_effects["max_health_bonus"] += gained["health_percent"]
	enemy_bian_layers += gained["bian_layers"]
	# 每回合回复跟着彼岸层数走（层数越高回得越多）
	enemy_permanent_effects["heal_per_turn"] = enemy_bian_layers * HEAL_PER_BIAN_LAYER

	var old_max = enemy_state.get_max_health()
	var new_max = int(old_max * (1.0 + enemy_permanent_effects["max_health_bonus"] / 100.0))
	var new_health = enemy_state.get_health() + (new_max - old_max)

	# 冲动彻底清算：既要清自己的记录，也要清掉卡片页上的标记，
	# 否则吃书之后那些标记会一直挂在已销毁的卡上。
	enemy_impulse_pages.clear()
	if enemy_state != null:
		enemy_state.clear_impulses(cards)

	# 魔女化清零交给 enemy.gd
	return {
		"max_health": new_max,
		"health": new_health,
		"page_count": page_count,
		"attack_bonus": gained["attack_bonus"],
		"armor_per_turn": gained["armor_per_turn"],
		"bian_layers": gained["bian_layers"],
		"health_percent": gained["health_percent"],
	}

## 单页换算：只看 page_type 的第一个类型
func _accumulate_page(page, gained: Dictionary) -> void:
	if page.page_type.is_empty():
		return
	var r: int = clamp(page.rarity, 0, RARITY_MAX)
	match page.page_type[0]:
		Generator_bookpage.PickupType.Attack:
			gained["attack_bonus"] += ATTACK_GAIN[r]
		Generator_bookpage.PickupType.Defense:
			gained["armor_per_turn"] += DEFENSE_GAIN[r]
		Generator_bookpage.PickupType.Ability:
			gained["bian_layers"] += ABILITY_GAIN[r]
		Generator_bookpage.PickupType.Heal:
			gained["health_percent"] += HEAL_PERCENT[r]
		Generator_bookpage.PickupType.Witch:
			gained["health_percent"] += WITCH_PERCENT[r]

func reset() -> void:
	enemy_bian_layers = 0
	enemy_attack_multiplier = 1.0
	enemy_impulse_pages.clear()
	enemy_permanent_effects = {"attack_bonus": 0, "armor_per_turn": 0, "max_health_bonus": 0, "heal_per_turn": 0}

# ==================== 调试 ====================
func printf_transform(gained: Dictionary) -> void:
	if not DebugOutput.enabled():
		return
	DebugOutput.say("──────── [彼岸之赐·吃书] ────────")
	DebugOutput.say("  吃掉 %d 页 → 攻击加算 +%d，回合防御 +%d，彼岸层数 +%d，最大生命 +%.1f%%" % [
		gained["page_count"], gained["attack_bonus"], gained["armor_per_turn"],
		gained["bian_layers"], gained["health_percent"]])
	DebugOutput.say("  吃后总量：攻击加算 %d，回合防御 %d，每回合回复 %d，彼岸层数 %d，最大生命加成 %.1f%%，攻击倍率 ×%.2f" % [
		enemy_permanent_effects["attack_bonus"], enemy_permanent_effects["armor_per_turn"],
		enemy_permanent_effects["heal_per_turn"], enemy_bian_layers,
		enemy_permanent_effects["max_health_bonus"], enemy_attack_multiplier])

func printf_state() -> void:
	if not DebugOutput.enabled():
		return
	DebugOutput.say("  彼岸之赐：层数 %d，攻击倍率 ×%.2f，攻击加算 %d，回合防御 %d，每回合回复 %d，最大生命加成 %.1f%%" % [
		enemy_bian_layers, enemy_attack_multiplier, enemy_permanent_effects["attack_bonus"],
		enemy_permanent_effects["armor_per_turn"], enemy_permanent_effects["heal_per_turn"],
		enemy_permanent_effects["max_health_bonus"]])
