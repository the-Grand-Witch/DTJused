extends Node
## 契约全局管理：扫描契约目录加载全部契约，提供随机获取与去重
var skip_rewards_remaining: int = 0
var skip_rewards_target_id: int = -1
const CONTRACT_DIR := "res://Data/contracts/"

var all_contracts: Array[Generator_contract] = []
var signed_ids: Array[int] = []

func _ready():
	signed_ids.clear()
	clear_skip_rewards()
	_load_all_contracts()


func _load_all_contracts():
	all_contracts.clear()
	var files = ResourceLoader.list_directory(CONTRACT_DIR)
	for file_name in files:
		if file_name.ends_with(".tres"):
			var path = CONTRACT_DIR + file_name
			var res = load(path)
			if res is Generator_contract:
				all_contracts.append(res)


func get_contract() -> Generator_contract:
	var pool: Array[Generator_contract] = []
	for c in all_contracts:
		if c.contract_id not in signed_ids:
			pool.append(c)
	if pool.is_empty():
		return null
	return pool[GlobalRng.range(0, pool.size() - 1)]

func mark_signed(contract_id: int) -> void:
	if contract_id not in signed_ids:
		signed_ids.append(contract_id)

func start_skip_rewards(count: int, target_id: int) -> void:
	skip_rewards_remaining += count
	skip_rewards_target_id = target_id

## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func should_skip_rewards() -> bool:
	return skip_rewards_remaining > 0

# ==================== 掉落屏蔽：来源方接口 ====================
## 说明：屏蔽不写死在奖励流程里，而是由各来源（契约 / 被动 / 饰品 / 将来任何东西）
## 各自声明「我这条规则这次要不要参与屏蔽」，奖励流程只负责调度与询问。
##
## 规则结构（名称全部可来自来源方，核心只认识 block_type / effect_id）：
##   {
##     "block_type":   String,   # 要屏蔽哪一类掉落，对应奖励参数名（"accessories" / "gold" / "cards"）
##     "effect_id":    String,   # 本条规则的标识，解析时原样回传给 consume_reward_block
##     "block_count":  int,      # 打算屏蔽几件
##     "reward_grant": bool,     # 可选：屏蔽兑现后是否要给一个「目标奖励」
##     "target_id":    int,      # 可选：目标奖励的资源 id（本契约=目标饰品 id）
##   }
## 屏蔽参数的来源可以是契约，也可以是任何别的来源；本对象只是其中一个来源。

## 契约当前状态 → 屏蔽参数
func get_reward_effects() -> Array:
	if skip_rewards_remaining <= 0:
		return []
	return [{
		"block_type": "accessories",
		"effect_id": "skip_accessories",
		"block_count": skip_rewards_remaining,
		"reward_grant": true,
		"target_id": skip_rewards_target_id,
	}]

## 解析器：奖励流程来问「这一件掉落，要不要被这条规则屏蔽掉？」
## context 携带的键：block_type / index / payload（该类型的掉落数组）/
##                    effect_id（当前在问的规则）/ rule（规则原文）
## 由来源方自己决定认不认领；返回 true 表示「这一件我屏蔽了」。
func consume_reward_block(context: Dictionary) -> bool:
	if context.get("effect_id", "") != "skip_accessories":
		return false
	if context.get("block_type", "") != "accessories":
		return false
	if skip_rewards_remaining <= 0:
		return false
	skip_rewards_remaining -= 1
	return true

# ==================== 目标奖励 ====================
func get_target_accessory() -> Generator_accessories:
	for acc in GlobalAccessories.all_accessories:
		if acc.acc_id == skip_rewards_target_id:
			return acc
	return null

## 兼容旧调用：消耗一次，返回 true 表示这是最后一次（该发目标饰品了）
## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func consume_skip_rewards() -> bool:
	if skip_rewards_remaining > 0:
		skip_rewards_remaining -= 1
		if skip_rewards_remaining == 0:
			return true
	return false

func clear_skip_rewards() -> void:
	skip_rewards_remaining = 0
	skip_rewards_target_id = -1

func reset():
	signed_ids.clear()
	skip_rewards_remaining = 0
	skip_rewards_target_id = -1
	_load_all_contracts()
