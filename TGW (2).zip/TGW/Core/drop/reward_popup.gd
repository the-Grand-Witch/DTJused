extends Control
class_name RewardPopup

## 卡面脚本：用 preload 而不是全局类名（新脚本要等编辑器扫过才进类缓存）
const PageFaceScript := preload("res://Core/book/page_face.gd")
## 1.5 倍悬浮框（和主界面事件卡同一套）
const BigTooltipScript := preload("res://Core/event/event_card_tooltip.gd")
## 饰品文字口径（名称 + 效果）
const AccessoryTextScript := preload("res://Core/accessories/accessory_text.gd")
## 掉落里每条「书页」的高度：卡面（名称·cd）在上、效果说明在下，两行都在卡面里面
## 2026-10-18：战利品文字整体 ×1.5（说明 14→21、卡名 18→27、饰品/金币 16→24），行高跟着 ×1.5（84→126）
const PAGE_ROW_HEIGHT := 140
## 书页那一行：卡名字号 / 说明字号（说明写在卡面里，不靠悬停）
const PAGE_NAME_FONT_SIZE := 27
const PAGE_DESC_FONT_SIZE := 21
## 金币 / 饰品条目的文字字号（原来是主题默认 16）
const LOOT_FONT_SIZE := 24

signal closed

@onready var background: TextureRect = $"."
@onready var title_label: Label = $TitleLabel
@onready var return_button: Button = $ReturnButton
@onready var loot_vbox: VBoxContainer = $LootScroll/LootVBox

var gold_amount: int = 0
var accessories: Array[Generator_accessories] = []
var cards: Array[Generator_bookpage] = []
var blocked_flags: Array[bool] = []
## >0 = 选择题模式：最多点选这么多个，选满自动关闭（0 = 原来的掉落模式，可以一件件全收）
var pick_limit: int = 0
var picked_count: int = 0

func _ready():
	return_button.pressed.connect(_on_return_pressed)
	title_label.text = "战利品"

func setup_rewards(gold: int, accs: Array[Generator_accessories], card_list: Array = [], flags: Array[bool] = [], max_picks: int = 0, title: String = "战利品") -> void:
	gold_amount = gold
	accessories = accs
	cards.clear()
	for c in card_list:
		cards.append(c)
	blocked_flags = flags
	pick_limit = max_picks
	picked_count = 0
	title_label.text = title
	if is_inside_tree():
		_populate_rewards()
	else:
		call_deferred("_populate_rewards")

func _populate_rewards():
	for child in loot_vbox.get_children():
		child.queue_free()

	if gold_amount > 0:
		var gold_btn = Button.new()
		gold_btn.set_script(BigTooltipScript)
		gold_btn.text = "金币 x%d" % gold_amount
		gold_btn.add_theme_font_size_override("font_size", LOOT_FONT_SIZE)
		gold_btn.pressed.connect(_on_gold_pressed.bind(gold_btn))
		loot_vbox.add_child(gold_btn)

	for i in range(accessories.size()):
		var acc = accessories[i]
		var acc_btn = Button.new()
		acc_btn.set_script(BigTooltipScript)
		# 点击 = 获得，所以效果直接写进按钮文字
		acc_btn.text = AccessoryTextScript.button_line(acc)
		acc_btn.add_theme_font_size_override("font_size", LOOT_FONT_SIZE)
		# 图标统一缩到 GlobalAccessories.ICON_DISPLAY_SIZE，否则 512×512 原图会把整条撑到 512 高
		acc_btn.icon = GlobalAccessories.display_icon(acc.icon)
		# 字号放大后一行放不下：允许换行，别把面板顶宽（VBox 宽 = 滚动区宽）
		acc_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		# 悬停看饰品说明（没有 Tooltip 就退回名字）
		acc_btn.tooltip_text = AccessoryTextScript.tooltip_text(acc)
		var is_blocked = i < blocked_flags.size() and blocked_flags[i]
		if is_blocked:
			acc_btn.modulate = Color(0.5, 0.5, 0.5)
		acc_btn.pressed.connect(_on_acc_pressed.bind(acc_btn, acc, is_blocked))
		loot_vbox.add_child(acc_btn)

	for card in cards:
		# 掉落条目：卡面（关键词底板 + 稀有度画框 +「名称 · cd」+ 效果说明），
		# 说明**写在书页自身**（点击就是「获得」，触屏又没悬停，所以必须常显）
		var page_btn = Button.new()
		page_btn.set_script(BigTooltipScript)
		page_btn.custom_minimum_size = Vector2(0, PAGE_ROW_HEIGHT)
		var face := PageFaceScript.attach_to_button(page_btn, card, PAGE_NAME_FONT_SIZE)
		face.set_detail(card.description, PAGE_DESC_FONT_SIZE)
		page_btn.pressed.connect(_on_page_pressed.bind(page_btn, card))
		loot_vbox.add_child(page_btn)

func _on_gold_pressed(gold_btn: Button):
	GlobalPlayer.add_gold(gold_amount)
	gold_btn.queue_free()

func _on_acc_pressed(acc_btn: Button, acc: Generator_accessories, is_blocked: bool):
	if is_blocked:
		# 屏蔽来源不一定是契约（见 reward_manager 的屏蔽管道），这里用中性说法
		GlobalPlayer.show("这件掉落被阻挡了")
		return
	GlobalAccessories.add_accessories(acc)
	acc_btn.queue_free()
	_count_pick()

func _on_page_pressed(page_btn: Button, card: Generator_bookpage):
	GlobalCardLibrary.add_acquired_count(card.book_id, 1)
	page_btn.queue_free()
	_count_pick()

## 选择题模式下标满就自动收摊；掉落模式 pick_limit = 0，永远不触发
func _count_pick() -> void:
	picked_count += 1
	if pick_limit > 0 and picked_count >= pick_limit:
		_on_return_pressed()

func _on_return_pressed():
	emit_signal("closed")
	queue_free()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		_on_return_pressed()
		get_viewport().set_input_as_handled()
