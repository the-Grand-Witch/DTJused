extends Node
## 奖励场景主控：跑管道修改掉落，调 RewardPopup 显示
##
## RewardPopup.tscn 的根节点挂的是本脚本，Background 子节点挂的是 reward_popup.gd。
## GlobalScenes 会实例化本场景并调用 setup()。

@onready var reward_popup = $Background

func setup(gold: int, accessories: Array, cards: Array, on_done: Callable) -> void:
	var accs: Array[Generator_accessories] = []
	accs.assign(accessories)
	var card_list: Array[Generator_bookpage] = []
	card_list.assign(cards)

	var pipeline = _run_pipeline(accs)

	reward_popup.setup_rewards(gold, pipeline.accessories, card_list, pipeline.blocked_flags)
	reward_popup.closed.connect(func():
		on_done.call(pipeline.triggered)
	)

## 选择题模式：不走掉落屏蔽管道（选择不是掉落），把候选直接交给 RewardPopup，最多选 max_picks 个
func setup_choice(cards: Array, accessories: Array, max_picks: int, title: String, on_done: Callable) -> void:
	var accs: Array[Generator_accessories] = []
	accs.assign(accessories)
	var card_list: Array[Generator_bookpage] = []
	card_list.assign(cards)
	# ⚠️ blocked_flags 是 Array[bool]，这里必须给有类型的空数组（直接写 [] 会类型不匹配）
	var no_flags: Array[bool] = []
	reward_popup.setup_rewards(0, accs, card_list, no_flags, max_picks, title)
	reward_popup.closed.connect(func():
		on_done.call()
	)

## 掉落屏蔽管道（不写死是「契约」在屏蔽）
##
## 模型：各来源声明「屏蔽参数」，奖励流程逐件掉落去问，由来源自己决定认不认领。
##   1. 收集：问每个来源 get_reward_effects() 要规则数组；
##   2. 合并：同一 effect_id 的规则合并（block_count 累加，reward_grant 取或）；
##   3. 解析：按掉落顺序逐件询问各来源 consume_reward_block(context)，
##      谁认领就把这一件标记为屏蔽；
##   4. 兑现：规则里标了 reward_grant 且这次确有屏蔽被兑现，才算「触发」，
##      由调用方（GlobalScenes）负责追加发放目标奖励。
##
## 屏蔽参数的来源不限于契约——被动、饰品、将来任何东西只要实现这两个接口就能参与。
func _run_pipeline(accessories: Array[Generator_accessories]) -> Dictionary:
	var rules := _collect_block_rules()

	var blocked_flags: Array[bool] = []
	for i in range(accessories.size()):
		blocked_flags.append(false)

	# 记录这次真的被认领过的 effect_id
	var claimed_ids: Array[String] = []
	for i in range(accessories.size()):
		var claimed_id := _claim_block("accessories", i, accessories)
		if claimed_id == "":
			continue
		blocked_flags[i] = true
		if claimed_id not in claimed_ids:
			claimed_ids.append(claimed_id)

	var triggered := false
	for effect_id in claimed_ids:
		if not rules.has(effect_id):
			continue
		if rules[effect_id].get("reward_grant", false):
			triggered = true

	return {
		"accessories": accessories,
		"blocked_flags": blocked_flags,
		"triggered": triggered,
	}

## 收集所有来源的屏蔽规则，并按 effect_id 合并
func _collect_block_rules() -> Dictionary:
	var merged: Dictionary = {}
	for source in _block_rule_sources():
		for rule in source.get_reward_effects():
			if not (rule is Dictionary):
				continue
			var effect_id := str(rule.get("effect_id", ""))
			if effect_id == "":
				continue
			if merged.has(effect_id):
				# 同一 id 被多个来源声明时：屏蔽量累加，其余字段保留先声明者
				merged[effect_id]["block_count"] = int(merged[effect_id].get("block_count", 0)) + int(rule.get("block_count", 0))
				if rule.get("reward_grant", false):
					merged[effect_id]["reward_grant"] = true
			else:
				var copy: Dictionary = rule
				merged[effect_id] = copy.duplicate()
	return merged

## 逐件掉落询问各来源：谁认领这一件？返回认领的 effect_id（没人认领返回空串）
func _claim_block(block_type: String, index: int, payload: Array) -> String:
	for source in _block_rule_sources():
		for rule in source.get_reward_effects():
			if not (rule is Dictionary):
				continue
			# 只把「同类型」的规则交给来源判断
			if str(rule.get("block_type", "")) != block_type:
				continue
			var this_effect_id := str(rule.get("effect_id", ""))
			var context := {
				"block_type": block_type,
				"index": index,
				"payload": payload,
				"effect_id": this_effect_id,
				"rule": rule,
			}
			if source.consume_reward_block(context):
				return this_effect_id
	return ""

## 屏蔽规则的来源清单。新增来源（被动 / 饰品 / 别的系统）往这里加即可。
func _block_rule_sources() -> Array:
	return [GlobalContract, GlobalPassive, GlobalAccessories]
