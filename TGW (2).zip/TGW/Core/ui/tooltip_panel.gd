extends CanvasLayer
## 全局「点一下看说明」面板（PC 用鼠标悬停，触屏/不看悬停时就点一下）。
## ==================================================================
## 节点全部在 `scenes/tooltip_panel.tscn` 里摆好（固定节点），这里只：
##   · 把文字填进 Label
##   · 按点击位置把面板摆到屏幕内
##   · 点任意处 / 再点一次关掉
## 为什么需要它：Godot 的 `tooltip_text` 是**鼠标悬停**驱动的，手机（触屏）上
## 不产生悬停，等于看不到说明。所以凡是「点击不是执行动作」的地方都改成点击弹这块面板；
## 「点击 = 购买 / 获得」的地方则不劫持点击，改成把效果直接写进按钮文字。
## ==================================================================

@onready var blocker: Control = $Blocker
@onready var panel: PanelContainer = $Panel
@onready var label: Label = $Panel/Label

const FONT_SIZE := 24
## 面板与屏幕边缘的最小间距
const SCREEN_MARGIN := 16.0
## 面板最大宽度（自动换行）
const MAX_WIDTH := 520.0
## 离点击位置往下偏移多少（不要正好盖住手指/光标）
const CURSOR_OFFSET := Vector2(12.0, 12.0)

func _ready() -> void:
	panel.add_theme_stylebox_override("panel", _make_style())
	label.add_theme_font_size_override("font_size", FONT_SIZE)
	label.add_theme_color_override("font_color", Color(0.95, 0.94, 0.92, 1.0))
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.custom_minimum_size = Vector2(MAX_WIDTH, 0.0)
	blocker.gui_input.connect(_on_blocker_gui_input)
	hide_tip()

func _make_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.10, 0.09, 0.11, 0.96)
	style.border_color = Color(0.56, 0.49, 0.42, 1.0)
	style.set_border_width_all(2)
	style.set_corner_radius_all(5)
	style.content_margin_left = 14.0
	style.content_margin_right = 14.0
	style.content_margin_top = 10.0
	style.content_margin_bottom = 10.0
	return style

## 在点击位置旁弹出说明。`at` 用**全局坐标**（一般传控件 `get_global_rect().position`）。
func show_text(text: String, at: Vector2) -> void:
	if text.strip_edges() == "":
		return
	label.text = text
	visible = true
	blocker.visible = true
	panel.visible = true
	panel.reset_size()
	await get_tree().process_frame       # 等容器把尺寸算出来再夹进屏幕
	var size: Vector2 = panel.size
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	var pos: Vector2 = at + CURSOR_OFFSET
	pos.x = clampf(pos.x, SCREEN_MARGIN, maxf(SCREEN_MARGIN, viewport_size.x - size.x - SCREEN_MARGIN))
	pos.y = clampf(pos.y, SCREEN_MARGIN, maxf(SCREEN_MARGIN, viewport_size.y - size.y - SCREEN_MARGIN))
	panel.position = pos

func hide_tip() -> void:
	visible = false
	panel.visible = false
	blocker.visible = false

## 从任意节点弹一条说明（给「点击看说明」的控件用）。
## ⚠️ 走 `root.get_node_or_null("GlobalTip")` 而不是直接写 `GlobalTip.`：
##    `--script` 模式下 autoload 名不是编译期全局，直接引用会在某些工具脚本里编译失败。
static func show_near(source: Node, text: String, at: Vector2) -> void:
	if source == null or not is_instance_valid(source) or source.get_tree() == null:
		return
	var tip = source.get_tree().root.get_node_or_null("GlobalTip")
	if tip != null and tip.has_method("show_text"):
		tip.show_text(text, at)

func _on_blocker_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		hide_tip()
		blocker.accept_event()
