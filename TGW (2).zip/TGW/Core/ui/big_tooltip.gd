extends RefCounted
## 统一悬浮框：把 Godot 默认那套（16 号字 + 小内边距的深色小框）
## 换成 **1.5 倍**字号、1.5 倍内边距的同款深色框。
##
## 用法（任一种）：
##   · 纯 Button：`btn.set_script(load("res://Core/event/event_card_tooltip.gd"))`
##   · 已经有自己的脚本（商店书签/药水）：在脚本里加
##         func _make_custom_tooltip(for_text: String) -> Object:
##             return BigTooltip.build(for_text)
## ==================================================================

## 整体缩放倍数（字号、内边距、圆角、最小宽都跟着走）
const SCALE := 1.5
## Godot 默认 tooltip 的字号 / 内边距（放大基准）
const BASE_FONT_SIZE := 16
const BASE_MARGIN := 6.0
## 换行宽度下限（默认的 240 × 1.5）
const MIN_WIDTH := 360.0

static func build(for_text: String) -> Control:
	var panel := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.10, 0.09, 0.11, 0.96)
	style.border_color = Color(0.56, 0.49, 0.42, 1.0)
	style.set_border_width_all(int(round(1.0 * SCALE)))
	style.set_corner_radius_all(int(round(3.0 * SCALE)))
	style.content_margin_left = BASE_MARGIN * SCALE
	style.content_margin_right = BASE_MARGIN * SCALE
	style.content_margin_top = BASE_MARGIN * SCALE * 0.75
	style.content_margin_bottom = BASE_MARGIN * SCALE * 0.75
	panel.add_theme_stylebox_override("panel", style)

	var label := Label.new()
	label.text = for_text
	label.add_theme_font_size_override("font_size", int(round(BASE_FONT_SIZE * SCALE)))
	label.add_theme_color_override("font_color", Color(0.95, 0.94, 0.92, 1.0))
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.custom_minimum_size = Vector2(MIN_WIDTH, 0)
	panel.add_child(label)
	return panel
