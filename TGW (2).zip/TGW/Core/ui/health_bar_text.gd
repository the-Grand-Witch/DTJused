extends Label
## 血条上的「当前/最大」血量数字，例如 `86/120`。
## ==================================================================
## 为什么是**运行时挂载**而不是在 .tscn 里加节点：
##   · 玩家血条有 3 处（main / battle / boss），敌人血条 2 处（野怪 / Boss），
##     全都手摆一遍容易漏、也容易被美术重排场景时冲掉；
##   · 调用一行 `HealthBarText.attach(...)` 就自动跟着血条走。
##
## 为什么 label 和血条**同级**（不是血条的子节点）：
##   玩家血条的 `modulate` 会按魔力做绿→紫染色（见 `player_health.gd`），
##   子节点会一起被染；做兄弟节点就不吃这份染色。
##
## 为什么每帧读一次：
##   玩家血条是**百分比条**（`max_value = 100`），真实血量只能从 GlobalPlayer 取；
##   敌人血条直接读 `value / max_value`，这样能跟着 `hit_performance` 的掉血 tween 一起跳字。

const TEXT_COLOR := Color(1, 1, 1, 1)
const OUTLINE_COLOR := Color(0.04, 0.02, 0.06, 0.9)
## 描边粗细 = 字号 × 该比例
const OUTLINE_RATIO := 0.18
const MIN_FONT_SIZE := 12
## 文字左右至少留出的边距，用来判断要不要缩字号
const SIDE_PADDING := 12.0

## 血条数字的默认字号（血条窄时 `_fit_font` 会自动缩）
const DEFAULT_FONT_SIZE := 36

## 被显示的血条（同级节点，弱引用式有效性检查）
var bar: Control = null
## 返回 Vector2i(当前, 最大) 的取值函数
var provider: Callable = Callable()
## 期望字号（血条太窄时会自动缩）
var base_font_size: int = DEFAULT_FONT_SIZE
## 数字在血条内的高度位置：0 = 顶部，1 = 底部。
## 玩家血条贴图（394×216）里血槽其实只在 y≈62..124，所以传 0.43 而不是 0.5。
var center_ratio: float = 0.5

var _last_value: Vector2i = Vector2i(-1, -2)
var _last_rect: Rect2 = Rect2()
var _last_font_size: int = 0
var _printed_once: bool = false

## 已经建过、但还没真正挂进树的数字（add_child 是延迟执行的，避免重复挂两个）
static var _pending: Dictionary = {}

## 挂一个血量数字到 `bar_node` 上（重复调用只会返回已有的那个）。
## value_provider 返回 Vector2i(当前血量, 最大血量)。
static func attach(bar_node: Control, value_provider: Callable, font_size: int = DEFAULT_FONT_SIZE, center_ratio: float = 0.5) -> Label:
	if bar_node == null or not is_instance_valid(bar_node):
		return null
	var host := bar_node.get_parent() as Control
	if host == null:
		push_warning("[HealthText] 血条没有 Control 父节点：%s" % bar_node.name)
		return null
	var node_name := "%s_HealthText" % bar_node.name
	var existing := host.get_node_or_null(node_name)
	if existing is Label:
		return existing
	# 顺手清掉已经随场景销毁的登记，免得字典越攒越大
	for old_key in _pending.keys():
		if not is_instance_valid(_pending[old_key]):
			_pending.erase(old_key)
	var key := "%d/%s" % [host.get_instance_id(), node_name]
	if _pending.has(key) and is_instance_valid(_pending[key]):
		return _pending[key]
	var label := Label.new()
	label.name = node_name
	label.set_script(load("res://Core/ui/health_bar_text.gd"))
	# 静态函数里拿到的是 Label 类型，脚本属性只能走 set()，避免静态类型检查报错
	label.set("bar", bar_node)
	label.set("provider", value_provider)
	label.set("base_font_size", maxi(MIN_FONT_SIZE, font_size))
	label.set("center_ratio", center_ratio)
	label.set("mouse_filter", Control.MOUSE_FILTER_IGNORE)
	_pending[key] = label
	# ⚠️ 必须延迟挂：节点 `_ready()` 里往**父节点**加子节点时，
	#    父节点可能还在 "busy setting up children"，直接 add_child 会失败。
	host.add_child.call_deferred(label)
	DebugOutput.say("[血量数字] %s ← 血条 %s %.0f×%.0f @ (%.0f, %.0f)，字号 %d" % [
		node_name, bar_node.name, bar_node.size.x, bar_node.size.y,
		bar_node.position.x, bar_node.position.y, label.get("base_font_size")])
	return label

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	autowrap_mode = TextServer.AUTOWRAP_OFF
	add_theme_color_override("font_color", TEXT_COLOR)
	add_theme_color_override("font_outline_color", OUTLINE_COLOR)
	add_theme_constant_override("outline_size", maxi(2, int(round(base_font_size * OUTLINE_RATIO))))
	text = ""
	_refresh(true)

func _process(_delta: float) -> void:
	_refresh(false)

func _refresh(force: bool) -> void:
	if bar == null or not is_instance_valid(bar):
		return
	if not bar.is_visible_in_tree() or bar.size.x <= 0.0:
		visible = false
		return
	visible = true
	_layout()

	var value := Vector2i.ZERO
	if provider.is_valid():
		value = provider.call()
	if value.y <= 0:
		if text != "":
			text = ""
		return
	value.x = clampi(value.x, 0, value.y)
	if force or value != _last_value:
		_last_value = value
		text = "%d/%d" % [value.x, value.y]
		if not _printed_once:
			_printed_once = true
			DebugOutput.say("[血量数字] %s 显示 %s（字号 %d，宽 %.0f，位置 (%.0f, %.0f)）" % [
				name, text, base_font_size, bar.size.x, position.x, position.y])
		_fit_font()
	elif _last_font_size == 0:
		# 血条被移动/缩放过了：字号要按新宽度重新算
		_fit_font()

## 跟着血条的位置/大小走（同级节点，所以用父级坐标系手算）
func _layout() -> void:
	var rect := Rect2(bar.position, bar.size)
	if not _last_rect.is_equal_approx(rect):
		_last_rect = rect
		_last_font_size = 0
	var height := float(base_font_size) * 1.35
	size = Vector2(bar.size.x, height)
	position = bar.position + Vector2(0.0, bar.size.y * center_ratio - height * 0.5)

## 血条太窄 / 数字太长时自动缩字号，避免压到血条边框外
func _fit_font() -> void:
	var font := get_theme_font("font")
	if font == null:
		return
	var max_width := maxf(8.0, bar.size.x - SIDE_PADDING)
	var size_px := base_font_size
	while size_px > MIN_FONT_SIZE:
		var width := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size_px).x
		if width <= max_width:
			break
		size_px -= 2
	if size_px == _last_font_size:
		return
	_last_font_size = size_px
	add_theme_font_size_override("font_size", size_px)
	add_theme_constant_override("outline_size", maxi(2, int(round(size_px * OUTLINE_RATIO))))
