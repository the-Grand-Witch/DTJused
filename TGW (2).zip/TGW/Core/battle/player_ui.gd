extends Node
## 玩家 UI 模块：手牌显示、冲动视觉、状态图标

@onready var hand_container = $player_hand_container
@onready var buff_display = $buff/Buffscenses
@onready var hint_label: Label = $HintLabel
@onready var player_icon: TextureRect = $PlayerIcon

signal cancel_requested

## 提示条停留时长（秒）与「哪一条最新」的令牌（防旧定时器关掉新提示）
const HINT_SECONDS := 3.0
var _hint_token: int = 0

func _ready():
	GlobalPlayer.hint_requested.connect(_on_hint_requested)
	GlobalPlayer.character_changed.connect(_on_character_changed)
	hint_label.visible = false
	hand_container.resized.connect(_layout_hand)
	# 手牌一律画在**饰品层之上**（场景里 ACC 图标容器 z_index = 2、底图 = 1）。
	# 子节点的 z_index 是相对父级的，所以卡片内部「越靠前越上层」的层序不受影响；
	# 展开的介绍框（PageInfoVBox）是卡片的子节点，会跟着卡片一起抬起来。
	hand_container.z_index = 10
	if GlobalPlayer.current_character:
		_update_player_icon(GlobalPlayer.current_character)

func _on_character_changed(character: Generator_girl):
	if character == null:
		player_icon.texture = null
		return
	_update_player_icon(character)

func _update_player_icon(character: Generator_girl):
	if character and character.portrait:
		player_icon.texture = character.portrait

func clear_hand():
	for child in hand_container.get_children():
		# ⚠️ 必须先 remove_child 再 queue_free。
		# queue_free 是**延迟**释放：只调它的话，节点当帧仍然留在
		# get_children() 里，紧随其后的 add_card + layout_row 会把这些
		# 「正在等待释放的旧卡」也排进去 —— 新卡就被挤到它们右边一大截，
		# 等旧卡真被释放后又不会重排（表现为「加书签后整排强制右移」）。
		hand_container.remove_child(child)
		child.queue_free()
	_layout_hand.call_deferred()

func add_card(card: BookmarkCard):
	hand_container.add_child(card)
	# 选中展开会让卡片变宽，手牌要重新排布
	card.expand_changed.connect(_on_card_expand_changed)
	# 页数变化会让卡片变高（高度 = 头部 + 行高 × 页数），也要重排。
	# ⚠️ metrics_changed 是**无参**信号，不能连 _on_card_expand_changed（那个要一个 bool），
	#    否则每次发信号都会报 "Method expected 1 arguments, but called with 0"。
	card.metrics_changed.connect(_layout_hand)
	# 互斥：手牌里同时只允许一张处于选中（展开）状态
	card.selection_changed.connect(_on_card_selection_changed.bind(card))
	_layout_hand.call_deferred()

func _on_card_expand_changed(_expanded: bool) -> void:
	_layout_hand.call_deferred()

## 选中互斥：选新的一张时，先把其他已选中的取消掉。
## 放在这里（而不是 battle_main）是因为战斗与主场景**共用同一个 Player 节点脚本**，
## 主场景没有 battle_main，否则主场景会出现两张同时展开。
## ⚠️ 选中**不动手牌顺序、也不推开别人**：卡片按自己的槽位原地抽出展开。
func _on_card_selection_changed(selected: bool, card: BookmarkCard) -> void:
	if not selected:
		return
	# 选中手牌：翻页声。挂在这里而不是 battle_main ——
	# 手牌是战斗与**主场景**共用的同一个 Player 节点，主场景没有 battle_main。
	GlobalAudio.play("页面展开")
	for other in hand_container.get_children():
		if other != card and other.is_selected:
			other.set_selected(false)

## 「打出就排头」：把本轮打出的书签依次移到手牌最前（传进来的顺序 = 打出顺序）。
## 打完之后它们保持排头不动，直到被下一次打出的书签挤到后面。
## ⚠️ 只在「打出」这一刻重排 —— 选中时不动顺序，否则双击出牌会被位移耽误。
func move_played_to_front(cards: Array) -> void:
	for card in cards:
		if is_instance_valid(card) and card.get_parent() == hand_container:
			hand_container.move_child(card, 0)
	_layout_hand.call_deferred()

func _deselect_all() -> void:
	for card in hand_container.get_children():
		if card.is_selected:
			card.set_selected(false)

# ==================== 手牌排布 ====================
## 手动定位，不能用 HBoxContainer —— 容器每次重排都会覆盖子节点的 position，
## 而「展开的书签 + 它左侧所有书签整体左移、右侧书签原地不动」这条规则
## 必须手动摆才做得到。规则本体在 BookmarkCard.layout_row()。
func _layout_hand() -> void:
	BookmarkCard.layout_row(hand_container.get_children(), hand_container)

func _on_hint_requested(text: String):
	# ⚠️ 定时器带 token：连发两条提示时，前一条的 3 秒定时器不能把后一条提前关掉
	_hint_token += 1
	var token: int = _hint_token
	hint_label.text = text
	hint_label.visible = true
	await get_tree().create_timer(HINT_SECONDS).timeout
	if token != _hint_token:
		return
	hint_label.visible = false

# ==================== 冲动视觉 ====================
## 冲动现在是战斗态（存在 BattleState 上），所以由调用方把 state 传进来，
## 而不是让 UI 去问全局单例。
func refresh_impulse_visual(cards: Array[BookmarkCard], battle_state = null) -> void:
	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			var display = card.get_node("BookmarkDisplay")
			# 整行（书页图标 + 书页名）一起染，这样图标也能看出冲动
			var row = display.get_page_row_by_index(idx)
			if not row:
				continue
			var has_impulse := false
			if battle_state != null:
				has_impulse = battle_state.has_impulse(card, idx)
			if has_impulse:
				row.modulate = Color(0.6, 0.2, 1)
			else:
				row.modulate = Color(1, 1, 1)

# ==================== 状态图标 ====================
func update_buffs(statuses: Dictionary, ability_buffs: Array = []):
	buff_display.update_display(statuses, ability_buffs)

# ==================== 右键取消 ====================
## 先把卡片本身取消掉（会顺带触发各卡的 selection_changed(false)，
## 战斗侧据此把自己那份 selected_cards 清掉），再广播 cancel_requested。
func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
		_deselect_all()
		cancel_requested.emit()
		get_viewport().set_input_as_handled()
