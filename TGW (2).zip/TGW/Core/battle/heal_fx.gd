extends Node2D
## 治疗特效播放器：挂在玩家头像上（battle.tscn 的 Player/HealFx）。
## ==================================================================
## ★ 特效中心 = **本节点的位置**（在编辑器里拖 HealFx 就能对准头像）。
##
## 素材来源：对接包的**备用库**里的「参考图/07_回血_最亮点.png」——
##   按最亮点 (984,552) 裁出 640x640，挪到在用目录 Assets/Textures/effects/heal_glow.png。
##   它和本包其它特效同一套做法：**纯黑底 + 加色混合**（黑 = 透明），所以这里也挂 BLEND_MODE_ADD。
##
## ⚠️ 本包的 effect_shim（回血光效）还缺 4 张贴图（spotlight_7/8、offset_glow、floaty_64），
##    没法直接用；等素材补齐了可以换成那个粒子特效，现在这张实拍亮芯单独用已经够看。
## ==================================================================

@export var heal_texture: Texture2D = preload("res://Assets/Textures/effects/heal_glow.png")
## 亮芯大小（相对裁出来的 640x640 原图）
@export_range(0.05, 2.0) var fx_scale := 0.55
## 上浮距离 / 持续时间
@export var rise := 40.0
@export var duration := 0.7

## 播一次治疗特效，播完才返回（战斗流程 await 它，期间回合保持冻结）。
func play_heal(_amount: int = 0) -> void:
	var sprite := Sprite2D.new()
	sprite.texture = heal_texture
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	sprite.material = mat
	sprite.modulate.a = 0.0
	sprite.scale = Vector2.ONE * fx_scale * 0.6
	add_child(sprite)

	var fade_in := create_tween().set_parallel(true)
	fade_in.tween_property(sprite, "modulate:a", 1.0, duration * 0.25)
	fade_in.tween_property(sprite, "scale", Vector2.ONE * fx_scale, duration * 0.45)
	fade_in.tween_property(sprite, "position:y", -rise, duration)
	await get_tree().create_timer(duration * 0.5).timeout

	var fade_out := create_tween()
	fade_out.tween_property(sprite, "modulate:a", 0.0, duration * 0.5)
	await fade_out.finished
	sprite.queue_free()
