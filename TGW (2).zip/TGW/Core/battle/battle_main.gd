extends Node
## 战斗主控制器：通用流程 + 根据场景分派特殊逻辑
## ==================================================================
## 战斗态都在 BattleState（玩家侧是 PlayerState）里，本文件只做流程编排：
##   _start_round       回合开始：被动钩子、冲动、冷却、回合效果
##   _on_end_turn_pressed 玩家行动结算 → 敌人受伤 → 敌人回合 → 下一回合
## ==================================================================

@onready var player_ui = $Player
@onready var player_heal_fx = $Player/HealFx
@onready var battle_calculator = $BattleCalculator
@onready var battle_state: BattleState = $BattleState
@onready var turn_label: Label = $TurnLabel
@onready var end_turn_button: Button = $EndTurnButton

## 每回合结束时打印「各项数值 + 来源」，调试用；开关在 Core/debug_output.gd（导出 release 自动关）

## 玩家护甲数字：解释「龙的意图 22，为什么我只掉 12」——那 10 点被自己的防御页护甲挡掉了。
## 数值取的是真正交给敌人回合的那个 total_armor（不含估算），所以一定对得上。
## 每次结束回合（打出一批书签）推进的游戏时间：10 分钟
const BATTLE_TURN_MINUTES := 10

const PLAYER_ARMOR_FONT_SIZE := 40
const PLAYER_ARMOR_COLOR := Color(0.72, 0.88, 1, 1)
const PLAYER_ARMOR_GAP := 16.0
const PLAYER_ARMOR_WIDTH := 320.0

var special: Node
var player_armor_label: Label

# ==================== 本回合账本（调试输出用） ====================
## 一回合的完整数据都记在这里，`_debug_round_end()` 拿去打「玩家行动 / 野怪 / 对账」三块。
var _last_played_cards: Array = []
var _last_player_result: Dictionary = {}
var _last_total_armor: int = 0
var _last_player_hp_loss: int = 0
var _last_enemy_hp_before: int = -1
var _last_enemy_hp_after: int = -1
var _last_enemy_armor_before: int = -1
var _last_enemy_armor_after: int = -1

## 演出中：这一回合被冻住，所有输入（按钮 / 空格 / 卡牌确认）一律吞掉。
var performing := false

func _ready():
	if has_node("Monster"):
		special = $Monster/Nomel
	elif has_node("Boss"):
		special = $Boss
	special.battle_main = self
	special.setup()

	battle_state.reset_battle()
	# 对手那一侧的 state（Boss 战才有）：魇蚀 `魇蚀-W1` 的「敌方魔女化 −8」需要它。
	# 普通怪没有 witch power，get_battle_state() 返回 null。
	battle_state.enemy_side = special.get_battle_state()
	if battle_state.enemy_side != null:
		battle_state.enemy_side.enemy_side = battle_state
	# 把本节点设为战斗态的 owner：算式与被动脚本都通过它取数，不再各自读全局。
	# 被动实例也在这一步同步进来，所以必须在 notify_battle_start() 之前。
	battle_state.bind_owner(self)
	_create_player_cards()
	end_turn_button.pressed.connect(_on_end_turn_pressed)
	player_ui.cancel_requested.connect(_cancel_all_selections)
	_setup_player_armor_label()
	battle_state.passives.notify_battle_start()
	_start_round()
	_update_player_buffs()

## 玩家血条右边挂一行「护甲 N」：只在「这一下真的挡了多少」时显示，
## 用来解释「龙的意图 22 → 我只掉 12」。数值 = 真正传进敌人回合的 total_armor。
func _setup_player_armor_label() -> void:
	if player_armor_label != null or player_ui == null:
		return
	var bar := player_ui.get_node_or_null("player_health") as Control
	if bar == null:
		return
	player_armor_label = Label.new()
	player_armor_label.name = "PlayerArmorLabel"
	player_armor_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	player_armor_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	player_armor_label.add_theme_font_size_override("font_size", PLAYER_ARMOR_FONT_SIZE)
	player_armor_label.add_theme_color_override("font_color", PLAYER_ARMOR_COLOR)
	player_armor_label.add_theme_color_override("font_outline_color", Color(0.04, 0.02, 0.06, 0.9))
	player_armor_label.add_theme_constant_override("outline_size", 7)
	player_armor_label.visible = false
	player_ui.add_child(player_armor_label)
	var height := float(PLAYER_ARMOR_FONT_SIZE) * 1.35
	player_armor_label.size = Vector2(PLAYER_ARMOR_WIDTH, height)
	# 血条贴图里血槽在高度 43% 处（与血量数字同一套口径）
	player_armor_label.position = bar.position + Vector2(
		bar.size.x + PLAYER_ARMOR_GAP, bar.size.y * 0.43 - height * 0.5)

func _set_player_armor_display(amount: int) -> void:
	if player_armor_label == null:
		return
	player_armor_label.text = "护甲 %d" % amount
	player_armor_label.visible = amount > 0

func _create_player_cards():
	player_ui.clear_hand()
	battle_state.cards.clear()
	for data in GlobalBookMark.bookmarks:
		var card = GlobalScenes.BOOKMARK_CARD_SCENE.instantiate()
		player_ui.add_card(card)
		card.setup(data)
		card.selection_changed.connect(_on_player_card_selected.bind(card))
		card.card_confirmed.connect(_on_card_confirmed)
		battle_state.cards.append(card)

func _on_player_card_selected(selected: bool, card: BookmarkCard):
	if selected:
		if battle_state.selected_cards.size() >= battle_state.max_selected:
			var oldest = battle_state.selected_cards[0]
			battle_state.selected_cards.erase(oldest)
			oldest.set_selected(false)
		battle_state.selected_cards.append(card)
	else:
		battle_state.selected_cards.erase(card)

func _on_card_confirmed(card: BookmarkCard):
	if card in battle_state.selected_cards:
		_on_end_turn_pressed()

func _cancel_all_selections() -> void:
	for card in battle_state.selected_cards:
		card.set_selected(false)
	battle_state.selected_cards.clear()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_SPACE:
			if not battle_state.selected_cards.is_empty():
				_on_end_turn_pressed()
				get_viewport().set_input_as_handled()
		elif event.keycode == KEY_Q:
			_cancel_all_selections()
			get_viewport().set_input_as_handled()

func _start_round():
	battle_state.turn_count += 1
	turn_label.text = "回合 %d" % battle_state.turn_count
	# 上一回合的护甲数字收掉（它只在「挨那一下」时有意义）
	if player_armor_label != null:
		player_armor_label.visible = false

	# 新回合开始，解除上一回合的「已使用」锁，否则书页数值会被永久冻结
	battle_state.clear_used()

	# 先更新所有被动的回合钩子（含雪莉的心衰档位更新）
	var effects = battle_state.passives.get_turn_effects(battle_state.turn_count)

	if battle_state.heal_count > 0:
		# 每回合回血：把 heal_count 交给被动做修正
		GlobalPlayer.heal(battle_state.passives.get_heal_per_turn(battle_state.heal_count))

	for card in battle_state.cards:
		card.reset_round_modifiers()

	# 回合边界：先把「本回合」的状态换挡成「上回合」，再跑汐信的 tick
	# （tick 读的正是 damage_taken_last_turn / played_last_turn 这些）
	# ⚠️ 第 1 回合不 tick：那时还没有「空过一回合」这回事，否则汐信页白拿一层。
	battle_state.shift_turn_flags()
	if battle_state.turn_count > 1:
		BattleFlow.run_keyword_pass(battle_state, special.enemy_witch_power(), "round_start")

	battle_state.reset_round()
	_update_player_buffs()

	for card in battle_state.cards:
		card.decrease_cooldown()

	var impulse_count = GlobalPlayer.get_impulse_count() + battle_state.impulse_per_turn_bonus + battle_state.consume_impulse_next_turn()
	battle_state.apply_impulses(battle_state.cards, impulse_count)
	player_ui.refresh_impulse_visual(battle_state.cards, battle_state)

	battle_state.used_ability_pages.clear()

	_apply_turn_effects(effects)

	special.on_round_start(battle_state.turn_count)

func _on_end_turn_pressed():
	if performing:
		return
	performing = true
	end_turn_button.disabled = true

	# 调试账本：先把「这回合打出了什么」抄一份（后面 selected_cards 会被清空）
	_last_played_cards = battle_state.selected_cards.duplicate()

	# 打出的书签排到手牌最前（手牌顺序 = 最近打出的顺序）。
	# ⚠️ 顺序只在「打出」这一刻变 —— 选中时不动它，否则双击出牌会被位移耽误。
	player_ui.move_played_to_front(battle_state.selected_cards)

	GlobalTime.add_time_units(BATTLE_TURN_MINUTES / GlobalTime.TIME_UNIT)   # 每回合 10 分钟（单位换算在 GlobalTime.TIME_UNIT）

	for card in battle_state.selected_cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			battle_state.consume_pending(card.get_page_mark(idx))

	var player_result = battle_calculator.calculate_player_effects(
		battle_state.selected_cards,
		battle_state,
		player_ui,
		special.enemy_witch_power()
	)
	battle_state.attack_bonus = player_result.attack_bonus
	_last_player_result = player_result
	_update_player_buffs()

	# 总结算后清空看破（走 owner，不让战斗逻辑直接摸全局）
	battle_state.clear_insight()

	# 演出：白闪 → 伤害数字 → 按实际攻击次数逐个播的命中特效；伤害在「命中那一下」才真正落地，所以这里 await。
	# 期间 performing 为真：空格 / 卡牌确认 / 结束回合按钮都进不来（回合是冻住的）。
	# 调试账本：记下敌人挨打前后的血/护甲，用来对「伤害 → 护甲吸收 → 掉血」
	_last_enemy_hp_before = special.get_health() if special.has_method("get_health") else -1
	_last_enemy_armor_before = special.enemy_armor_count() if special.has_method("enemy_armor_count") else -1
	await special.play_hit(player_result.damage, player_result.hits)
	_last_enemy_hp_after = special.get_health() if special.has_method("get_health") else -1
	_last_enemy_armor_after = special.enemy_armor_count() if special.has_method("enemy_armor_count") else -1
	if special.is_enemy_dead():
		# 保持冻结：按钮不复位，等掉落界面走完由场景切换收尾
		special.on_enemy_defeated()
		return

	if player_result.healing > 0:
		# 卡片的回血已在 BattleFlow.aggregate 里乘过倍率，这里用 raw 避免二次乘算
		GlobalPlayer.heal_raw(player_result.healing)
		# 治疗演出：在玩家头像上冒治疗特效（回合仍冻着，播完才继续）
		await player_heal_fx.play_heal(player_result.healing)

	if player_result.witch_power != 0:
		# 走 state 的出口（不只是 possessed）：这样「本回合魔女化增量」才被记下来（`魇蚀-D3` 读它）
		battle_state.gain_witch_power(player_result.witch_power)

	battle_state.punish_unused_impulses(battle_state.cards)
	player_ui.refresh_impulse_visual(battle_state.cards, battle_state)

	# 护甲在「被敌人攻击」这一刻才交给被动修正，避免把修正值写回 state 造成逐回合叠加
	var total_armor = battle_state.passives.get_armor_per_turn(player_result.armor + battle_state.armor_count)
	_last_total_armor = total_armor
	# 把「这一下挡了多少」显示出来：意图伤害 − 护甲 = 实际掉血，界面上的数字才对得上
	_set_player_armor_display(total_armor)
	# 上回合有没有受伤（汐信 `汐信-D1` 读它）：护甲挡完还掉血才算受伤
	var health_before = GlobalPlayer.health
	special.enemy_take_turn(total_armor)
	_last_player_hp_loss = health_before - GlobalPlayer.health
	if GlobalPlayer.health < health_before:
		battle_state.note_damage_taken()
		# 玩家受伤：两种受伤音效随机播一个（表演性随机，不进种子 —— 见 GlobalRng 头部规矩）
		GlobalAudio.play("玩家受伤-斩击" if randf() < 0.5 else "玩家受伤-撕裂")

	if GlobalPlayer.health <= 0:
		GlobalScenes.check_game_over()
		return

	_update_player_buffs()

	battle_state.passives.notify_turn_end(battle_state.turn_count)
	_debug_round_end()

	# 演出播完，解冻：下一回合可以操作了
	performing = false
	end_turn_button.disabled = false
	_start_round()

## 回合结束的调试输出：这一回合打完之后的各项数值与来源。
## 结构固定为四块，方便逐项核对：
##   [玩家侧状态] battle_state.debug_round()  —— 血/魔女化/乘数明细/关键词触发
##   [玩家行动]   本回合打出的每张书签、每一页「卡面 → 实际」，以及整轮合计
##   [野怪]       意图行、本回合打出、宣告伤害→玩家护甲→实际掉血、护甲、蓄力
##   [对账]       双方血量变化的一条式子
## 不要这些输出就改 `Core/debug_output.gd` 的 FORCE_SILENT。
func _debug_round_end() -> void:
	if not DebugOutput.enabled():
		return
	var enemy_wp = 0
	if special != null and special.has_method("enemy_witch_power"):
		enemy_wp = special.enemy_witch_power()
	battle_state.debug_round(enemy_wp)
	_debug_player_action()
	if special != null and special.has_method("debug_round"):
		# 野怪的 debug_round 需要玩家这一下抵挡的护甲；Boss 的不需要
		if special.has_method("intent_text"):
			special.debug_round(_last_total_armor)
		else:
			special.debug_round()
	_debug_reconcile()

## 玩家行动账本：每张书签每一页「卡面 → 实际」，被作废的页也标出来
func _debug_player_action() -> void:
	DebugOutput.say("──────── [玩家行动] %d 张书签 ────────" % _last_played_cards.size())
	for card in _last_played_cards:
		var pages: Array = card.Generator_bookmark.pages
		DebugOutput.say("  ·「%s」%d 页" % [card.Generator_bookmark.title, pages.size()])
		for idx in range(pages.size()):
			var page = pages[idx]
			var resolved: Dictionary = battle_state.get_resolved(card, idx)
			var voided: String = battle_state.get_voided_reason(card, idx)
			var face: String = _page_face_text(page)
			var actual: String = _resolved_text(resolved)
			var tail := ""
			if voided != "":
				tail = "   ⚠️ %s → 整页作废（算式给的是 %s，不计入）" % [voided, actual]
			elif resolved.is_empty():
				tail = "   （没有进入结算）"
			DebugOutput.say("    [%d] %s｜卡面 %s → 实际 %s%s" % [idx, page.page_name, face, actual, tail])
	if _last_player_result.is_empty():
		return
	var hits: Array = _last_player_result.get("hits", [])
	DebugOutput.say("  合计：伤害 %d（%d 次命中）｜护甲 %d｜回血 %d｜魔女化 %+d｜攻击加算 %d" % [
		int(_last_player_result.get("damage", 0)), hits.size(),
		int(_last_player_result.get("armor", 0)),
		int(_last_player_result.get("healing", 0)),
		int(_last_player_result.get("witch_power", 0)),
		int(_last_player_result.get("attack_bonus", 0))])

## 一页的「卡面」：只列数据面板上写着的数（不含任何乘区）
func _page_face_text(page) -> String:
	var parts: PackedStringArray = []
	if page.damage + page.effect_damage != 0:
		parts.append("伤害%d" % (page.damage + page.effect_damage))
	if page.armor + page.effect_armor != 0:
		parts.append("护甲%d" % (page.armor + page.effect_armor))
	if page.healing + page.effect_healing != 0:
		parts.append("回血%d" % (page.healing + page.effect_healing))
	if page.witchpower + page.effect_witchpower != 0:
		parts.append("魔女化%+d" % (page.witchpower + page.effect_witchpower))
	if page.count + page.effect_count != 0:
		parts.append("能力%d" % (page.count + page.effect_count))
	if not page.keywords.is_empty():
		var kws: PackedStringArray = []
		for kw in page.keywords:
			kws.append(GlobalKeywordDict.display_name(kw))
		parts.append("关键词[%s]" % ", ".join(kws))
	if parts.is_empty():
		parts.append("—")
	return "、".join(parts)

## 一页「实际」结算出来的数（`note_resolved` 记下的，已过所有乘区）
func _resolved_text(resolved: Dictionary) -> String:
	if resolved.is_empty():
		return "—"
	var parts: PackedStringArray = []
	if int(resolved.get("damage", 0)) != 0:
		parts.append("伤害%d" % int(resolved["damage"]))
	if int(resolved.get("armor", 0)) != 0:
		parts.append("护甲%d" % int(resolved["armor"]))
	if int(resolved.get("healing", 0)) != 0:
		parts.append("回血%d" % int(resolved["healing"]))
	if int(resolved.get("witchpower", 0)) != 0:
		parts.append("魔女化%+d" % int(resolved["witchpower"]))
	if int(resolved.get("ability", 0)) != 0:
		parts.append("能力%d" % int(resolved["ability"]))
	return "、".join(parts) if not parts.is_empty() else "0"

## 对账：一回合里双方的血量到底怎么变的（左边减右边必须等于实际变化）
func _debug_reconcile() -> void:
	var player_damage := int(_last_player_result.get("damage", 0))
	var enemy_hp_lost := 0
	var enemy_armor_absorbed := 0
	if _last_enemy_hp_before >= 0 and _last_enemy_hp_after >= 0:
		enemy_hp_lost = _last_enemy_hp_before - _last_enemy_hp_after
		enemy_armor_absorbed = player_damage - enemy_hp_lost
	DebugOutput.say("──────── [对账] 回合 %d ────────" % battle_state.turn_count)
	DebugOutput.say("  玩家伤害 %d → 敌人护甲吸收 %d → 敌人掉血 %d" % [
		player_damage, enemy_armor_absorbed, enemy_hp_lost])
	DebugOutput.say("  玩家护甲 %d ｜ 玩家掉血 %d ｜ 玩家血 %d/%d" % [
		_last_total_armor, _last_player_hp_loss, GlobalPlayer.health, GlobalPlayer.max_health])
	if _last_enemy_hp_after >= 0:
		DebugOutput.say("  敌人血 %d（护甲剩 %d）｜攻击力 %s" % [
			_last_enemy_hp_after,
			_last_enemy_armor_after,
			("[%d]" % special.attack_level) if special != null and "attack_level" in special else "—"])
	DebugOutput.say("─────────────")

func _update_player_buffs():
	var statuses = battle_state.status_dict.duplicate()
	var accessories_bonus = battle_state.get_attack_bonus()
	if accessories_bonus > 0:
		statuses["accessories_attack"] = accessories_bonus
	if battle_state.armor_count > 0:
		statuses["armor_per_turn"] = battle_state.armor_count
	player_ui.update_buffs(statuses, battle_state.ability_buffs)

func _apply_turn_effects(effects: Array) -> void:
	for effect_data in effects:
		var condition: Dictionary = effect_data.get("condition", {})
		for card in battle_state.cards:
			for mark in card.get_all_marks():
				if _match_condition(mark, condition):
					battle_state.apply_effect(effect_data, mark)

func _match_condition(mark: Dictionary, condition: Dictionary) -> bool:
	for key in condition:
		if mark.get(key) != condition[key]:
			return false
	return true
