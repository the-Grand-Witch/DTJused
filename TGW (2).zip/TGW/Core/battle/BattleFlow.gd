extends RefCounted
class_name BattleFlow

## 关键词触发时直接打一行日志（玩家 / 镜像都会打）。排查「关键词到底有没有触发」时看它；
## 开关在 `Core/debug_output.gd`（DEBUG 构建打、导出 release 不打），不影响 `BattleState.keyword_logs`。

## 战斗流程的共享实现（阵营无关）
## ==================================================================
## 分工：
##   GlobalStats  —— 纯函数**公式**（倍率、加算）
##   BattleFlow   —— **流程**：页脚本的编入/使用/结束、关键词、位置层、快照、结算汇总、context
##   BattleState / EnemyState —— **状态**：数值从哪来、写到哪去
##
## 玩家与镜像都调这里的静态方法，所以两边公式一致；
## 差异全部通过入参体现：
##   side          —— 阵营状态（BattleState / EnemyState），供 GlobalStats 取数
##   battle_state  —— 同一场结算的临时状态（临时乘数、快照容器、本回合累计器）
##   passives      —— 该阵营的被动运行器（页可用性通知走它，不碰全局）
##
## 关键词的接口（见 卡牌设计稿.md §八）：
##   输入 —— context（与页脚本共用一份，只增不改）+ kw_vars（声明式表达式的变量表）
##   输出 —— 一个字典，认得的键：
##           add / set / add_to / set_to / multiply_to / extra_play / retrigger /
##           page_cd / flags / witch_power / log
## ==================================================================

# ==================== 类型工具 ====================
## 真类型 = page_type 里去掉 Witch 与 friend。
## 「Witch 永不参与分段」这条口径就落在这里：魔女化标记不会污染段状态。
static func real_types(types: Array) -> Array:
	var out: Array = []
	for t in types:
		if t == Generator_bookpage.PickupType.Witch or t == Generator_bookpage.PickupType.friend:
			continue
		out.append(t)
	return out

## 主类型 = 运行态类型数组的第一个（配比 / RPS / 吃书都认它）
static func main_type(types: Array):
	if types.is_empty():
		return null
	return types[0]

## 类型名。声明式表达式里用英文名（中文只出现在注释与 UI 里）
static func type_name(t) -> String:
	match t:
		Generator_bookpage.PickupType.Attack: return "Attack"
		Generator_bookpage.PickupType.Defense: return "Defense"
		Generator_bookpage.PickupType.Ability: return "Ability"
		Generator_bookpage.PickupType.Heal: return "Heal"
		Generator_bookpage.PickupType.Witch: return "Witch"
	return ""

static func type_of_name(name: String):
	match name:
		"Attack": return Generator_bookpage.PickupType.Attack
		"Defense": return Generator_bookpage.PickupType.Defense
		"Ability": return Generator_bookpage.PickupType.Ability
		"Heal": return Generator_bookpage.PickupType.Heal
		"Witch": return Generator_bookpage.PickupType.Witch
	push_error("[BattleFlow] 未知的类型名：%s（可用 Attack / Defense / Ability / Heal / Witch）" % name)
	return null

# ==================== 位置属性层 ====================
## 整本书签算一份位置表。口径（卡牌设计稿 §五 谱序）：
##   · 分段按**每个真类型**各算一份；同一格可以同时属于多个类型的段，
##     但位置读的是**自己主类型**那一份
##   · 邻 = 相邻格（不是「上一个同类型页」）
##   · 段首 = 右邻同类 · 段中 = 左右都同类 · 段尾 = 左邻同类 · 孤立 = 左右都不同类
##   · 阵中 = 正中间（偶数长度时中间两格都算）
## 返回 { "pages": {下标: {...}}, "size", "type_counts", "type_count", "tag_count", "main_type" }
static func build_positions(card: BookmarkCard) -> Dictionary:
	var n: int = card.Generator_bookmark.pages.size()
	var marks: Array[Dictionary] = card.get_all_marks()
	var types: Array = []
	var mains: Array = []
	for i in range(n):
		var runtime: Array = marks[i]["page_type"]
		types.append(real_types(runtime))
		mains.append(main_type(runtime))

	var type_counts: Dictionary = {}
	var tag_set: Dictionary = {}
	for i in range(n):
		for t in types[i]:
			type_counts[t] = type_counts.get(t, 0) + 1
		for t in marks[i]["page_type"]:
			tag_set[t] = true

	var mid_lo: int = int(floor((n + 1) / 2.0))
	var mid_hi: int = int(ceil((n + 1) / 2.0))
	var table: Dictionary = {}
	for i in range(n):
		var t = mains[i]
		var left_same: bool = i > 0 and t != null and t in types[i - 1]
		var right_same: bool = i < n - 1 and t != null and t in types[i + 1]
		var pos: String = "alone"
		if left_same and right_same:
			pos = "middle"
		elif right_same:
			pos = "head"
		elif left_same:
			pos = "tail"
		var start: int = i
		while t != null and start > 0 and t in types[start - 1]:
			start -= 1
		var end: int = i
		while t != null and end < n - 1 and t in types[end + 1]:
			end += 1
		table[i] = {
			"index": i,
			"types": types[i],
			"main_type": t,
			"position": pos,
			"segment_start": start,
			"segment_end": end,
			"segment_index": i - start + 1,
			"segment_length": end - start + 1,
			"segment_head": start,
			"segment_tail": end,
			"position_number": i + 1,
			"page_total": n,
			"pages_before": i,
			"pages_after": n - 1 - i,
			"is_middle": (i + 1) >= mid_lo and (i + 1) <= mid_hi,
			"left_index": i - 1,
			"right_index": i + 1 if i < n - 1 else -1,
			"left_type": mains[i - 1] if i > 0 else null,
			"right_type": mains[i + 1] if i < n - 1 else null,
		}

	# 书签的主类型：张数最多的真类型（并列时按枚举顺序取先者）
	var bookmark_main = null
	var best: int = -1
	for t in type_counts:
		var count: int = type_counts[t]
		if count > best:
			best = count
			bookmark_main = t
	return {
		"pages": table,
		"size": n,
		"type_counts": type_counts,
		"type_count": type_counts.size(),
		"tag_count": tag_set.size(),
		"main_type": bookmark_main,
	}

## 声明式表达式（关键词的 when / then）的变量表。
## 变量名一变，所有 .tres 里的声明就跟着失效 —— 改这里要同步 卡牌设计稿.md §八.11。
static func keyword_vars(card: BookmarkCard, idx: int, positions: Dictionary, battle_state, enemy_witch_power: int) -> Dictionary:
	var p: Dictionary = positions["pages"][idx]
	var mark: Dictionary = card.get_page_mark(idx)
	var counts: Dictionary = positions["type_counts"]
	var left_res: Dictionary = battle_state.get_resolved(card, p["left_index"])
	return {
		# ---- 位置（自己主类型那一份）----
		"position": p["position"],
		"is_segment_head": 1 if p["position"] == "head" else 0,
		"is_segment_middle": 1 if p["position"] == "middle" else 0,
		"is_segment_tail": 1 if p["position"] == "tail" else 0,
		"is_alone": 1 if p["position"] == "alone" else 0,
		"main_type": type_name(p["main_type"]),
		"left_type": type_name(p["left_type"]),
		"right_type": type_name(p["right_type"]),
		"position_number": p["position_number"],
		"segment_index": p["segment_index"],
		"segment_length": p["segment_length"],
		"is_middle": 1 if p["is_middle"] else 0,
		"pages_before": p["pages_before"],
		"pages_after": p["pages_after"],
		# ---- 邻：left_is_* / right_is_* 按「邻页含有该真类型」判（与 *_neighbors 同口径）----
		"left_is_attack": _has_type(card, p["left_index"], Generator_bookpage.PickupType.Attack),
		"left_is_defense": _has_type(card, p["left_index"], Generator_bookpage.PickupType.Defense),
		"left_is_heal": _has_type(card, p["left_index"], Generator_bookpage.PickupType.Heal),
		"left_is_ability": _has_type(card, p["left_index"], Generator_bookpage.PickupType.Ability),
		"left_is_witch": _has_type(card, p["left_index"], Generator_bookpage.PickupType.Witch),
		"right_is_attack": _has_type(card, p["right_index"], Generator_bookpage.PickupType.Attack),
		"right_is_defense": _has_type(card, p["right_index"], Generator_bookpage.PickupType.Defense),
		"right_is_heal": _has_type(card, p["right_index"], Generator_bookpage.PickupType.Heal),
		"right_is_ability": _has_type(card, p["right_index"], Generator_bookpage.PickupType.Ability),
		"right_is_witch": _has_type(card, p["right_index"], Generator_bookpage.PickupType.Witch),
		# ---- 本书签（振鸣读这些）----
		"bookmark_size": positions["size"],
		"type_count": positions["type_count"],
		"tag_count": positions["tag_count"],
		"attack_pages": int(counts.get(Generator_bookpage.PickupType.Attack, 0)),
		"defense_pages": int(counts.get(Generator_bookpage.PickupType.Defense, 0)),
		"ability_pages": int(counts.get(Generator_bookpage.PickupType.Ability, 0)),
		"heal_pages": int(counts.get(Generator_bookpage.PickupType.Heal, 0)),
		"witch_pages": _tag_count(card, Generator_bookpage.PickupType.Witch),
		"unused_pages": _unused_pages(card),
		"bookmark_plays": card.battle_play_count,
		"types_after": _distinct_types_after(card, idx),
		# ---- 邻（attack_neighbors 这类按「邻页含有该类型」数，left_type 按「邻页的主类型」）----
		"attack_neighbors": _neighbor_count(card, idx, positions, Generator_bookpage.PickupType.Attack),
		"defense_neighbors": _neighbor_count(card, idx, positions, Generator_bookpage.PickupType.Defense),
		"ability_neighbors": _neighbor_count(card, idx, positions, Generator_bookpage.PickupType.Ability),
		"heal_neighbors": _neighbor_count(card, idx, positions, Generator_bookpage.PickupType.Heal),
		"same_neighbors": _same_neighbors(positions, idx),
		"left_armor": int(left_res.get("armor", 0)),
		"left_damage": int(left_res.get("damage", 0)),
		"left_healing": int(left_res.get("healing", 0)),
		# ---- 本回合「已结算」的产出 ----
		"resolved_damage": battle_state.resolved_damage,
		"resolved_armor": battle_state.resolved_armor,
		"resolved_healing": battle_state.resolved_healing,
		# ---- 本页最终值（含倍率；「本次正在结算的这一份」也算进去）----
		"final_damage": final_value(card, idx, "damage", battle_state, enemy_witch_power),
		"final_armor": final_value(card, idx, "armor", battle_state, enemy_witch_power),
		"final_healing": final_value(card, idx, "healing", battle_state, enemy_witch_power),
		"final_witchpower": final_value(card, idx, "witchpower", battle_state, enemy_witch_power),
		# ---- 状态 ----
		"page_plays": int(mark["use_count"]),
		"page_cd": int(mark["cd_remaining"]),
		"page_limit": battle_state.get_bookmark_page_limit(),
		"witch_power": battle_state.get_witch_power(),
		"enemy_witch_power": enemy_witch_power,
		"turn_count": battle_state.turn_count,
		# ---- 本页自己那几格（不含倍率），"基础数值"类效果读它 ----
		"self_damage": _raw_value(card, idx, "damage"),
		"self_armor": _raw_value(card, idx, "armor"),
		"self_healing": _raw_value(card, idx, "healing"),
		"self_witchpower": _raw_value(card, idx, "witchpower"),
		# ---- 振鸣读的本书签结构 ----
		"is_sole_of_type": 1 if _type_count(card, p["main_type"]) == 1 else 0,
		"is_type_most": 1 if _type_count(card, p["main_type"]) == _max_type_count(positions) else 0,
		"same_keyword_plays_turn": _keyword_plays(battle_state.keyword_plays_turn, card, idx),
		"same_keyword_plays_battle": _keyword_plays(battle_state.keyword_plays_battle, card, idx),
		"same_keyword_pages": _keyword_pages_in_play(battle_state, card, idx),
		# ---- 魇蚀读的那些数 ----
		"witch_gain_this_turn": battle_state.witch_gain_this_turn,
		"impulse_per_turn": battle_state.impulse_per_turn_bonus,
		"impulse_punishment": battle_state.get_final_impulse_punishment(),
		"impulse_pages": _impulse_pages(battle_state),
		# ---- 汐信读的回合级状态 ----
		"wait_stack": int(mark["persistent"].get("wait", 0)),
		"played_this_turn": 1 if battle_state.is_played_this_turn(card, idx) else 0,
		"played_last_turn": 1 if battle_state.was_played_last_turn(card, idx) else 0,
		"last_play_attack": _flag(battle_state.types_played_last_turn, Generator_bookpage.PickupType.Attack),
		"last_play_defense": _flag(battle_state.types_played_last_turn, Generator_bookpage.PickupType.Defense),
		"last_play_heal": _flag(battle_state.types_played_last_turn, Generator_bookpage.PickupType.Heal),
		"last_play_ability": _flag(battle_state.types_played_last_turn, Generator_bookpage.PickupType.Ability),
		"last_play_witch": _flag(battle_state.types_played_last_turn, Generator_bookpage.PickupType.Witch),
		"last_play_type_count": battle_state.types_played_last_turn.size(),
		"damage_taken_last_turn": 1 if battle_state.damage_taken_last_turn else 0,
		"damage_dealt_this_turn": 1 if battle_state.resolved_damage > 0 else 0,
		"has_last_played": 1 if battle_state.last_played_index >= 0 else 0,
		"bookmark_cd_total": _bookmark_cd_total(card),
		"global_ready_pages": battle_state.count_ready_pages(),
		"global_slowest_cd": int(battle_state.slowest_page()["cd"]),
	}

## 字典里有没有这个类型的标记（1 / 0）
static func _flag(flags: Dictionary, t) -> int:
	return 1 if flags.has(t) else 0

## 本页某格的**当前数值**（基础 + 特效，不含任何倍率与加算）
static func _raw_value(card: BookmarkCard, idx: int, field: String) -> int:
	var v: Dictionary = card.get_values(idx)
	return int(v.get(field, 0)) + int(v.get("effect_" + field, 0))

## 本书签里有几张主类型为 t 的页
static func _type_count(card: BookmarkCard, t) -> int:
	var count: int = 0
	for i in range(card.Generator_bookmark.pages.size()):
		if main_type(card.get_runtime_types(i)) == t:
			count += 1
	return count

## 本书签里最多的那个类型有几张
static func _max_type_count(positions: Dictionary) -> int:
	var counts: Dictionary = positions["type_counts"]
	var best: int = 0
	for t in counts:
		var count: int = counts[t]
		if count > best:
			best = count
	return best

## 本页的第一个关键词被打出过几次
static func _keyword_plays(counter: Dictionary, card: BookmarkCard, idx: int) -> int:
	var keywords: Array = card.Generator_bookmark.pages[idx].keywords
	if keywords.is_empty():
		return 0
	return int(counter.get(keywords[0], 0))

## 本次结算里一共有几页带本页那个关键词（振鸣 `振鸣-B1` 的「手上振鸣卡数量」）
static func _keyword_pages_in_play(battle_state, card: BookmarkCard, idx: int) -> int:
	var keywords: Array = card.Generator_bookmark.pages[idx].keywords
	if keywords.is_empty():
		return 0
	var name: StringName = keywords[0]
	var count: int = 0
	for c in battle_state.touched_cards:
		for page in c.Generator_bookmark.pages:
			if name in page.keywords:
				count += 1
	return count

## 本方当前挂着冲动的页数
static func _impulse_pages(battle_state) -> int:
	var count: int = 0
	for card in battle_state.cards:
		for mark in card.get_all_marks():
			if mark.get("effects", {}).get("impulse", false):
				count += 1
	return count

## 本书签所有页的 cd 之和（读资源的 cd，玩家自己能算出来）
static func _bookmark_cd_total(card: BookmarkCard) -> int:
	var total: int = 0
	for page in card.Generator_bookmark.pages:
		total += page.cd
	return total

static func _tag_count(card: BookmarkCard, t) -> int:
	var count: int = 0
	for mark in card.get_all_marks():
		if t in mark["page_type"]:
			count += 1
	return count

## 某格是否含有该类型（下标 -1 = 没有这一格）
static func _has_type(card: BookmarkCard, i: int, t) -> int:
	if i < 0:
		return 0
	if t in card.get_runtime_types(i):
		return 1
	return 0

static func _unused_pages(card: BookmarkCard) -> int:
	var count: int = 0
	for mark in card.get_all_marks():
		if int(mark["use_count"]) == 0:
			count += 1
	return count

## 自己之后出现过几种真类型（祭仪 `谱序-W1` 的「后续各类型第一张」有多份）
static func _distinct_types_after(card: BookmarkCard, idx: int) -> int:
	var seen: Dictionary = {}
	for i in range(idx + 1, card.Generator_bookmark.pages.size()):
		for t in real_types(card.get_runtime_types(i)):
			seen[t] = true
	return seen.size()

## 左右邻里**含有**该类型的张数（0~2）
static func _neighbor_count(card: BookmarkCard, idx: int, positions: Dictionary, t) -> int:
	var p: Dictionary = positions["pages"][idx]
	var count: int = 0
	for neighbor in [p["left_index"], p["right_index"]]:
		var i: int = neighbor
		if i < 0:
			continue
		if t in card.get_runtime_types(i):
			count += 1
	return count

## 左右邻里主类型与自己相同的张数（0~2）
static func _same_neighbors(positions: Dictionary, idx: int) -> int:
	var p: Dictionary = positions["pages"][idx]
	var count: int = 0
	for neighbor in [p["left_index"], p["right_index"]]:
		var i: int = neighbor
		if i < 0:
			continue
		if positions["pages"][i]["main_type"] == p["main_type"]:
			count += 1
	return count

# ==================== 本页最终值 ====================
## 本页的最终产出 —— 与 aggregate 同一套公式（逐快照取整 → 乘通道倍率 → 取整）。
## 用在「使用时」：此时本次的 values 还没被采集进快照，
## 所以它 = 已采集的快照 + 本次将产出的那一份。
static func final_value(card: BookmarkCard, idx: int, field: String, battle_state, enemy_witch_power: int) -> int:
	var mark: Dictionary = card.get_page_mark(idx)
	var types: Array = mark["page_type"]
	var calc = battle_state
	var ability_mult: Dictionary = GlobalStats.collect_ability_multipliers(calc, battle_state)
	var channel_mult: float = 1.0
	match field:
		"damage":
			channel_mult = GlobalStats.get_damage_multiplier(calc, enemy_witch_power, battle_state, ability_mult)
			if Generator_bookpage.PickupType.Attack in types and calc.has_impulse(card, idx):
				channel_mult *= GlobalStats.get_impulse_multiplier(calc)
		"armor":
			channel_mult = GlobalStats.get_armor_multiplier(calc, battle_state, ability_mult)
		"healing":
			channel_mult = GlobalStats.get_heal_multiplier(calc, battle_state, ability_mult)
		"witchpower":
			channel_mult = GlobalStats.get_witch_power_multiplier(calc, battle_state, ability_mult)

	# ⚠️ 攻击加算**只作用于攻击页** —— 与 aggregate 里 `if Attack in types: result.damage += …` 同一口径。
	#    不判类型的话，身上带着攻击加算时（例如打过「蓄力」/ 戴攻击项链）**防御、治疗页也会被算出一份伤害**：
	#    结算总伤害仍是 0（aggregate 那边有类型判定），但 note_hit 照 final_value 会白记一条命中
	#    ⇒ 每页都放一发斩击特效 + 音效（「0 攻击的防御页仍然触发攻击特效」就是这么来的）。
	var bonus: int = 0
	if field == "damage" and Generator_bookpage.PickupType.Attack in types:
		bonus = battle_state.attack_bonus + calc.get_attack_bonus()
	# 防御加算同口径：只作用于**防御页**（饰品「防御书页数值+N」）
	# ⚠️ 这是**玩家饰品**的加成，不能顺手加到敌人（野怪 / 镜像）的防御页上
	if field == "armor" and Generator_bookpage.PickupType.Defense in types and calc is PlayerState:
		bonus = GlobalAccessories.get_defense_page_bonus()
	var total: float = 0.0
	for snap in mark["snapshots"]:
		total += _round_field(field, _snapshot_field(snap, field, bonus))
	var v: Dictionary = card.get_values(idx)
	var live: float = float(v.get(field, 0)) + float(v.get("effect_" + field, 0)) + float(mark["overall_sum"])
	if field == "damage" or field == "armor":
		live += bonus
	live *= float(mark["overall_multiplier"])
	total += _round_field(field, live)
	return int(ceil(total * channel_mult))

## 一份快照里某字段的贡献（加算在括号内、乘区在括号外 —— 与旧 aggregate 完全一致）
## no_bonus 的快照（repeat_keyword 的增量快照）不吃攻击加算，避免"重复触发"平白多拿加算。
static func _snapshot_field(snap: Dictionary, field: String, attack_bonus: int) -> float:
	var v: Dictionary = snap["values"]
	var bonus: int = attack_bonus if field == "damage" else 0
	if snap.get("no_bonus", false):
		bonus = 0
	return (float(v.get(field, 0)) + float(v.get("effect_" + field, 0)) + float(snap["sum"]) + bonus) * float(snap["mult"])

## 逐快照的取整口径：伤害向上取整，其余四舍五入（与旧 aggregate 一致）
static func _round_field(field: String, value: float) -> int:
	if field == "damage":
		return int(ceil(value))
	return int(round(value))

# ==================== 阶段效果 ====================
## phase：
##   "enter" / "use" / "end" —— 书签结算的三个阶段（玩家与镜像共用）
##   "intent"                —— 敌人**预告意图**那一刻先跑一遍（只有需要提前挂到对手身上的
##                              效果才实现 `on_intent`，例如硬骨 / 吼叫：野怪回合在玩家之后，
##                              等它出牌才生效就晚了一回合，看起来像「意图和实际对不上」）
static func run_phase_effects(card: BookmarkCard, idx: int, phase: String, all_cards: Array, battle_state, enemy_witch_power: int = 0) -> void:
	var page = card.Generator_bookmark.pages[idx]
	if page.page_effects.is_empty():
		return
	var context = build_context(card, idx, all_cards, battle_state, phase, enemy_witch_power)
	for effect_script in page.page_effects:
		if effect_script == null:
			continue
		var script_obj = effect_script.new()
		match phase:
			"intent":
				if script_obj.has_method("on_intent"):
					script_obj.on_intent(context)
			"enter":
				if script_obj.has_method("on_enter"):
					script_obj.on_enter(context)
			"use":
				if script_obj.has_method("on_use"):
					script_obj.on_use(context)
			"end":
				if script_obj.has_method("on_end"):
					script_obj.on_end(context)

# ==================== 关键词 ====================
## 关键词是无状态的（GlobalKeywordDict 只吃 context），所以两边共用完全安全。
## context 与页脚本**共用同一份**（见 build_context），另外补上旧关键词在读的键。
## keyword_phase = "use"（打出时，默认）/ "round_end" / "round_start"：
## 声明里的 "at" 与它比对，决定这一条声明在哪个时机跑。
## in_repeat = true 表示这次是 repeat_keyword 的重跑（不再接受 retrigger / repeat_keyword）。
static func run_keywords(card: BookmarkCard, idx: int, all_cards: Array, battle_state, enemy_witch_power: int, keyword_phase: String = "use", in_repeat: bool = false) -> void:
	var page = card.Generator_bookmark.pages[idx]
	if page.keywords.is_empty():
		return
	var context = build_context(card, idx, all_cards, battle_state, keyword_phase, enemy_witch_power)
	var positions: Dictionary = context["positions"]
	# 旧关键词读的键：语义一个字不差（card 仍然是**页资源**）
	context["card"] = page
	context["bookmark"] = card.Generator_bookmark
	context["player_cards"] = all_cards
	context["player_attack_bonus"] = battle_state.attack_bonus
	context["has_impulse"] = battle_state.has_impulse(card, idx)
	context["enemy_witch_power"] = enemy_witch_power
	context["keyword_phase"] = keyword_phase
	var mark: Dictionary = card.get_page_mark(idx)
	for keyword in page.keywords:
		context["keyword"] = keyword
		var keyword_result: Dictionary = GlobalKeywordDict.execute_keyword(keyword, context)
		apply_keyword_result(keyword_result, card, idx, positions, battle_state, all_cards, enemy_witch_power, in_repeat)
		# 只要关键词真的产出了东西就记一条（玩家/镜像都记），
		# 回合结算日志里能看到「哪一页的哪个关键词在哪个时机生效」。
		# ⚠️ 镜像的 `reset_round()` 会在它出牌时清掉 keyword_logs（round_start 那条会被冲掉），
		#    所以这里同时直接打一行，玩家/镜像、哪个时机都看得见。
		if not keyword_result.is_empty():
			var text := "「%s」%s 生效 %s" % [GlobalKeywordDict.display_name(keyword), keyword_phase, _short_result(keyword_result)]
			battle_state.note_keyword_log(card, idx, text)
			if DebugOutput.enabled():
				DebugOutput.say("[关键词] %s 第%d页 %s" % [card.Generator_bookmark.title, idx, text])

## 关键词结果的简写（日志用）：只列改了哪些键，不打印整份快照
static func _short_result(result: Dictionary) -> String:
	var parts: PackedStringArray = []
	for key in result:
		var value = result[key]
		if value is Dictionary:
			var inner: PackedStringArray = []
			for field in value:
				inner.append("%s=%s" % [field, str(value[field])])
			parts.append("%s{%s}" % [key, ", ".join(inner)])
		else:
			parts.append("%s=%s" % [key, str(value)])
	return "、".join(parts)

## 回合级关键词：遍历**本方全部书签**的每一页。
## 为什么不是「本次选中的书签」——汐信的等待正是「它所在的书签这回合没被选中」，
## 只在选中的书签里找，就永远找不到正在等的那些页。
static func run_keyword_pass(battle_state, enemy_witch_power: int, keyword_phase: String) -> void:
	for card in battle_state.cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			run_keywords(card, idx, battle_state.cards, battle_state, enemy_witch_power, keyword_phase)

# ==================== 关键词结果的落地 ====================
## 认识的键见文件头；不认识的键一律忽略（旧关键词只返回 add，行为不变）。
## ⚠️ 读取口径：`kw_vars` 在**打出那一刻**算一次 —— 所以一张页自己的 `witch_power` 变化
##    **不参与它自己的读取**（后一张页读得到）。这里把 `witch_power` 放在最前面，是为了让
##    「代价」先记进本回合增量，与别的键的处理顺序无关。
## in_repeat = true 时不接受 retrigger / repeat_keyword（「重复触发不再触发重复」，只放一层）。
static func apply_keyword_result(result: Dictionary, card: BookmarkCard, idx: int, positions: Dictionary, battle_state, all_cards: Array = [], enemy_witch_power: int = 0, in_repeat: bool = false) -> void:
	var wp: Dictionary = result.get("witch_power", {})
	if wp.has("self"):
		battle_state.gain_witch_power(int(wp["self"]))
	if wp.has("enemy") and battle_state.enemy_side != null:
		battle_state.enemy_side.gain_witch_power(int(wp["enemy"]))
	if result.has("swap"):
		var pair: Array = result["swap"]
		var current: Dictionary = card.get_values(idx)
		var first = current.get(pair[0], 0)
		var second = current.get(pair[1], 0)
		battle_state.set_page_value(card, idx, pair[0], second)
		battle_state.set_page_value(card, idx, pair[1], first)
	for field in result.get("add", {}):
		battle_state.add_page_value(card, idx, field, result["add"][field])
	for field in result.get("set", {}):
		battle_state.set_page_value(card, idx, field, result["set"][field])
	for key in result.get("add_persistent", {}):
		battle_state.add_persistent(card, idx, key, result["add_persistent"][key])
	for key in result.get("set_persistent", {}):
		battle_state.set_persistent(card, idx, key, result["set_persistent"][key])
	for entry in _entries(result.get("add_to", [])):
		var add_entry: Dictionary = entry
		for target in resolve_selector(card, idx, positions, add_entry.get("who", "self"), battle_state):
			battle_state.add_to_page(target["card"], target["index"], add_entry.get("field", ""), add_entry.get("value", 0))
	for entry in _entries(result.get("set_to", [])):
		var set_entry: Dictionary = entry
		for target in resolve_selector(card, idx, positions, set_entry.get("who", "self"), battle_state):
			battle_state.set_to_page(target["card"], target["index"], set_entry.get("field", ""), set_entry.get("value", 0))
	for entry in _entries(result.get("add_main", [])):
		var main_entry: Dictionary = entry
		for target in resolve_selector(card, idx, positions, main_entry.get("who", "self"), battle_state):
			add_main_value(target["card"], target["index"], main_entry.get("value", 0), battle_state)
	for entry in _entries(result.get("multiply_to", [])):
		var mult_entry: Dictionary = entry
		for target in resolve_selector(card, idx, positions, mult_entry.get("who", "self"), battle_state):
			battle_state.multiply_overall(target["card"], target["index"], mult_entry.get("value", 1.0))
	for entry in _entries(result.get("extra_play", [])):
		var play_entry: Dictionary = entry
		var times: int = int(play_entry.get("n", 1))
		for target in resolve_selector(card, idx, positions, play_entry.get("who", "self"), battle_state):
			battle_state.add_play_count(target["card"], target["index"], times)
	for entry in _entries(result.get("pending", [])):
		var pending_entry: Dictionary = entry
		battle_state.set_pending(card, idx, pending_entry)
	if not in_repeat:
		for entry in _entries(result.get("retrigger", [])):
			var retrigger_entry: Dictionary = entry
			for target in resolve_selector(card, idx, positions, retrigger_entry.get("who", "self"), battle_state):
				battle_state.queue_retrigger(target["card"], target["index"])
		for entry in _entries(result.get("repeat_keyword", [])):
			var repeat_entry: Dictionary = entry
			var repeat_times: int = int(repeat_entry.get("times", 1))
			for target in resolve_selector(card, idx, positions, repeat_entry.get("who", "self"), battle_state):
				repeat_keyword(target["card"], target["index"], all_cards, battle_state, enemy_witch_power, repeat_times)
	for entry in _entries(result.get("page_cd", [])):
		var cd_entry: Dictionary = entry
		for target in resolve_selector(card, idx, positions, cd_entry.get("who", "self"), battle_state):
			if cd_entry.has("set"):
				battle_state.set_page_cd(target["card"], target["index"], int(cd_entry["set"]))
			else:
				battle_state.add_page_cd(target["card"], target["index"], int(cd_entry.get("add", 0)))
	for entry in _entries(result.get("card_cd", [])):
		var card_cd_entry: Dictionary = entry
		for item in _resolve_cards(card, card_cd_entry.get("who", "self"), battle_state):
			var target_card: BookmarkCard = item
			target_card.current_cd = int(card_cd_entry.get("set", 0))
	for entry in _entries(result.get("flags", [])):
		var flag_entry: Dictionary = entry
		for target in resolve_selector(card, idx, positions, flag_entry.get("who", "self"), battle_state):
			if flag_entry.has("add_type"):
				battle_state.add_runtime_type(target["card"], target["index"], type_of_name(flag_entry["add_type"]))
			if flag_entry.has("persist"):
				battle_state.set_persistent(target["card"], target["index"], flag_entry["persist"], flag_entry.get("value", 0))
	var impulse: Dictionary = result.get("impulse", {})
	if impulse.has("per_turn"):
		battle_state.add_impulse_per_turn(int(impulse["per_turn"]))
	if impulse.has("next_turn"):
		battle_state.add_impulse_next_turn(int(impulse["next_turn"]))
	if impulse.has("punishment"):
		battle_state.add_impulse_punishment(int(impulse["punishment"]))
	if result.has("log"):
		battle_state.note_keyword_log(card, idx, str(result["log"]))

## 「基础数值 +N」：加到目标页**主类型对应的那一格**（攻→伤害 / 防→护甲 / 回→治疗 / 魔→魔女化 / 能→次数）
static func add_main_value(card: BookmarkCard, idx: int, value, battle_state) -> void:
	var field: String = main_field(card.get_runtime_types(idx))
	if field == "":
		return
	battle_state.add_to_page(card, idx, field, value)

## 类型 → 它的数值字段
static func main_field(types: Array) -> String:
	match main_type(types):
		Generator_bookpage.PickupType.Attack: return "damage"
		Generator_bookpage.PickupType.Defense: return "armor"
		Generator_bookpage.PickupType.Heal: return "healing"
		Generator_bookpage.PickupType.Witch: return "witchpower"
		Generator_bookpage.PickupType.Ability: return "count"
	return ""

## 额外触发某页的**关键词效果**（不是重放整页）：
## 跑一遍它的关键词，然后只把「这次跑出来的增量」记成一份快照（`no_bonus`，不吃攻击加算）。
## ⇒ 基础数值不会被重复产出，所以「再触发一次谱序/振鸣效果」是干净的。
## ⚠️ 重复期间产生的 repeat_keyword / retrigger 不生效（只放一层）。
static func repeat_keyword(card: BookmarkCard, idx: int, all_cards: Array, battle_state, enemy_witch_power: int, times: int = 1) -> void:
	var mark: Dictionary = card.get_page_mark(idx)
	if not mark.has("snapshots"):
		mark["snapshots"] = []
	for i in range(max(0, times)):
		var before: Dictionary = card.get_values(idx).duplicate()
		battle_state.clear_used_page(card, idx)
		run_keywords(card, idx, all_cards, battle_state, enemy_witch_power, "use", true)
		append_delta_snapshot(card, idx, before)
		battle_state.mark_used(card, idx)

## 把「相对 before 的增量」记成一份快照
static func append_delta_snapshot(card: BookmarkCard, idx: int, before: Dictionary) -> void:
	var after: Dictionary = card.get_values(idx)
	var delta: Dictionary = {}
	for field in after:
		var diff = after[field] - before.get(field, 0)
		if diff != 0:
			delta[field] = diff
	card.get_page_mark(idx)["snapshots"].append({"values": delta, "mult": 1.0, "sum": 0, "no_bonus": true})

## 书签级 selector（只有 self / others / all 三种）
static func _resolve_cards(card: BookmarkCard, who: String, battle_state) -> Array:
	if who == "self":
		return [card]
	if who == "others":
		var others: Array = []
		for c in battle_state.cards:
			if c != card:
				others.append(c)
		return others
	if who == "all":
		return battle_state.cards.duplicate()
	return []

## 把「可以是单个字典 / 单个字符串 / 数组」的声明统一成字典数组
static func _entries(spec) -> Array:
	var out: Array = []
	if spec is Array:
		for item in spec:
			out.append(item)
	elif spec is Dictionary:
		out.append(spec)
	return out

## selector 迷你语法（见 卡牌设计稿.md §八.2.3）：
##   self · all · all_pages · segment_head · segment_tail · last_played · slowest_page
##   index:4              位置数（1 起）
##   type:Defense         该真类型的全部页 · type:Defense:2 该类型第 2 张
##   next:Defense / prev:Defense   往后 / 往前第一张该类型页（不限段）
##   after_self:Defense   同段内、自己之后的该类型页
##   next_page            本书签紧跟着的下一页
##   next_keyword:ZM / last_keyword:ZM / all_keyword:ZM
##                        按**关键词**找页：本回合之后第一张 / 本回合上一张打出的 / 本次结算里全部
## all_pages / slowest_page / last_played / last_keyword / all_keyword 需要 battle_state。
## 返回 [{card, index}, ...]
static func resolve_selector(card: BookmarkCard, idx: int, positions: Dictionary, who: String, battle_state = null) -> Array:
	var pages: Dictionary = positions["pages"]
	var n: int = positions["size"]
	var out: Array = []
	if who == "self":
		out.append({"card": card, "index": idx})
		return out
	if who == "all":
		for i in range(n):
			out.append({"card": card, "index": i})
		return out
	if who == "all_pages":
		for c in battle_state.cards:
			for i in range(c.Generator_bookmark.pages.size()):
				out.append({"card": c, "index": i})
		return out
	if who == "slowest_page":
		var slowest: Dictionary = battle_state.slowest_page()
		if slowest["index"] >= 0:
			out.append({"card": slowest["card"], "index": slowest["index"]})
		return out
	if who == "last_played":
		if battle_state.last_played_index >= 0:
			out.append({"card": battle_state.last_played_card, "index": battle_state.last_played_index})
		return out
	if who == "segment_head":
		out.append({"card": card, "index": pages[idx]["segment_head"]})
		return out
	if who == "segment_tail":
		out.append({"card": card, "index": pages[idx]["segment_tail"]})
		return out
	var parts: PackedStringArray = who.split(":")
	var head: String = parts[0]
	if head == "index":
		out.append({"card": card, "index": int(parts[1]) - 1})
		return out
	if head == "type":
		var t = type_of_name(parts[1])
		var nth: int = int(parts[2]) if parts.size() > 2 else 0
		var found: int = 0
		for i in range(n):
			if t in pages[i]["types"]:
				found += 1
				if nth == 0 or found == nth:
					out.append({"card": card, "index": i})
		return out
	if head == "next" or head == "prev":
		var t2 = type_of_name(parts[1])
		var step: int = 1 if head == "next" else -1
		var i2: int = idx + step
		while i2 >= 0 and i2 < n:
			if t2 in pages[i2]["types"]:
				out.append({"card": card, "index": i2})
				break
			i2 += step
		return out
	if head == "after_self":
		var t3 = type_of_name(parts[1])
		for i3 in range(idx + 1, int(pages[idx]["segment_end"]) + 1):
			if t3 in pages[i3]["types"]:
				out.append({"card": card, "index": i3})
		return out
	if head == "next_page":
		if idx + 1 < n:
			out.append({"card": card, "index": idx + 1})
		return out
	if head == "next_keyword":
		var name_next: StringName = parts[1]
		for i4 in range(idx + 1, n):
			if name_next in card.Generator_bookmark.pages[i4].keywords:
				out.append({"card": card, "index": i4})
				break
		return out
	if head == "last_keyword":
		var name_last: StringName = parts[1]
		var order: Array = battle_state.play_order
		for o in range(order.size() - 1, -1, -1):
			var played: Dictionary = order[o]
			var played_card: BookmarkCard = played["card"]
			var played_index: int = played["index"]
			if played_card == card and played_index == idx:
				continue
			if name_last in played_card.Generator_bookmark.pages[played_index].keywords:
				out.append({"card": played_card, "index": played_index})
				break
		return out
	if head == "all_keyword":
		var name_all: StringName = parts[1]
		for c in battle_state.touched_cards:
			for i5 in range(c.Generator_bookmark.pages.size()):
				if name_all in c.Generator_bookmark.pages[i5].keywords:
					out.append({"card": c, "index": i5})
		return out
	return out

# ==================== 快照 ====================
## 记录一次「使用」的结果，并把 overall 乘区清零（下一次使用重新累计）
static func record_snapshot(card: BookmarkCard, idx: int) -> void:
	var mark = card.get_page_mark(idx)
	if not mark.has("snapshots"):
		mark["snapshots"] = []
	mark["snapshots"].append({
		"values": card.get_values(idx).duplicate(),
		"mult": mark.get("overall_multiplier", 1.0),
		"sum": mark.get("overall_sum", 0),
	})
	mark["overall_multiplier"] = 1.0
	mark["overall_sum"] = 0

## 清掉一次结算留下的临时痕迹（本回合区；persistent 与 use_count 不动）
static func clear_marks(card: BookmarkCard, idx: int) -> void:
	var mark = card.get_page_mark(idx)
	mark["overall_multiplier"] = 1.0
	mark["overall_sum"] = 0
	mark["play_count"] = 1
	mark["snapshots"] = []

# ==================== 能力脚本 ====================
static func call_ability_scripts(card: BookmarkCard, idx: int, count: float) -> Dictionary:
	var page = card.Generator_bookmark.pages[idx]
	var combined = {}
	for effect_script in page.page_effects:
		if effect_script == null:
			continue
		var script_obj = effect_script.new()
		if script_obj.has_method("on_ability"):
			var r = script_obj.on_ability({"count": count, "self_card": card, "self_index": idx})
			if r is Dictionary:
				for key in r:
					combined[key] = combined.get(key, 0) + r[key]
	return combined

# ==================== 使用阶段（阵营无关，玩家与镜像共用） ====================
## 编入 → 使用（受 play_count / extra_play 影响）→ 排空 retrigger →
## 结束阶段 → **回合结束关键词** → 再排空 retrigger（`汐信-W1` 会在这里插进一次重放）
## 返回值：真的进入了结算的页下标（冲动命中判定要用，见 enemy.gd）
static func run_use_phase(cards: Array[BookmarkCard], battle_state, enemy_witch_power: int) -> Array[int]:
	var played_indices: Array[int] = []
	# 先把本次打出的书签全部登记进结算范围（振鸣的「手上全部 X 页」要能一次看全）
	for card in cards:
		battle_state.touch_card(card)
	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			run_phase_effects(card, idx, "enter", cards, battle_state, enemy_witch_power)

	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			if not battle_state.is_page_available(card.Generator_bookmark.pages[idx]):
				continue
			played_indices.append(idx)
			play_page(card, idx, cards, battle_state, enemy_witch_power)

	_drain_retriggers(cards, battle_state, enemy_witch_power)

	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			run_phase_effects(card, idx, "end", cards, battle_state, enemy_witch_power)

	# 回合结束关键词（在 aggregate 之前 —— 所以它重放出来的数值会被同一次结算算进去）
	run_keyword_pass(battle_state, enemy_witch_power, "round_end")
	_drain_retriggers(cards, battle_state, enemy_witch_power)

	# 汐信的「收益打出后清零」放在**整段行动结算完之后**：
	# 有的页（`汐信-W2`）的收益要到回合结束才算（它要读本回合的已结算伤害），
	# 清得太早它就会读到 0。
	for card in battle_state.touched_cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			if battle_state.is_played_this_turn(card, idx) and "XX" in card.Generator_bookmark.pages[idx].keywords:
				battle_state.clear_persistent(card, idx)
	return played_indices

## 排空 retrigger 链：可以级联，但一页在一次使用周期里只被指向一次（所以链天然有限）
static func _drain_retriggers(cards: Array[BookmarkCard], battle_state, enemy_witch_power: int) -> void:
	while not battle_state.retrigger_queue.is_empty():
		var entry: Dictionary = battle_state.retrigger_queue.pop_front()
		var target: BookmarkCard = entry["card"]
		var target_index: int = entry["index"]
		if not battle_state.mark_retriggered(target, target_index):
			continue
		play_page(target, target_index, cards, battle_state, enemy_witch_power)

## 一页的一次「打出」：先吃页级 pending，再跑使用阶段（play_count 次），每次：
## 页脚本 → 关键词 → 记「已结算」→ 采快照 → 被动钩子
## ⚠️ 开头先解开 is_used：retrigger 重放时这一页已经结算过，
##    不解开的话它自己的数值（add_page_value）会被流程层挡住。
static func play_page(card: BookmarkCard, idx: int, all_cards: Array, battle_state, enemy_witch_power: int) -> void:
	var mark: Dictionary = card.get_page_mark(idx)
	if not mark.has("snapshots"):
		mark["snapshots"] = []
	battle_state.clear_used_page(card, idx)
	_consume_pending(card, idx, battle_state, all_cards, enemy_witch_power)
	var played: int = 0
	# ⚠️ 次数在**第一打之后定下来**，之后不再延长：
	#    关键词的 extra_play 是「每次打出都会 +N」的效果，如果循环每轮都重读次数，
	#    就会自己喂自己（打一次 → 次数 +1 → 再打一次 → 次数又 +1…）⇒ 死循环。
	#    语义上也正是我们要的：「额外打出 N 次」= 这一页本次共打 1+N 次。
	var total: int = battle_state.get_play_count(card, idx)
	while played < total:
		run_phase_effects(card, idx, "use", all_cards, battle_state, enemy_witch_power)
		run_keywords(card, idx, all_cards, battle_state, enemy_witch_power)
		note_resolved(card, idx, battle_state, enemy_witch_power)
		battle_state.record_use(card, idx)
		record_snapshot(card, idx)
		battle_state.notify_page_played(mark)
		played += 1
		if played == 1:
			total = max(total, battle_state.get_play_count(card, idx))
	battle_state.mark_used(card, idx)
	battle_state.mark_page_played(card, idx)
	# ⚠️ 汐信的「收益打出后清零」**不在这里**做 —— 挪到 run_use_phase 的末尾，
	#    否则 `汐信-W2` 那种「回合结束才结算」的页会读不到自己攒的层数（读到 0）。

## 记下本页这次「已结算」的产出（左邻读取 + 本回合累计器），
## 并给命中特效记一条打点 —— play_page 的循环是按**实际次数**跑的，所以这里每打一次就记一条。
static func note_resolved(card: BookmarkCard, idx: int, battle_state, enemy_witch_power: int) -> void:
	var damage: int = final_value(card, idx, "damage", battle_state, enemy_witch_power)
	battle_state.note_resolved(
		card, idx,
		damage,
		final_value(card, idx, "armor", battle_state, enemy_witch_power),
		final_value(card, idx, "healing", battle_state, enemy_witch_power),
		final_value(card, idx, "witchpower", battle_state, enemy_witch_power))
	battle_state.note_hit(card, idx, damage)

## 页级 pending 的消费：谁声明了「下一张 X 页」，就在匹配的页被打出前生效一次。
## 条目支持三种形态：
##   {who, field, value}        加一格数值
##   {who, main, value}         加到主类型对应的那一格（"基础数值 +N"）
##   {who, repeat: "self"}      额外触发某个页的关键词效果一次
## 还可以带 add_type：先把目标页的运行态类型打开（例如让治疗页也能吃魔女化）
## （范围 = 本书签；pending 挂在本回合区，回合开始被清）
static func _consume_pending(card: BookmarkCard, idx: int, battle_state, all_cards: Array = [], enemy_witch_power: int = 0) -> void:
	var positions := build_positions(card)
	for src in range(card.Generator_bookmark.pages.size()):
		var entries: Array = card.get_page_mark(src)["pending"]
		if entries.is_empty():
			continue
		var keep: Array = []
		for entry in entries:
			var pending: Dictionary = entry
			var hit: bool = false
			for target in resolve_selector(card, src, positions, pending.get("who", "self"), battle_state):
				if target["index"] == idx:
					hit = true
			if not hit:
				keep.append(pending)
				continue
			if pending.has("add_type"):
				battle_state.add_runtime_type(card, idx, type_of_name(pending["add_type"]))
			if pending.has("field"):
				battle_state.add_page_value(card, idx, pending["field"], pending.get("value", 0))
			if pending.has("main"):
				add_main_value(card, idx, pending["main"], battle_state)
			if pending.has("repeat"):
				for repeat_target in resolve_selector(card, src, positions, pending["repeat"], battle_state):
					repeat_keyword(repeat_target["card"], repeat_target["index"], all_cards, battle_state, enemy_witch_power, 1)
		card.get_page_mark(src)["pending"] = keep

# ==================== 结算汇总 ====================
## 阵营无关的结算。side 既提供数据（GlobalStats 取数），也决定临时乘数从哪读。
## 结算顺序：
##   ① 每页把各快照的加算总量累加出来（基础 + 特效 + values.sum）× 快照倍率
##   ② 攻击力加算在这一步加进去（side.get_attack_bonus()）
##   ③ 能力页逐快照跑 on_ability，返回值可覆盖 damage/healing/armor/witch_power/heal_count
##   ④ 每页最后统一乘上「被动 × 饰品 × 能力」三类来源的乘数
## 乘数取用时机很关键：必须在「编入 / 使用 / 结束」三个阶段都跑完之后，
## 因为书页脚本是在那些阶段里通过 context["add_*_multiplier"] 写入的。
## ⚠️ 通道归属读的是**运行态类型**（mark.page_type），不是资源 —— 振鸣-A3 那类改标记才有效。
## 一回合结算的总出口：把每张书签的每一页累加进来。
## ⚠️ 拆成三段（2026-10-18，审计 P1-3：原来是 117 行）：
##   结果容器 `_empty_result` / 本回合不变的量 `_aggregate_context` / 单页结算 `_aggregate_page`。
##   行为与拆分前完全一致 —— 61 条冒烟断言 + 8 回合回归守着。
static func aggregate(cards: Array[BookmarkCard], battle_state, enemy_witch_power: int, side) -> Dictionary:
	var result := _empty_result(battle_state)
	var ctx := _aggregate_context(battle_state, side, enemy_witch_power)
	for card in cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			_aggregate_page(card, idx, battle_state, side, result, ctx)
	return result

## 结算结果的容器。键名是「卡牌设计稿 §九」的对外口径，不要改名。
static func _empty_result(battle_state) -> Dictionary:
	return {
		"damage": 0,
		"healing": 0,
		"armor": 0,
		"attack_bonus": battle_state.attack_bonus,
		"witch_power": 0,
	}

## 只在「本回合这一批结算」里不变的量：攻击加算、防御页加算、怪物的吼叫/硬骨、五个乘区。
## 拆出来是为了让 `_aggregate_page` 每页只算自己的事，也避免每页重新查一遍饰品/被动。
static func _aggregate_context(battle_state, side, enemy_witch_power: int) -> Dictionary:
	var ctx := {
		"total_attack_bonus": battle_state.attack_bonus + side.get_attack_bonus(),
		# 防御页加算（饰品「防御书页数值+N」）：**只在玩家自己出牌时**加，
		# 野怪 / 镜像的防御页不该吃玩家的饰品加成
		"defense_page_bonus": GlobalAccessories.get_defense_page_bonus() if side is PlayerState else 0,
		# 怪物页留下的跨阵营效果（写在对手 state 的具名战斗态上，见 Core/book/card/page/monster_*.gd）
		# 吼叫：每个书签的**最后一张页**本次不参与结算
		# 硬骨：最终伤害 ≤ 阈值的攻击页整页作废
		"roar_last_page_off": side != null and bool(side.get_passive_value("monster_roar", false)),
		"hardbone_threshold": int(side.get_passive_value("monster_hardbone", 0)) if side != null else 0,
	}
	var ability_mult = GlobalStats.collect_ability_multipliers(side, battle_state)
	ctx["ability_mult"] = ability_mult
	ctx["damage_mult"] = GlobalStats.get_damage_multiplier(side, enemy_witch_power, battle_state, ability_mult)
	ctx["heal_mult"] = GlobalStats.get_heal_multiplier(side, battle_state, ability_mult)
	ctx["armor_mult"] = GlobalStats.get_armor_multiplier(side, battle_state, ability_mult)
	ctx["witch_mult"] = GlobalStats.get_witch_power_multiplier(side, battle_state, ability_mult)
	return ctx

## 结算一页：快照折算 → 能力/冲动 → 硬骨判定 → 四类通道累加到 `result`。
## 结算一页：快照折算 → 能力/冲动 → 硬骨判定 → 四类通道累加到 `result`。
static func _aggregate_page(card: BookmarkCard, idx: int, battle_state, side, result: Dictionary, ctx: Dictionary) -> void:
	# 吼叫：这个书签的最后一张页整页失效（伤害/护甲/回复/特效/能力全部不参与结算）
	if ctx["roar_last_page_off"] and idx == card.Generator_bookmark.pages.size() - 1:
		battle_state.note_voided_page(card, idx, "吼叫")
		return
	var mark = card.get_page_mark(idx)
	var page = card.Generator_bookmark.pages[idx]
	var types: Array = mark["page_type"]
	var sums := _sum_page_snapshots(card, idx, mark.get("snapshots", []), types, battle_state, result, ctx)
	var page_count: float = sums["count"]

	if Generator_bookpage.PickupType.Ability in types and page.buff_icon:
		battle_state.ability_buffs.append({
			"icon": page.buff_icon,
			"count": int(page_count),
		})

	# 记下这一页给了多少「能力」次数（调试账本用；不影响结算）
	if Generator_bookpage.PickupType.Ability in types:
		battle_state.note_resolved_ability(card, idx, int(page_count))

	# 冲动：只对**这一页**生效（页级判定，不是整张书签级）
	# 倍率 = 1 + 自己的魔女化/100，出口在 GlobalStats.get_impulse_multiplier()
	var page_impulse_mult := 1.0
	if Generator_bookpage.PickupType.Attack in types and side.has_impulse(card, idx):
		page_impulse_mult = GlobalStats.get_impulse_multiplier(side)

	# 先算出这一页的最终伤害 —— 硬骨的判定要在这之前做
	var page_damage := 0
	if Generator_bookpage.PickupType.Attack in types:
		page_damage = int(ceil(int(sums["damage"]) * ctx["damage_mult"] * page_impulse_mult))

	# 硬骨：玩家打出书页后、造成伤害前，把**最终伤害 ≤ 阈值**的攻击页整页标记为无效
	# （不是只把伤害清零：这一页的护甲/回复/特效都不再生效）
	# 阈值 5 → 「5 点及以下」作废；6 点及以上照常打。
	var hardbone_threshold: int = ctx["hardbone_threshold"]
	if hardbone_threshold > 0 and Generator_bookpage.PickupType.Attack in types:
		if page_damage <= hardbone_threshold:
			DebugOutput.say("[硬骨] 「%s」最终伤害 %d ≤ %d → 整页作废" % [page.page_name, page_damage, hardbone_threshold])
			mark["invalid"] = true
			battle_state.note_voided_page(card, idx, "硬骨")
			return
		DebugOutput.say("[硬骨] 「%s」最终伤害 %d > %d → 照常生效" % [page.page_name, page_damage, hardbone_threshold])

	if Generator_bookpage.PickupType.Attack in types:
		result.damage += page_damage

	if Generator_bookpage.PickupType.Heal in types:
		result.healing += int(ceil(int(sums["healing"]) * ctx["heal_mult"]))

	if Generator_bookpage.PickupType.Defense in types:
		# 防御页：护甲加算只在这里计入（饰品「防御书页数值+N」），按页算、不按快照重复加
		result.armor += int(ceil((int(sums["armor"]) + ctx["defense_page_bonus"]) * ctx["armor_mult"]))

	if Generator_bookpage.PickupType.Witch in types:
		result.witch_power += int(ceil(int(sums["witchpower"]) * ctx["witch_mult"]))

## 把这一页的**所有快照**按同一套公式折算成 4 个加算值，顺便跑能力脚本。
## 返回 {damage, healing, armor, witchpower, count}；能力脚本的额外键直接并进 `result`。
static func _sum_page_snapshots(card: BookmarkCard, idx: int, snapshots, types: Array, battle_state, result: Dictionary, ctx: Dictionary) -> Dictionary:
	var sums := {"damage": 0, "healing": 0, "armor": 0, "witchpower": 0, "count": 0.0}
	if snapshots == null:
		snapshots = []
	for snap in snapshots:
		var v = snap["values"]
		var mult = snap["mult"]
		var sum = snap["sum"]

		# 与 final_value 共用同一套公式（_snapshot_field + _round_field），避免两处漂移
		sums["damage"] += _round_field("damage", _snapshot_field(snap, "damage", ctx["total_attack_bonus"]))
		sums["healing"] += _round_field("healing", _snapshot_field(snap, "healing", 0))
		sums["armor"] += _round_field("armor", _snapshot_field(snap, "armor", 0))
		sums["witchpower"] += _round_field("witchpower", _snapshot_field(snap, "witchpower", 0))

		if Generator_bookpage.PickupType.Ability in types:
			var count = (v.get("count", 0) + v.get("effect_count", 0) + sum) * mult
			sums["count"] += count
			var ability_result = call_ability_scripts(card, idx, count)
			for key in ability_result:
				var value = int(ability_result[key])
				if result.has(key):
					result[key] += value
				elif key == "heal_count":
					battle_state.heal_count += value
	return sums

# ==================== context ====================
## 页脚本与关键词**共用**的一份 context。旧键一个不动，只加：
##   mark / positions / kw_vars / final_value / 以及一批写口
##   （写口见 卡牌设计稿.md §八.1.1）
static func build_context(card: BookmarkCard, idx: int, all_cards: Array, battle_state, phase: String, enemy_witch_power: int = 0) -> Dictionary:
	var positions := build_positions(card)
	return {
		"self_card": card,
		"self_index": idx,
		"self_page": card.Generator_bookmark.pages[idx],
		"self_values": card.get_values(idx),
		"all_cards": all_cards,
		"mark": card.get_page_mark(idx),
		"positions": positions,
		"kw_vars": keyword_vars(card, idx, positions, battle_state, enemy_witch_power),
		"set_self": func(field, value): battle_state.set_page_value(card, idx, field, value),
		"add_self": func(field, delta): battle_state.add_page_value(card, idx, field, delta),
		"get_of": func(target_card, target_idx): return target_card.get_values(target_idx),
		"set_of": func(target_card, target_idx, field, value): battle_state.set_page_value(target_card, target_idx, field, value),
		"add_of": func(target_card, target_idx, field, delta): battle_state.add_page_value(target_card, target_idx, field, delta),
		"add_to_page": func(target_card, target_idx, field, delta): battle_state.add_to_page(target_card, target_idx, field, delta),
		"set_to_page": func(target_card, target_idx, field, value): battle_state.set_to_page(target_card, target_idx, field, value),
		"add_play_count": func(target_card, target_idx, n): battle_state.add_play_count(target_card, target_idx, n),
		"multiply_overall": func(target_card, target_idx, m): battle_state.multiply_overall(target_card, target_idx, m),
		"add_overall": func(target_card, target_idx, s): battle_state.add_overall(target_card, target_idx, s),
		# ---- 页级 cd / 运行态类型 / 持久区 / 待生效 / retrigger ----
		"set_page_cd": func(target_card, target_idx, value): battle_state.set_page_cd(target_card, target_idx, value),
		"add_page_cd": func(target_card, target_idx, delta): battle_state.add_page_cd(target_card, target_idx, delta),
		"add_runtime_type": func(target_card, target_idx, t): battle_state.add_runtime_type(target_card, target_idx, t),
		"set_runtime_types": func(target_card, target_idx, types): battle_state.set_runtime_types(target_card, target_idx, types),
		"set_persistent": func(target_card, target_idx, key, value): battle_state.set_persistent(target_card, target_idx, key, value),
		"add_persistent": func(target_card, target_idx, key, delta): battle_state.add_persistent(target_card, target_idx, key, delta),
		"set_pending": func(target_card, target_idx, entry): battle_state.set_pending(target_card, target_idx, entry),
		"retrigger": func(target_card, target_idx): battle_state.queue_retrigger(target_card, target_idx),
		"final_value": func(target_card, target_idx, field): return final_value(target_card, target_idx, field, battle_state, enemy_witch_power),
		"gain_witch_power": func(amount): battle_state.gain_witch_power(amount),
		# ---- 能力来源的乘数接口 ----
		# 书页脚本在这里写入本次结算的临时乘数，由 GlobalStats 统一乘上去。
		# stat 取 "damage" / "armor" / "heal" / "witch_power"；delta 是「增量」：
		#   +0.5 → 最终 ×1.5，-0.25 → 最终 ×0.75，累加。
		"add_damage_multiplier": func(delta): battle_state.add_ability_multiplier("damage", delta),
		"add_armor_multiplier": func(delta): battle_state.add_ability_multiplier("armor", delta),
		"add_heal_multiplier": func(delta): battle_state.add_ability_multiplier("heal", delta),
		"add_witch_power_multiplier": func(delta): battle_state.add_ability_multiplier("witch_power", delta),
		"add_ability_multiplier": func(stat, delta): battle_state.add_ability_multiplier(stat, delta),
		"battle_state": battle_state,
		"phase": phase,
	}

# ==================== 一整张书签的结算（两边共用） ====================
## 编入 → 使用 → 结束 → 结算 → 清理（镜像走这条；玩家一次打多张，走 run_use_phase + aggregate）
## 返回值：
##   damage / healing / armor / witch_power / attack_bonus   常规结算结果
##   played_indices   这次**真的进入了结算**的页下标（冲动命中判定要用，见 enemy.gd）
static func resolve_bookmark(card: BookmarkCard, battle_state, enemy_witch_power: int, side) -> Dictionary:
	var one_card: Array[BookmarkCard] = [card]
	battle_state.reset_round()
	battle_state.clear_used()
	battle_state.clear_ability_multipliers()
	battle_state.ability_buffs.clear()
	battle_state.heal_count = 0

	var played_indices = run_use_phase(one_card, battle_state, enemy_witch_power)

	# 结算范围 = 这张书签 + 被 retrigger 拉进来的别的书签
	var aggregate_cards: Array[BookmarkCard] = [card]
	for touched in battle_state.touched_cards:
		if touched not in aggregate_cards:
			aggregate_cards.append(touched)
	for c in aggregate_cards:
		c.battle_play_count += 1

	var result = aggregate(aggregate_cards, battle_state, enemy_witch_power, side)
	result["played_indices"] = played_indices

	for c in aggregate_cards:
		for idx in range(c.Generator_bookmark.pages.size()):
			clear_marks(c, idx)

	return result

## 一张书签里出现过的所有页类型（去重）
static func collect_page_types(card: BookmarkCard) -> Array:
	var used_types: Array = []
	for page in card.Generator_bookmark.pages:
		for t in page.page_type:
			if t not in used_types:
				used_types.append(t)
	return used_types
