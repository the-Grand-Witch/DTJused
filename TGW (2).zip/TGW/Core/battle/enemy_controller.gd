extends Node
## 敌人公共骨架（孤独的野怪 / 镜像 Boss 共用）
## ==================================================================
## 敌人 = 一套 EnemyState + 若干书签 + 一个选牌器 + 意图。
## 两家只在这三处不同，其余全走这里：
##   · 牌从哪来   —— 子类在 `build_cards()` 里给（野怪来自数据，镜像来自快照）
##   · 谁选牌     —— 子类在 `choose_intent()` 里挑（野怪简单策略，镜像 enemy_ai）
##   · 魔女化     —— 镜像吃威胁值增长，野怪恒定值（都由子类覆写 `enemy_witch_power()`）
##
## 本文件只管「阵营无关」的那半：建牌、回合回滚、结算落地、护甲池、眩晕。
## ⚠️ 与玩家侧的分工不变：页结算/关键词/公式仍走 BattleFlow + GlobalStats，
##    传进去的 side 是敌人的 EnemyState（`enemy_state.cards` 要指向 `cards`）。
## ==================================================================

## 敌人自己的战斗态（子类在 setup 里建好并初始化）
var enemy_state: EnemyState
## 战斗主控（battle_main 在 setup() 之前赋值，子类可经它取玩家侧数据）
var battle_main: Node
var base_attack: int = 0
var cards: Array[BookmarkCard] = []
var selected_card: BookmarkCard
var last_damage_dealt: int = 0
## 这一步「宣告」的伤害（扣玩家护甲之前）；调试对账用：宣告 − 玩家护甲 = 实际掉血
var last_declared_damage: int = 0
var _stunned: bool = false

# ==================== 建牌 ====================
## 把一组书签铺成手牌（卡节点挂到 `hand_container` 下，与玩家同一套 BookmarkCard）。
## 冷却缩减用**敌人自己的**饰品算（EnemyState.get_bookpage_cd_reload）。
func build_cards(bookmark_list: Array, hand_container: Node) -> void:
	cards.clear()
	for child in hand_container.get_children():
		child.queue_free()
	var reload: int = enemy_state.get_bookpage_cd_reload()
	for data in bookmark_list:
		var card = load("res://scenes/bookmark.tscn").instantiate()
		hand_container.add_child(card)
		card.setup(data, reload)
		card.current_cd = 0
		cards.append(card)
	enemy_state.cards = cards

## 每回合：页数值回滚到数据初始值 + 冷却 -1。
## ⚠️ 回滚必须每回合做，否则关键词写进 values 的数值会跨回合无限累积。
func reset_cards_for_round() -> void:
	for card in cards:
		card.reset_round_modifiers()
		card.decrease_cooldown()

# ==================== 血量 / 护甲 ====================
func get_health() -> int:
	return enemy_state.get_health()

func get_max_health() -> int:
	return enemy_state.get_max_health()

func get_witch_power() -> int:
	return enemy_state.get_witch_power()

## 受击：先扣护甲池，剩下的才掉血。
## 护甲是一次性的 —— 敌人自己回合开始时会清空重堆（见 take_turn）。
func take_damage(amount: int) -> void:
	var absorbed: int = min(enemy_state.armor_count, amount)
	enemy_state.armor_count -= absorbed
	var dealt: int = amount - absorbed
	enemy_state.set_health(enemy_state.get_health() - dealt)
	if dealt > 0:
		# 上回合有没有受伤（汐信 `汐信-D1` 这类读它）
		enemy_state.note_damage_taken()
	_on_health_changed()
	_on_damage_taken(amount, absorbed)

func heal(amount: int) -> void:
	enemy_state.set_health(min(enemy_state.get_health() + amount, enemy_state.get_max_health()))
	_on_health_changed()

# ==================== 眩晕 ====================
func stunned() -> void:
	_stunned = true

func is_stunned() -> bool:
	return _stunned

func clear_stunned() -> void:
	_stunned = false

# ==================== 回合 ====================
## 敌人出牌（由 battle_main 在玩家结算之后调用）。
## 流程固定：清护甲池 → 没有可出的牌就走兜底攻击 → 否则按书页结算并落地。
func take_turn(player_armor: int) -> Dictionary:
	var result := {"damage_dealt": 0, "healing": 0, "armor": 0, "witch_power": 0}
	if is_stunned():
		clear_stunned()
		return result

	# 护甲是一次性的：每到自己回合先清空，再由「书页护甲 + 回合防御」重新堆。
	# 玩家在敌人行动**之前**攻击，所以这里堆的护甲正好抵挡玩家的下一次攻击。
	# ⚠️ 野怪走的是「防御页当回合生效」（见 `armor_applied_at_intent()`），护甲在回合开始就挂好了，
	#    这里就不要再重置/重堆，否则玩家刚打穿的护甲会被重新补上。
	if not armor_applied_at_intent():
		enemy_state.armor_count = 0

	if cards.is_empty() or selected_card == null:
		last_declared_damage = direct_attack_amount()
		var actual: int = max(direct_attack_amount() - player_armor, 0)
		if actual > 0:
			GlobalPlayer.take_damage(actual)
		last_damage_dealt = actual
		result["damage_dealt"] = actual
		_on_direct_attack()
		return result

	# 走与玩家相同的流程与公式（side = 敌人自己的 state）
	var card_result = BattleFlow.resolve_bookmark(selected_card, enemy_state, opponent_witch_power(), enemy_state)
	_apply_card_result(card_result, player_armor, result)
	_after_card_played(card_result, card_result.get("played_indices", []))
	return result

## 把一次书页结算落到「玩家身上 / 敌人自己身上」（不含魔女化与彼岸之赐那部分）。
func _apply_card_result(card_result: Dictionary, player_armor: int, result: Dictionary) -> void:
	last_declared_damage = int(card_result.get("damage", 0))
	result["damage_dealt"] = max(card_result.damage - player_armor, 0)
	result["healing"] = card_result.healing
	result["armor"] = card_result.armor
	result["witch_power"] = card_result.witch_power

	if result["damage_dealt"] > 0:
		GlobalPlayer.take_damage(result["damage_dealt"])
	last_damage_dealt = result["damage_dealt"]

	if card_result.healing > 0:
		enemy_state.set_health(min(enemy_state.get_health() + card_result.healing, enemy_state.get_max_health()))
		_on_health_changed()
	if card_result.witch_power > 0:
		enemy_state.gain_witch_power(card_result.witch_power)

	# 书页护甲落到自己身上（回合防御加成由子类在 _after_card_played 里加）
	# ⚠️ 野怪的护甲已经在「预告意图」那一刻按这张书签挂好了，这里不再重复加
	if not armor_applied_at_intent():
		enemy_state.armor_count += card_result.armor

	selected_card.start_cooldown()

	# 通知玩家侧被动：敌人打出了这些类型的页（雪莉的「看破」靠这个，读的是玩家状态）
	GlobalPassive.notify_enemy_page_used(BattleFlow.collect_page_types(selected_card))

# ==================== 子类钩子（默认什么都不做）====================
## 护甲是不是在「预告意图」那一刻就已经按这张书签挂好了？
## 默认 false（镜像 Boss：它自己有整套 AI，护甲在出牌时结算）。
## 野怪 true —— 「这回合的防御页这回合生效」，见 `wild_monster.on_round_start()`。
func armor_applied_at_intent() -> bool:
	return false

## 没有可出的牌时的兜底伤害（扣血与护甲结算由基类做）
func direct_attack_amount() -> int:
	return base_attack

## 兜底攻击之后（镜像在这里结算冲动惩罚与回合防御）
func _on_direct_attack() -> void:
	pass

## 本场「对手的魔女化」：敌人打的是玩家，所以默认取玩家的魔女化
func opponent_witch_power() -> int:
	return GlobalPlayer.witch_power

## 血量变化后（刷新 UI / 打日志）
func _on_health_changed() -> void:
	pass

## 受击之后（日志）
func _on_damage_taken(amount: int, absorbed: int) -> void:
	pass

## 一次出牌结算完之后（镜像在这里结算彼岸之赐的魔女化、满值 transform）
func _after_card_played(card_result: Dictionary, played: Array) -> void:
	pass
