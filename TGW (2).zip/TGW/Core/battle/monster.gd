extends Node
## 怪物管理器：负责随机怪物加载、UI更新及怪物状态
## ==================================================================
## 出怪分两池：
##   · 普通池：`elite_variant = false` 的怪
##   · 强化池：`elite_variant = true` 的怪（红色滤镜版本，血量+30 / 攻击力+1）
## 强化个体的出现概率**随游戏时间上涨**（见 `elite_chance_percent()`）：
##   06:00 → 0%；12:00 起 5%，之后每小时 +4%，跨天继续累加。
## ==================================================================

@onready var texture_rect = $MonsterTexture
@onready var damage_label = $MonsterDamageLabel
@onready var health_bar = $MonsterHealthBar

## 血条上的「当前/最大」血量数字
const HealthBarText := preload("res://Core/ui/health_bar_text.gd")
## 血条节点 679×72（贴图 600×50 拉伸），36 号字 + 描边正好贴在血槽里
## 怪物 id 的合法区间（Data/monster/*.tres 里填的 id 必须落在这个范围）
const MONSTER_ID_MIN := 1
const MONSTER_ID_MAX := 19
## 百分比上限（强化概率是 0~100%）
const PERCENT_MAX := 100

const HP_TEXT_FONT_SIZE := 36

var current_monster: Generator_monster
var health: int
var max_health: int
var attack: int

## 强化池开始出现的时刻：开局 06:00 起算的第 6 小时（= 当天 12:00）
const ELITE_START_MINUTES := 6 * 60
## 刚出现时的概率（%）
const ELITE_BASE_PERCENT := 5
## 之后每整整 1 小时涨多少（%）
const ELITE_PERCENT_PER_HOUR := 4

func _ready() -> void:
	# 血条上的「当前/最大」数字：直接读血条的 value/max_value，
	# 这样 hit_performance 的掉血 tween 也能跟着跳字
	HealthBarText.attach(health_bar, _hp_values, HP_TEXT_FONT_SIZE, 0.5)

func _hp_values() -> Vector2i:
	return Vector2i(int(round(health_bar.value)), int(round(health_bar.max_value)))

func load_random_monster():
	var normal_pool: Array[Generator_monster] = []
	var elite_pool: Array[Generator_monster] = []
	for file_name in ResourceLoader.list_directory("res://Data/monster/"):
		if not file_name.ends_with(".tres"):
			continue
		var res = load("res://Data/monster/" + file_name)
		if not (res is Generator_monster):
			continue
		if res.monster_id < MONSTER_ID_MIN or res.monster_id > MONSTER_ID_MAX:
			continue
		if res.elite_variant:
			elite_pool.append(res)
		else:
			normal_pool.append(res)

	var chance := elite_chance_percent()
	var use_elite := not elite_pool.is_empty() and GlobalRng.range(1, PERCENT_MAX) <= chance
	var pool: Array[Generator_monster] = elite_pool if use_elite else normal_pool
	if pool.is_empty():
		pool = normal_pool if not normal_pool.is_empty() else elite_pool
	current_monster = pool[GlobalRng.range(0, pool.size() - 1)]
	health = current_monster.health
	max_health = current_monster.health
	attack = current_monster.attack
	DebugOutput.say("[出怪] 强化概率 %d%% → %s（血 %d / 攻 %d）" % [
		chance, current_monster.display_name, max_health, attack])

## 强化个体的出现概率（%）。
## 以「开局 06:00 = 0 分钟」为基准累加**跨天**的总分钟数：
##   06:00           → 0%
##   12:00           → 5%
##   13:00           → 9%      （此后每小时 +4%）
##   第 2 天 12:00   → 5 + 4×24 = 101 → 封顶 100%
func elite_chance_percent() -> int:
	var elapsed: int = (GlobalTime.get_day() - 1) * GlobalTime.MINUTES_PER_DAY \
		+ (GlobalTime.get_time() - GlobalTime.DAY_START_MINUTES)
	if elapsed < ELITE_START_MINUTES:
		return 0
	var hours: int = (elapsed - ELITE_START_MINUTES) / 60
	return mini(100, ELITE_BASE_PERCENT + ELITE_PERCENT_PER_HOUR * hours)

func setup_ui():
	texture_rect.texture = current_monster.icon_textrue
	# 立绘滤镜：强化个体（红色版本）只改这个颜色，不另做美术
	texture_rect.modulate = current_monster.icon_modulate
	damage_label.text = "伤害: %d" % attack
	health_bar.max_value = max_health
	health_bar.value = health

func take_damage(amount: int):
	health -= amount
	if health < 0:
		health = 0
	health_bar.value = health

func is_dead() -> bool:
	return health <= 0

func get_attack() -> int:
	return attack

func get_current_monster() -> Generator_monster:
	return current_monster
