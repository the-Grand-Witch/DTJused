extends "res://Core/battle/enemy_controller.gd"
## 孤独的野怪：按怪物数据里的 `bookmark_cycle` **一本一本出牌**。
## ==================================================================
## 与镜像 Boss 共用基类（`enemy_controller.gd`）的全部流程：
##   建牌 → 每回合回滚/冷却 → 结算落地 → 护甲池 → 眩晕
## 差别只有三处：
##   1. 牌来自 `Generator_monster.bookmark_cycle`（数组顺序就是出牌顺序，循环）
##   2. 不参与魔女化：`enemy_witch_power()` 恒定 100（= 视为满魔女化，给玩家侧公式用）；
##      自己`enemy_state` 的 witch power 恒 0，也不会 transform
##   3. 出牌是**按序轮转**，没有 AI 选牌
##
## ⚠️ 没有任何书签的怪会自然退化成「每回合基础攻击」，
##    与重制前的行为一致（`enemy_controller.take_turn()` 的兜底分支）。
## ==================================================================

## 野怪恒定的「敌方魔女化」（玩家侧公式读它：视为满魔女化）
const WITCH_POWER := 100

@onready var manager := $".."                       # Monster（monster.gd：随机怪 + 立绘）
@onready var hit_performance = $"../HitPerformance"
@onready var health_bar: TextureProgressBar = $"../MonsterHealthBar"
@onready var intent_label: Label = $"../MonsterDamageLabel"

var monster: Generator_monster
## 当前走到循环里的第几本
var cycle_index: int = 0
var loot_bonus: int = 0
## 野怪的「攻击力」：基础值（`Generator_monster.attack`）+ 蓄力强化累积。
## 出牌前同步到 `enemy_state.attack_bonus` —— 由 `BattleFlow.aggregate` 逐攻击页加算，
## 所以**每个攻击页打出的伤害 = 攻击力 + 该页伤害**。
## ⚠️ 没有另开新数值：蓄力页写的就是这个 attack_bonus，回合结束把它读回来累到攻击力上。
var attack_level: int = 0
## 出牌前的攻击力快照（`debug_round` 里显示「蓄力把它从几抬到几」）
var last_attack_level_before: int = 0

# ==================== 护甲显示 ====================
## 野怪的护甲原本**完全不可见**：玩家只看到「打了但没掉血」，
## 分不清是硬骨把那页作废了、还是伤害被护甲吃掉了（牛1 每回合 +8、牛3 +25）。
## 所以在血条右边挂一行「护甲 N」，没护甲时隐藏。
const ARMOR_FONT_SIZE := 36
const ARMOR_COLOR := Color(0.72, 0.88, 1, 1)
## 与血条右边缘的间距
const ARMOR_GAP := 16.0
## 数字离血条顶部的距离（让它在血条那条带子里居中）
const ARMOR_LABEL_WIDTH := 300.0

var _armor_label: Label

# ==================== 意图说明文本 ====================
## 意图主行（「伤害20 · 硬骨」）下面再挂几行说明，说清楚三件事：
##   1. 对的伤害是多少（回合末才打出来）
##   2. 本回合的护甲是多少（防御页当回合生效，你的攻击先打在它上面）
##   3. 特殊意图（硬骨 / 吼叫 / 蓄力）到底干什么
const INTENT_DESC_FONT_SIZE := 28
const INTENT_DESC_COLOR := Color(0.86, 0.90, 1, 1)
## 与意图主行的间距
const INTENT_DESC_GAP := 8.0
const INTENT_DESC_WIDTH := 800.0

## 特殊页的「人话」说明：key 是书页的 code（见 Data/bookpage/monster/*.tres）
const SPECIAL_PAGE_DESC := {
	"M-S1": "吼叫 · 本回合你每个书签的最后一张页失效",
	"M-S2": "硬骨 · 本回合你最终伤害 ≤5 的攻击页整页无效",
	"M-C1": "蓄力 · 攻击力 +1（回合末并进攻击力，之后的攻击页更痛）",
	"M-C2": "蓄力 · 攻击力 +2（回合末并进攻击力，之后的攻击页更痛）",
}

var _intent_desc_label: Label
## 上次刷新说明文本时的护甲值（护甲被打掉时要重建文本）
var _last_desc_armor: int = -1

# ==================== 生命周期 ====================
func setup():
	manager.load_random_monster()
	monster = manager.get_current_monster()
	base_attack = monster.attack
	attack_level = monster.attack

	enemy_state = EnemyState.new()
	add_child(enemy_state)
	enemy_state.name = "EnemyState"
	enemy_state.reset_battle()
	enemy_state.setup_from_monster(monster)
	enemy_state.attack_bonus = attack_level

	# 手牌的容器：野怪的手牌**不显示**（只看意图），但仍然要建出来参与结算
	var hand := Control.new()
	hand.name = "EnemyHand"
	hand.visible = false
	add_child(hand)
	build_cards(monster.bookmark_cycle, hand)

	manager.setup_ui()
	_on_health_changed()
	hit_performance.setup($"../MonsterTexture", $"../MonsterHealthBar", $"../HitDamageLabel", $"../AttackFx")
	_setup_armor_display()
	_setup_intent_desc()
	_show_intent()

## 血条右边挂一行「护甲 N」：野怪的护甲是**上一回合它自己堆的**（防御页），
## 玩家看不到就分不清「这一下是被硬骨作废了」还是「被护甲吃掉了」。
func _setup_armor_display() -> void:
	if _armor_label != null:
		return
	_armor_label = Label.new()
	_armor_label.name = "MonsterArmorLabel"
	_armor_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_armor_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_armor_label.add_theme_font_size_override("font_size", ARMOR_FONT_SIZE)
	_armor_label.add_theme_color_override("font_color", ARMOR_COLOR)
	_armor_label.add_theme_color_override("font_outline_color", Color(0.04, 0.02, 0.06, 0.9))
	_armor_label.add_theme_constant_override("outline_size", maxi(2, int(round(ARMOR_FONT_SIZE * 0.18))))
	_armor_label.visible = false
	# 挂在 Monster 下（与血条同级），坐标跟着血条走
	$"..".add_child(_armor_label)

func _process(_delta: float) -> void:
	if enemy_state == null or health_bar == null:
		return

	var armor: int = int(enemy_state.armor_count)
	# ---- 护甲数字 ----
	if _armor_label != null:
		if armor <= 0:
			_armor_label.visible = false
		else:
			_armor_label.visible = health_bar.is_visible_in_tree()
			_armor_label.text = "护甲 %d" % armor
			_armor_label.size = Vector2(ARMOR_LABEL_WIDTH, health_bar.size.y)
			_armor_label.position = health_bar.position + Vector2(health_bar.size.x + ARMOR_GAP, 0.0)

	# ---- 意图说明：护甲被打掉后「本回合护甲 X」要跟着变 ----
	if armor != _last_desc_armor:
		_rebuild_intent_desc()

## 意图说明文本：伤害 / 本回合护甲 / 特殊意图的效果，一行一条。
func _setup_intent_desc() -> void:
	if _intent_desc_label != null or intent_label == null:
		return
	_intent_desc_label = Label.new()
	_intent_desc_label.name = "MonsterIntentDescLabel"
	_intent_desc_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_intent_desc_label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	_intent_desc_label.add_theme_font_size_override("font_size", INTENT_DESC_FONT_SIZE)
	_intent_desc_label.add_theme_color_override("font_color", INTENT_DESC_COLOR)
	_intent_desc_label.add_theme_color_override("font_outline_color", Color(0.04, 0.02, 0.06, 0.9))
	_intent_desc_label.add_theme_constant_override("outline_size", 6)
	_intent_desc_label.add_theme_constant_override("line_spacing", 2)
	# 挂在 Monster 下（与意图主行同级），位置跟主行走
	$"..".add_child(_intent_desc_label)

func _rebuild_intent_desc() -> void:
	if _intent_desc_label == null:
		return
	_last_desc_armor = 0 if enemy_state == null else int(enemy_state.armor_count)
	var lines: Array[String] = []
	if selected_card == null or selected_card.Generator_bookmark == null:
		lines.append("伤害 %d · 回合末打出" % direct_attack_amount())
	else:
		var damage := _intent_damage_total()
		if damage > 0:
			# 伤害可能被「攻击力」抬高（蓄力 / 基础攻击力），页伤总和对不上时把组成写出来
			var attack_pages := 0
			var page_sum := 0
			for idx in range(selected_card.Generator_bookmark.pages.size()):
				var pg = selected_card.Generator_bookmark.pages[idx]
				if Generator_bookpage.PickupType.Attack in pg.page_type:
					attack_pages += 1
					page_sum += pg.damage + pg.effect_damage
			var line := "伤害 %d · 回合末打在你身上" % damage
			if attack_pages > 0 and page_sum != damage:
				line = "伤害 %d（页伤 %d + 攻击力 %d×%d 页）· 回合末打在你身上" % [
					damage, page_sum, attack_level, attack_pages]
			lines.append(line)
		# 护甲：防御页当回合生效，所以这里显示的是「现在还剩多少」
		if _last_desc_armor > 0:
			lines.append("本回合护甲 %d · 你的攻击先打在护甲上" % _last_desc_armor)
		elif _intent_armor_total() > 0:
			lines.append("本回合护甲 0 · 已经被打穿了")
		# 特殊页（硬骨 / 吼叫 / 蓄力…）直接写效果
		for idx in range(selected_card.Generator_bookmark.pages.size()):
			var page = selected_card.Generator_bookmark.pages[idx]
			var types: Array = page.page_type
			if Generator_bookpage.PickupType.Attack in types or Generator_bookpage.PickupType.Defense in types:
				continue
			var desc: String = SPECIAL_PAGE_DESC.get(page.code, "")
			if desc == "":
				desc = "%s · %s" % [page.page_name, page.description]
			lines.append(desc)
	_intent_desc_label.text = "\n".join(lines)
	_intent_desc_label.visible = not lines.is_empty()
	_position_intent_desc()

func _position_intent_desc() -> void:
	if _intent_desc_label == null or intent_label == null:
		return
	_intent_desc_label.position = intent_label.position + Vector2(0.0, intent_label.size.y + INTENT_DESC_GAP)
	var min_size := _intent_desc_label.get_combined_minimum_size()
	_intent_desc_label.size = Vector2(maxf(INTENT_DESC_WIDTH, min_size.x), min_size.y)

# ==================== special 接口 ====================
func get_battle_state():
	return enemy_state

## 玩家侧公式里的「敌方魔女化」：野怪恒定满值
func enemy_witch_power() -> int:
	return WITCH_POWER

func on_round_start(turn_count: int):
	enemy_state.turn_count = turn_count
	reset_cards_for_round()
	# 攻击力每回合同步一次（蓄力在上一回合结算完已经并进 attack_level）
	enemy_state.attack_bonus = attack_level

	# 玩家身上的「硬骨 / 吼叫」上一回合已经消费掉了，这里兜底清一次再挂新的
	var player_state = enemy_state.enemy_side
	if player_state != null and player_state.has_method("clear_monster_debuffs"):
		player_state.clear_monster_debuffs()

	# 循环出牌：没有书签的怪走基础攻击兜底（selected_card = null）
	if cards.is_empty():
		selected_card = null
	else:
		selected_card = cards[cycle_index % cards.size()]
		cycle_index += 1
		_apply_intent_effects()
	# 护甲：这张书签的防御页**这回合就生效**（不是等它回合末出牌才贴）
	enemy_state.armor_count = _intent_armor_total()
	_show_intent()

## 野怪的护甲在「预告意图」那一刻就按这张书签挂好 —— 这回合的防御页这回合生效。
func armor_applied_at_intent() -> bool:
	return true

## 这张书签的防御页会给多少护甲（口径与 `BattleFlow.aggregate` 一致：
## 逐页取 `final_value(armor)`，所以倍率 / 饰品加成都算进去了）。
## 没有书签（`selected_card == null`）返回 0 —— 护甲是一次性的，不跨回合累积。
func _intent_armor_total() -> int:
	if selected_card == null or selected_card.Generator_bookmark == null:
		return 0
	var total := 0
	for idx in range(selected_card.Generator_bookmark.pages.size()):
		var types: Array = selected_card.Generator_bookmark.pages[idx].page_type
		if Generator_bookpage.PickupType.Defense in types:
			total += BattleFlow.final_value(selected_card, idx, "armor", enemy_state, enemy_witch_power())
	return total

## 预告意图的同一刻，先把「作用在玩家身上」的页效果挂上（硬骨 / 吼叫）。
## ==================================================================
## ⚠️ 为什么不在野怪真正出牌（回合末）时才挂：
##    野怪的回合在玩家行动**之后**，那时玩家的这次行动已经结算完了，
##    效果只能落到下一回合 —— 而下一回合的意图标签已经换成另一张书签，
##    玩家看到的就变成「预告硬骨那回合我的页照打，下一回合才作废」，
##    像是意图和实际出的牌对不上。
## 现在挂在回合开始（= 意图显示的那一刻），玩家这次行动立刻吃到它；
## 结算完由 `battle_calculator.calculate_player_effects()` 清掉，不会拖到下一回合。
## ==================================================================
func _apply_intent_effects() -> void:
	if selected_card == null:
		return
	var player_state = enemy_state.enemy_side
	var hardbone_before: int = 0 if player_state == null else int(player_state.get_passive_value("monster_hardbone", 0))
	var roar_before: bool = false if player_state == null else bool(player_state.get_passive_value("monster_roar", false))
	for idx in range(selected_card.Generator_bookmark.pages.size()):
		BattleFlow.run_phase_effects(selected_card, idx, "intent", cards, enemy_state, enemy_witch_power())
	if player_state == null:
		return
	var hardbone_after: int = int(player_state.get_passive_value("monster_hardbone", 0))
	var roar_after: bool = bool(player_state.get_passive_value("monster_roar", false))
	if hardbone_after != hardbone_before or roar_after != roar_before:
		DebugOutput.say("[意图] %s → 本回合立刻生效：硬骨=%d 吼叫=%s" % [
			selected_card.Generator_bookmark.title, hardbone_after, str(roar_after)])

func enemy_take_turn(player_armor: int):
	# 记下出牌前的攻击力：调试输出要显示「蓄力把它从几抬到几」
	last_attack_level_before = attack_level
	return take_turn(player_armor)

## 给 battle_main 的对账用：当前护甲（不含「这一回合已经生效」的说明）
func enemy_armor_count() -> int:
	return 0 if enemy_state == null else int(enemy_state.armor_count)

func play_hit(amount: int, hits: Array) -> void:
	await hit_performance.play(amount, hits, func(): take_damage(amount))

func is_enemy_dead() -> bool:
	return get_health() <= 0

## 按 id 从**全图鉴**里取一件饰品：怪物的固定掉落可以指向玩家还没拥有的东西，
## 所以不能走 `GlobalAccessories.get_accessories_by_id()`（那个只查已拥有）。
func _get_any_accessories_by_id(acc_id: int) -> Generator_accessories:
	for acc in GlobalAccessories.all_accessories:
		if acc.acc_id == acc_id:
			return acc
	return null

func on_enemy_defeated():
	var gold = GlobalRng.range(monster.min_gold, monster.max_gold)
	var dropped_accessories: Array[Generator_accessories] = []

	if monster.fixed_drop_id != -1:
		var fixed_acc = _get_any_accessories_by_id(monster.fixed_drop_id)
		if fixed_acc and not GlobalAccessories.has_accessories(fixed_acc.acc_id):
			dropped_accessories.append(fixed_acc)

	var candidates: Array[Generator_accessories] = []
	for acc in GlobalAccessories.all_accessories:
		if acc.acc_id >= monster.accessories_id_min and acc.acc_id <= monster.accessories_id_max:
			if not GlobalAccessories.has_accessories(acc.acc_id):
				candidates.append(acc)

	var count = monster.random_drop_count + loot_bonus
	count = min(count, candidates.size())
	for i in range(count):
		var idx = GlobalRng.range(0, candidates.size() - 1)
		var acc = candidates[idx]
		candidates.remove_at(idx)
		dropped_accessories.append(acc)

	# 掉落内容在这里算好后交给统一奖励入口
	var on_closed = func(): GlobalScenes.return_to_previous()
	GlobalScenes.show_reward(gold, dropped_accessories, [], on_closed)

# ==================== 基类钩子 ====================
func _on_health_changed() -> void:
	if health_bar == null:
		return
	health_bar.max_value = get_max_health()
	health_bar.value = get_health()

## 没有可出的牌（怪没有书签）：用当前攻击力兜底
func direct_attack_amount() -> int:
	return attack_level

## 一次出牌结算完之后：把蓄力给的点数并进攻击力。
## `aggregate` 的 `attack_bonus` = 本次结算用的攻击力 + 本次蓄力给的点数，所以直接赋值即可。
func _after_card_played(card_result: Dictionary, _played: Array) -> void:
	attack_level = int(card_result.get("attack_bonus", attack_level))
	enemy_state.attack_bonus = attack_level

# ==================== 意图 / 调试 ====================
## 意图：把「下一本要出的书签」折算成玩家看得懂的话：
##   攻击页 → `伤害X`（每页 = 攻击力 + 页伤害，累加）
##   防御页 → `防御X`（护甲累加）
##   其它页（吼叫 / 硬骨 / 蓄力…）→ 直接写特殊动作的名字
func _show_intent() -> void:
	if intent_label == null:
		return
	intent_label.text = intent_text()
	_rebuild_intent_desc()
	# 每回合打一行：从这行能直接看出「这回合预告的是哪本书签、它做什么」
	# （setup 阶段 turn_count 还是 0，那时还没有书签可选，不用打）
	if enemy_state == null or enemy_state.turn_count <= 0:
		return
	var title: String = "（无书签，基础攻击）" if selected_card == null else String(selected_card.Generator_bookmark.title)
	DebugOutput.say("[意图] 第 %d 回合 %s → %s（护甲 %d）" % [
		enemy_state.turn_count, title, intent_label.text, enemy_state.armor_count])

func intent_text() -> String:
	if selected_card == null or selected_card.Generator_bookmark == null:
		return "攻击%d" % attack_level
	var damage := 0
	var armor := 0
	var specials: Array[String] = []
	# 用 `BattleFlow.final_value` 取每一页的真正数值（与结算同一套公式），
	# 这样意图上的「伤害 X / 防御 Y」和实际打出来的一致，不会因为倍率/加成对不上。
	for idx in range(selected_card.Generator_bookmark.pages.size()):
		var page = selected_card.Generator_bookmark.pages[idx]
		var types: Array = page.page_type
		if Generator_bookpage.PickupType.Attack in types:
			damage += BattleFlow.final_value(selected_card, idx, "damage", enemy_state, enemy_witch_power())
		elif Generator_bookpage.PickupType.Defense in types:
			armor += BattleFlow.final_value(selected_card, idx, "armor", enemy_state, enemy_witch_power())
		else:
			specials.append(page.page_name)
	var parts: Array[String] = []
	if damage > 0:
		parts.append("伤害%d" % damage)
	if armor > 0:
		parts.append("防御%d" % armor)
	parts.append_array(specials)
	if parts.is_empty():
		return "—"
	return " · ".join(parts)

## 这张书签的攻击页一共打多少伤害（口径与 `intent_text` / 结算一致）
func _intent_damage_total() -> int:
	if selected_card == null or selected_card.Generator_bookmark == null:
		return 0
	var total := 0
	for idx in range(selected_card.Generator_bookmark.pages.size()):
		var types: Array = selected_card.Generator_bookmark.pages[idx].page_type
		if Generator_bookpage.PickupType.Attack in types:
			total += BattleFlow.final_value(selected_card, idx, "damage", enemy_state, enemy_witch_power())
	return total

## 回合结束的野怪账本（由 battle_main 调用；player_armor = 这一下玩家抵挡掉的护甲）
func debug_round(player_armor: int = 0) -> void:
	if not DebugOutput.enabled():
		return
	if monster == null:
		return
	var title: String = "（无书签，基础攻击）" if selected_card == null else String(selected_card.Generator_bookmark.title)
	DebugOutput.say("──────── [野怪] %s  血 %d/%d  护甲 %d  攻击力 %d ────────" % [
		monster.display_name, get_health(), get_max_health(), enemy_state.armor_count, attack_level])
	DebugOutput.say("  意图行          %s" % intent_text())
	DebugOutput.say("  本回合打出      %s" % title)
	DebugOutput.say("  宣告伤害        %d  → 玩家护甲 %d  → 实际掉血 %d" % [
		last_declared_damage, player_armor, last_damage_dealt])
	DebugOutput.say("  本回合获得护甲  %d（回合开始就生效，回合末不再补；当前剩 %d）" % [
		_intent_armor_total(), enemy_state.armor_count])
	if attack_level != last_attack_level_before:
		DebugOutput.say("  攻击力          %d → %d（蓄力 +%d，之后每个攻击页都吃这个）" % [
			last_attack_level_before, attack_level, attack_level - last_attack_level_before])
	else:
		DebugOutput.say("  攻击力          %d（本回合没变）" % attack_level)
