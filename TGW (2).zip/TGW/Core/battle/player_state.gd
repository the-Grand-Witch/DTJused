extends BattleState
class_name PlayerState

## ==================================================================
## 玩家阵营的战斗态
## ==================================================================
## 继承 BattleState：战斗流程（页结算、关键词、冲动、具名战斗态）都在基类里，
## 本类只负责「玩家这一侧的数从哪来」：
##   血量 / 魔女化 / 饰品 → 委托 GlobalPlayer / GlobalAccessories（跨战斗存活）
##   被动实例            → 沿用 GlobalPassive 里注册的那批（保持现有饰品流程）
##
## 之所以不把这些搬进节点：事件、商店、契约这些**战斗外**的代码也在用 GlobalPlayer。
##
## ⚠️ 本节点是战斗场景里的 BattleState 节点，类名与节点名同名是历史原因。
## ==================================================================

func _init() -> void:
	party = Party.PLAYER

## 开战：同步玩家侧的被动实例，并把 owner 指过来
func bind_owner(_owner_node: Node) -> void:
	passives.side = self
	passives.sync_from_global()
	invalidate_attack_bonus()

# ==================== 持久态：委托 GlobalPlayer ====================
func get_health() -> int:
	return GlobalPlayer.health

func set_health(value: int) -> void:
	GlobalPlayer.health = max(0, value)
	GlobalPlayer.health_changed.emit(GlobalPlayer.health)

func get_max_health() -> int:
	return GlobalPlayer.max_health

func get_witch_power() -> int:
	return GlobalPlayer.witch_power

func set_witch_power(value: int) -> void:
	GlobalPlayer.witch_power = value
	GlobalPlayer.witch_power_changed.emit(GlobalPlayer.witch_power)

func get_max_witch_power() -> int:
	# 饰品提升走基类的 get_witch_max_increase()（数据源 = 本阵营的 get_accessories()）
	return GlobalPlayer.max_witch_power + get_witch_max_increase()

func get_accessories() -> Array:
	return GlobalAccessories.accessories

## 玩家涨魔女化：走 GlobalPlayer 的既有流程（含被动的 modify_witch_power_gain、满值游戏结束判定）。
## 顺便记下**本回合增量**（`魇蚀-D3` 要读），所以记的是「实际变化量」而不是传入量。
func gain_witch_power(amount: int) -> void:
	var before: int = GlobalPlayer.witch_power
	GlobalPlayer.possessed(amount)
	note_witch_change(GlobalPlayer.witch_power - before)

func get_impulse_punishment() -> int:
	return GlobalPlayer.get_impulse_punishment()

func is_overloaded() -> bool:
	return get_witch_power() >= get_max_witch_power()

# ==================== 调试来源说明 ====================
func _witch_power_source() -> String:
	return "GlobalPlayer（跨战斗存活）"

func _passive_source() -> String:
	return "GlobalPassive 注册的那批（角色被动 + 饰品被动）"
