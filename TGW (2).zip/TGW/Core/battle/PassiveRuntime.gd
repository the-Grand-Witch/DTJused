extends Node
class_name PassiveRuntime

## 一个阵营的被动运行器
## ==================================================================
## 负责「本阵营这一场战斗里，有哪些被动实例、什么时候广播什么钩子」。
##
## 为什么需要它：被动实例原先只有玩家一份（挂在 GlobalPassive 上），
## 镜像如果复用同一批实例，双方的战斗态会互相踩（例如护盾层数、心衰档位）。
## 现在每个阵营各持一个 PassiveRuntime，实例互不相干。
##
## 玩家侧：实例仍由 GlobalPassive 创建（保持现有饰品注册流程），
##         本运行器只是把 collect / 广播收敛到一处。
## 镜像侧：实例由镜像自己的饰品 effect_script 现场创建。
## ==================================================================

## 所属的阵营状态（BattleState / EnemyState）。被动脚本的 owner 就是它。
var side: Node = null
var character_passive: Generator_PassiveEffect = null
var accessories_passives: Array[Generator_PassiveEffect] = []
var accessories_passive_map: Dictionary = {}

## 镜像侧跳过的被动脚本。
## 2026-10：`kill_witch.gd` 与 `xueli's guaili.gd` 都已改成**走 owner 取数**，
## 给镜像实例化不会读到玩家的数了 ⇒ 从名单里移除，镜像现在也吃这两个先天技能。
## 以后再有「直接读 GlobalPlayer」的脚本，往这里加。
const INCOMPATIBLE_PASSIVE_SCRIPTS: Array[String] = []
## 记录被跳过的脚本，便于排查
var skipped_scripts: Array[String] = []

func bind_side(side_node: Node) -> void:
	side = side_node
	_bind_owner_to_passives()

func _bind_owner_to_passives() -> void:
	for p in collect():
		if p != null and p.has_method("set_battle_owner"):
			p.set_battle_owner(side)

# ==================== 玩家侧：从全局被动管理器取 ====================
## 玩家的被动实例仍由 GlobalPassive 持有（饰品加成走它的注册流程）
func sync_from_global() -> void:
	if GlobalPassive == null:
		return
	character_passive = GlobalPassive.character_passive
	accessories_passives = GlobalPassive.accessories_passives
	accessories_passive_map = GlobalPassive.accessories_passive_map
	_bind_owner_to_passives()

# ==================== 镜像侧：自己创建 ====================
## 按饰品列表现场创建被动实例（跳过依赖玩家全局状态的脚本）
func build_from_accessories(acc_list: Array) -> void:
	character_passive = null
	accessories_passives.clear()
	accessories_passive_map.clear()
	skipped_scripts.clear()

	for acc in acc_list:
		if not (acc is Generator_accessories) or acc.effect_script == null:
			continue
		# ⚠️ 不能用 := ：acc 来自无类型数组（Variant），推断不出类型
		var script_path: String = acc.effect_script.resource_path
		if _is_incompatible(script_path):
			skipped_scripts.append(script_path)
			push_warning("[PassiveRuntime] %s 依赖玩家全局状态，镜像侧跳过（否则会读到玩家的数值）" % script_path)
			continue
		var instance = acc.effect_script.new()
		if not (instance is Generator_PassiveEffect):
			continue
		if instance.has_method("setup"):
			instance.setup(acc)
		accessories_passives.append(instance)
		accessories_passive_map[acc.acc_id] = instance

	_bind_owner_to_passives()

func _is_incompatible(script_path: String) -> bool:
	for name in INCOMPATIBLE_PASSIVE_SCRIPTS:
		if script_path.ends_with(name):
			return true
	return false

# ==================== 查询 ====================
func collect() -> Array:
	var list: Array = []
	if character_passive != null:
		list.append(character_passive)
	list.append_array(accessories_passives)
	return list

func count() -> int:
	return collect().size()

func get_summary() -> String:
	return "被动 %d 个（含角色被动 %s）" % [
		collect().size(),
		"有" if character_passive != null else "无",
	]

# ==================== 钩子广播 ====================
func notify_battle_start() -> void:
	for p in collect():
		if p != null and p.has_method("on_battle_start"):
			p.on_battle_start()

func get_turn_effects(turn_count: int) -> Array:
	var effects: Array = []
	for p in collect():
		if p != null and p.has_method("on_turn_start"):
			effects.append_array(p.on_turn_start(turn_count))
	return effects

func notify_turn_end(turn_count: int) -> void:
	for p in collect():
		if p != null and p.has_method("on_turn_end"):
			p.on_turn_end(turn_count)

func notify_page_played(mark: Dictionary) -> void:
	for p in collect():
		if p != null and p.has_method("on_page_played"):
			p.on_page_played(mark)

func notify_damage_taken(amount: int) -> void:
	for p in collect():
		if p != null and p.has_method("on_damage_taken"):
			p.on_damage_taken(amount)

func notify_damage_dealt(amount: int) -> void:
	for p in collect():
		if p != null and p.has_method("on_damage_dealt"):
			p.on_damage_dealt(amount)

func notify_heal(amount: int) -> void:
	for p in collect():
		if p != null and p.has_method("on_heal"):
			p.on_heal(amount)

func notify_witch_power_changed(value: int) -> void:
	for p in collect():
		if p != null and p.has_method("on_witch_power_changed"):
			p.on_witch_power_changed(value)

## 敌方出牌后通知：注意这是**给玩家侧被动看**的（雪莉的看破靠它）
func notify_enemy_page_used(types: Array) -> void:
	for p in collect():
		if p != null and p.has_method("on_enemy_page_used"):
			p.on_enemy_page_used(types)

func clear_insight() -> void:
	for p in collect():
		if p != null and p.has_method("clear_insight"):
			p.clear_insight()

# ==================== 查询转发 ====================
func is_page_available(page: Generator_bookpage) -> bool:
	for p in collect():
		if p != null and p.has_method("is_page_available") and not p.is_page_available(page):
			return false
	return true

func try_consume_block() -> bool:
	for p in collect():
		if p != null and p.has_method("try_consume_block") and p.try_consume_block():
			return true
	return false

func get_block_charge() -> int:
	var total := 0
	for p in collect():
		if p != null and p.has_method("get_block_charge"):
			total += int(p.get_block_charge())
	return total

func get_armor_per_turn(base: int = 0) -> int:
	var value := base
	for p in collect():
		if p != null and p.has_method("modify_armor_per_turn"):
			value = int(p.modify_armor_per_turn(value))
	return value

func get_heal_per_turn(base: int = 0) -> int:
	var value := base
	for p in collect():
		if p != null and p.has_method("modify_heal_per_turn"):
			value = int(p.modify_heal_per_turn(value))
	return value

## 是否有任一被动禁用了技能页
func is_ability_disabled() -> bool:
	for p in collect():
		if p != null and p.has_method("is_ability_disabled") and p.is_ability_disabled():
			return true
	return false

func is_heal_disabled() -> bool:
	for p in collect():
		if p != null and p.has_method("is_heal_disabled") and p.is_heal_disabled():
			return true
	return false
