extends Node
## 普通战斗特殊逻辑

@onready var monster_manager = $".."
@onready var hit_performance = $"../HitPerformance"


var battle_main: Node
var loot_bonus: int = 0

func setup():
	monster_manager.load_random_monster()
	monster_manager.setup_ui()
	hit_performance.setup($"../MonsterTexture", $"../MonsterHealthBar", $"../HitDamageLabel", $"../AttackFx")

func on_round_start(_turn_count: int):
	pass

func enemy_witch_power() -> int:
	return 0

## 普通怪没有自己的战斗态（没有魔女化），所以跨阵营写口（`魇蚀-W1`）在这里没有对象。
func get_battle_state():
	return null

func enemy_take_damage(amount: int):
	monster_manager.take_damage(amount)

## 命中演出：白闪 + 伤害数字 + 按实际次数逐个播的命中特效。伤害在「命中那一下」才真正落地，
## 由 battle_main await 整段（演出期间回合是冻住的）。
func play_hit(amount: int, hits: Array) -> void:
	await hit_performance.play(amount, hits, func(): monster_manager.take_damage(amount))

func is_enemy_dead() -> bool:
	return monster_manager.is_dead()

## 按 id 从**全图鉴**里取一件饰品：怪物的固定掉落可以指向玩家还没拥有的东西，
## 所以不能走 `GlobalAccessories.get_accessories_by_id()`（那个只查已拥有）。
func _get_any_accessories_by_id(acc_id: int) -> Generator_accessories:
	for acc in GlobalAccessories.all_accessories:
		if acc.acc_id == acc_id:
			return acc
	return null

func on_enemy_defeated():
	var monster = monster_manager.get_current_monster()
	var gold = GlobalRng.range(monster.min_gold, monster.max_gold)
	var dropped_accessories: Array[Generator_accessories] = []

	if monster.fixed_drop_id != -1:
		var fixed_acc = _get_any_accessories_by_id(monster.fixed_drop_id)
		if fixed_acc and not GlobalAccessories.has_accessories(fixed_acc.acc_id):
			dropped_accessories.append(fixed_acc)

	var candidates: Array[Generator_accessories] = []
	for acc in GlobalAccessories.all_accessories:
		if acc.acc_id >= monster.accessories_id_min and acc.acc_id <= monster.accessories_id_max:
			if not GlobalAccessories.has_accessories(acc.acc_id):
				candidates.append(acc)

	var count = monster.random_drop_count + loot_bonus
	count = min(count, candidates.size())
	for i in range(count):
		var idx = GlobalRng.range(0, candidates.size() - 1)
		var acc = candidates[idx]
		candidates.remove_at(idx)
		dropped_accessories.append(acc)

	# 掉落内容在这里算好后交给统一奖励入口；monster 不参与展示，故不再传递
	var on_closed = func(): GlobalScenes.return_to_previous()
	GlobalScenes.show_reward(gold, dropped_accessories, [], on_closed)

func enemy_take_turn(player_armor: int):
	var result = battle_main.battle_calculator.calculate_monster_attack(
		monster_manager.get_attack(),
		player_armor
	)
	if result.damage_dealt > 0:
		GlobalPlayer.take_damage(result.damage_dealt)
	# 通知被动：怪物使用了 Attack 类型
	GlobalPassive.notify_enemy_page_used([Generator_bookpage.PickupType.Attack])

func debug_round() -> void:
	if not DebugOutput.enabled():
		return
	if monster_manager == null or monster_manager.get_current_monster() == null:
		return
	DebugOutput.say("──────── [普通怪] %s  血量 %d/%d  攻击 %d ────────" % [
		monster_manager.get_current_monster().display_name,
		monster_manager.health,
		monster_manager.max_health,
		monster_manager.get_attack(),
	])
