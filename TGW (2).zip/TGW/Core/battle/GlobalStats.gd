extends Node

## 战斗数值修正的**纯函数库**
## ==================================================================
## ⚠️ 刻意**不加** `class_name`：它已经注册为 autoload（project.godot 的 [autoload]），
##    加了 class_name 会让 `GlobalStats` 这个名字变成「类」而不是「单例」，
##    于是实例方法没法再用 `GlobalStats.xxx()` 调（报
##    「Cannot call non-static function on the class directly」）。
##    所以这里保持 autoload 单例身份，方法写成普通方法。
##
## 语义上它是纯函数库：每个方法只吃入参、不读任何全局单例，
## 「某个单位当前是什么状态」由调用方通过 `owner` 传进来。
##
## owner 需要提供的最小接口（玩家侧是 BattleState，镜像侧是 EnemyState）：
##   collect_passives() -> Array          # 该单位的被动实例
##   get_accessories() -> Array           # 该单位的饰品（纯数值来源）
##   get_ability_multiplier(channel) -> float   # 该单位的临时能力乘数
##
## 三类来源仍然一条路走完：
##   1. 被动来源 —— 角色被动（Generator_PassiveEffect 子类）
##   2. 饰品来源 —— 饰品的 effect_script（同样继承 Generator_PassiveEffect）
##   3. 能力来源 —— 两条子通道，最终加在一起（都是「增量」语义，1.0 + 累加值）：
##        a) 书页脚本在结算中通过 context["add_xxx_multiplier"] 临时写入
##        b) 被动对象实现 get_ability_multipliers() 返回 {维度: 增量}，常驻生效
##
## 调用方约定
## ------------------------------------------------------------------
## 每个 get_xxx_multiplier() 都返回一个**乘数**，基准值 1.0：
##   1.0 = 不变，< 1.0 = 削弱，> 1.0 = 增强；多来源之间累乘。
## get_attack_bonus() 返回**加算**，基准值 0。
##
## 怎么加一个新维度（不需要动本文件以外的地方）
## ------------------------------------------------------------------
## 在 STATS 里加一行即可，收集逻辑是注册表驱动的：
##   "新维度": {"passive": "modify_新维度_multiplier", "ability": "新维度"},
##   - passive：被动/饰品里实现同名方法；不实现就是 1.0，旧脚本无需同步改。
##   - ability：书页脚本用 context["add_新维度_multiplier"](delta) 写入；
##             被动也可以实现 get_ability_multipliers() 返回 {"新维度": delta}。
## ==================================================================

const ONE := 1.0

## 乘算维度注册表：维度 -> {被动方法名, 能力 channel}
## 注意 key 既是对外 API 名，也是 battle_state 与 context 里用的名字。
const STATS := {
	"damage": {"passive": "modify_damage_multiplier", "ability": "damage"},
	"armor": {"passive": "modify_armor_multiplier", "ability": "armor"},
	"heal": {"passive": "modify_heal_multiplier", "ability": "heal"},
	"witch_power": {"passive": "modify_witch_power_multiplier", "ability": "witch_power"},
	"damage_taken": {"passive": "modify_damage_taken_multiplier", "ability": ""},
	"impulse": {"passive": "modify_impulse_multiplier", "ability": ""},
}

## 冲动是否自带倍率（1 + 自己魔女化/100）。
## 这是「冲动」这个关键词的核心效果：魔女化越深，带冲动的页打得越狠。
## 做成模块常量是为了让实现一眼可见；算式的唯一出口在 get_impulse_multiplier()。
const IMPULSE_SCALES_WITH_WITCH_POWER := true

## 乘区来源类别：id 进逻辑与日志（ASCII），中文只在这里给显示用。
## entries / breakdown 里的 `kind` 写的是 id，打印前过 `kind_name()`。
const KIND_NAMES := {
	"passive": "被动",
	"ability": "能力",
	"accessory": "饰品",
}

static func kind_name(kind: String) -> String:
	return KIND_NAMES.get(kind, kind)

# ==================== 内部工具（全部只吃入参） ====================
## 安全地取一个被动提供的方法返回值：没实现该方法就返回 fallback
func _call_passive(p, method: String, args: Array, fallback):
	if p == null or not p.has_method(method):
		return fallback
	var value = p.callv(method, args)
	if value == null:
		return fallback
	return value

## 取该单位的被动实例；owner 不合法时返回空数组
func _passives_of(owner) -> Array:
	if owner == null or not owner.has_method("collect_passives"):
		return []
	return owner.collect_passives()

## 被动来源的乘数：该单位所有被动累乘
## 被动来源的乘数：该单位所有被动累乘
## want_breakdown = true 时把每个来源单独记下来（只影响调试，不影响计算结果）
func _passive_multiplier(owner, stat: String, context: Dictionary, want_breakdown: bool = false) -> float:
	var entry: Dictionary = STATS.get(stat, {})
	var method: String = entry.get("passive", "")
	if method == "":
		return ONE
	# 目前只有伤害乘数需要敌人魔女化做参数，其余无参；统一用 args 适配
	var args: Array = []
	if stat == "damage":
		args = [int(context.get("enemy_witch_power", 0))]
	var value := ONE
	for p in _passives_of(owner):
		var m := float(_call_passive(p, method, args, ONE))
		value *= m
		if want_breakdown and not is_equal_approx(m, ONE):
			var log: Array = context.get("_breakdown", [])
			log.append({"kind": "passive", "source": _passive_name(p), "method": method, "value": m})
			context["_breakdown"] = log
	return value

## 能力来源的原始增量（未折算成乘数）
## 对同一个 stat 反复调用会重复遍历被动，所以战斗结算里请先取一次 collect_ability_multipliers()。
func _ability_delta(owner, stat: String, battle_state, want_breakdown: bool = false, context: Dictionary = {}) -> float:
	var entry: Dictionary = STATS.get(stat, {})
	var channel: String = entry.get("ability", "")
	if channel == "":
		return 0.0
	var delta := 0.0
	# (a) 卡片脚本在结算中写入的临时值
	if battle_state != null and battle_state.has_method("get_ability_multiplier"):
		var from_card := float(battle_state.get_ability_multiplier(channel))
		if not is_zero_approx(from_card):
			delta += from_card
			if want_breakdown:
				_append_breakdown(context, "ability", "书页脚本写入", "channel=%s" % channel, from_card)
	# (b) 被动对象自带的常驻值（不需要书页脚本配合）
	for p in _passives_of(owner):
		var provided = _call_passive(p, "get_ability_multipliers", [], {})
		if provided is Dictionary:
			var from_passive := float(provided.get(channel, 0.0))
			if not is_zero_approx(from_passive):
				delta += from_passive
				if want_breakdown:
					_append_breakdown(context, "ability", _passive_name(p), "get_ability_multipliers", from_passive)
	return delta

func _append_breakdown(context: Dictionary, kind: String, source: String, detail: String, value: float) -> void:
	var log: Array = context.get("_breakdown", [])
	log.append({"kind": kind, "source": source, "method": detail, "value": value})
	context["_breakdown"] = log

## 取被动实例的「人话名字」：脚本文件名即可
func _passive_name(p) -> String:
	if p == null:
		return "?"
	var script = p.get_script()
	if script == null:
		return "?"
	var path: String = script.resource_path
	if path == "":
		return "?"
	return path.get_file().get_basename()

## 一次性取出所有能力来源的增量，供一次结算内复用
func collect_ability_multipliers(owner, battle_state) -> Dictionary:
	var out := {}
	for stat in STATS:
		if STATS[stat].get("ability", "") != "":
			out[stat] = _ability_delta(owner, stat, battle_state)
	return out

## 统一取乘数
## ability_snapshot 传入时用它（已包含「卡片脚本 + 被动常驻」两部分增量），不再重新遍历被动。
## want_breakdown = true 时往 context["_breakdown"] 里记下每个来源（只影响调试，不影响数值）。
func _multiplier(owner, stat: String, context: Dictionary = {}, ability_snapshot = null, want_breakdown: bool = false) -> float:
	if not STATS.has(stat):
		push_warning("[GlobalStats] 未知的乘数维度：%s（可用：%s）" % [stat, STATS.keys()])
		return ONE
	var delta := 0.0
	if ability_snapshot is Dictionary:
		delta = float(ability_snapshot.get(stat, 0.0))
		if want_breakdown and not is_zero_approx(delta):
			var channel: String = STATS[stat].get("ability", "")
			_append_breakdown(context, "ability", "合计", "channel=%s" % channel, delta)
	else:
		delta = _ability_delta(owner, stat, context.get("battle_state"), want_breakdown, context)
	return _passive_multiplier(owner, stat, context, want_breakdown) * (ONE + delta)

# ==================== 调试：把一个乘数拆成来源明细 ====================
## 返回 { "total": float, "passive": float, "ability_bonus": float, "entries": Array }
## entries 每项：{kind, source, method, value}
##   kind = passive / ability / accessory（显示名走 `kind_name()`）
##   value：被动与饰品是**乘数**（1.0 为无影响）；能力是**增量**（0 为无影响）
## ⚠️ 只用于调试。它会把被动再遍历一遍，别放进热路径。
func get_multiplier_breakdown(owner, stat: String, enemy_witch_power: int = 0, battle_state = null) -> Dictionary:
	var context := {"enemy_witch_power": enemy_witch_power, "battle_state": battle_state, "_breakdown": []}
	var total := _multiplier(owner, stat, context, null, true)
	var entries: Array = context.get("_breakdown", [])

	# 饰品来源是「加算」，单独列出来（它不参与乘数，但用户要看「来自哪里」）
	if stat == "damage" or stat == "armor" or stat == "heal":
		for acc in _accessories_of(owner):
			if acc.attack_bonus != 0:
				entries.append({"kind": "accessory", "source": acc.name, "method": "attack_bonus（加算）", "value": acc.attack_bonus})

	var passive_part: float = _passive_multiplier(owner, stat, context)
	var ability_part: float = 0.0
	for e in entries:
		if e["kind"] == "ability":
			ability_part += float(e["value"])
	return {
		"total": total,
		"passive": passive_part,
		"ability_bonus": ability_part,
		"entries": entries,
	}

func _accessories_of(owner) -> Array:
	if owner == null or not owner.has_method("get_accessories"):
		return []
	return owner.get_accessories()

# ==================== 调试：攻击加算的来源明细 ====================
## 返回 { "total": int, "entries": [{kind, source, value}] }
## attack_bonus 是**加算**，直接相加，不是相乘。
func get_attack_bonus_breakdown(owner) -> Dictionary:
	var entries: Array = []
	var total := 0
	for acc in _accessories_of(owner):
		if acc.attack_bonus != 0:
			entries.append({"kind": "accessory", "source": acc.name, "value": acc.attack_bonus})
			total += acc.attack_bonus
	for p in _passives_of(owner):
		var v := int(_call_passive(p, "get_ability_bonus_attack", [], 0))
		if v != 0:
			entries.append({"kind": "passive", "source": _passive_name(p), "value": v})
			total += v
	return {"total": total, "entries": entries}

# ==================== 对外 API：乘数（基准 1.0） ====================
## 说明：不带 ability_snapshot 的版本会现场遍历被动，适合零星调用（事件、UI、调试）。
## 战斗结算这种批量场景请先用 collect_ability_multipliers() 取一次，再走带 snapshot 的版本。

## 所有「被动 × 饰品 × 能力」的伤害乘数
func get_damage_multiplier(owner, enemy_witch_power: int = 0, battle_state = null, ability_snapshot = null) -> float:
	return _multiplier(owner, "damage", {"enemy_witch_power": enemy_witch_power, "battle_state": battle_state}, ability_snapshot)

func get_armor_multiplier(owner, battle_state = null, ability_snapshot = null) -> float:
	return _multiplier(owner, "armor", {"battle_state": battle_state}, ability_snapshot)

func get_heal_multiplier(owner, battle_state = null, ability_snapshot = null) -> float:
	return _multiplier(owner, "heal", {"battle_state": battle_state}, ability_snapshot)

func get_witch_power_multiplier(owner, battle_state = null, ability_snapshot = null) -> float:
	return _multiplier(owner, "witch_power", {"battle_state": battle_state}, ability_snapshot)

## 「承受伤害」的乘数：预留给护盾/减伤类被动与饰品，1.0 表示不减伤
func get_damage_taken_multiplier(owner, battle_state = null, ability_snapshot = null) -> float:
	return _multiplier(owner, "damage_taken", {"battle_state": battle_state}, ability_snapshot)

## 通用入口：给将来新增的维度或不方便写专名的地方用
## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func get_stat_multiplier(owner, stat: String, context: Dictionary = {}, ability_snapshot = null) -> float:
	return _multiplier(owner, stat, context, ability_snapshot)

# ==================== 冲动倍率（「冲动」关键词的核心效果） ====================
## 基准 1 + 自己的魔女化/100：魔女化越深，带冲动的页打得越狠。
## 这是**乘法**，与「冲动赋予数量」是两件事：
##   数量决定「有几页被挂上冲动」，这里决定「被挂上的页强多少」。
## 两边共用同一个出口，所以镜像与玩家的口径一致。
## 被动可以用 modify_impulse_multiplier() 再叠一层（不实现就是 1.0）。
func get_impulse_multiplier(owner) -> float:
	var base := ONE
	if IMPULSE_SCALES_WITH_WITCH_POWER and owner != null and owner.has_method("get_witch_power"):
		base = ONE + float(owner.get_witch_power()) / 100.0
	var extra := _passive_multiplier(owner, "impulse", {})
	return base * extra

# ==================== 对外 API：加算（基准 0） ====================
## 该单位每次攻击附带的固定加算：饰品导出字段 + 被动提供的加算。
## 这是攻击加算的**唯一公式**，两边都用它；战斗中请缓存结果（逐页调用会重复遍历被动）。
func get_attack_bonus(owner) -> int:
	var bonus := 0
	if owner != null and owner.has_method("get_accessories"):
		for acc in owner.get_accessories():
			bonus += acc.attack_bonus
	for p in _passives_of(owner):
		bonus += int(_call_passive(p, "get_ability_bonus_attack", [], 0))
	return bonus

# ==================== 静态查询（不需要 owner 实例） ====================
## battle_state 用它校验维度名，避免调用方拼错
static func is_valid_ability_channel(stat: String) -> bool:
	return STATS.has(stat) and STATS[stat].get("ability", "") != ""

## 该单位的能力是否被整体禁用（例如雪莉心衰到档）
static func is_ability_disabled(owner) -> bool:
	if owner == null or not owner.has_method("collect_passives"):
		return false
	for p in owner.collect_passives():
		if p != null and p.has_method("is_ability_disabled") and p.is_ability_disabled():
			return true
	return false

# ==================== 调试 ====================
## 把该单位当前所有乘数打印成一行，方便核对数值
## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func debug_dump(owner, enemy_witch_power: int = 0, battle_state = null) -> String:
	var parts: PackedStringArray = ["[GlobalStats]"]
	for stat in STATS:
		parts.append("%s=%.3f" % [stat, _multiplier(owner, stat, {"enemy_witch_power": enemy_witch_power, "battle_state": battle_state})])
	parts.append("attack_bonus=%d" % get_attack_bonus(owner))
	return " ".join(parts)
