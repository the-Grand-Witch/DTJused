extends Node
class_name BattleState

## ==================================================================
## 阵营战斗态（基类）
## ==================================================================
## 玩家用本类（战斗场景里的 BattleState 节点），镜像用 EnemyState 继承它。
## 两者是**同一套状态接口的两个实现**：
##   - 纯函数（GlobalStats）只认这组读口，所以两边都能直接传进去；
##   - 战斗流程（编入/使用/结束、关键词、冲动、魔女化）都在这里，
##     具体数值取哪来的由子类决定。
##
## 归属划分（重要）：
##   跨战斗存活的（血量/魔女化/金币/角色/饰品）→ 玩家侧留在 GlobalPlayer
##   打完就没的（每回合乘数/护盾/心衰/看破/冲动/页标记）→ 停在各自的 state 里
##
## 子类必须实现这几个「取数」口：
##   get_health / set_health / get_max_health
##   get_witch_power / set_witch_power / get_max_witch_power
##   get_accessories
##   gain_witch_power(amount)   # 增减魔女化（用于冲动惩罚等）
##
## ⚠️ 用 battle_owner 而不是 owner：Node 内建就有 owner 属性，避免语义混淆。
## ==================================================================

enum Party { PLAYER, ENEMY }

var party: Party = Party.PLAYER
## 被动运行器：本阵营这一场战斗的被动实例
var passives := PassiveRuntime.new()
## 攻击加算缓存（子类在合适的时机失效/重算）
var _attack_bonus_cache: int = 0
var _attack_bonus_cached: bool = false

# ==================== 战斗态字段 ====================
var turn_count: int = 0
var attack_bonus: int = 0
var heal_count: int = 0
var armor_count: int = 0
var pending_effect: String = ""
var pending_value: float = 0.0
var max_selected: int = 1
var cards: Array[BookmarkCard] = []
var selected_cards: Array[BookmarkCard] = []
var status_dict: Dictionary = {}
var used_ability_pages: Array = []
var ability_buffs: Array = []
var used_pages: Dictionary = {}

## 本回合「已结算」的产出：逐页一份（左邻读它）+ 按主类型分组 + 总计。
## 谱序的「此前已结算伤害 × 0.3」这类效果读它；每回合（reset_round）清零。
var resolved_pages: Dictionary = {}
## 本回合的命中打点：每次**真正打出**（含 effect_play_count / 脚本追加的额外次数）各记一条。
## 命中特效按条逐个播，所以这里记的是「实际攻击次数」而不是页数。回合开始时随 clear_resolved 清空。
var hit_log: Array = []
var resolved_by_type: Dictionary = {}
var resolved_damage: int = 0
var resolved_armor: int = 0
var resolved_healing: int = 0

## 本回合被整页作废的页：key → 原因（"硬骨" / "吼叫"）。只用于调试输出。
## 作废发生在 `BattleFlow.aggregate()`，页面本身的 resolved 值（作废前算出来的）仍留着，
## 所以想核对「这页算出来是多少、为什么没生效」必须看这份记录。
var voided_pages: Dictionary = {}

## retrigger 队列：使用阶段排空（见 BattleFlow.run_use_phase）
var retrigger_queue: Array = []

## 这次行动真的被打出过的书签（含被 retrigger 打到的别的书签）——
## 结算要覆盖它们，否则「回合结束时把上一张再打一次」产出的数值会被漏掉。
var touched_cards: Array[BookmarkCard] = []

## 回合级状态（汐信读它们）：本回合 / 上回合
##   played_*        —— 这一页有没有被打出（= 它所在的书签这回合有没有被选中）
##   types_played_*  —— 这回合打出过哪些页类型
##   damage_taken_*  —— 这回合有没有受伤
## 回合边界由 shift_turn_flags() 把「本回合」搬到「上回合」。
var played_this_turn: Dictionary = {}
var played_last_turn: Dictionary = {}
var types_played_this_turn: Dictionary = {}
var types_played_last_turn: Dictionary = {}
var damage_taken_this_turn: bool = false
var damage_taken_last_turn: bool = false
## 这回合最后一次被打出的页（`汐信-W1` 的「把上一张再打一次」）
var last_played_card: BookmarkCard = null
var last_played_index: int = -1

## 关键词触发日志（调试用；每回合清，由 debug_round 打出来）
var keyword_logs: Array = []

## 对手那一侧的 state（Boss 战才有；普通怪没有 witch power，所以是 null）。
## 给 `魇蚀-W1`「敌方魔女化 −8」这类跨阵营写口用。由 battle_main 在开战时对接。
var enemy_side = null

## 本回合魔女化**增量**（`魇蚀-D3` 读它）。任何走 gain_witch_power 的变化都会记进来。
var witch_gain_this_turn: int = 0

## 冲动（魇蚀那一组）：
##   impulse_per_turn_bonus   —— 每回合额外赋予的冲动条数（`魇蚀-B1`）
##   impulse_next_turn        —— 下回合额外赋予一次（`魇蚀-W2`），回合开始时被消费
##   impulse_punishment_delta —— 冲动惩罚的修正（`魇蚀-B2`），**可以为负**
var impulse_per_turn_bonus: int = 0
var impulse_next_turn: int = 0
var impulse_punishment_delta: int = 0

## 打出记录（振鸣读）：
##   play_order            —— 本回合的打出顺序 [{card, index}]（`振鸣-B2` 找「上一张振鸣页」）
##   keyword_plays_turn    —— 本回合每个关键词被打出的次数
##   keyword_plays_battle  —— 本场每个关键词被打出的次数（`振鸣-W1`）
var play_order: Array = []
var keyword_plays_turn: Dictionary = {}
var keyword_plays_battle: Dictionary = {}

## 能力来源的临时乘数：书页脚本在结算中调用 context["add_*_multiplier"] 写入，
## 由 GlobalStats 读走。存的是「累加值」，最终折算为 1.0 + 累加值。
## 维度名由 GlobalStats.STATS 定义，避免拼错。
var ability_multipliers: Dictionary = {}

## 被动的具名战斗态。
## 被动脚本不要把这些值存在自己实例的字段上，改为存这里；
## 否则镜像与玩家会共用同一份（实例可能是共享的）。
## 例：{"heart_failure": 5, "insight_stacks": 2, "impulse_immune": true}
var passive_values: Dictionary = {}

# ==================== 生命周期 ====================
## 玩家侧退出战斗场景时，解除在全局单例上留下的引用（镜像侧不需要，N/A 覆盖）
func _exit_tree() -> void:
	if party != Party.PLAYER:
		return
	if GlobalPassive != null:
		GlobalPassive.clear_active_owner()
	if GlobalPlayer != null:
		GlobalPlayer.bind_battle_owner(null)

## 绑定被动运行器（由场景在开战时调用）
##   player：PassiveRuntime.sync_from_global()
##   enemy ：PassiveRuntime.build_from_accessories(...)
func bind_passives() -> void:
	passives.side = self
	passives._bind_owner_to_passives()

## 被动实例的 owner 指向自己
func bind_owner(_owner_node: Node) -> void:
	bind_passives()

# ==================== owner 读口：被动 / 饰品 ====================
## 被动实例（角色被动 + 饰品被动）
func collect_passives() -> Array:
	return passives.collect()

## 已拥有饰品（纯数值来源；事件型脚本的实例在 collect_passives 里）
func get_accessories() -> Array:
	return []

# ==================== owner 读口：饰品的纯数值汇总 ====================
## 下面几个方法在 GlobalAccessories 里都有一一对应的同名版本（玩家侧的老 API）。
## 之所以收到基类来：算「怎么求和的」只有一份，**数据源由 get_accessories() 决定** ——
##   玩家 → GlobalAccessories.accessories
##   镜像 → EnemyState 自己那批
## 这样玩家与镜像各自独立判定，谁都不会读到对方的饰品。
func get_max_health_bonus() -> int:
	var total := 0
	for acc in get_accessories():
		total += acc.max_health_bonus
	return total

func get_bookpage_cd_reload() -> int:
	var total := 0
	for acc in get_accessories():
		total += acc.bookpage_cd_reload
	return total

func get_witch_max_increase() -> int:
	var total := 0
	for acc in get_accessories():
		total += acc.witch_max_increase
	return total

func get_witch_impulse_reduce() -> int:
	var total := 0
	for acc in get_accessories():
		total += acc.witch_impulse_reduce
	return total

func get_bookmark_page_limit_up() -> int:
	var total := 0
	for acc in get_accessories():
		total += acc.bookmark_page_limit_up
	return total

## 本方阵营的书签页数上限：基础规则 + 自己饰品的提升。
## ⚠️ 页数上限必须问 owner（玩家与镜像的饰品不同）—— 以前写死读 GlobalAccessories，
##    于是玩家的「加页上限」饰品会被算进镜像的上限里。
func get_bookmark_page_limit() -> int:
	return GlobalBookMark.BASE_PAGE_LIMIT + get_bookmark_page_limit_up()

# ==================== owner 读口：血量 / 魔女化（子类实现） ====================
func get_health() -> int:
	return 0

func set_health(_value: int) -> void:
	pass

func get_max_health() -> int:
	return 0

func get_witch_power() -> int:
	return 0

func set_witch_power(_value: int) -> void:
	pass

func get_max_witch_power() -> int:
	return 0

## 增减魔女化（冲动惩罚、彼岸之赐等用）。子类决定写到哪。
func gain_witch_power(_amount: int) -> void:
	pass

## 溢出提示：子类可覆写
func is_overloaded() -> bool:
	return false

# ==================== owner 读口：能力乘数 / 页可用性 / 钩子 ====================
func get_ability_multiplier(stat: String) -> float:
	return ability_multipliers.get(stat, 0.0)

func is_page_available(page: Generator_bookpage) -> bool:
	return passives.is_page_available(page)

func is_ability_disabled() -> bool:
	return passives.is_ability_disabled()

func try_consume_block() -> bool:
	return passives.try_consume_block()

func notify_page_played(mark: Dictionary) -> void:
	passives.notify_page_played(mark)

func notify_damage_dealt(amount: int) -> void:
	passives.notify_damage_dealt(amount)

# ==================== 攻击加算 / 能力乘数 ====================
## 本阵营每次攻击附带的固定加算（饰品导出字段 + 被动提供的加算）。
## 公式在 GlobalStats 里；这里做一层缓存，避免逐页重复遍历被动。
## 饰品数量变化时子类要调 invalidate_attack_bonus()。
func get_attack_bonus() -> int:
	if not _attack_bonus_cached:
		_attack_bonus_cache = GlobalStats.get_attack_bonus(self)
		_attack_bonus_cached = true
	return _attack_bonus_cache

func invalidate_attack_bonus() -> void:
	_attack_bonus_cached = false

## add_ability_multiplier("damage", 0.5) → 本次结算伤害 ×1.5
## add_ability_multiplier("damage", -0.25) → 本次结算伤害 ×0.75
## 可用维度由 GlobalStats.STATS 决定；写入的是「增量」，最终折算为 1.0 + 累加值。
func add_ability_multiplier(stat: String, delta: float) -> void:
	if not GlobalStats.is_valid_ability_channel(stat):
		push_warning("[BattleState] 未知的能力乘数维度：%s（可用：%s）" % [stat, GlobalStats.STATS.keys()])
		return
	ability_multipliers[stat] = ability_multipliers.get(stat, 0.0) + delta

func clear_ability_multipliers() -> void:
	ability_multipliers.clear()

# ==================== 被动具名战斗态 ====================
func get_passive_value(key: String, default_value = 0):
	return passive_values.get(key, default_value)

func set_passive_value(key: String, value) -> void:
	passive_values[key] = value

## 怪物页写在「对手身上」的跨阵营效果（硬骨 / 吼叫）。
## 野怪在**预告意图那一刻**就挂上（见 `wild_monster.on_round_start`），
## 玩家本次行动结算完由 `battle_calculator.calculate_player_effects()` 调这里清掉 ——
## 只作用一次，不会拖到下一回合。
const MONSTER_DEBUFF_KEYS := ["monster_roar", "monster_hardbone"]

func clear_monster_debuffs() -> void:
	for key in MONSTER_DEBUFF_KEYS:
		passive_values.erase(key)

# ---- 看破（雪莉的帽子用） ----
func add_insight(amount: int = 1) -> void:
	set_passive_value("insight_stacks", int(get_passive_value("insight_stacks", 0)) + amount)

func get_insight_stacks() -> int:
	return int(get_passive_value("insight_stacks", 0))

## 清空看破，并通知各被动清掉本地记录
func clear_insight() -> void:
	passive_values.erase("insight_stacks")
	passives.clear_insight()

# ---- 冲动免疫（雪莉的战斗开始时开启） ----
func is_impulse_immune() -> bool:
	return bool(get_passive_value("impulse_immune", false))

func set_impulse_immune(value: bool) -> void:
	set_passive_value("impulse_immune", value)

# ==================== 冲动（战斗态） ====================
## 冲动只挂**攻击页**（卡牌设计稿 §五 魇蚀：冲动是挂在攻击页上的标记）。
## 旧的「优先挂魇蚀页」行为已删除 —— 那是旧魇蚀的设计，与新设计无关。
func apply_impulses(target_cards: Array[BookmarkCard], count: int) -> void:
	if is_impulse_immune():
		return
	clear_impulses(target_cards)
	if count <= 0:
		return

	var attack_pages: Array[Dictionary] = []
	for card in target_cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			# 读运行态类型（与结算口径一致；回合开始时它等于资源值）
			if Generator_bookpage.PickupType.Attack in card.get_runtime_types(idx):
				attack_pages.append({"card": card, "page_index": idx})

	attack_pages.shuffle()
	for i in range(min(count, attack_pages.size())):
		var entry = attack_pages[i]
		var card: BookmarkCard = entry["card"]
		var idx: int = entry["page_index"]
		_mark_impulse(card, idx, true)

func clear_impulses(target_cards: Array[BookmarkCard]) -> void:
	for card in target_cards:
		for idx in range(card.get_all_marks().size()):
			_mark_impulse(card, idx, false)

func has_impulse(card: BookmarkCard, page_index: int) -> bool:
	var mark = card.get_page_mark(page_index)
	return mark.get("effects", {}).get("impulse", false)

func consume_impulse(card: BookmarkCard, page_index: int) -> bool:
	var mark = card.get_page_mark(page_index)
	if mark.get("effects", {}).get("impulse", false):
		mark["effects"].erase("impulse")
		return true
	return false

## 未打出的冲动惩罚：每个还挂着冲动的页让自己涨一次魔女化。
## ⚠️ 用 get_final_impulse_punishment()：`魇蚀-B2` 会把它改成 **负数**，
##    那时「没清冲动」反而**降压**（设计：越接近失败越强）。
func punish_unused_impulses(target_cards: Array[BookmarkCard]) -> void:
	for card in target_cards:
		for mark in card.get_all_marks():
			if mark.get("effects", {}).get("impulse", false):
				gain_witch_power(get_final_impulse_punishment())
				mark["effects"].erase("impulse")

## 子类给「基础惩罚值」（玩家侧读 GlobalPlayer，镜像侧是自己的数）
func get_impulse_punishment() -> int:
	return 2

## 实际生效的惩罚值 = 基础值 + 本场修正（`魇蚀-B2` 的 −1，可为负）
func get_final_impulse_punishment() -> int:
	return get_impulse_punishment() + impulse_punishment_delta

## 本回合实际赋予的冲动条数（基础 + 每回合额外 + 下回合额外），消费掉「下回合额外」
func consume_impulse_next_turn() -> int:
	var extra: int = impulse_next_turn
	impulse_next_turn = 0
	return extra

# ---- 魇蚀那一组写口 ----
func add_impulse_per_turn(n: int) -> void:
	impulse_per_turn_bonus += n

func add_impulse_next_turn(n: int) -> void:
	impulse_next_turn += n

func add_impulse_punishment(n: int) -> void:
	impulse_punishment_delta += n

func _mark_impulse(card: BookmarkCard, page_index: int, on: bool) -> void:
	var mark = card.get_page_mark(page_index)
	if not mark.has("effects"):
		mark["effects"] = {}
	if on:
		mark["effects"]["impulse"] = true
	else:
		mark["effects"].erase("impulse")

# ==================== used / use_count ====================
func _key(card: BookmarkCard, page_index: int) -> String:
	return "%d:%d" % [card.get_instance_id(), page_index]

func record_use(card: BookmarkCard, page_index: int) -> void:
	card.page_marks[page_index]["use_count"] += 1

func mark_used(card: BookmarkCard, page_index: int) -> void:
	used_pages[_key(card, page_index)] = true

func is_used(card: BookmarkCard, page_index: int) -> bool:
	return used_pages.get(_key(card, page_index), false)

func clear_used() -> void:
	used_pages.clear()

## 让某页重新变成「没结算过」。
## retrigger 重放一页时必须先解开，否则它自己的数值写不进去（add_page_value 会被 is_used 挡住）。
func clear_used_page(card: BookmarkCard, page_index: int) -> void:
	used_pages.erase(_key(card, page_index))

# ==================== 页数值 ====================
func set_page_value(card: BookmarkCard, page_index: int, field: String, value) -> void:
	if is_used(card, page_index):
		return
	var v = card.get_values(page_index)
	v[field] = value

func add_page_value(card: BookmarkCard, page_index: int, field: String, delta) -> void:
	if is_used(card, page_index):
		return
	var v = card.get_values(page_index)
	v[field] = v.get(field, 0) + delta

## 给「本回合已经结算过」的页加值：回填它已采集的所有快照。
## 关键词的 selector 可能指向已经打过的页（此时 add_page_value 会被 is_used 挡住）。
func add_to_page(card: BookmarkCard, page_index: int, field: String, delta) -> void:
	if not is_used(card, page_index):
		add_page_value(card, page_index, field, delta)
		return
	for snap in card.get_page_mark(page_index)["snapshots"]:
		var v: Dictionary = snap["values"]
		v[field] = v.get(field, 0) + delta

## 把「本回合已经结算过」的页的某个字段**改成**指定值（同样回填快照）
func set_to_page(card: BookmarkCard, page_index: int, field: String, value) -> void:
	if not is_used(card, page_index):
		set_page_value(card, page_index, field, value)
		return
	for snap in card.get_page_mark(page_index)["snapshots"]:
		snap["values"][field] = value

# ==================== 页冷却 / 运行态类型 / 持久区（关键词写口） ====================
## ⚠️ 页级 cd 只在**下一次 start_cooldown()** 时被读成书签 cd（取平均），
##    之后会被重置回 page.cd —— 所以动态 cd 是「这一次打出算数」。
func set_page_cd(card: BookmarkCard, page_index: int, value: int) -> void:
	card.get_page_mark(page_index)["cd_remaining"] = max(0, value)

func add_page_cd(card: BookmarkCard, page_index: int, delta: int) -> void:
	var mark = card.get_page_mark(page_index)
	mark["cd_remaining"] = max(0, int(mark["cd_remaining"]) + delta)

## 加一个运行态类型标记（只在运行态副本上，不写回资源）
func add_runtime_type(card: BookmarkCard, page_index: int, t) -> void:
	if t == null:
		return
	var types: Array = card.get_page_mark(page_index)["page_type"]
	if t not in types:
		types.append(t)

func set_runtime_types(card: BookmarkCard, page_index: int, types: Array) -> void:
	card.get_page_mark(page_index)["page_type"] = types.duplicate()

func set_persistent(card: BookmarkCard, page_index: int, key: String, value) -> void:
	card.get_page_mark(page_index)["persistent"][key] = value

func add_persistent(card: BookmarkCard, page_index: int, key: String, delta) -> void:
	var p: Dictionary = card.get_page_mark(page_index)["persistent"]
	p[key] = p.get(key, 0) + delta

func get_persistent(card: BookmarkCard, page_index: int) -> Dictionary:
	return card.get_page_mark(page_index)["persistent"]

## 页级「下一张 X 页」待生效：挂在**写它的那一页**上，等匹配的页被打出时消费
func set_pending(card: BookmarkCard, page_index: int, entry: Dictionary) -> void:
	card.get_page_mark(page_index)["pending"].append(entry)

# ==================== retrigger ====================
## 让某页再走一遍使用阶段。可以级联（被 retrigger 的页自己再 retrigger 别人），
## 但**一页在一次使用周期里只能被指向一次** —— 所以链天然有限。
## 周期 = 一次行动的「使用阶段」，由 reset_round_modifiers() 清 retriggered 标记。
func queue_retrigger(card: BookmarkCard, page_index: int) -> void:
	retrigger_queue.append({"card": card, "index": page_index})

## 返回 true = 这一页本次周期还没被 retrigger 指向过（可以再打一次）
func mark_retriggered(card: BookmarkCard, page_index: int) -> bool:
	var mark = card.get_page_mark(page_index)
	if mark["retriggered"]:
		return false
	mark["retriggered"] = true
	return true

# ==================== 本回合「已结算」的产出 ====================
## 逐页记一份（左邻读它），并按主类型分组累加（本回合累计器）
func note_resolved(card: BookmarkCard, page_index: int, damage: int, armor: int, healing: int, witchpower: int) -> void:
	resolved_pages[_key(card, page_index)] = {
		"damage": damage, "armor": armor, "healing": healing, "witchpower": witchpower,
	}
	resolved_damage += damage
	resolved_armor += armor
	resolved_healing += healing
	var types: Array = card.get_page_mark(page_index)["page_type"]
	var main = null
	if not types.is_empty():
		main = types[0]
	var bucket: Dictionary = resolved_by_type.get(main, {"damage": 0, "armor": 0, "healing": 0, "witchpower": 0})
	bucket["damage"] += damage
	bucket["armor"] += armor
	bucket["healing"] += healing
	bucket["witchpower"] += witchpower
	resolved_by_type[main] = bucket

func get_resolved(card: BookmarkCard, page_index: int) -> Dictionary:
	if page_index < 0:
		return {}
	return resolved_pages.get(_key(card, page_index), {})

## 记一页「整页作废」（硬骨 / 吼叫）。只给调试输出用，不影响结算。
func note_voided_page(card: BookmarkCard, page_index: int, reason: String) -> void:
	voided_pages[_key(card, page_index)] = reason

## 这一页本回合为什么没生效（""=没被作废）
func get_voided_reason(card: BookmarkCard, page_index: int) -> String:
	return String(voided_pages.get(_key(card, page_index), ""))

## 记一页的「能力」产出次数（`count`）。能力不在 damage/armor 那几个字段里，
## 单独记一份，否则调试账本上看不出「这页到底给了几点能力」。
func note_resolved_ability(card: BookmarkCard, page_index: int, count: int) -> void:
	if count == 0:
		return
	var key := _key(card, page_index)
	if not resolved_pages.has(key):
		resolved_pages[key] = {"damage": 0, "armor": 0, "healing": 0, "witchpower": 0}
	resolved_pages[key]["ability"] = int(resolved_pages[key].get("ability", 0)) + count

## 记一次命中打点（由 BattleFlow.note_resolved 在每次打出时调用）。
##   page   —— 这张页（特效判定的来源，也是 hit_effect 卡牌额外特效的出处）
##   witch  —— 运行态类型里带 Witch：魔女化攻击卡 → 用白色爪痕
##   buffed —— 这一发打出的伤害被**正面增加过**（高于数据面板的基础值）→ 用红色版本
func note_hit(card: BookmarkCard, page_index: int, damage: int) -> void:
	if damage <= 0:
		return
	var page: Generator_bookpage = card.Generator_bookmark.pages[page_index]
	hit_log.append({
		"page": page,
		"damage": damage,
		"witch": Generator_bookpage.PickupType.Witch in card.get_runtime_types(page_index),
		"buffed": damage > page.damage + page.effect_damage,
	})

func clear_resolved() -> void:
	resolved_pages.clear()
	resolved_by_type.clear()
	resolved_damage = 0
	resolved_armor = 0
	resolved_healing = 0
	hit_log.clear()

## 关键词触发日志（给 debug_round 打；见 printf）
func note_keyword_log(card: BookmarkCard, page_index: int, text: String) -> void:
	keyword_logs.append("%s 第 %d 页：%s" % [card.Generator_bookmark.title, page_index, text])

# ==================== 回合级状态（汐信读） ====================
## 一页被打出：记「本回合打出过它 / 它的类型 / 它的关键词」，并更新「最后打出的页」
func mark_page_played(card: BookmarkCard, page_index: int) -> void:
	played_this_turn[_key(card, page_index)] = true
	for t in card.get_runtime_types(page_index):
		types_played_this_turn[t] = true
	for keyword in card.Generator_bookmark.pages[page_index].keywords:
		keyword_plays_turn[keyword] = keyword_plays_turn.get(keyword, 0) + 1
		keyword_plays_battle[keyword] = keyword_plays_battle.get(keyword, 0) + 1
	play_order.append({"card": card, "index": page_index})
	last_played_card = card
	last_played_index = page_index
	if card not in touched_cards:
		touched_cards.append(card)

## 把一张书签列入「本次结算要覆盖的范围」（选中的书签在开打时就登记）
func touch_card(card: BookmarkCard) -> void:
	if card not in touched_cards:
		touched_cards.append(card)

## 记一次魔女化变化（正=涨，负=降）。出口是 gain_witch_power，所以两边口径一致。
func note_witch_change(delta: int) -> void:
	witch_gain_this_turn += delta

func was_played_last_turn(card: BookmarkCard, page_index: int) -> bool:
	return played_last_turn.get(_key(card, page_index), false)

func is_played_this_turn(card: BookmarkCard, page_index: int) -> bool:
	return played_this_turn.get(_key(card, page_index), false)

func note_damage_taken() -> void:
	damage_taken_this_turn = true

## 回合边界：把「本回合」搬到「上回合」，再清空本回合那一份。
## ⚠️ 必须在回合开始的关键词 tick **之前**调（tick 读的是 *_last_turn）。
func shift_turn_flags() -> void:
	played_last_turn = played_this_turn
	types_played_last_turn = types_played_this_turn
	damage_taken_last_turn = damage_taken_this_turn
	played_this_turn = {}
	types_played_this_turn = {}
	damage_taken_this_turn = false
	# 「最后打出的页」只在本回合内有效（`汐信-W1` 说的是「本回合上一张打出的页」）
	last_played_card = null
	last_played_index = -1

func clear_turn_flags() -> void:
	played_this_turn.clear()
	played_last_turn.clear()
	types_played_this_turn.clear()
	types_played_last_turn.clear()
	damage_taken_this_turn = false
	damage_taken_last_turn = false
	last_played_card = null
	last_played_index = -1
	touched_cards.clear()

# ==================== 全局查询（汐信读） ====================
## 本方「可使用状态」的页数（它所在的书签 cd 已转好）
func count_ready_pages() -> int:
	var total: int = 0
	for card in cards:
		if not card.is_ready():
			continue
		total += card.Generator_bookmark.pages.size()
	return total

## 本方冷却最长的那张页（`汐信-B2` 对它下手）。
## 口径：先找**书签剩余冷却**最长的书签，再取其中页 cd 最大的一张 ——
## 页级 cd 只在「下一次 start_cooldown() 取平均」时生效，所以减它的 cd = 让那本书签更快回来。
## （cards 可能为空：镜像吃书之后手牌被清空）
func slowest_page() -> Dictionary:
	if cards.is_empty():
		return {"card": null, "index": -1, "cd": 0}
	var slowest_card: BookmarkCard = null
	for card in cards:
		if slowest_card == null or card.current_cd > slowest_card.current_cd:
			slowest_card = card
	var best_index: int = -1
	var best_cd: int = -1
	for i in range(slowest_card.Generator_bookmark.pages.size()):
		var cd: int = int(slowest_card.get_page_mark(i)["cd_remaining"])
		if cd > best_cd:
			best_cd = cd
			best_index = i
	return {"card": slowest_card, "index": best_index, "cd": best_cd}

## 清掉某页的本场持久区（汐信页被打出后由流程层调）
func clear_persistent(card: BookmarkCard, page_index: int) -> void:
	card.get_page_mark(page_index)["persistent"].clear()

# ==================== play_count / overall ====================
func add_play_count(card: BookmarkCard, page_index: int, n: int) -> void:
	var mark = card.get_page_mark(page_index)
	mark["play_count"] = mark.get("play_count", 1) + n

## 读取本页的总使用次数。
## 由三部分相加而成：基础 1 次 + 数据里的 effect_play_count + 书页脚本的追加值。
## 注意 add_page_value(card, idx, "play_count", n) 也会写进 values["play_count"]，
## 所以两个入口都要算，避免脚本用哪个写法结果不一样。
func get_play_count(card: BookmarkCard, page_index: int) -> int:
	var mark = card.get_page_mark(page_index)
	var values = card.get_values(page_index)
	var total = int(mark.get("play_count", 1))
	total += int(values.get("effect_play_count", 0))
	total += int(values.get("play_count", 0))
	return max(1, total)

func multiply_overall(card: BookmarkCard, page_index: int, m: float) -> void:
	var mark = card.get_page_mark(page_index)
	mark["overall_multiplier"] = mark.get("overall_multiplier", 1.0) * m

func add_overall(card: BookmarkCard, page_index: int, s: int) -> void:
	var mark = card.get_page_mark(page_index)
	mark["overall_sum"] = mark.get("overall_sum", 0) + s

# ==================== 回合转换 ====================
func reset_round() -> void:
	clear_resolved()
	voided_pages.clear()
	retrigger_queue.clear()
	keyword_logs.clear()
	touched_cards.clear()
	play_order.clear()
	keyword_plays_turn.clear()
	witch_gain_this_turn = 0

# ==================== 效果标记 ====================
## effect_data: {"effect": "xxx" 或 "xxx_pending", "condition": {...}, "value": 数值}
func apply_effect(effect_data: Dictionary, mark: Dictionary) -> void:
	var effect_name: String = effect_data.get("effect", "")
	if effect_name == "":
		return
	if effect_name.ends_with("_pending"):
		pending_effect = effect_name.replace("_pending", "")
		pending_value = effect_data.get("value", 0)
		return
	if not mark.has("effects"):
		mark["effects"] = {}
	mark["effects"][effect_name] = true

func consume_pending(mark: Dictionary) -> bool:
	if pending_effect == "":
		return false
	match pending_effect:
		"overall_multiplier":
			mark["overall_multiplier"] = mark.get("overall_multiplier", 1.0) * pending_value
		"overall_sum":
			mark["overall_sum"] = mark.get("overall_sum", 0) + int(pending_value)
		"play_count":
			mark["play_count"] = mark.get("play_count", 1) + int(pending_value)
		_:
			if not mark.has("effects"):
				mark["effects"] = {}
			mark["effects"][pending_effect] = true
	pending_effect = ""
	pending_value = 0.0
	return true

# ==================== 战斗重置 ====================
func reset_battle() -> void:
	turn_count = 0
	attack_bonus = 0
	heal_count = 0
	armor_count = 0
	pending_effect = ""
	pending_value = 0.0
	cards.clear()
	selected_cards.clear()
	status_dict.clear()
	used_ability_pages.clear()
	used_pages.clear()
	ability_buffs.clear()
	ability_multipliers.clear()
	passive_values.clear()
	clear_resolved()
	retrigger_queue.clear()
	keyword_logs.clear()
	clear_turn_flags()
	play_order.clear()
	keyword_plays_turn.clear()
	keyword_plays_battle.clear()
	witch_gain_this_turn = 0
	impulse_per_turn_bonus = 0
	impulse_next_turn = 0
	impulse_punishment_delta = 0
	_attack_bonus_cached = false

# ==================== 调试：回合结算数值与来源 ====================
## 打印这一回合结束后，本阵营各项数值的**实际值 + 来自哪里**。
## 由 battle_main 在每回合结束时调用（玩家与镜像各一次）。
## enemy_witch_power 用于伤害乘数的计算（镜像那边是玩家的魔女化）。
func debug_round(enemy_witch_power: int = 0) -> void:
	if not DebugOutput.enabled():
		return
	# ⚠️ 不能用 := ：Party.keys() 的元素是 Variant，推断不出类型
	var tag: String = Party.keys()[party]
	var lines: PackedStringArray = []
	lines.append("──────── [%s] 回合 %d 结算 ────────" % [tag, turn_count])

	# ---- 基础数值（持久态由子类提供） ----
	lines.append("  血量        %d / %d" % [get_health(), get_max_health()])
	lines.append("  魔女化      %d / %d   来源：%s" % [
		get_witch_power(), get_max_witch_power(), _witch_power_source()])
	lines.append("  饰品 %d 件  被动 %d 个  来源：%s" % [
		get_accessories().size(), collect_passives().size(), _passive_source()])

	# ---- 战斗态 ----
	lines.append("  攻击加算    %d   %s" % [get_attack_bonus(), _format_bonus_sources()])
	lines.append("  护甲        %d" % armor_count)
	lines.append("  下回合回血  %d" % heal_count)
	lines.append("  冲动免疫    %s" % ("是" if is_impulse_immune() else "否"))

	# ---- 具名战斗态（heart_failure / insight_stacks ...） ----
	if passive_values.is_empty():
		lines.append("  具名战斗态  （空）")
	else:
		var parts: PackedStringArray = []
		for key in passive_values:
			parts.append("%s=%s" % [key, passive_values[key]])
		lines.append("  具名战斗态  %s" % ", ".join(parts))

	# ---- 乘数明细 ----
	for stat in GlobalStats.STATS:
		var bd: Dictionary = GlobalStats.get_multiplier_breakdown(self, stat, enemy_witch_power, self)
		var entries: Array = bd["entries"]
		lines.append("  %s 乘数 ×%.3f   %s" % [
			_stat_label(stat), float(bd["total"]), _format_entries(entries)])

	# ---- 关键词触发日志（谱序 / 汐信 / 振鸣的声明式触发） ----
	if keyword_logs.is_empty():
		lines.append("  关键词触发  （无）")
	else:
		lines.append("  关键词触发  %d 条：" % keyword_logs.size())
		for log in keyword_logs:
			lines.append("    " + str(log))

	# ---- 回合级状态（汐信读） ----
	var last_types: PackedStringArray = []
	for t in types_played_last_turn:
		last_types.append(BattleFlow.type_name(t))
	lines.append("  上回合 受伤=%s 打出类型=[%s] 打出页数=%d" % [
		"是" if damage_taken_last_turn else "否",
		", ".join(last_types),
		played_last_turn.size(),
	])

	# ---- 魇蚀 / 振鸣读的那些数 ----
	lines.append("  本回合魔女化增量 %d   冲动：每回合 +%d，下回合 +%d，惩罚 %d（基础 %d）" % [
		witch_gain_this_turn,
		impulse_per_turn_bonus,
		impulse_next_turn,
		get_final_impulse_punishment(),
		get_impulse_punishment(),
	])
	if not keyword_plays_turn.is_empty():
		var kw_parts: PackedStringArray = []
		for keyword in keyword_plays_turn:
			kw_parts.append("%s×%d（本场 %d）" % [keyword, keyword_plays_turn[keyword], keyword_plays_battle.get(keyword, 0)])
		lines.append("  本回合关键词打出  %s" % ", ".join(kw_parts))

	DebugOutput.say("\n".join(lines))

func _stat_label(stat: String) -> String:
	match stat:
		"damage": return "伤害"
		"armor": return "护甲"
		"heal": return "回复"
		"witch_power": return "魔女化"
		"damage_taken": return "承伤"
		"impulse": return "冲动"
	return stat

## 把来源明细拼成一行：被动/能力是乘数或增量，饰品是加算
func _format_entries(entries: Array) -> String:
	if entries.is_empty():
		return "来源：（无，全部为基准值 1.0 / 0）"
	var parts: PackedStringArray = []
	for e in entries:
		var value = e.get("value", 0)
		if e.get("kind", "") == "accessory":
			parts.append("%s[%s]+%s" % [e.get("source", "?"), e.get("method", ""), value])
		else:
			parts.append("%s(%s)%s" % [e.get("source", "?"), GlobalStats.kind_name(String(e.get("kind", ""))), _format_delta(value)])
	return "来源：" + " × ".join(parts)

## 把「增量」格式化成好读的样子：小于 10 的显示成倍率，否则原样显示
func _format_delta(value) -> String:
	var v: float = float(value)
	if v > 0.0 and v < 10.0:
		return "×%.3f" % (1.0 + v)
	return str(value)

func _format_bonus_sources() -> String:
	var bd: Dictionary = GlobalStats.get_attack_bonus_breakdown(self)
	var entries: Array = bd["entries"]
	if entries.is_empty():
		return "来源：（无）"
	var parts: PackedStringArray = []
	for e in entries:
		parts.append("%s[%s]+%s" % [e.get("source", "?"), GlobalStats.kind_name(String(e.get("kind", ""))), e.get("value", 0)])
	return "来源：" + " + ".join(parts)

## 子类覆写：血量/魔女化的来源说明
func _witch_power_source() -> String:
	return "未声明"

func _passive_source() -> String:
	return "未声明"

# ==================== 调试（旧） ====================
func printf() -> void:
	if not DebugOutput.enabled():
		return
	DebugOutput.say("[State:%s] atk_bonus=%d heal=%d armor=%d hp=%d/%d wp=%d/%d" % [
		Party.keys()[party],
		attack_bonus,
		heal_count,
		armor_count,
		get_health(),
		get_max_health(),
		get_witch_power(),
		get_max_witch_power(),
	])
