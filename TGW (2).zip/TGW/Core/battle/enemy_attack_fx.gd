extends Node2D
## 命中特效播放器：挂在**敌人身上**（battle.tscn 的 Monster / boss.tscn 的 Boss/Enemy 下）。
## ==================================================================
## 特效**直接显示在敌人中心**（不从玩家发射），并按本次结算的**实际攻击次数**逐个播：
##   ① 每次真正打出（含 effect_play_count / 脚本追加的额外次数）都有一条 hit_log → 一条播一发，
##      发与发之间隔 stagger，依次叠加；
##   ② 魔女化攻击卡（运行态类型带 Witch）→ **白色爪痕**；
##   ③ 其余 → 白色直线斩击 / 白色炸开 **随机**（impact_chance 控制炸开概率）；
##   ④ 该发的伤害被**正面增加过**（高于数据面板基础值）→ 换成对应的**红色版本**；
##   ⑤ 书页自带 hit_effect → 额外再叠一发（卡牌额外特效）。
##
## ★ 特效中心 = **本节点的位置**：在编辑器里直接拖 AttackFx 节点，特效就跟到哪。
##
## ⚠️ 本包全屏类特效（斩击 / 炸开 / 爪痕）的画布是 2560x1440，shader 全在 UV 空间作画，
##    所以「缩小」不是改节点 scale 就行的 —— 是把**整块画布缩放后居中到本节点**（见 _place）。
## ⚠️ 驱动脚本挂在「带材质那一层」，不是场景根：root/ColorRect 上才有 play()/set_line()/finished；
##    粒子类（回血 / 聚光）则直接挂根节点，_driver_of() 两种都认。
## ⚠️ 卡牌额外特效必须是「播放型」（有 play() 与 finished），否则 await 会一直等下去。
## ==================================================================

@export_group("素材")
## 白版 / 红版（红版 = 该发伤害被正面增加过）。爪痕留给魔女化攻击卡。
@export var slash_white: PackedScene = preload("res://Assets/Textures/effects/effect_slash.tscn")
@export var slash_red: PackedScene = preload("res://Assets/Textures/effects/effect_slash_heavy.tscn")
@export var impact_white: PackedScene = preload("res://Assets/Textures/effects/effect_impact.tscn")
@export var impact_red: PackedScene = preload("res://Assets/Textures/effects/effect_impact_red.tscn")
@export var claw_white: PackedScene = preload("res://Assets/Textures/effects/effect_claw.tscn")
@export var claw_red: PackedScene = preload("res://Assets/Textures/effects/effect_claw_heavy.tscn")

## 命中音效：直线类（斩击 / 爪痕）与炸开类各一种（键名 = Assets/Audio/work/ 里的文件名）
const SFX_LINE := "斩击"
const SFX_IMPACT := "击打"

@export_group("大小")
## 整体缩放：1.0 = 铺满全屏（原始大小），1/3 = 缩到三分之一。斩击长度、炸开半径一起缩。
@export_range(0.05, 1.0) var fx_scale := 1.0 / 3.0

@export_group("形状")
## 斩击 / 爪击是**过中心**的斜线：这两条是相对画布中心的半长（UV，受 fx_scale 影响）。
@export var line_from := Vector2(0.10, -0.30)
@export var line_to := Vector2(-0.10, 0.30)

@export_group("节奏")
## 多发之间的间隔（依次叠加播放）
@export var stagger := 0.15
## 非魔女化、未被强化的攻击里抽到「炸开」的概率（其余出直线斩击）
@export_range(0.0, 1.0) var impact_chance := 0.5

## 画布中心：全屏类特效的坐标都相对它
const CANVAS_CENTER := Vector2(0.5, 0.5)

var _pending := 0

## 播完一组命中特效，等所有特效收尾才返回。
## hits = battle_state.hit_log 的快照（每次真正打出各一条，见 BattleFlow.note_resolved）。
func play_hits(hits: Array) -> void:
	_pending = 0
	for hit in hits:
		_play_one(hit)
		await get_tree().create_timer(stagger).timeout
	while _pending > 0:
		await get_tree().process_frame

## 一发命中特效：魔女化攻击卡 → 爪痕；被正面增加过 → 红色版本；其余白色直线/炸开随机。
func _play_one(hit: Dictionary) -> void:
	var witch: bool = hit["witch"]
	var red: bool = hit["buffed"]
	var is_line := true
	var scene: PackedScene
	if witch:
		scene = claw_red if red else claw_white
	else:
		# 表演性随机（命中抽斩击/爆开）：按 GlobalRng 的规矩**不进种子**，否则同一发重放会变形
		is_line = randf() >= impact_chance
		if is_line:
			scene = slash_red if red else slash_white
		else:
			scene = impact_red if red else impact_white
	_show(scene, is_line)
	# 音效跟着形态走：直线类（斩击 / 爪痕）→ 斩击，炸开类 → 击打
	GlobalAudio.play(SFX_LINE if is_line else SFX_IMPACT)

	# 卡牌额外特效：书页自带就再叠一发
	var extra: PackedScene = hit["page"].hit_effect
	if extra != null:
		var extra_root: Node2D = _spawn(extra)
		_place(extra_root, _driver_of(extra_root))
		_driver_of(extra_root).play()

func _show(scene: PackedScene, is_line: bool) -> void:
	var root: Node2D = _spawn(scene)
	var fx = _driver_of(root)
	_place(root, fx)
	if is_line:
		fx.set_line(CANVAS_CENTER + line_from, CANVAS_CENTER + line_to)
	else:
		fx.set_center(CANVAS_CENTER)
	fx.play()

## 摆放：把特效的「中心」对到本节点的位置。
##   画布类（驱动在 ColorRect 上）—— 整块画布缩到 fx_scale 后居中到本节点，
##   这样 shader 里 (0.5,0.5) 正好落在节点位置，斩击长度 / 炸开半径也跟着缩。
##   粒子类（驱动就是根节点）—— 根节点的位置本身就是效果中心，直接放过去。
func _place(root: Node2D, fx) -> void:
	root.scale = Vector2(fx_scale, fx_scale)
	if fx == root:
		root.position = global_position
	else:
		root.position = global_position - get_viewport_rect().size * fx_scale * 0.5

## 实例化 → 跳过预览用的自动播放 → 接好 finished（播完自动回收整棵特效节点）
func _spawn(scene: PackedScene) -> Node2D:
	var root: Node2D = scene.instantiate()
	add_child(root)
	var fx = _driver_of(root)
	fx.auto_play = false
	fx.loop_preview = false
	_pending += 1
	fx.finished.connect(_on_fx_finished.bind(root))
	return root

func _driver_of(root: Node2D):
	if root.has_method("play"):
		return root
	return root.get_node("ColorRect")

func _on_fx_finished(root: Node2D) -> void:
	_pending -= 1
	root.queue_free()
