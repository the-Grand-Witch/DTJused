extends Node
## 受击演出：白闪 → 伤害数字 → **命中那一下才真正扣血** → 血条与命中特效同步滑动。
## ==================================================================
## 普通怪（battle.tscn 的 Monster）与 Boss（boss.tscn 的 Boss/Enemy）各挂一份，
## 节点由各自的管理器在 setup() 里交进来（Monster/Nomel、Boss/Enemy 的 boss_battle）；
## 血量口径不在这里，扣血通过 apply 回调交回各自管理器。
##
## 战斗流程用 await 等它：整段演出播完，回合才继续（回合结束到下一回合之间是冻住的）。
## ⚠️ 必须设 flash 节点上那个 hit_flash 脚本的 auto_play = false / loop_preview = false，
##    否则一进战斗就会自己闪、而且循环。
## ==================================================================

var flash: CanvasItem                     ## 挂了 hit_flash 材质的立绘（立绘是 TextureRect 也可以）
var health_bar: Range                     ## 血条
var number_label: Label                   ## 伤害数字
var attack_fx: Node2D                     ## 命中特效宿主（enemy_attack_fx.gd）

@export_group("节奏")
@export var hit_delay := 0.12             ## 起手到命中（白闪刷亮之后）的间隔
@export var bar_time := 0.25              ## 血条补间用时
@export var number_rise := 90.0           ## 伤害数字上浮距离
@export var number_time := 0.55           ## 伤害数字停留 + 淡出用时

var _number_home := Vector2.ZERO
## 血条补间有没有跑完（见 play() 里的收尾 —— 两段演出并行，必须靠它判断该不该 await）
var _bar_done := false

## 由普通怪 / Boss 的管理器在 setup() 时接线。
func setup(p_flash: CanvasItem, p_bar: Range, p_label: Label, p_fx: Node2D) -> void:
	flash = p_flash
	health_bar = p_bar
	number_label = p_label
	attack_fx = p_fx
	_number_home = number_label.position
	number_label.visible = false

## 播一次受击演出。apply 在命中那一下调用（真正扣血）；hits 是本次结算的命中打点。
func play(damage: int, hits: Array, apply: Callable) -> void:
	var before: float = health_bar.value
	# 没伤害就什么都不播：不闪、不冒数字（例如这回合只打了护甲 / 回血 / 被护甲全挡住）
	if damage > 0:
		flash.play()
		_show_number(damage)

	await get_tree().create_timer(hit_delay).timeout
	# 命中这一下才真正扣血。
	# ⚠️ 各管理器的 take_damage 会**顺手把血条写成新值**（monster.gd / enemy_ui.gd），
	#    所以这里**同一帧内**再把血条拨回旧值、交给补间滑过去：中间没有 await，
	#    画面永远看不到「先掉一下再跳回来」，否则血条会蹦迪（瞬间掉 → 回弹 → 再滑）。
	apply.call()
	var after: float = health_bar.value
	if is_equal_approx(before, after):
		await attack_fx.play_hits(hits)
		return
	health_bar.value = before

	# 血条与命中特效**同时**走：血条在挨打那一下就开始掉，不再等特效播完才补间。
	# ⚠️ 两段用时谁长不一定（特效按命中数逐个播，常常比 bar_time 久），所以用 `_bar_done` 收尾：
	#    **绝不能**在补间已经跑完之后再去 `await tween.finished` —— 那时信号已经发过了，
	#    这一等就永远等不到，`battle_main` 的 await 会跟着永久挂住（表现为「打出攻击后回合冻住」）。
	_bar_done = false
	var tween := create_tween()
	tween.tween_property(health_bar, "value", after, bar_time)
	tween.finished.connect(_on_bar_tween_done)
	await attack_fx.play_hits(hits)
	if not _bar_done:
		await tween.finished

func _on_bar_tween_done() -> void:
	_bar_done = true

func _show_number(damage: int) -> void:
	number_label.text = "-%d" % damage
	number_label.position = _number_home
	number_label.modulate.a = 1.0
	number_label.visible = true
	var tween := create_tween().set_parallel(true)
	tween.tween_property(number_label, "position:y", _number_home.y - number_rise, number_time)
	tween.tween_property(number_label, "modulate:a", 0.0, number_time)
	tween.chain().tween_callback(_hide_number)

func _hide_number() -> void:
	number_label.visible = false
