extends Node
## 战斗数值计算（玩家侧的编排）
## ==================================================================
## 分工：
##   GlobalStats  —— 纯函数公式（倍率、加算）
##   BattleFlow   —— 阵营无关的流程（页脚本、关键词、快照、结算汇总、context）
##   本文件       —— 玩家这一侧的编排：三阶段顺序、冲动/钩子广播、清理与冷却
##
## ⚠️ 玩家一次结算会打多张书签，`heal_count` 要**跨书签累加**给下一回合，
##    所以这里没有直接用 BattleFlow.resolve_bookmark（那个会重置 heal_count）。
## ==================================================================

@onready var battle_state: PlayerState = $"../BattleState"

func calculate_player_effects(cards: Array[BookmarkCard], battle_state: BattleState, player_ui, enemy_witch_power: int) -> Dictionary:
	# ========== 编入 → 使用 → 结束 → 回合结束关键词（与镜像共用，见 BattleFlow.run_use_phase） ==========
	var played_indices = BattleFlow.run_use_phase(cards, battle_state, enemy_witch_power)

	# 结算范围 = 本次选中的书签 + 被 retrigger 拉进来的别的书签
	# （`汐信-W1` 会在回合结束时把「上一张被打出的页」再打一次，那张页可能属于别的书签）
	var aggregate_cards: Array[BookmarkCard] = cards.duplicate()
	for touched in battle_state.touched_cards:
		if touched not in aggregate_cards:
			aggregate_cards.append(touched)

	# ========== 结算（阵营无关的公式，side = 玩家本场战斗的 state） ==========
	var result = BattleFlow.aggregate(aggregate_cards, battle_state, enemy_witch_power, battle_state)
	result["played_indices"] = played_indices
	# 本次结算的命中打点（每次真正打出各一条），命中特效按这个逐个播；回合开始才清。
	result["hits"] = battle_state.hit_log.duplicate()

	# 怪物页（吼叫 / 硬骨）的跨阵营效果只作用这一次玩家结算
	# ⚠️ 它们是野怪**预告意图那一刻**就挂上的（不是野怪出牌那一刻），
	#    所以这里清掉正好卡在「玩家这次行动」的边界上，不会拖到下一回合。
	battle_state.clear_monster_debuffs()

	# 本书签本场被打出过几次（振鸣读它）
	for card in aggregate_cards:
		card.battle_play_count += 1

	# ========== 被动钩子：本次行动实际打出的伤害 ==========
	# 放在结算之后广播，保证拿到的是乘完所有倍率的最终值。
	if result.damage > 0:
		battle_state.notify_damage_dealt(result.damage)

	# ========== 清理 ==========
	for card in aggregate_cards:
		for idx in range(card.Generator_bookmark.pages.size()):
			BattleFlow.clear_marks(card, idx)

	# 只有本次选中的书签才走冷却（没选的书签 cd 不动）
	for card in cards:
		card.set_selected(false)
		card.start_cooldown()

	player_ui.refresh_impulse_visual(cards, battle_state)
	printf(result)
	return result

# ==================== 其他 ====================
func calculate_monster_attack(monster_attack: int, player_armor: int) -> Dictionary:
	var actual_damage = max(monster_attack - player_armor, 0)
	return {"damage_dealt": actual_damage}

# ==================== 调试 ====================
func printf(result: Dictionary) -> void:
	if not DebugOutput.enabled():
		return
	DebugOutput.say("========== [Calc] ==========")
	for key in result:
		DebugOutput.say("  %s = %s" % [key, result[key]])
	DebugOutput.say("============================")
