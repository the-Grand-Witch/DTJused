extends RefCounted
class_name DebugOutput
## 调试输出总闸（开发规范 §调试输出）。
##
## 用法：
##   DebugOutput.say("一行文本")          # 只在 DEBUG 构建里打
##   if not DebugOutput.enabled(): return # 整段调试逻辑的入口守卫（release 里连字符串都不拼）
##
## 判定：
##   · 编辑器 / `--headless` 跑 ⇒ `OS.is_debug_build()` 为 true ⇒ 打
##   · 导出 release 包 ⇒ 为 false ⇒ **一行都不打**
##   · 想临时全静音（录屏、给别人演示）把 FORCE_SILENT 改 true
##
## ⚠️ 这里唯一的 `print` 是全项目允许的：其余脚本一律 `DebugOutput.say(...)`，
##    所以「Core 里还有几处 print」用一条 grep 就能对着文档核对。
const FORCE_SILENT := false

static func enabled() -> bool:
	return not FORCE_SILENT and OS.is_debug_build()

## 一行调试输出。文本里的 `[标签]` 前缀沿用各脚本原有写法，便于控制台里筛。
static func say(text: String) -> void:
	if enabled():
		print(text)
