extends Node
## 全局随机（autoload 名：GlobalRng）
## ==================================================================
## 目的：**影响资源的随机**全部走同一个种子 ⇒ 同一颗种子跑出同一局
##（可复盘、可复现、可分享种子、方便定位"这一局为什么这样"）。
##
## 分界线（重要 ✗ 别越界）：
##   · **进种子**：怪物选择 / 怪物掉落内容与金币 / 事件奖励与次数 / 商店货架 / 事件三选一
##   · **不进种子**：纯表演性随机（命中特效抽到白斩还是白爆、粒子抖动等）
##     ⇒ 这些继续用全局 `randi()`，**不要**接进来 ✓（否则同一发攻击重放会变形）
##
## 用法：
##   GlobalRng.range(5, 7)        # 等价 randi_range，但走种子
##   GlobalRng.chance(0.3)        # 30% 概率命中
##   GlobalRng.pick(array)        # 随机取一个元素
##   GlobalRng.shuffle(array)     # 原地洗牌（返回同一个数组）
##   GlobalRng.reseed()           # 开新局时调用；不传参数会自动生成一颗新种子
## ==================================================================

## 换种子时广播（存档 / 回放 / UI 显示种子都靠它）
signal seed_changed(seed_value: int)

var run_seed: int = 0
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	# 先起一颗初始种子；真正的"开新局"由流程层再调一次 reseed()
	reseed(randi())

## 开新局：换种子。不传 / 传 0 就自动生成一颗。
func reseed(new_seed: int = 0) -> void:
	run_seed = new_seed if new_seed != 0 else randi()
	_rng.seed = run_seed
	seed_changed.emit(run_seed)
	DebugOutput.say("[GlobalRng] 本局种子 = %d" % run_seed)

## 整数区间（含两端），等价 randi_range
func range(from: int, to: int) -> int:
	return _rng.randi_range(from, to)

## 概率判定
func chance(probability: float) -> bool:
	return _rng.randf() < probability

## 随机取一个元素（数组不能为空）
func pick(array: Array):
	return array[_rng.randi_range(0, array.size() - 1)]

## 原地洗牌（Fisher–Yates）
func shuffle(array: Array) -> Array:
	for i in range(array.size() - 1, 0, -1):
		var j := _rng.randi_range(0, i)
		var tmp = array[i]
		array[i] = array[j]
		array[j] = tmp
	return array

## 0~1 浮点（等价 randf()，但走种子）
func rand_float() -> float:
	return _rng.randf()
