extends Node
## 全局音效管理器（autoload 名：GlobalAudio）
## ==================================================================
## 用法：任何地方 `GlobalAudio.play("鼠标点击")` —— 键名 = **文件名（不含扩展名）**。
##   · 实战素材放 `Assets/Audio/work/`（本文件只扫这里）
##   · `Assets/Audio/1/` 是**素材材料库**（原 .m4a 那批），不参与加载，留着备查
##   · 只认 Godot 能导入的格式：.ogg / .mp3 / .wav（.m4a 引擎不支持）
##     ⚠️ 新丢进来的文件要等编辑器扫一遍生成 .import 才能播（FileSystem 里能看到就行）
##   · 音量走 **Master 总线** —— 设置界面那个滑条（Core/setting/settings.gd）控的就是它
##   · 多声并发用播放器池轮流用，互相不打断
##
## 已接的全局绑定（都在本文件里，不用各处埋点）：
##   ① 鼠标点击 —— 任何 BaseButton 一进场景就自动接上 pressed（含运行时动态生成的按钮）
##   ② 金币     —— 每帧比对 GlobalPlayer.gold，涨了就播
##   ③ 购买     —— 同上，跌了就播（商店/事件扣钱都覆盖）
##   ⚠️ ②③ 比的是「帧间变化」，所以**金币被初始化**的那些地方（开局发初始金币 / reset 清零）
##      必须顺手调一次 `sync_gold()` 把基准掰过去，否则初始金币会白响一声。
## ==================================================================

const AUDIO_DIR := "res://Assets/Audio/work/"
const POOL_SIZE := 8
const SUPPORTED := ["ogg", "mp3", "wav"]

## 三个绑定的键名（= Assets/Audio/work/ 下的文件名）
## 金币音效的最小增幅：一次入账达到这个数才播
const GOLD_SFX_MIN := 20

const SFX_CLICK := "鼠标点击"
const SFX_GOLD_UP := "金币"
const SFX_PURCHASE := "购买"

## 键名 → AudioStream（只装得进来的）
var _streams: Dictionary = {}
var _players: Array[AudioStreamPlayer] = []
var _next := 0
## 已经警告过的键名，避免每次调用都刷一条日志
var _warned: Dictionary = {}
## 上一帧的金币数（②③ 靠它比对）
var _last_gold := 0

func _ready() -> void:
	_scan()
	for i in POOL_SIZE:
		var player := AudioStreamPlayer.new()
		player.bus = &"Master"
		add_child(player)
		_players.append(player)
	# ① 全局按钮点击音：所有按钮（含运行时生成的）自动接上
	get_tree().node_added.connect(_on_node_added)
	_last_gold = GlobalPlayer.gold
	DebugOutput.say("[GlobalAudio] 可用音效 %d 个：%s" % [_streams.size(), ", ".join(_streams.keys())])

## ②③ 金币/购买：每帧比对一次，商店、奖励、事件所有入口都覆盖，不用各处埋点
func _process(_delta: float) -> void:
	var gold: int = GlobalPlayer.gold
	if gold == _last_gold:
		return
	# 小幅入账不播（否则每个格子 +3 都会响，吵死人）；一次 20 以上才播
	if gold > _last_gold:
		if gold - _last_gold >= GOLD_SFX_MIN:
			play(SFX_GOLD_UP)
	else:
		play(SFX_PURCHASE)
	_last_gold = gold

## 播一个音效。key = 文件名（不含扩展名），例如 play("鼠标点击")。
## volume_db 用来临时压某一发（默认 0 = 原始音量）。
func play(key: String, volume_db := 0.0) -> void:
	if not _streams.has(key):
		if not _warned.has(key):
			_warned[key] = true
			push_warning("[GlobalAudio] 没有这个音效：%s（看看 Assets/Audio/work/ 里有没有 %s.ogg|.mp3|.wav）" % [key, key])
		return
	var player := _players[_next]
	_next = (_next + 1) % POOL_SIZE
	player.stream = _streams[key]
	player.volume_db = volume_db
	player.play()

## 有没有这个音效（给「有就播、没有就算了」的场合用）
## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func has_sfx(key: String) -> bool:
	return _streams.has(key)

## 金币基准复位：**只在「金币被初始化」的场合调用**（开局 set_character 发初始金币 / reset 清零）。
## 那两处不是玩家挣到或花掉的钱，不该响音效 —— 不调这个的话，
## `starting_gold`（50）会被当成一次入账而开局就响一声「金币」，重开时的清零还会响「购买」。
func sync_gold() -> void:
	_last_gold = GlobalPlayer.gold

func _on_node_added(node: Node) -> void:
	if node is BaseButton and not node.pressed.is_connected(_on_any_button_pressed):
		node.pressed.connect(_on_any_button_pressed)

func _on_any_button_pressed() -> void:
	play(SFX_CLICK)

## 扫目录建表：文件名（去扩展名）当键，不支持的格式直接跳过
func _scan() -> void:
	for file in ResourceLoader.list_directory(AUDIO_DIR):
		if file.get_extension().to_lower() not in SUPPORTED:
			continue
		_streams[file.get_basename()] = load(AUDIO_DIR + file)
