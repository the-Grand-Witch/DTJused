@tool
extends Resource
class_name Generator_monster
#声明
enum MonsterType {
	normal,
	elite,
	boss,
	}
#分组
@export_group("怪物配置")
@export var monster_type: MonsterType = MonsterType.normal
@export var display_name: String = ""     
@export var monster_id: int  	
## 强化个体（红色滤镜版本）：血量+30 / 攻击力+1，由 `monster.gd` 的强化池随机出现
@export var elite_variant: bool = false
@export var icon_textrue:Texture2D 
## 立绘滤镜：白 = 原色；红色版本用带红的 modulate 做「强化个体」区分（不需要另画资源）
@export var icon_modulate: Color = Color(1, 1, 1, 1)
@export_group("怪物数值")     
@export var health: int = 0                           
@export var attack: int = 0
@export_group("精英怪物增益")
@export var enable_elite_bonus: bool = false
@export var elite_attack_interval: int = 3   
@export var elite_attack_bonus_multiplier: float = 2
@export var elite_attack_witchpower_bonus: int = 5
@export_group("头目怪物增益")
@export var enable_boss_bonus: bool = false
@export var boss_attack_interval: int = 2
@export var boss_attack_bonus_multiplier: float = 2
@export var boss_attack_witchpower_bonus: int = 7
@export_group("掉落")
@export var fixed_drop_id: int = -1          # 固定掉落道具 ID，-1 表示不使用
@export var accessories_id_min: int = 0       # 随机掉落道具 ID 范围下限（包含）
@export var accessories_id_max: int = 0         # 随机掉落道具 ID 范围上限（包含）
@export var random_drop_count: int = 1             
@export var min_gold: int = 0                # 金币掉落
@export var max_gold: int = 0   

@export_group("手牌")
## 这个敌人的书签循环：**数组顺序就是出牌顺序**，打完最后一个回到第 0 个。
##   龙：1→2→1→2      ⇒ [龙1, 龙2]
##   牛：3→1→2→3→1→2  ⇒ [牛3, 牛1, 牛2]
## 书签本身在 `Data/bookmark/monster_*.tres`，页在 `Data/bookpage/monster/`。
@export var bookmark_cycle: Array[Generator_bookmark] = []
