# 怪物专用书页（monster）

这个目录放**只有敌人能用**的特殊书页：野怪与镜像 Boss 手牌里的那几张。

## 规则（改动前务必读完）

| 事项 | 规定 |
|---|---|
| 目录 | `Data/bookpage/monster/`（英文小写，**资源路径里不出现中文**） |
| 是否进 `cards` | **是** —— 由 `GlobalCardLibrary._load_all_cards()` 扫进 `cards`，否则 `book_id` 索引不到、书签引用会变成空 |
| 是否进 `drop_pool` | **绝对不行** —— 玩家不该从商店/奖励/事件里抽到怪物的页 |
| 取用入口 | `GlobalCardLibrary.get_monster_pool()` / `get_monster_pages([book_id, ...])` |
| `book_id` 段 | **2001 起**（玩家页已用 1–5 / 11–13 / 201–212 / 221–232 / 301–312 / 321–332 / 1001–1003） |
| 改动后 | 重开游戏（`_load_all_cards()` 只在启动时跑一次），或调 `GlobalCardLibrary._load_all_cards()` |

## 书页字段（`Data/bookpage/Generator_bookpage.gd`）

- `book_id` —— 唯一标识，按上面的段位取号
- `page_name` / `code` —— 显示名 / 编号（编号**不上卡面**，只在悬浮提示里）
- `cd` —— 冷却回合数
- `damage` / `armor` / `healing` / `witchpower` / `count` —— 基础效果（卡面会显示）
- `effect_damage` / `effect_armor` / `effect_healing` / `effect_witchpower` / `effect_count` / `effect_play_count` —— 特效数值
- `page_type` —— **决定数值走哪条通道**（`Attack=1 / Defense=2 / Ability=3 / Heal=4 / Witch=5`）。
  ⚠️ 只有 `Attack` 才吃伤害、`Defense` 才吃护甲、`Heal` 才吃回血（见 `BattleFlow.aggregate`）——
  想让它回血就必须把 `Heal` 放进 `page_type`，光填 `healing` 是不生效的。
- `keywords` —— 关键词 id（`PX` / `XX` / `YS` / `ZM`，中文显示名见 `GlobalKeywordDict.KEYWORD_NAMES`）；
  怪物页建议留空，效果用 `page_effects` 脚本或 `keyword_ops` 写
- `icon` —— 卡图占位（卡面本身走 `PageFace` 的关键词底板，不看这个字段）

## 配套的书签与循环

怪物的手牌是「书签」，放在 `Data/bookmark/`；**出牌顺序**写在怪物资源的
`bookmark_cycle` 里（数组顺序 = 出牌顺序，打完最后一个回到第 0 个）。

| 怪物 | 循环 | 书签内容 |
|---|---|---|
| 诺亚的龙（id 3） | `1 → 2 → 1 → 2` | 龙1：攻击力4 ×3 + 攻击力5 ×2<br>龙2：防御力5 ×3 + 蓄力1 + 吼叫 |
| 诺亚的牛（id 2） | `3 → 1 → 2 → 3 → 1 → 2` | 牛1：攻击力5 ×3 + 防御力4 ×2<br>牛2：硬骨 + 攻击力5 ×4（意图「伤害24 · 硬骨」）<br>牛3：防御力5 ×5（意图「防御25」） |

⚠️ 意图里的「伤害」= **每张攻击页 = 怪物基础攻击力 + 页伤害**，所以基础攻击力一变，三本书签的意图数字全变。
当前：牛 `attack = 1`（红牛 `attack = 2`）、龙 `attack = 0`（红龙 `attack = 1`）。

```
Data/bookmark/
├─ monster_long_1.tres   （诺亚的龙 1）
├─ monster_long_2.tres   （诺亚的龙 2）
├─ monster_niu_1.tres    （诺亚的牛 1）
├─ monster_niu_2.tres    （诺亚的牛 2）
└─ monster_niu_3.tres    （诺亚的牛 3）
```

## 效果的生效时机（硬骨 / 吼叫 / 防御页）

野怪的回合在玩家行动**之后**，所以它这回合的书签不能等出牌时才生效，否则一切都会晚一回合
（意图标签那时已经换成下一本）。现在的规则是「**这回合的书签这回合生效**」：

| 书签内容 | 生效时机 | 代码位置 |
|---|---|---|
| 硬骨 / 吼叫（写在玩家身上的跨阵营效果） | 回合开始、显示意图那一刻挂上；玩家这次行动结算完清掉 | `on_intent` + `wild_monster._apply_intent_effects()` |
| 防御页给的护甲 | 回合开始就按这本书签挂好（护甲一次性，不跨回合累积） | `wild_monster.on_round_start()` → `enemy_state.armor_count` |
| 攻击页的伤害 | 回合末野怪出牌时结算（玩家有整回合时间堆护甲） | `enemy_controller.take_turn()` |

```
回合 N 开始 ─── 选书签 + 显示意图 + 挂护甲(防御页) + 挂硬骨/吼叫
   │
回合 N 玩家行动 ─ 打的是「这回合预告的护甲」，硬骨/吼叫同样这回合生效
   │
回合 N 末 ───── 野怪出牌：只结算伤害/回复（护甲已提前挂好，不再重复加）
```

⚠️ 为什么不能等出牌再挂：野怪的回合在玩家行动**之后**，那时玩家这次行动已经结算完了，
效果只能落到下一回合；而下一回合意图标签已经换成另一张书签，玩家看到的就是
「预告硬骨那回合我的页照打、下一回合才作废」——像是意图和实际出的牌对不上。

对应实现在 `enemy_controller.armor_applied_at_intent()`（野怪 true、镜像 Boss false）。

## 战斗界面上的意图显示（`Core/battle/wild_monster.gd`）

| 元素 | 内容 | 节点 |
|---|---|---|
| 意图主行 | `伤害20 · 硬骨` / `防御25` / `防御15 · 蓄力1 · 吼叫` | `Monster/MonsterDamageLabel`（场景里手摆） |
| 意图说明 | 一行一条：`伤害 20 · 回合末打在你身上` / `本回合护甲 25 · 你的攻击先打在护甲上` / `硬骨 · 本回合你最终伤害 ≤5 的攻击页整页无效` | `Monster/MonsterIntentDescLabel`（运行时生成，跟主行走） |
| 护甲数字 | 血条右边 `护甲 N`，没有护甲时隐藏 | `Monster/MonsterArmorLabel`（运行时生成） |

特殊页的说明文案在 `wild_monster.gd` 的 `SPECIAL_PAGE_DESC` 里，按书页 `code`（`M-S1/M-S2/M-C1/M-C2`）查表；
没登记的特殊页会退回 `页名 · 页描述`。新增特殊页时记得在表里补一行。

## 回合结算日志（`DebugOutput.enabled()` 为真时打；导出 release 自动关）

每回合结束固定打四块，逐项可以对上：

```
──────── [PLAYER] 回合 N 结算 ────────      玩家状态：血/魔女化/饰品/乘数明细/关键词触发
──────── [玩家行动] X 张书签 ────────       每张书签每一页：卡面 X → 实际 Y
  [3] 防御｜卡面 护甲5 → 实际 护甲5  ⚠️ 吼叫 → 整页作废（算式给的是 护甲5，不计入）
  合计：伤害… ｜护甲… ｜回血… ｜魔女化… ｜攻击加算…
──────── [野怪] 名字  血/护甲/攻击力 ────────  意图行 / 本回合打出 / 宣告伤害→玩家护甲→实际掉血 / 获得护甲 / 蓄力
──────── [对账] 回合 N ────────             玩家伤害→敌人护甲吸收→敌人掉血；玩家护甲/掉血；双方血量
```

作废原因由 `BattleState.voided_pages` 记录（`硬骨` / `吼叫`），在 `BattleFlow.aggregate()` 里写；
页面的「实际」值来自 `BattleState.resolved_pages`（`note_resolved` / `note_resolved_ability`），是**过完所有乘区**的数。

判定口径：硬骨作废**最终伤害 ≤ 5**的攻击页（5 点也作废，6 点起照常打），
且是整页无效（该页的护甲/回复/特效一并失效），见 `BattleFlow.aggregate()`。

⚠️ `bookmark_cycle` 由 `Core/battle/wild_monster.gd` 消费：数组顺序 = 每回合出牌顺序，循环。
