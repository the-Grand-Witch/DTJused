@tool
extends Resource
class_name Generator_bookpage

enum PickupType {
	Attack = 1,
	Defense = 2,
	Ability = 3,
	Heal = 4,
	Witch = 5,
	friend = 10,
}

@export_group("书页配置")
@export var book_id : int
## 编号（如 `谱序-A1`）。**这是数据侧的唯一标识**：绑定图标、脚本按编号找页、卡表都认它。
@export var code : String = ""
## 显示名（卡名）。名字还没定的时候可以留空 —— UI 会退回显示 `code`。
@export var page_name : String = "未命名卡牌"
@export var icon : Texture2D
@export var description : String = ""
@export var cd : int

@export_group("书页效果")
@export var damage : int = 0
@export var healing : int = 0
@export var armor : int = 0
@export var witchpower : int = 0
@export var count : int = 0
@export var page_effects: Array[Script] = []

@export_group("特效数值")
@export var effect_damage : int = 0
@export var effect_healing : int = 0
@export var effect_armor : int = 0
@export var effect_witchpower : int = 0
@export var effect_count : int = 0
## 额外使用次数：本页在被选中后于「使用」阶段额外多打几次。
## 总次数 = 1 + effect_play_count + 书页脚本用 add_play_count / add_of("play_count", n) 追加的值。
@export var effect_play_count : int = 0

@export_group("打击特效")
## 这张页命中敌人时的**卡牌额外特效**（播放型场景：有 play() 与 finished 信号）。
## 与「按伤害判定的档位特效」叠加播放，不是替换；留空就只播档位特效。
## 档位：轻（伤害 ≤9）/ 中（≥10），判定与素材见 Core/battle/enemy_attack_fx.gd。
@export var hit_effect : PackedScene

@export_group("稀有度")
@export var rarity : int = 0
@export var price : int = 0

@export_group("buff 配置")
@export var buff_icon : Texture2D


@export_group("关键词")
@export var keywords: Array[StringName] = []

@export_group("关键词声明")
## 关键词的「条件 → 效果」声明，由 GlobalKeywordDict 的声明式执行器读（谱序 / 汐信 / 振鸣）。
## 每项：{ "keyword": &"PX", "when": "left_is_attack", "then": { "add": {"damage": 4} } }
##   · when —— 表达式，变量表见 BattleFlow.keyword_vars()；留空 = 无条件
##   · then —— 数值写字符串就是表达式，写数字就是字面量
## 详细格式与 48 张的写法见 卡牌设计稿.md §八.11。
@export var keyword_ops: Array[Dictionary] = []

@export_group("书页归类")
@export var page_type: Array[PickupType] = []
