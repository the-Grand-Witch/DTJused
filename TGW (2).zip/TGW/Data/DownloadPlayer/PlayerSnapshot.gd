@tool
extends Resource
class_name PlayerSnapshot

enum SnapshotType {
	PLAYER_MIRROR,      # 普通玩家上传镜像
	SPECIAL_CHARACTER   # 开发者设计特殊人物
}

@export var snapshot_id: String = ""
@export var player_name: String = "未知玩家"
## 这个镜像是哪个角色（`hanna` / `meruru` / `aima` / `xueli`）。
## 威胁值会按角色做特赦（见 GlobalThreat.CHARACTER_THREAT_ADJUST）；空字符串 = 不做特赦。
@export var character_id: String = ""
## 角色「先天技能」（`Generator_girl.passive`，如艾玛的 kill_witch / 雪莉的心衰）。
## 镜像现在也会吃这份被动；留空 = 该角色没有先天技能。
@export var character_passive: Generator_PassiveEffect
@export var max_health: int = 200
@export var current_health: int = 200
@export var witch_power: int = 0
@export var max_witch_power: int = 100
@export var bookmarks: Array[Generator_bookmark] = []
@export var accessories: Array[Generator_accessories] = []
@export var base_attack: int = 10
@export var portrait: Texture2D
## 魔女化后的立绘（同一张图预先烘好的紫色版本）。留空则不换图。
@export var portrait_transformed: Texture2D

# 类型选择器：决定该快照是普通玩家镜像还是特殊人物
@export var snapshot_type: SnapshotType = SnapshotType.PLAYER_MIRROR

# 特殊角色表现（仅 SPECIAL_CHARACTER 时使用）
@export_group("特殊角色表现")

@export_multiline var dialogue_intro: String = ""      # 入场时
@export_multiline var dialogue_attack: String = ""     # 攻击时
@export_multiline var dialogue_damaged: String = ""    # 受到大量伤害后
@export_multiline var dialogue_powerup: String = ""    # 强化时（形态改变或彼岸之赐触发）
@export_multiline var dialogue_idle: String = ""       # 闲聊/随机待机
