@tool
extends Resource
class_name Generator_girl

@export_group("角色信息")
@export var character_id: String = ""
@export var character_name: String = "未命名角色"
## 未解锁（还没做完的角色）：选人界面**仍然显示**（头像灰掉 + 不可选中），
## 只是不能被选来开局。做完之后把它改回 false 即可。
@export var hidden: bool = false
@export var portrait: Texture2D
## 立绘（全身站立画）：角色选择 / 结算这类要放大的场合用；portrait 是头像（大头）
@export var full_body: Texture2D
@export_multiline var description: String = ""
## 角色介绍：选人界面顶部那格的文案（口味/人物设定）。
## ⚠️ 这不是技能 —— 技能文本在 `description` 里，格式「技能名：技能说明」（见 choose.gd 的 _fill_info）。
## 留空则选人界面顶部那一行自动隐藏。
@export_multiline var flavor: String = ""

@export_group("基础数值")
@export var base_max_health: int = 200
@export var base_max_witch_power: int = 100
@export var witch_power: int = 0
## 开局金币：reset() 清零后由 set_character() 按角色写入
@export var starting_gold: int = 50

@export_group("被动效果")
@export var passive: Generator_PassiveEffect

@export_group("独特饰品")
@export var unique_accessories: Generator_accessories

@export_group("起始书签")
@export var starting_bookmarks: Array[Generator_bookmark] = []

@export_group("本局掉落池")
@export var pool_keywords: Array[String] = []
