@tool
extends Resource
class_name Generator_PassiveEffect

## ==================================================================
## 被动的持有者（owner）
## ==================================================================
## 战斗开始时由持有者调用 set_battle_owner() 注入，之后被动脚本**一律通过 owner 取数**，
## 不要再读 GlobalPlayer / GlobalPassive / GlobalAccessories 这些全局单例。
##
## 这么做有两个目的：
##   1. 同一个被动脚本既能服务玩家、也能服务镜像，不需要为镜像另写一份；
##   2. 算式与被动变成「纯函数 + 显式入参」，不会因为某处偷偷读全局而出现静默算错。
##
## owner 需要提供的读口（见 Core/battle/battle_state.gd）：
##   get_health() / get_max_health() / get_witch_power() / get_max_witch_power()
##   get_accessories() / collect_passives() / get_ability_multiplier()
##   具名战斗态：get_passive_value(key, default) / set_passive_value(key, value)
## ==================================================================
var battle_owner: Node = null

func set_battle_owner(owner_node: Node) -> void:
	battle_owner = owner_node

## 取当前魔女化（无 owner 时退化为 0，避免报错）
func owner_witch_power() -> int:
	if battle_owner == null:
		return 0
	if battle_owner.has_method("get_witch_power"):
		return int(battle_owner.get_witch_power())
	return 0

## 取魔女化上限（含饰品加成）
func owner_max_witch_power() -> int:
	if battle_owner == null:
		return 0
	if battle_owner.has_method("get_max_witch_power"):
		return int(battle_owner.get_max_witch_power())
	return 0

## 读写「具名战斗态」。
## 被动脚本不要把这些值存在自己实例上 —— 实例挂在全局管理器上，玩家与镜像会共用同一份。
func owner_get_value(key: String, default_value = 0):
	if battle_owner == null:
		return default_value
	if battle_owner.has_method("get_passive_value"):
		return battle_owner.get_passive_value(key, default_value)
	return default_value

func owner_set_value(key: String, value) -> void:
	if battle_owner != null and battle_owner.has_method("set_passive_value"):
		battle_owner.set_passive_value(key, value)

# 数值修改型
## 以下 modify_*_multiplier 的返回值都是**乘数**，基准 1.0：
##   1.0 = 不变，< 1.0 = 削弱，> 1.0 = 增强。多个被动之间是累乘。
## 不想改就直接不覆写（基类默认返回 1.0），GlobalStats 会用 has_method 安全取值。
## 取数路径统一在 Core/battle/GlobalStats.gd，不要各自写求和/求积。
func modify_gold_gain(value: int) -> int:
	return value
func modify_damage_multiplier(enemy_witch_power: int) -> float:
	return 1.0
func modify_armor_multiplier() -> float:
	return 1.0
func modify_heal_multiplier() -> float:
	return 1.0
func modify_witch_power_multiplier() -> float:
	return 1.0
## 玩家承受伤害的乘数，1.0 表示不减伤
func modify_damage_taken_multiplier() -> float:
	return 1.0
func modify_witch_power_gain(value: int) -> int:
	return value
func modify_max_health(value: int) -> int:
	return value
func modify_armor_per_turn(value: int) -> int:
	return value
func modify_heal_per_turn(value: int) -> int:
	return value
# 事件钩子，基类默认空
func on_battle_start() -> void:
	pass
func on_turn_start(_turn_count: int) -> Array:
	return []
## 每执行完一个格子事件（局外）时触发。默认什么也不做。
func on_event_done() -> void:
	pass

func on_turn_end(_turn_count: int) -> void:
	pass
func on_page_played(_mark: Dictionary) -> void:
	pass
func on_damage_taken(_amount: int) -> void:
	pass
func on_damage_dealt(_amount: int) -> void:
	pass
func on_heal(_amount: int) -> void:
	pass
func on_witch_power_changed(_value: int) -> void:
	pass
func on_time_changed(_units: int) -> void:
	pass
## 预留（暂无调用）：接口先留着，接线或用到时把这行删掉。
func get_description() -> String:
	return ""
func clear_insight() -> void:
	pass

func on_enemy_page_used(_types: Array) -> void:
	pass

func is_page_available(_page: Generator_bookpage) -> bool:
	return true

func is_ability_disabled() -> bool:
	return false

func is_heal_disabled() -> bool:
	return false
