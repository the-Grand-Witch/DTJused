@tool
extends Resource
class_name Generator_event

# 事件类型枚举
enum EventType {
	event,
	BATTLE,
	SHOP,
	REST,
	WALK,
	DIG,
	SPECIAL,
}

# === 基础信息 ===
@export_group("基础信息")
@export var event_id: int
@export var event_type: EventType = EventType.WALK
@export var weight: int = 1   #权重
@export var is_special: bool = false    #启用脚本

# === 显示信息 ===
@export_group("显示信息")
@export var event_name: String = "未命名事件"
@export_multiline var description: String = ""
@export var icon: Texture2D

# === 效果调用 ===
@export_group("效果调用")
@export var effect_script: Script
@export var effect_scene: PackedScene
@export var health_change: int = 0
@export var witch_power_change: int = 0
@export var gold_change: int = 0
@export var time_units: int = 1

# === 特殊标记 ===
@export_group("特殊标记")
## 单个事件的通用下架开关：取消勾选后该事件不进入任何事件池。
## 注意：Boss 事件（100-103）由 manager_event 的夜间封锁单独取用，
## 是否参与白天随机由 manager_event.BOSS_BATTLE_ENABLED 决定，与这里无关。
@export var enabled: bool = true
@export var unique: bool = false
@export var conditions: Array[String] = []
@export_group("场景加载")
@export var is_full_scene: bool = false   # true 表示切换整个场景（如战斗），false 表示作为覆盖层加载（如商店）
# === 选择题 ===
@export_group("选择题")
## 2~5 个选项；每个选项就是一个"迷你事件"：按钮文案吃 event_name，效果吃下面那三个数值字段。
## 配套场景：scenes/event/choice.tscn（选项会被铺成按钮）
@export var choices: Array[Generator_event] = []
## 选项被点掉之后，弹出界面（书页 / 遗物）的标题，例如「她给你的启示」。
## 留空则退回用 event_name。只有选择题的选项会读它。
@export var popup_title: String = ""
# === 动画资源 ===
@export_group("动画资源")
@export var anim_join_frames: SpriteFrames
@export var anim_execute_frames: SpriteFrames
@export var anim_end_frames: SpriteFrames
@export var anim_destroy_frames: SpriteFrames
@export var anim_duration: float = 0.3
