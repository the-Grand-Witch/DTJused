extends Node
## 全局关键词字典：统一管理所有关键词的描述与效果逻辑

# 关键词定义：每个关键词包含描述和效果函数引用
var keyword_dict: Dictionary = {}

func _ready():
	_register_default_keywords()

func _register_default_keywords():
	# 始源：增加卡牌效果，但同一书签内始源越多，效果越弱
	keyword_dict["始源"] = {
		"description": "增加卡牌效果，但同一书签内始源越多，效果越弱",
		"execute": _execute_primordial
	}
	# 维协：每打出一张，下回合获得一层，每有一层强化一张卡牌
	keyword_dict["维协"] = {
		"description": "每打出一张，下回合获得一层，每有一层强化一张卡牌",
		"execute": _execute_harmony
	}
	# 强压：书签中的卡牌越少，效果越强
	keyword_dict["强压"] = {
		"description": "书签中的卡牌越少，效果越强",
		"execute": _execute_pressure
	}
	# 统洁：书签内种类相同，效果增加
	keyword_dict["统洁"] = {
		"description": "书签内种类相同，效果增加",
		"execute": _execute_purity
	}

## 获取关键词描述
func get_keyword_description(keyword_name: StringName) -> String:
	if keyword_dict.has(keyword_name):
		return keyword_dict[keyword_name]["description"]
	return ""

## 执行关键词效果
func execute_keyword(keyword_name: StringName, context) -> Dictionary:
	if keyword_dict.has(keyword_name):
		var func_ref = keyword_dict[keyword_name]["execute"]
		if func_ref is Callable:
			return func_ref.call(context)
	return {}

# ==================== 关键词效果实现（待填充具体逻辑） ====================
func _execute_primordial(context) -> Dictionary:
	# TODO: 实现始源效果
	return {}

func _execute_harmony(context) -> Dictionary:
	# TODO: 实现维协效果
	return {}

func _execute_pressure(context) -> Dictionary:
	# TODO: 实现强压效果
	return {}

func _execute_purity(context) -> Dictionary:
	# TODO: 实现统洁效果
	return {}
