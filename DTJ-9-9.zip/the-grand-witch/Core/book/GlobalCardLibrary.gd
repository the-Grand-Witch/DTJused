extends Node
## 全局卡牌库：管理卡牌定义、获得量与可使用量

const DEFAULT_BOOK_IDS := []   # 默认基础卡牌 ID（仅用于测试，未来可能移除）

var cards: Dictionary = {}               # book_id -> Generator_bookpage
var owned_cards: Dictionary = {}          # book_id -> Generator_bookpage（获得量>0）
var card_acquired_counts: Dictionary = {} # 获得量
var card_usable_counts: Dictionary = {}   # 可使用量

func _ready() -> void:
	_load_all_cards()
	_init_owned_cards()
	# 注意：不再自动设置默认数量，游戏开始时数量为0

func _load_all_cards() -> void:
	cards.clear()
	var files = ResourceLoader.list_directory("res://Data/bookpage/")
	for file_name in files:
		if file_name.ends_with(".tres"):
			var res = load("res://Data/bookpage/" + file_name)
			if res is Generator_bookpage:
				cards[res.book_id] = res

func _init_owned_cards() -> void:
	owned_cards.clear()
	# 初始没有任何卡牌，所以 owned_cards 为空
	# 后续通过 add_acquired_count 添加获得量时，会自动加入 owned_cards

func get_all_cards() -> Array[Generator_bookpage]:
	var arr: Array[Generator_bookpage] = []
	for key in cards.keys():
		arr.append(cards[key])
	arr.sort_custom(func(a, b): return a.book_id < b.book_id)
	return arr

func get_owned_cards() -> Array[Generator_bookpage]:
	var arr: Array[Generator_bookpage] = []
	for key in owned_cards.keys():
		if card_acquired_counts.get(key, 0) > 0:
			arr.append(owned_cards[key])
	arr.sort_custom(func(a, b): return a.book_id < b.book_id)
	return arr

func get_card_by_book_id(id: int) -> Generator_bookpage:
	return cards.get(id)

## 增加卡牌获得量（掉落、购买等）
func add_acquired_count(book_id: int, amount: int = 1) -> void:
	card_acquired_counts[book_id] = card_acquired_counts.get(book_id, 0) + amount
	card_usable_counts[book_id] = card_usable_counts.get(book_id, 0) + amount
	# 如果卡牌定义存在且尚未加入 owned_cards，则加入
	if cards.has(book_id) and not owned_cards.has(book_id):
		owned_cards[book_id] = cards[book_id]

## 仅增加获得量，不增加可使用量（用于初始书签中的卡牌）
func add_acquired_only(book_id: int, amount: int = 1) -> void:
	card_acquired_counts[book_id] = card_acquired_counts.get(book_id, 0) + amount
	if cards.has(book_id) and not owned_cards.has(book_id):
		owned_cards[book_id] = cards[book_id]

## 减少可使用量（添加到书签时调用），返回是否成功
func use_card(book_id: int) -> bool:
	if card_usable_counts.get(book_id, 0) > 0:
		card_usable_counts[book_id] -= 1
		return true
	return false

## 返还可使用量（从书签移除或删除书签时调用）
func return_card(book_id: int, amount: int = 1) -> void:
	card_usable_counts[book_id] = card_usable_counts.get(book_id, 0) + amount

## 获取获得量
func get_acquired_count(book_id: int) -> int:
	return card_acquired_counts.get(book_id, 0)

## 获取可使用量
func get_usable_count(book_id: int) -> int:
	return card_usable_counts.get(book_id, 0)
