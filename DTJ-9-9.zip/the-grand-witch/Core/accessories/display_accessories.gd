extends Control

@onready var accessory_grid: GridContainer = $ScrollContainer/GridContainer

func _ready():
	_refresh_accessory_display()
	GlobalAccessories.accessory_added.connect(_on_accessory_added)

func _refresh_accessory_display():
	for child in accessory_grid.get_children():
		child.queue_free()
	
	for accessory in GlobalAccessories.accessories:
		var icon_rect = AccessoryIcon.new()   # 使用自定义类
		icon_rect.texture = accessory.icon
		icon_rect.custom_minimum_size = Vector2(64, 64)
		icon_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon_rect.mouse_filter = Control.MOUSE_FILTER_STOP
		
		# 设置 Tooltip 文本
		if accessory.Tooltip != "":
			icon_rect.tooltip_text = accessory.Tooltip
		else:
			icon_rect.tooltip_text = accessory.name
		
		# 传递字体大小
		icon_rect.tooltip_font_size = accessory.tooltip_font_size
		
		accessory_grid.add_child(icon_rect)

func _on_accessory_added(accessory: Generator_accessories):
	_refresh_accessory_display()
