extends Node

# 信号：饰品添加
signal accessory_added(accessory: Generator_accessories)
signal accessory_removed(acc_id: int)

# 已获得的饰品数组
var accessories: Array[Generator_accessories] = []

# 添加饰品（自动去重）
func add_accessory(accessory: Generator_accessories) -> void:
	for existing in accessories:
		if existing.acc_id == accessory.acc_id:
			return   # 已拥有，不重复添加
	accessories.append(accessory)
	accessory_added.emit(accessory)

# 判断是否拥有指定 ID 的饰品
func has_accessory(acc_id: int) -> bool:
	for acc in accessories:
		if acc.acc_id == acc_id:
			return true
	return false

# 根据 ID 获取饰品（未拥有则返回 null）
func get_accessory_by_id(acc_id: int) -> Generator_accessories:
	for acc in accessories:
		if acc.acc_id == acc_id:
			return acc
	return null

# 移除饰品（按 ID）
func remove_accessory(acc_id: int) -> void:
	for i in range(accessories.size()):
		if accessories[i].acc_id == acc_id:
			accessories.remove_at(i)
			accessory_removed.emit(acc_id)
			return

func reset() -> void:
	accessories.clear()
	# 发送一个信号，让界面清空饰品显示
	accessory_added.emit(null)   # 或额外定义一个 reset 信号，这里简单处理
