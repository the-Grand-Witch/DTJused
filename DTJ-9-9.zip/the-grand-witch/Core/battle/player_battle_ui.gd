extends Node
## 负责玩家手牌显示和杀人冲动标记

@onready var hand_container = $player_hand_container

var player_impulse_pages: Array[Dictionary] = []

func clear_hand():
	for child in hand_container.get_children():
		child.queue_free()
	player_impulse_pages.clear()

func add_card(card: BookmarkCard):
	hand_container.add_child(card)

# ==================== 冲动 ====================
func clear_impulses():
	for entry in player_impulse_pages:
		var card: BookmarkCard = entry["card"]
		var page_index: int = entry["page_index"]
		var label = card.get_page_label_by_index(page_index)
		if label:
			label.modulate = Color(1, 1, 1)
	player_impulse_pages.clear()

func apply_impulses(cards: Array[BookmarkCard], count: int):
	clear_impulses()
	if count <= 0:
		return

	var attack_pages: Array[Dictionary] = []
	for card in cards:
		for idx in range(card.bookmark_data.pages.size()):
			var page = card.bookmark_data.pages[idx]
			if page.pickup_type == Generator_bookpage.PickupType.Attack:
				attack_pages.append({"card": card, "page_index": idx})

	for i in range(count):
		if attack_pages.is_empty():
			break
		var rand_idx = randi() % attack_pages.size()
		var entry = attack_pages[rand_idx]
		player_impulse_pages.append(entry)
		attack_pages.remove_at(rand_idx)
		var card: BookmarkCard = entry["card"]
		var page_index: int = entry["page_index"]
		var label = card.get_page_label_by_index(page_index)
		if label:
			label.modulate = Color(0.6, 0.2, 1)

func has_impulse(card: BookmarkCard, page_index: int) -> bool:
	for entry in player_impulse_pages:
		if entry["card"] == card and entry["page_index"] == page_index:
			return true
	return false

func consume_impulse(card: BookmarkCard, page_index: int) -> bool:
	for i in range(player_impulse_pages.size()):
		var entry = player_impulse_pages[i]
		if entry["card"] == card and entry["page_index"] == page_index:
			player_impulse_pages.remove_at(i)
			var label = card.get_page_label_by_index(page_index)
			if label:
				label.modulate = Color(1, 1, 1)
			return true
	return false

func punish_unused_impulses():
	if player_impulse_pages.is_empty():
		return
	for entry in player_impulse_pages:
		var card: BookmarkCard = entry["card"]
		GlobalPlayer.possessed(GlobalPlayer.get_impulse_punishment())
		var label = card.get_page_label_by_index(entry["page_index"])
		if label:
			label.modulate = Color(1, 1, 1)
	player_impulse_pages.clear()
