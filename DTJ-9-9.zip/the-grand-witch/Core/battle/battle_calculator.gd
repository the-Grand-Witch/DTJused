extends Node
## 负责伤害、治疗、护甲等数值计算

var player_attack_bonus: int = 0

func calculate_player_effects(cards: Array[BookmarkCard], attack_bonus: int, player_ui) -> Dictionary:
	var result = {"damage": 0, "healing": 0, "armor": 0}
	var accessory_bonus = _get_accessory_attack_bonus()
	var total_attack_bonus = attack_bonus + accessory_bonus

	for card in cards:
		for idx in range(card.bookmark_data.pages.size()):
			var page = card.bookmark_data.pages[idx]
			match page.pickup_type:
				Generator_bookpage.PickupType.Attack:
					var dmg = page.damage + total_attack_bonus
					if player_ui.has_impulse(card, idx):
						var multiplier = GlobalPlayer.get_impulse_damage_multiplier()
						dmg = int(ceil(dmg * multiplier))
						player_ui.consume_impulse(card, idx)
					result.damage += dmg
				Generator_bookpage.PickupType.Heal:
					result.healing += page.healing
				Generator_bookpage.PickupType.Defense:
					result.armor += page.Armor
				Generator_bookpage.PickupType.Ability:
					player_attack_bonus += page.attack_bonus

	for card in cards:
		card.set_selected(false)
		card.start_cooldown()
	return result

func get_player_attack_bonus() -> int:
	return player_attack_bonus

func calculate_monster_attack(monster_attack: int, player_armor: int) -> Dictionary:
	var actual_damage = max(monster_attack - player_armor, 0)
	return {"damage_dealt": actual_damage}

func _get_accessory_attack_bonus() -> int:
	var bonus = 0
	for acc in GlobalAccessories.accessories:
		bonus += acc.attack_bonus
	return bonus
