@tool
extends Resource
class_name Generator_bookpage

enum PickupType {
	Attack = 1,
	Defense = 2,
	Ability = 3,
	Heal = 4
}

# 关键词选项列表
const KEYWORD_OPTIONS: Array[StringName] = ["始源", "维协", "强压", "统洁"]

@export_group("书页配置")
@export var book_id : int
@export var pickup_type : PickupType = PickupType.Attack
@export var page_name : String = "未命名卡牌"
@export var icon : Texture2D
@export var description : String = ""
@export var cd : int

@export_group("书页效果")
@export var damage : int = 0
@export var healing : int = 0
@export var Armor : int = 0
@export var attack_segments : int = 0
@export var attack_bonus : int = 0
@export var strength_power : int = 0


@export_group("稀有度")
@export var rarity : int = 0

@export_group("价格")
@export var override_price : bool = false
@export var price : int = 0

# 能力卡专属 buff 配置
@export_group("buff 配置")
@export var buff_icon : Texture2D
@export var buff_icon_size : Vector2 = Vector2(32, 32)
@export var buff_font_size : int = 10

# 特殊效果组（始终显示）
@export_group("特殊效果")
@export var effect_damage : int = 0
@export var effect_healing : int = 0
@export var effect_Armor : int = 0
@export var effect_attack_segments : int = 0
@export var effect_attack_bonus : int = 0
@export var effect_strength_power : int = 0


@export_group("关键词")
# 关键词数组（隐藏，由复选框控制）
@export var keywords: Array[StringName] = []

var _updating_price := false

func _init():
	if not override_price and price == 0:
		_update_price()

func _get_property_list() -> Array[Dictionary]:
	var properties: Array[Dictionary] = []
	# 为每个关键词生成复选框，归入“关键词”分组
	for kw in KEYWORD_OPTIONS:
		properties.append({
			"name": kw,
			"type": TYPE_BOOL,
			"usage": PROPERTY_USAGE_DEFAULT,
			"group": "关键词",
		})
	return properties

func _set(property: StringName, value):
	if _updating_price:
		return false

	# 处理关键词复选框
	if property in KEYWORD_OPTIONS:
		var is_checked = value as bool
		if is_checked:
			if not keywords.has(property):
				keywords.append(property)
		else:
			keywords.erase(property)
		return true

	# 处理其他属性
	if property == "pickup_type":
		var new_type = value
		if new_type == PickupType.Ability or new_type == PickupType.Heal:
			if rarity == 0:
				rarity = 1
		if not override_price:
			_update_price()
		return true
	elif property == "rarity":
		if pickup_type == PickupType.Ability or pickup_type == PickupType.Heal:
			if value < 1:
				value = 1
		rarity = value
		if not override_price:
			_update_price()
		return true
	elif property == "override_price":
		override_price = value
		if not value:
			_update_price()
		return true
	elif property == "price":
		if override_price:
			price = value
			return true
		else:
			return true
	return false

func _get(property: StringName):
	if property in KEYWORD_OPTIONS:
		return property in keywords
	return null


func _validate_property(property: Dictionary):
	# buff 配置仅在能力卡时显示
	if property.name in ["buff_icon", "buff_icon_size", "buff_font_size"]:
		if pickup_type == PickupType.Ability:
			property.usage = PROPERTY_USAGE_DEFAULT
		else:
			property.usage = PROPERTY_USAGE_NONE
	# 价格字段根据 override_price 切换可编辑状态
	if property.name == "price":
		if override_price:
			property.usage = PROPERTY_USAGE_DEFAULT
		else:
			property.usage = PROPERTY_USAGE_READ_ONLY
	# 隐藏原始 keywords 数组，防止直接编辑
	if property.name == "keywords":
		property.usage = PROPERTY_USAGE_NONE

func _update_price():
	_updating_price = true
	var base_price = 0
	var variance = 0
	match rarity:
		0:
			base_price = 20
			variance = 3
		1:
			base_price = 35
			variance = 5
		2:
			base_price = 50
			variance = 7
	price = randi_range(base_price - variance, base_price + variance)
	_updating_price = false
