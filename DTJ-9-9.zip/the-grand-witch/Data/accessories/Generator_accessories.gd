extends Resource
class_name Generator_accessories

enum PickupType {
	Health,
	AttackPower,
	WitchPower,
	TakeDamage,
	SkillReload,
	BlockCharges,
}

@export_group("道具配置")
@export var acc_id : int
@export var pickup_type : PickupType = PickupType.AttackPower
@export var name : String
@export var icon : Texture2D
@export var Tooltip : String = ""
@export var tooltip_font_size : int = 14

@export_group("道具效果")
@export var attack_bonus : int = 0
@export var heal_amount : int = 0
@export var damage_amount : int = 0
@export var witch_amount : int = 0
@export var skillreload_amount : int = 0
@export var block_charges : int = 0
@export var max_health_bonus : int = 0

@export_group("稀有度")
@export var rarity : int = 0   # 0=普通, 1=稀有, 2=史诗

@export_group("价格")
@export var override_price : bool = false
@export var price : int = 0

var _updating_price := false

func _init():
	# 如果价格无效且未手动覆盖，则自动生成
	if not override_price and price == 0:
		_update_price()

func _validate_property(property: Dictionary):
	if property.name == "price":
		if override_price:
			property.usage = PROPERTY_USAGE_DEFAULT
		else:
			property.usage = PROPERTY_USAGE_READ_ONLY

func _set(property: StringName, value):
	if _updating_price:
		return false

	if property == "rarity":
		rarity = value
		if not override_price:
			_update_price()
		return true
	elif property == "override_price":
		override_price = value
		if not value:
			_update_price()
		return true
	elif property == "price":
		if override_price:
			price = value
			return true
		else:
			return true
	return false

func _update_price():
	_updating_price = true
	var base_price = 0
	var variance = 0
	match rarity:
		0:
			base_price = 60
			variance = 3
		1:
			base_price = 105
			variance = 5
		2:
			base_price = 150
			variance = 7
	price = randi_range(base_price - variance, base_price + variance)
	_updating_price = false
