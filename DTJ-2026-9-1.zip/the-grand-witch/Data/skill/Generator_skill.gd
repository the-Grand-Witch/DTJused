extends Resource
class_name Generator_skill
#声明
enum SkillType {
	name,
	ATTACK_BOOST_BY_WITCHPOWER,
}
#分组
@export_group("技能配置")
@export var Skill_type: SkillType = SkillType.name
@export var display_name: String = "skill"      
@export_group("技能效果")     
@export var JXLSkill = SkillType.ATTACK_BOOST_BY_WITCHPOWER
@export var cooldown: float = 0.0
@export var duration: float = 0.0 
@export_group("显示资源")
@export var icon_textrue:Texture2D 
