#不喜欢空着
extends Control
func _ready():
	$Icon.texture = load("res://Assets/Textures/Cards/YellowCell.png")
	$Icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
func trigger_effect():
	print("this shop")    #没实现所以只有文本输出
