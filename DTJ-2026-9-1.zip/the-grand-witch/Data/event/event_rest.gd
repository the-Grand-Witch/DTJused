extends Control
func _ready():
	$Icon.texture = load("res://Assets/Textures/Icons/Blood.png")
	$Icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
func trigger_effect():
	GlobalPlayer.heal(50)   #调用全局玩家例的heal方法，数值为50
