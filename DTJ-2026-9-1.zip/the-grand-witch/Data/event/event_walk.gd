extends Control
func _ready():
	$Icon.texture = load("res://Assets/Textures/Icons/SideWay.png")
	$Icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
func trigger_effect():
	GlobalScenes.event_manager.refresh_all_cards()    #调用全局例方法，刷新所有卡牌
