extends Control
func _ready():
	$Icon.texture = load("res://Assets/Textures/Icons/Dig.png")
	$Icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
func trigger_effect():
	print("this dig")   #没实现所以只有文本输出
