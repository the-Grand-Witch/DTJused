#所有card卡牌格式是一样的，所以我只写一遍
extends Control
#卡面资源调用
func _ready():
	$Icon.texture = load("res://Assets/Textures/Monsters/Owl.png")
	$Icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
#卡牌效果调用，方法一定要是trigger_effect（后续缩写为FE）
#写不下就用这个FE调用别的，因为cardmanaeger只会调用这个方法
func trigger_effect():
	GlobalScenes.enter_battle()
