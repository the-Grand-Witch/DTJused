extends Node
#恭喜你来到了第二麻烦的代码，随机事件生成，为了保证可拓展性每一个定义都是一个变量
#放轻松，这才是开始
#事件来源Card.tscn
const CARD_SCENE = preload("res://scenes/event.tscn")
#加载子节点容器option
@onready var option_nodes = [$OptionA, $OptionB, $OptionC]
#加载节点启用时间流逝
@onready var time_manager = $"../TimeDisplay"
#定义卡牌变量组，作为全局变量容器
var cards = {}
#那么，我们开始把 -25
func _ready():
	GlobalScenes.event_manager = self
	randomize()     #随机数生成
	for btn in option_nodes:    #循环为容器加载事件
		btn.pressed.connect(_on_option_pressed.bind(btn))  #按钮信号绑定点击并执行方法
		_create_card(btn)     #执行字典方法
#这是字典方法的内容
func _create_card(btn):
	if cards.has(btn):        #确定卡牌是否存在
		var old_card = cards[btn]      #定义旧卡牌
		cards.erase(btn)                   #从字典删除  
		old_card.queue_free()             #删除旧的
	var card = CARD_SCENE.instantiate()    #生成新卡
	btn.add_child(card)                    #加载节点
	btn.flat = true                        #隐藏边框
	btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND   #改变鼠标ui
	card.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)   #设定卡牌形状为拉伸覆盖
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE                 #设定穿透，不予卡牌交互，与下面的按钮交互
	_recursive_setup(card)                #执行递归方法，重复图像覆盖，可能会改
	var events = card.get_node("Card").get_children()    #从card中寻找事件，并获取节点
	var chosen = events[randi() % events.size()]        #选一个作为选项
	for e in events:        #只显示选中的事件
		e.visible = (e == chosen)          
	card.set_meta("event", chosen.name)     #获取名字，用作时间管理器
	card.set_meta("active_event_node", chosen)  #获取方法，执行时间
	cards[btn] = card    #卡牌映射，联动字典和按钮
#上文说的递归方法
func _recursive_setup(node):
	if node is Control:    #修改卡牌形状
		node.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		node.mouse_filter = Control.MOUSE_FILTER_IGNORE    
	if node is TextureRect:       #修改图像形状
		node.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		node.stretch_mode = TextureRect.STRETCH_SCALE
	for child in node.get_children(): #全部穿透不交互
		_recursive_setup(child)       #递归重复赋予
#点击发生时的方法
func _on_option_pressed(btn):         
	var card = cards[btn]           #取出卡牌实例
	var event_name = card.get_meta("event")      #读取名字
	var active_event = card.get_meta("active_event_node")      #读取方法
	active_event.trigger_effect()             #执行方法
	time_manager.call("do_" + event_name)       #时间流逝这个名字对应的时间单位
	_create_card(btn)           #刷新卡牌
#供外部调用的刷新卡牌
func refresh_all_cards() -> void:
	for btn in option_nodes:
		_create_card(btn)
