extends Resource
class_name BookmarkData
#书签data数据，定义名称，图像，伤害质量等等等需要调用的数据
#类比一下，菜鸟驿站，不是数据起点，也不是重点，只是为了方便存取
@export var title: String = ""
@export var icon: Texture2D
@export var pages: Array[Generator_bookpage] = []
#计算书签冷却
func get_cd() -> int:
	if pages.is_empty():
		return 0
	var total := 0
	for page in pages:
		total += page.cd
	return int(round(float(total) / pages.size()))
# 计算书签内所有书页的总伤害
func get_total_damage() -> int:
	var total := 0
	for page in pages:
		total += page.damage
	return total
# 计算总治疗量
func get_total_healing() -> int:
	var total := 0
	for page in pages:
		total += page.healing
	return total
# 计算总护甲值
func get_total_armor() -> int:
	var total := 0
	for page in pages:
		total += page.Armor
	return total
