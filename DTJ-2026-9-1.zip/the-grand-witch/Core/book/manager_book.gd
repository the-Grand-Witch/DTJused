extends Control
# 书签创建/编辑界面控制器，负责UI交互、卡牌选择、书签保存与删除
@onready var add_bookmark_button: Button = $AddBookMark               # 添加书签按钮
@onready var bookmark_name_input: LineEdit = $BookMarkName            # 书签名输入框
@onready var back_button: Button = $esc                               # 返回按钮
@onready var warning_label: Label = $WarningLabel                     # 警告提示标签
@onready var card_grid: GridContainer = $CardScroll/CardGrid          # 卡牌选择网格
@onready var selected_pages_label: Label = $SelectedPagesLabel        # 显示当前已选页面的标签
@onready var undo_button: Button = $CancelButton                      # 撤销按钮
@onready var delete_bookmark_button: Button = $DeleteBookmarkButton   # 进入删除模式按钮
@onready var delete_panel: PanelContainer = $DeletePanel              # 删除确认面板
@onready var bookmark_option: OptionButton = $DeletePanel/VBoxContainer/BookmarkOption # 选择要删除书签的下拉框
@onready var confirm_delete_button: Button = $DeletePanel/VBoxContainer/ConfirmDeleteButton # 确认删除按钮
@onready var cancel_delete_button: Button = $DeletePanel/VBoxContainer/CancelDeleteButton # 取消删除按钮
var current_bookmark: BookmarkData # 当前正在编辑的书签数据
# 初始化##别想着看懂这东西，调用的太多了，ai懂就行了，你只需要知道这里实现什么，调用什么就够
func _ready() -> void:
	add_bookmark_button.pressed.connect(_on_add_bookmark_pressed)      # 连接添加按钮
	back_button.pressed.connect(_on_back_pressed)                      # 连接返回按钮
	undo_button.pressed.connect(_on_undo_pressed)                      # 连接撤销按钮
	bookmark_name_input.max_length = 12                                # 限制书签名最多12个字
	delete_bookmark_button.pressed.connect(_on_delete_bookmark_button_pressed)      # 连接删除面板按钮
	confirm_delete_button.pressed.connect(_on_confirm_delete_pressed)  # 连接确认删除按钮
	cancel_delete_button.pressed.connect(_on_cancel_delete_pressed)    # 连接取消删除按钮
	delete_panel.visible = false                                       # 隐藏删除面板
	bookmark_name_input.alignment = HORIZONTAL_ALIGNMENT_CENTER        # 书签名居中显示
	if warning_label:
		warning_label.visible = false                                  # 隐藏警告
	current_bookmark = BookmarkData.new()                              # 初始化当前书签数据
	current_bookmark.icon = preload("res://Assets/Textures/Icons/bookmark.png") # 加载默认图标
	bookmark_name_input.text = "未命名书签%d" % (GlobalBookMark.bookmarks.size() + 1) # 自动生成默认名称
	_refresh_card_grid()                                               # 刷新卡牌选择列表
# 刷新卡牌选择网格
func _refresh_card_grid() -> void:
	for child in card_grid.get_children():
		card_grid.remove_child(child)
		child.queue_free()                                             # 清除旧卡牌按钮
	for card in GlobalCardLibrary.get_owned_cards():                   # 遍历拥有的卡牌
		var card_button := Button.new()                                # 创建新按钮
		card_button.icon = card.icon                                   # 设置图标
		card_button.expand_icon = true                                 # 图标自适应大小
		card_button.custom_minimum_size = Vector2(64, 64)              # 设置最小尺寸
		card_button.tooltip_text = card.page_name + "\n" + card.description # 鼠标悬停提示
		card_button.pressed.connect(_on_card_selected.bind(card))      # 连接点击事件，并将卡牌数据作为参数传入
		card_grid.add_child(card_button)
# 当选中一张卡牌时的逻辑
func _on_card_selected(card: Generator_bookpage) -> void:
	if current_bookmark:
		if current_bookmark.pages.size() >= 5:                         # 检查数量限制
			if warning_label:
				warning_label.text = "书签已满，无法添加更多卡牌"
				warning_label.visible = true
			return
		current_bookmark.pages.append(card)                            # 将卡牌加入当前书签
		_update_selected_pages_display()                               # 刷新已选列表
		if warning_label:
			warning_label.visible = false                              # 隐藏警告
# 撤销上一步操作
func _on_undo_pressed() -> void:
	if current_bookmark and current_bookmark.pages.size() > 0:
		current_bookmark.pages.pop_back()                              # 移除最后添加的一页
		_update_selected_pages_display()
	else:
		if warning_label:
			warning_label.text = "没有可撤销的操作"
			warning_label.visible = true
# 更新当前已选卡牌的文本显示
func _update_selected_pages_display() -> void:
	if not selected_pages_label:
		return
	var names: PackedStringArray = []
	for page in current_bookmark.pages:
		names.append(page.page_name)
	selected_pages_label.text = "\n".join(names) # 换行拼接显示
# 点击返回按钮（关闭当前界面）
func _on_back_pressed() -> void:
	if get_parent() and get_parent().has_method("_on_book_closed"):
		get_parent()._on_book_closed()
	queue_free()
	get_viewport().set_input_as_handled()
# 全局输入处理（按ESC键返回）
func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if get_parent() and get_parent().has_method("_on_book_closed"):
			get_parent()._on_book_closed()
		queue_free()
		get_viewport().set_input_as_handled()
# 点击保存书签按钮
func _on_add_bookmark_pressed() -> void:
	if GlobalBookMark.bookmarks.size() >= 6:                           # 限制全局书签总数
		if warning_label:
			warning_label.text = "已经写不下了"
			warning_label.visible = true
		return
	var bookmark_text := bookmark_name_input.text.strip_edges()        # 去除输入首尾空格
	if bookmark_text == "":
		bookmark_text = "未命名书签%d" % (GlobalBookMark.bookmarks.size() + 1) # 空名自动填充
	current_bookmark.title = bookmark_text                             # 赋予书签名
	GlobalBookMark.add_bookmark(current_bookmark)                      # 调用全局单例添加书签
	current_bookmark = BookmarkData.new()                              # 重置当前书签（准备存下一本）
	current_bookmark.icon = preload("res://Assets/Textures/Icons/bookmark.png")
	bookmark_name_input.text = "未命名书签%d" % (GlobalBookMark.bookmarks.size() + 1) # 自动生成下一个默认名
	if warning_label:
		warning_label.visible = false
	_update_selected_pages_display()
# 刷新删除面板里的下拉列表
func _refresh_bookmark_option() -> void:
	bookmark_option.clear()
	var bm = GlobalBookMark
	for bookmark in bm.bookmarks:
		bookmark_option.add_item(bookmark.title)
	if bm.bookmarks.size() == 0:
		bookmark_option.add_item("无书签")
		bookmark_option.disabled = true
	else:
		bookmark_option.disabled = false
# 点击删除按钮，显示删除面板
func _on_delete_bookmark_button_pressed() -> void:
	_refresh_bookmark_option()
	delete_panel.visible = true
# 点击取消删除按钮
func _on_cancel_delete_pressed() -> void:
	delete_panel.visible = false
# 点击确认删除按钮（执行实际删除操作）
func _on_confirm_delete_pressed() -> void:
	var selected_idx = bookmark_option.selected                        # 获取下拉框选中的索引
	if selected_idx == -1:
		if warning_label:
			warning_label.text = "未选择书签"
			warning_label.visible = true
		return
	var bookmark_data = GlobalBookMark.bookmarks[selected_idx]         # 从全局数据里获取对应书签
	GlobalBookMark.remove_bookmark(bookmark_data)                      # 调用单例移除
	delete_panel.visible = false                                       # 隐藏面板
	if warning_label:
		warning_label.text = "书签已删除"
		warning_label.visible = true
