extends Node

signal bookmark_removed(bookmark_data)
signal bookmark_added(bookmark_data)

var bookmarks: Array[BookmarkData] = []
var card_library: Array[Generator_bookpage] = []

func _ready():
	_load_card_library()
	if bookmarks.is_empty():
		_create_default_bookmarks()

# 扫描目录加载所有书页资源
func _load_card_library():
	card_library.clear()
	var dir = DirAccess.open("res://Data/BookPage/")
	dir.list_dir_begin()
	var file_name = dir.get_next()
	while file_name != "":
		if not dir.current_is_dir() and file_name.ends_with(".tres"):
			var res = load("res://Data/BookPage/" + file_name)
			if res is Generator_bookpage:
				card_library.append(res)
		file_name = dir.get_next()
	dir.list_dir_end()
	print("卡牌库加载完成，共加载页面数：", card_library.size())

# 根据 book_id 获取所有匹配的页面
func _get_pages_by_id(book_id: int) -> Array[Generator_bookpage]:
	var result: Array[Generator_bookpage] = []
	for page in card_library:
		if page.book_id == book_id:
			result.append(page)
	return result

# 创建默认书签
func _create_default_bookmarks():
	var pages_id1 = _get_pages_by_id(1)
	var pages_id2 = _get_pages_by_id(2)
	if pages_id1.is_empty() or pages_id2.is_empty():
		push_error("卡牌库中缺少必要的 book_id (1 或 2) 页面")
		return

	var bookmark_a = BookmarkData.new()
	bookmark_a.title = "书签A"
	for i in range(5):
		bookmark_a.pages.append(pages_id1[0])
	bookmarks.append(bookmark_a)

	var bookmark_b = BookmarkData.new()
	bookmark_b.title = "书签B"
	bookmark_b.pages.append(pages_id1[0])
	for i in range(4):
		bookmark_b.pages.append(pages_id2[0])
	bookmarks.append(bookmark_b)

func add_bookmark(data: BookmarkData) -> void:
	bookmarks.append(data)
	emit_signal("bookmark_added", data)

# 限制数量
func can_add_bookmark() -> bool:
	return bookmarks.size() < 6

func remove_bookmark(data: BookmarkData) -> void:
	var index = bookmarks.find(data)
	if index != -1:
		bookmarks.remove_at(index)
		emit_signal("bookmark_removed", data)
