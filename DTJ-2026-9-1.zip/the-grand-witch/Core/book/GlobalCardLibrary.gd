extends Node
# 默认已获得的基础卡牌 book_id
const DEFAULT_BOOK_IDS := [1, 2, 3]
# 全部卡牌定义（book_id -> Generator_bookpage）
var cards: Dictionary = {}
# 已获得卡牌（book_id -> Generator_bookpage）
var owned_cards: Dictionary = {}
#这是全局牌库，加载所有卡牌，显示已有卡牌
func _ready() -> void:
	_load_all_cards()
	_init_owned_cards()
# 扫描目录加载所有 .tres 卡牌资源
func _load_all_cards() -> void:
	var dir_path = "res://Data/BookPage/"
	var dir = DirAccess.open(dir_path)
	if dir == null:
		push_error("无法打开卡牌目录: " + dir_path)
		return
	dir.list_dir_begin()
	var file_name = dir.get_next()
	while file_name != "":
		if not dir.current_is_dir() and file_name.ends_with(".tres"):
			var full_path = dir_path + "/" + file_name
			var res = load(full_path)
			if res is Generator_bookpage:
				cards[res.book_id] = res
		file_name = dir.get_next()
	dir.list_dir_end()
# 初始化已获得卡牌：将 DEFAULT_BOOK_IDS 中存在的卡牌加入 owned_cards
func _init_owned_cards() -> void:
	for id in DEFAULT_BOOK_IDS:
		var card = get_card_by_book_id(id)
		if card:
			owned_cards[id] = card
# 获取所有卡牌定义（包括未获得的）
func get_all_cards() -> Array[Generator_bookpage]:
	var arr: Array[Generator_bookpage] = []
	for key in cards.keys():
		arr.append(cards[key])
	arr.sort_custom(func(a, b): return a.book_id < b.book_id)
	return arr
# 获取已获得卡牌
func get_owned_cards() -> Array[Generator_bookpage]:
	var arr: Array[Generator_bookpage] = []
	for key in owned_cards.keys():
		arr.append(owned_cards[key])
	arr.sort_custom(func(a, b): return a.book_id < b.book_id)
	return arr
# 根据 book_id 获取卡牌定义
func get_card_by_book_id(id: int) -> Generator_bookpage:
	return cards.get(id)
# 向“已获得”库添加卡牌（用于后续获得新卡牌的事件）
func add_owned_card(card: Generator_bookpage) -> void:
	if card and not owned_cards.has(card.book_id):
		owned_cards[card.book_id] = card
# 向卡牌定义库添加新卡牌
func add_card(card: Generator_bookpage) -> void:
	if card and not cards.has(card.book_id):
		cards[card.book_id] = card
