extends PanelContainer
class_name BookmarkCard
# 当卡片选中状态改变时发出的信号（参数为当前是否选中）
signal selection_changed(selected: bool)
# 获取场景中的节点引用（路径需根据实际节点树调整）
@onready var title_label: Label = $VBoxContainer/TextureRect/TitleLabel
@onready var pages_name_label: Label = $VBoxContainer/TextureRect/PagesNameLabel   
# 数据与状态变量
var bookmark_data: BookmarkData   # 存储当前卡片对应的数据
var current_cd: int = 0           # 当前剩余冷却时间
var is_selected := false          # 当前是否处于选中状态
var is_dragging := false          # 当前是否正在拖拽中
var drag_threshold := 10          # 判定为拖拽的鼠标移动像素阈值
# 视觉常量
const SELECTED_SCALE := Vector2(1.5, 1.5)  # 选中时的缩放比例
const NORMAL_SCALE := Vector2(1.0, 1.0)    # 正常时的缩放比例
const BORDER_COLOR := Color(1, 0.8, 0, 1)  # 选中时的边框颜色（金黄色）
const BORDER_WIDTH := 4                    # 边框宽度
# 样式盒与输入状态
var default_style: StyleBox                # 保存默认的Panel样式（用于恢复）
var _mouse_pressed_position := Vector2.ZERO # 记录鼠标按下时的全局位置（用于判断拖拽）
# just ready
func _ready() -> void:
	# 阻止鼠标事件穿透到下层UI
	mouse_filter = Control.MOUSE_FILTER_STOP
	# 设置缩放中心点为卡片中心，这样放大缩小不会改变位置
	pivot_offset = size / 2
	# 获取当前的默认样式，以便后续恢复
	default_style = get_theme_stylebox("panel")
# 初始化卡片的数据并更新显示
func setup(data: BookmarkData) -> void:
	bookmark_data = data
	current_cd = 0                    
	_update_cooldown_visual()
	title_label.text = data.title
	# 显示内部卡牌名称列表（每行一个）
	var names: PackedStringArray = []
	for page in data.pages:
		names.append(page.page_name)
	pages_name_label.text = "\n".join(names)
# 判断是否冷却完毕（是否可以使用）
func is_ready() -> bool:
	return current_cd <= 0
# 实现冷却（通常由主逻辑每帧或每秒调用）
func decrease_cooldown() -> void:
	if current_cd > 0:
		current_cd -= 1
		_update_cooldown_visual()
# 用不同灰度表达冷却时间
func _update_cooldown_visual() -> void:
	var gray: Color
	match current_cd:
		0: gray = Color(1, 1, 1, 1)      # 0: 正常白色
		1: gray = Color(0.7, 0.7, 0.7, 1) # 1: 浅灰
		2: gray = Color(0.5, 0.5, 0.5, 1) # 2: 中灰
		3: gray = Color(0.4, 0.4, 0.4, 1) # 3: 深灰
		_: gray = Color(0.2, 0.2, 0.2, 1) # 其他: 更深的灰
	modulate = gray # 修改整体调色板实现变暗
	# 冷却中：忽略鼠标（不可点击），冷却结束：恢复鼠标响应
	mouse_filter = Control.MOUSE_FILTER_IGNORE if current_cd > 0 else Control.MOUSE_FILTER_STOP
# 判定鼠标事件，实现点击和拖动（目前没优化好）
func _gui_input(event: InputEvent) -> void:
	# 监听鼠标左键按下/抬起
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			# 记录按下的全局位置
			_mouse_pressed_position = get_global_mouse_position()
			is_dragging = false
		else:
			# 抬起时，如果未超过拖拽阈值，则视为点击
			if not is_dragging:
				_on_clicked()
			is_dragging = false
			_mouse_pressed_position = Vector2.ZERO
	# 监听鼠标移动
	elif event is InputEventMouseMotion and _mouse_pressed_position != Vector2.ZERO:
		# 如果鼠标移动距离超过阈值，判定为开始拖拽
		if get_global_mouse_position().distance_to(_mouse_pressed_position) > drag_threshold:
			is_dragging = true
# 被点击时的逻辑
func _on_clicked() -> void:
	if not is_ready(): # 如果冷却中，禁止点击
		return
	set_selected(not is_selected)
# 统一设置选中的方法
func set_selected(selected: bool) -> void:
	if is_selected == selected:
		return
	is_selected = selected
	_update_visual()
	emit_signal("selection_changed", is_selected)
# 更新选中状态下的视觉效果（放大和加边框）
func _update_visual() -> void:
	if is_selected:
		scale = SELECTED_SCALE
		# 创建一个新的扁平样式盒并设置边框
		var style := StyleBoxFlat.new()
		style.bg_color = Color(0, 0, 0, 0) # 背景透明
		style.border_color = BORDER_COLOR
		style.set_border_width_all(BORDER_WIDTH)
		# 覆盖默认的"panel"样式
		add_theme_stylebox_override("panel", style)
	else:
		scale = NORMAL_SCALE
		# 恢复默认的"panel"样式
		add_theme_stylebox_override("panel", default_style)
# Godot内置拖拽系统：获取拖拽的数据和预览图
func _get_drag_data(at_position):
	var preview = Control.new()
	var texture_rect = TextureRect.new()
	preview.add_child(texture_rect)
	set_drag_preview(preview)
	# 返回携带卡片自身的数据，用于后面判断能否放下
	return {"card": self}
# Godot内置拖拽系统：判断是否允许丢下数据（只要携带了card数据）
func _can_drop_data(at_position, data):
	return data.has("card")
# Godot内置拖拽系统：执行放下数据的逻辑（在这里是实现排序）
func _drop_data(at_position, data):
	var target_card = data["card"]
	if target_card == self:
		return
	var parent = get_parent()
	# 确保在容器中
	if parent is Container:
		var from_index = target_card.get_index()
		var to_index = get_index()
		# 将目标卡片移动到当前卡片的位置
		parent.move_child(target_card, to_index)
		# 如果是从前面拖到后面，因为移除了一个，索引会有偏移，需要减1修正
		if from_index < to_index:
			parent.move_child(target_card, to_index - 1)
# Godot内置通知系统：监听拖拽开始和结束的系统全局通知
func _notification(what):
	if what == NOTIFICATION_DRAG_BEGIN:
		is_dragging = true # 强制标记为拖拽（防止误触点击）
	elif what == NOTIFICATION_DRAG_END:
		is_dragging = false
		_mouse_pressed_position = Vector2.ZERO
# 打出书签时调用，设置冷却为内部页面的平均 cd
func start_cooldown() -> void:
	current_cd = bookmark_data.get_cd()
	_update_cooldown_visual()
