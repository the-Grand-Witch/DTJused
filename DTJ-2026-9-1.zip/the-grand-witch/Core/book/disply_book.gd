extends Control
#主场的卡组互动都写在这里
@onready var bookmark_container: Node = $disply_bookmark
@onready var open_book_button: Button = $open
#我不想解释这些了，这个都看不懂就不用继续往下看了
const BOOK_SCENE := preload("res://scenes/book.tscn")
const BOOKMARK_CARD_SCENE := preload("res://scenes/bookmark.tscn")
var book_instance: Node = null
var selected_cards: Array[BookmarkCard] = []
var max_selected: int = 1   # 最多选择一张，可修改
#同上
func _ready() -> void:
	# 获取全局书签数据管理单例
	var bm = GlobalBookMark
	# 连接全局数据信号：当添加或删除书签时，自动刷新UI显示
	bm.bookmark_added.connect(_on_bookmark_added)
	bm.bookmark_removed.connect(_on_bookmark_removed)
	# 初始化界面显示（首次运行加载已有的书签）
	_refresh_bookmark_display()
	# 连接“打开书籍”按钮的点击信号
	open_book_button.pressed.connect(_on_open_book_pressed)
# 当有新的书签被添加时触发
func _on_bookmark_added(_data) -> void:
	_refresh_bookmark_display()
# 当有书签被移除时触发
func _on_bookmark_removed(_data) -> void:
	_refresh_bookmark_display()
func _refresh_bookmark_display() -> void:
	# 1. 清除旧节点：遍历容器中的所有子节点，先移除再释放内存，防止UI重复堆积
	for child in bookmark_container.get_children():
		bookmark_container.remove_child(child)
		child.queue_free()
	# 2. 清空选择状态：确保重建UI后，之前记录的选中卡片数组是干净的
	selected_cards.clear()   
	# 3. 如果是横向流式布局，设置负的间距，让卡片产生重叠效果（类似牌堆）
	if bookmark_container is HFlowContainer:
		bookmark_container.add_theme_constant_override("separation", -20)
	# 4. 重新构建卡片：遍历全局的书签数据，实例化卡片场景
	var bm = GlobalBookMark
	for bookmark_data in bm.bookmarks:
		var card = BOOKMARK_CARD_SCENE.instantiate()
		bookmark_container.add_child(card)
		card.setup(bookmark_data) # 将数据传给卡片，更新UI文本
		# 连接选择信号（bind(card)将当前卡片实例作为参数传入回调）
		card.selection_changed.connect(_on_card_selection_changed.bind(card))
# 处理卡片选中状态变化的逻辑（限制最大选中数）
func _on_card_selection_changed(selected: bool, card: BookmarkCard) -> void:
	if selected:
		# 如果当前选中的数量已经达到或超过上限
		if selected_cards.size() >= max_selected:
			# 取出最早选中的卡片（数组的第0个索引）
			var oldest_card = selected_cards[0]
			# 将其从数组中移除（注意：此时它还在UI上高亮）
			selected_cards.erase(oldest_card)
			# 手动调用 set_selected(false)，强制让这张旧卡片取消高亮
			# 这里会再次触发selection_changed信号，但因为它已经被移出数组了，所以不会被二次执行限制逻辑
			oldest_card.set_selected(false)   
		# 将新选中的卡片加入数组
		selected_cards.append(card)
	else:
		# 如果是取消选中，直接从数组中移除该卡片
		selected_cards.erase(card)
func _on_open_book_pressed() -> void:
	# 实例化书籍主场景
	book_instance = BOOK_SCENE.instantiate()
	if book_instance is Control:
		# 将书籍实例设置为全屏锚点（铺满父节点）
		book_instance.anchor_left = 0.0
		book_instance.anchor_top = 0.0
		book_instance.anchor_right = 1.0
		book_instance.anchor_bottom = 1.0
		book_instance.offset_left = 0
		book_instance.offset_top = 0
		book_instance.offset_right = 0
		book_instance.offset_bottom = 0
		# 阻止鼠标事件穿透，防止点击书籍时误触后面的卡片
		book_instance.mouse_filter = Control.MOUSE_FILTER_STOP
	# 将书籍实例添加到当前节点下
	add_child(book_instance)
# 供书籍场景调用，清除引用（注意：这里原代码写了两遍 `book_instance = null`，是冗余的，保留一行即可）
func _on_book_closed() -> void:
	book_instance = null
