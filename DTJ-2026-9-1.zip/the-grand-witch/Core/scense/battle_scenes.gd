extends Node
var current_monster: Generator_monster
var selected_cards: Array[BookmarkCard] = []
var max_selected: int = 1
@onready var monster_texture: TextureRect = $MonsterTexture
@onready var end_turn_button: Button = $EndTurnButton
@onready var monster_damage_label: Label = $MonsterDamageLabel
@onready var monster_health_bar: TextureProgressBar = $MonsterHealthBar
@onready var bookmark_container: HBoxContainer = $BookmarkContainer
@onready var ability_scroll: ScrollContainer = $AbilityScroll
@onready var ability_list: HBoxContainer = $AbilityScroll/AbilityList

const BOOKMARK_CARD_SCENE := preload("res://scenes/bookmark.tscn")
var all_cards: Array[BookmarkCard] = []
var previous_scene_path: String = "res://scenes/main.tscn"

# 能力卡相关变量
var player_attack_bonus: int = 0   # 攻击加成（持续整场战斗）
var used_ability_cards: Array[Generator_bookpage] = []  # 已使用的能力卡页面
#加载所有功能，都是些调用方法和链接资源
func _ready():
	previous_scene_path = GlobalScenes.last_scene_path
	load_random_monster()
	setup_monster_ui()
	create_bookmarks()
	end_turn_button.pressed.connect(_on_end_turn_pressed)
	update_ability_list()
#寻找怪物资源
func load_random_monster():
	var files = []
	var dir = DirAccess.open("res://Data/monster/")
	dir.list_dir_begin()
	var f = dir.get_next()
	while f != "":
		if f.ends_with(".tres"): files.append("res://Data/monster/" + f)
		f = dir.get_next()
	dir.list_dir_end()
	current_monster = load(files[randi() % files.size()])
#添加怪物
func setup_monster_ui():
	monster_texture.texture = current_monster.icon_textrue
	monster_health_bar.max_value = current_monster.health
	monster_health_bar.value = current_monster.health
	monster_damage_label.text = "伤害: %d" % current_monster.attack
#调整书签效果，比如选中放大，实现打出
func create_bookmarks():
	bookmark_container.add_theme_constant_override("separation", 0)
	for data in GlobalBookMark.bookmarks:
		var card = BOOKMARK_CARD_SCENE.instantiate()
		bookmark_container.add_child(card)
		card.setup(data)
		card.scale = Vector2(1.2, 1.2)
		card.selection_changed.connect(_on_card_selection_changed.bind(card))
		all_cards.append(card)
#卡牌选中方法
func _on_card_selection_changed(selected: bool, card: BookmarkCard) -> void:
	if selected:
		if selected_cards.size() >= max_selected:
			var oldest_card = selected_cards[0]
			selected_cards.erase(oldest_card)
			oldest_card.set_selected(false)
		selected_cards.append(card)
	else:
		selected_cards.erase(card)
#回合结束扳机
func _on_end_turn_pressed():    
	if selected_cards.is_empty():
		return
	# 1所有卡片冷却递减
	for card in all_cards:
		card.decrease_cooldown()
	#计算总伤害、治疗、护甲，并处理能力卡
	var total_damage = 0
	var total_healing = 0
	var total_armor = 0
	var attack_count = 0
	var total_attack_base = 0
	# 累加治疗和护甲（所有页面通用）
	for card in selected_cards:
		total_healing += card.bookmark_data.get_total_healing()
		total_armor += card.bookmark_data.get_total_armor()
		# 遍历页面，处理攻击卡和能力卡
		for page in card.bookmark_data.pages:
			if page.pickup_type == Generator_bookpage.PickupType.Attack:
				attack_count += 1
				total_attack_base += page.damage
			elif page.pickup_type == Generator_bookpage.PickupType.Ability:
				player_attack_bonus += page.attack_bonus
				used_ability_cards.append(page)
	# 总伤害 = 攻击卡基础伤害总和 + 攻击次数 × 攻击加成
	total_damage = total_attack_base + attack_count * player_attack_bonus
	# 3使用卡牌：取消选中并进入冷却
	for card in selected_cards:
		card.set_selected(false)
		card.start_cooldown()
	selected_cards.clear()
	# 4对怪物造成伤害
	if total_damage > 0:
		current_monster.health -= total_damage
		monster_health_bar.value = current_monster.health
		if current_monster.health <= 0:
			get_tree().change_scene_to_file(previous_scene_path)
			return
	#  玩家治疗
	if total_healing > 0:
		GlobalPlayer.heal(total_healing)
	# 6怪物反击
	var actual_damage = max(current_monster.attack - total_armor, 0)
	GlobalPlayer.take_damage(actual_damage)
	# 7更新能力卡显示列表
	update_ability_list()
# 更新能力卡显示列表：为每个已使用的能力卡动态添加一个 TextureRect
func update_ability_list():
	# 清空现有列表
	for child in ability_list.get_children():
		child.queue_free()
	# 为每个已使用的能力卡创建 TextureRect
	for page in used_ability_cards:
		var texture_rect = TextureRect.new()
		texture_rect.texture = page.icon
		texture_rect.custom_minimum_size = Vector2(64, 64)
		texture_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		texture_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ability_list.add_child(texture_rect)
