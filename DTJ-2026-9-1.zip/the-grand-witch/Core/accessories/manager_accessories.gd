extends Node
#你看，没实现（其实写了但效果不好，看有人弄（疑似）就删了）
func _ready():
	pass
	
