extends Node 
func _ready() -> void: 
	pass
#看，没实现（其实写了但效果不好，看有人弄（疑似）就删了）
