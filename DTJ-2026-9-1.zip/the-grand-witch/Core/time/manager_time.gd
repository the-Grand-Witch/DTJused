extends Control
# 基础时间单位与起始时间
const TIME_UNIT: int = 5
var total_minutes: int = 6 * 60
#时间显示路径
@onready var time_label: Label = $TextureRect/Label
# 获取按钮节点并连接信号
func _ready():
	update_time_display()
# 信号来源除非不同计数的时间
func do_Dig() :
	add_time_units(2)
func do_Walk() :
	add_time_units(3)
func do_Battle() :
	add_time_units(1)	
func do_Rest():
	add_time_units(6)	
func do_Shop():
	add_time_units(1)	
# 累加指定数量的时间单位
func add_time_units(units: int):
	total_minutes += units * TIME_UNIT
	update_time_display()
# 更新时间
func update_time_display():
	var hours = total_minutes / 60
	var mins = total_minutes % 60
	time_label.text = "%02d:%02d" % [hours, mins]
