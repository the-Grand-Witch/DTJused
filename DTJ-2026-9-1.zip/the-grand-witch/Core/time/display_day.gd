extends Control
# 基础天数
var day :int = 1
#时间显示路径
@onready var day_label: Label = $TextureRect/Label
#完全没做天数更新，因为目前连第一天都不会走完
func _ready():
	_update_time_display()
func _update_time_display():
	day_label.text = "%1d" % [day]
