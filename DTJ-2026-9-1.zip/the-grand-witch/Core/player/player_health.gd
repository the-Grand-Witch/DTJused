extends TextureProgressBar
@onready var player_health_bar: TextureProgressBar = self
#玩家血量代码，可扩展性不保证，因为继承定义死了，最好别碰
func _ready():
	max_value = GlobalPlayer.max_health / 2.0  # 因为 value = health/2.0
	value = GlobalPlayer.health / 2.0
	# 连接全局信号，实时更新显示
	GlobalPlayer.health_changed.connect(_on_health_changed)
#血量改变时
func _on_health_changed(new_health: int) -> void:
	value = new_health / 2.0
# 移除 _input 中的测试代码，改为正式方法（可保留但需改为使用全局数据）
func _input(event: InputEvent) -> void:
	if event.is_action_pressed("a"):
		GlobalPlayer.take_damage(50)   # 测试扣血
