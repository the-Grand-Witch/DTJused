extends Node
signal health_changed(new_health: int)
signal witch_power_changed(new_power: int)
var health: int = 200
var witch_power: int = 0
const max_health: int = 200
const max_witch_power: int = 100
#定义一些基础方法，以后直接调用全局玩家例的方法
func take_damage(amount: int) -> void:
	health = max(health - amount, 0)
	health_changed.emit(health)
#回血
func heal(amount: int = 10) -> void:
	health = min(health + amount, max_health)
	health_changed.emit(health)
#魔女化，只加了值，没深做
func possessed(amount: int = 1) -> void:
	witch_power = min(witch_power + amount, max_witch_power)
	witch_power_changed.emit(witch_power)
